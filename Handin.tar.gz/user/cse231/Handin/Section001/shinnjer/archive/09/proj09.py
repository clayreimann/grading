#This program will play the card game, Seahaven Towers.

import cardsBasic.py
import seahavenStart.py

def play(start):
    ace=1
    jack=11
    queen=12
    king=13
    for cards in foundation.equal_suit():
        if foundations=="full":
            print("WINNING")

def move_cards(cardname):
    #One card may be moved at a time
    #Cards may be placed on a higher card of the same suit, a cell or foundation

def cell(spot):
    #4 cells can each hold one card
    #Cards can be moved to and from the cells dictated by the move_cards function

def foundation(destination):
    #Cards may be placed in the foundation in ace through king order
    #Once each of the four suited foundations are full the game is over.

