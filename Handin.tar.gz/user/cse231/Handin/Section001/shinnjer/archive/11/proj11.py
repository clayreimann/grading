#This program involves a class that interacts with iGoogle map API
#The program will report distances between US cities

class Tour:
    '''Gives the distance between two US cities'''

    def __init__(self, city_x, city_y):
        city_x = input('Select a US city:')
        city_y = input('Select another US city to find the distance between:')
        self.x = city_x
        self.y = city_y

    def __distance__ (self, travel_method):
        travel_method = 'driving'
        if travel_method != 'driving' or 'bicycling' or 'walking':
            return ValueError

    def __str__(self):
        return city_x ; city_y

    def __add__(self, city_z):
        __init__.append(ciy_z)
        
    def __mul__(self):
        __add__(self, city_z)
        if value is not int:
            return TypeError

    def __rmul__ (self):
        __add__(self, city_z)
        if value is not int:
            return TypeError

    def __gt__(self, tour1, tour2):
        if int(tour1) > int(tour2):
            return True
        if int(tour1) < int(tour2):
            return False

    def __lt__(self, toura, tourb):
        if int(toura) < int(tourb):
            return True
        if int(toura) > int(tourb):
            return False

    def __eq__(self, tour1, tour2):
        if int(tour1) == int(tour2):
            return "Distances are equal"

def main():

        
