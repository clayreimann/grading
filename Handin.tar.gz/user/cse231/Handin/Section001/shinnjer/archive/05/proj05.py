#This program will produce a tessellation of hexagons.
#The user will select the color and number of hexagons per row and column.

import turtle
print("Color choices are:")
print("Red")
print("Blue")
print("Green")
print("Orange")
def get_color_choice(color):
    color_pick=input("Select a color from above (print in lower case):")
    if color_pick=="red":
        color_one="red"
    elif color_pick=="blue":
        color_one="blue"
    elif color_pick=="green":
        color_one="green"
    elif color_pick=="orange":
        color_one="orange"
    else:
        print("Color is invalid.")
        get_color_choice("color1")
    return str (color_one)
get_color_choice("color1")
get_color_choice("color2")

def get_num_hexagons(hex_num):
    hex_num=input("How many hexagons wide would you like your tessellation (between 4 and 20:")
    hex_int= int(hex_num)
    if hex_int <4:
        print("Number is too small.")
        get_num_hexagons("Num1")
    elif hex_int>20:
        print("Number is too large.")
        get_num_hexagons("Num1")
    return (hex_int)
get_num_hexagons("Num1")

def draw_hex(x,y,side_len,pen,color):
    pen=turtle
    x=0
    y=0
    hex_int=int(hex_num)
    side_len=500/hex_int
    color="color1"
draw_hex(0,0,"side_len","pen","color1")

    
    

