#A 6 digit number will be assigned the letters, "SLAYER."
#The program will test the number to see if SLAYER+SLAYER+SLAYER=LAYERS.
slay_inp=input("Enter a 6 digit number:")
slay_int=int(slay_inp)
lst=list(slay_inp)
slay=['S','L','A','Y','E','R']
lst=slay
math=slay_int+slay_int+slay_int
str_lays=str(math)
if str_lays is ['L','A','Y','E','R','S']:
   print("Correct!")
else:
    print("Number is incorrect, try again")
    
