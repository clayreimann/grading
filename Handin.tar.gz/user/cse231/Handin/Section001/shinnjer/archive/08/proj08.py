#This program will act as a text editor.
#The program can accelerate user input and eliminate common errors.

import string

def fill_completions(c_dict, fd):
    fill_input=input("Begin typing:")
    c_dict=[n, l]
    n=fill_input[n]
    l=c_dict[n]
    for word in c_dict:
        line=line.strip()
        word_list=line.split()
        for word in word_list:
            words=word.lower()
            words=word.strip(string.punctuation)
    return c_dict

def find_completions(prefix, c_dict):
    prefix=input("Enter a prefix:")
    while prefix[:2] == c_dict[:2]:
        print(c_dict)
        prefix=input("Enter a prefix:")
    if prefix[:2] != c_dict[:2]:
        print("Match was not found in dictionary.")
    if prefix == "#":
        print("Thank you for playing.")


def main_function():
    file_name=open(ap_docs.txt, 'o')
    fill_completions(c_dict, fd)
    find_completions(prefix, c_dict)
    
