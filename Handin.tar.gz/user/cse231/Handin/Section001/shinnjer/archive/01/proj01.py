rich_input=input("Richter Scale measure:")
rich_float=float(rich_input)
jou_float=10**((1.5*rich_float)+4.8)
tnt_float=jou_float/4.184e9
print("Richter Scale:", rich_float)
print("Equivalance in Joules:", jou_float)
print ("Equivalance in TNT:", tnt_float)
print ("Richter          Joules                   TNT")
print ("  1       1.995262.3149688789   0.00047687913837688307")
print ("  5       1995262314968.8828       476.87913837688404")
print (" 9.1     2.818382931264449e+18     673609687.2046962")
print (" 9.2     3.981071705534953e+18     951498973.5982201")
print (" 9.5    1.1220184543019653e+19     2681688466.3048882")
       

