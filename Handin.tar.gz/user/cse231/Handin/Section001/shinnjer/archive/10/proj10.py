#This program will draw flags from a set of stars and rectangles

import turtle

class Star:
   '''creates a 5 pointed star'''
   __init__(self, x, y, arm_length, color)
   draw(self, turtle)
   #arm length indicates the length of the star arms
   __str__(self)
      return 'star x:100, y:200, arm:50, color:green'

class Rectangle:
   '''creates rectangle for flag background and bands of the flag'''
   __init__(self, x, y, length, width, color)
   draw(self, turtle)
   #length and width indicate the dimensions of the rectangle
   __str__(self)
      return 'Rectangle x:100, y:200, width:300, height:300, color:blue'
   
class Flag:
   __init__(self, file_obj)
   file_obj=input("Select a file with a flag to be drawn:")
   draw(self, turtle)
   #Combines the stars and rectangles into a pre-selected flag design
   __str__(self)




