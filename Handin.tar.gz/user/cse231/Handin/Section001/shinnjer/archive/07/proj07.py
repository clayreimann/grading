#This program will scramble the words of a text file.
#The first and last letters of each word will be left in their place.
#User must input the file to be scrambled and the line of said file.

import random

file_name=input("Select a file to be read:")
if file_name == "hard.txt" or "easy.txt":
    my_file=open(file_name, 'r')
elif file_name != "hard.txt" or "easy.txt":
    print("Invalid file name, Try Again.")
    file_name=input("Select a file to be read:")
    my_file=open(file_name, 'r')
    

my_file=open(file_name, 'r')

file_line=input("Select a line of the selected file:")
file_num=int(file_line)

my_list=list(my_file)
my_list=random.shuffle(my_list)
print(my_list)

