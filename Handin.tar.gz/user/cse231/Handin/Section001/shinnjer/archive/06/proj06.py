#This program will data mine relevant information from a large source

import csv

def get_input_descriptor():
    file_name=input("Select a file to be used:")
    while file_name != "table.csv":
        print ("File could not be found. Try Again.")
        file_name=input("Select a valid file name.")
    return "This file contains Apple stock information."

    

def get_data_list():
    file_name=table.csv
    file_read=open(file_name, 'r')
    for line in file_read:
        my_list=line.split()
    column_input=input("Which column should be examined?")
    col_num=int(column_input)
    while col_num<1 or col_num >6:
        print("Invalid column. Try Again.")
        column_input=input("Select a valid column.")
        col_num=int(column_input)
    return (my_list[0], col_num)

def average_data():
    file_name=table.csv
    file_read=open(file_name, 'r')
    for column in file_read:
        my_list=column.split()
    for row in file_read:
        date=row[0]
    my_data=int(row[1:])
    entry=column.count()
    total=column.sum()
    data_avg=total/entry
    return data_avg, date

def main():
    get_input_descriptor()
    get_data_list()
    average_data()
    sort_list=sorted(my_list)
    return "Lowest 6"/ sort_list[:6]/"Highest 6"/ sort_list[len(sort_list):(len(sort_list-6)]
            
