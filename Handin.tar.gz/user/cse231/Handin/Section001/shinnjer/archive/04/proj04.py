#Enter two strings of letters to be compared or manipulated.
#These strings will be evaluated as DNA strands.
dna_str1=input("Enter a string of letters:")
dna_str2=input("Enter another string of letters:")
print("What do you want to do:")
print("a for add")
print("d for delete")
print("s for score")
act_str=input("q for quit:")
if act_str=='a':
    cha_str=input("Which string would you like to work with (1 or 2):")
    ind_str=input("Before which index (starting at 0):")
    if cha_str=="1":
        cha_str=dna_str1
        new_str=dna_str1[:"ind_str"]+"-"+dna_str1["ind_str":]
    if cha_str=="2":
        cha_str=dna_str2
        new_str=dna_str2[:"ind_str"]+"-"+dna_str2["ind_str":]
        
print("new_str")

if act_str=="d":
    ch_str=input("Which string would you like to work with (1 or 2):")
    in_str=input("Which index would you like to delete:")
    if ch_str=="1":
        ch_str=dna_str1
        new_stri=dna_str1[0:"in_str"]+dna_str1["in_str":]
    if ch_str=="2":
        ch_str=dna_str2
        new_stri=dna_str2[0:"in_str"]+dna_str2["in_str":]
print("new_stri")

if act_str=="s":
    

if act_str=="q":
    print("Thanks for playing.")
    

