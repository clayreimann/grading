#Enter a price of an item and the amount of money deposited for payment
#Program will give proper change and keep a running total
price_inp=input("What is the price of your item:")
price_flo=float(price_inp)
if price_flo<=0:
   print("Price must be a positive number.")
print("Please make a payment.")
pay5_int=input("How many $5 bills would you like to pay with?")
pay5_flo=float(pay5_int)
pay5_tot=pay5_flo*5.0
if pay5_tot==price_flo:
   print("Thank you for shopping!")
if pay5_tot>price_flo:
   print("Change is due.")
if pay5_tot < price_flo:
   pay1_inp=input("How many $1 bills would you like to pay with?")
   pay1_flo=float(pay1_inp)
   pay_tot=pay5_tot+pay1_flo
   if pay_tot==price_flo:
      print("Thank you for shopping!")
   if pay_tot>price_flo:
      print("Change is due.")
   else:
      pay25_inp=input("How many quarters would you like to pay with?")
      pay25_flo=float(pay25_inp)
      pay25_tot=pay25_flo*.25
      pay2_tot=pay_tot+pay25_tot
      if pay2_tot==price_flo:
         print("Thank you for shopping!")
      if pay2_tot>price_flo:
         print("Change is due.")
      if pay2_tot<price_flo:
         pay10_inp=input("How many dimes would you like to pay with?")
         pay10_flo=float(pay10_inp)
         pay10_tot=pay10_flo*.1
         pay3_tot=pay2_tot+pay10_tot
         if pay3_tot==price_flo:
            print("Thank you for shopping!")
         if pay3_tot>price_flo:
            print("Change is due.")
         if pay3_tot<price_flo:
            payn_inp=input("How many nickels would you like to pay with?")
            payn_flo=float(payn_inp)
            payn_tot=payn_flo*.05
            final_tot=pay3_tot+payn_tot
            if final_tot==price_flo:
               print("Thank you for shopping!")
            if final_tot<price_flo:
               print("Insufficent Payment.")
            if final_tot>price_flo:
               print("Change is due.")
bank5_flo=int(pay5_flo)
bank1_flo=int(pay1_flo)
bank25_flo=int(25+pay25_flo)
bank10_flo=int(25+pay10_flo)
bankn_flo=int(25+payn_flo)
print("Machine Totals")
print(bank5_flo, "Five Dollar Bills")
print(bank1_flo, "One Dollar Bills")
print(bank25_flo, "Quarters")
print(bank10_flo, "Dimes")
print(bankn_flo, "Nickels")

