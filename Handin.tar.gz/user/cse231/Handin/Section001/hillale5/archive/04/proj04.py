  ##################################################################
  #  Section 001H
  #  Computer Project #4
  #  Percentage contribution:
  #  hillale5        100%
  ##################################################################

action = ''

string_1a = input("What is the first string? ")
string_2a = input("What is the second string? ")

#I prompt the user for the strings to use.

string_1 = string_1a
string_2 = string_2a

#I set these strings to a second variable for later use

print("String 1 =", string_1a)
print("String 2 =", string_2a)

while action != 'q':

    #quit when the user enters q, and only when that happens
    
    string1_length = len(string_1)
    string2_length = len(string_2)
    
    print("What do you want to do?")
    print("       a = (add indel)")
    print("       d = (delete indel)")
    print("       s = (score)")
    print("       q = (quit)")
    print(" ")

    action = input("Your choice is: ")

    count = 0
    matches = 0
    mismatches = 0

    #these variables are used in the scoring
    
    if action == 's':

        string_1b = string_1
        string_2b = string_2

        string1b_length = len(string_1b)
        string2b_length = len(string_2b)
        
        while string1b_length > string2b_length:
            string_2b = string_2b +'-'
            string2b_length = len(string_2b)
        
        while string2b_length > string1b_length:
            string_1b = string_1b +'-'
            string1b_length = len(string_1b)

            #this adds indels to the end of the strings if one is longer than the other

        while string1b_length > count or string2b_length > count:
            if string_1b[count] == string_2b[count]:
                string_1b = string_1b[:(count)] + string_1b[count].lower() + string_1b[(count+1):]
                string_2b = string_2b[:(count)] + string_2b[count].lower() + string_2b[(count+1):]
                matches += 1
                count += 1

            elif string_1b[count] != string_2b[count]:
                string_1b = string_1b[:(count)] + string_1b[count].upper() + string_1b[(count+1):]
                string_2b = string_2b[:(count)] + string_2b[count].upper() + string_2b[(count+1):]
                mismatches += 1
                count += 1

                #this checks each character in the string. if they are the same, they
                #stay lower case. If they are different, they are displayed uppercase.

        else:
            print("Matches =",matches,"Mismatches =", mismatches)
            print("String 1 =", string_1b)
            print("String 2 =", string_2b)
            
        
    elif action == 'a':
        string_choice = input("Which string would you like to work on? ")
        index_choice = int(input("Which index would you like to add an indel before? "))
        
        if string_choice == '1':
            if string1_length < index_choice:
                print("Invalid selection. Index is not present.")
            else:
                string_1 = string_1[:index_choice] + '-' + string_1[index_choice:]            

        #this adds an indel to the string in the designated place

        elif string_choice == '2':
            if string2_length < index_choice:
                print("Invalid selection. Index is not present.")
            else:
                string_2 = string_2[:index_choice] + '-' + string_2[index_choice:]            

        #if the indel is out of range, none is added

        else:
            print("Invalid selection.")
        
    elif action == 'd':
        string_choice = input("Which string would you like to work on? ")
        index_choice = int(input("From which index would you like to delete the indel? "))
        index_help = index_choice + 1
        
        if string_choice == '1':
            if string_1[index_choice] == '-':
                string_1 = string_1[:index_choice] + string_1[index_help:]
            else:
                print("Invalid selection.")

            #this deletes whatever indel the user wants

        if string_choice == '2':
            if string_2[index_choice] == '-':
                string_2 = string_2[:index_choice] + string_2[index_help:]
            else:
                print("Invalid selection.")

            #if the choice is not an indel, it is not deleted
                
    
    elif action != "a" and action != "d" and action != "q" and action != "s":
        print("Invalid selection. Please try again.")
        print("")
        continue
    
