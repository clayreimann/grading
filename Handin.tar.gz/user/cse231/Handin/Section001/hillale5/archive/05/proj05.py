import turtle
import math
import time
import string

print("Color choices:")
print("  Red")
print("  Blue")
print("  Green")

def get_color_choice():
    while True:
        color = str(input("Which color would you like? "))

        if color != "Red" and color != "red" and color != "Blue" and color != "blue" and color != "Green" and color != "green":
            print("Invalid selection. Please choose again.")
        else:
            return color

def get_num_hexagons():
    while True:
        number0 = input("How many hexagons per row? ")

        if str.isdigit(number0) == False:
            print("Invalid selection. Please choose again.")
            
        else: 
            number = int(number0)

            if number < 4 or number > 20:
                print("Invalid selection. Please choose again.")
            else:
                return number

def draw_hexagon(x, y, side_len, pen, color):
    pen.down()
    pen.begin_fill()
    
    pen.seth(330)
    pen.forward(side_len)
    pen.seth(270)
    pen.forward(side_len)
    pen.seth(210)
    pen.forward(side_len)
    pen.seth(150)
    pen.forward(side_len)
    pen.seth(90)
    pen.forward(side_len)
    pen.seth(30)
    pen.forward(side_len)
    pen.color(color)
    pen.end_fill()
    pen.color("black")

def moveleft(side_len,pen):
    pen.up()
    pen.seth(0)
    pen.backward(side_len*math.sqrt(3))
    
def moveright(side_len,pen):
    pen.up()
    pen.seth(180)
    pen.backward(side_len*math.sqrt(3))


color1 = get_color_choice()
color2 = get_color_choice()

number1 = get_num_hexagons()
count1 = 0
count2 = 0

turtle.up()
turtle.goto(135,200)
turtle.speed(20)

while count1 < number1:
    count2 = 0
    while count2 < number1:
        draw_hexagon(0,0,216.5063/number1,turtle,color1)
        moveleft(216.5063/number1,turtle)
        count2 += 1
        if count2 == number1:
            break
        draw_hexagon(0,0,216.5063/number1,turtle,color2)
        moveleft(216.5063/number1,turtle)
        count2 += 1
        
    count1 += 1
    if count1 == number1:
        break
    
    turtle.up()
    turtle.seth(270)
    turtle.forward(325/number1)
    
    turtle.seth(0)
    turtle.forward(190/number1)
    
    count2 = 0
    
    while count2 < number1:
        draw_hexagon(0,0,216.5063/number1,turtle,color1)
        moveright(216.5063/number1,turtle)
        count2 += 1
        if count2 == number1:
            break
        draw_hexagon(0,0,216.5063/number1,turtle,color2)
        moveright(216.5063/number1,turtle)
        count2 += 1

    count1 += 1
    
    turtle.up()
    turtle.seth(180)
    turtle.forward(190/number1)
    
    turtle.seth(270)
    turtle.forward(325/number1)

time.sleep(5)
turtle.bye()


