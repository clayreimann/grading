  ##################################################################
  #  Section 001H
  #  Computer Project #10
  #  Percentage contribution:
  #  hillale5        100%
  ##################################################################


import turtle
import time

class Rectangle(object):
    def __init__(self,x,y,width,height,color):
        '''takes coordinates, size and colors as input'''
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.tag = "Rectangle"

    def __str__(self):
        return "%s x:%s, y:%s, width:%s, height:%s, color:%s" % (self.tag,self.x,self.y,self.width,self.height,self.color)

    def draw(self,turtle):
        '''draw the rectangle'''
        if turtle.pos() != (self.x,self.y):
            turtle.up()
            turtle.goto(self.x,self.y)
        if self.color:
            turtle.color(self.color)
            turtle.begin_fill()
        turtle.up()
        turtle.seth(270)
        turtle.forward(self.height/2)
        turtle.down()
        turtle.seth(0)
        turtle.forward(self.width/2)
        turtle.seth(90)
        turtle.forward(self.height)
        turtle.seth(180)
        turtle.forward(self.width)
        turtle.seth(270)
        turtle.forward(self.height)
        turtle.seth(0)
        turtle.forward(self.width/2)

#this just draws the rectangle, nothing interesting really
            
        turtle.end_fill()
        turtle.up()
        turtle.goto(0,-250)

class Star(object):
    def __init__(self,x,y,arm_length,color):
        '''takes coordinates, length of arm and colors as input'''
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color
        self.tag = "Star"

    def __str__(self):
        '''used to create the output string'''
        return "%s x:%s, y:%s, arm:%s, color:%s" % (self.tag,self.x,self.y,self.arm_length,self.color)

    def draw(self,turtle):
        '''draw the star based on the given values'''
        if turtle.pos() != (self.x,self.y):
            turtle.up()
            turtle.goto(self.x,self.y)
        if self.color:
            turtle.color(self.color)
            turtle.begin_fill()
        turtle.up()
        turtle.seth(90)
        turtle.forward(self.arm_length/2.35)
        turtle.seth(0)
        turtle.forward(self.arm_length/3.236)
        turtle.down
        turtle.forward(self.arm_length)
        turtle.seth(216)
        turtle.forward(self.arm_length)
        turtle.seth(288)
        turtle.forward(self.arm_length)
        turtle.seth(144)
        turtle.forward(self.arm_length)
        turtle.seth(216)
        turtle.forward(self.arm_length)
        turtle.seth(72)
        turtle.forward(self.arm_length)
        turtle.seth(144)
        turtle.forward(self.arm_length)
        turtle.seth(0)
        turtle.forward(self.arm_length)
        turtle.seth(72)
        turtle.forward(self.arm_length)
        turtle.seth(288)
        turtle.forward(self.arm_length)            
        turtle.end_fill()
        turtle.up()
        turtle.goto(0,-250)

#this draws the star, complicated math, but it is easy to draw as two halves


class Flag(object):
    def __init__(self,f_obj):
        '''takes coordinates, length of arm and colors as input'''
        rectangle_list = []
        star_list = []
        self.rectangle_list = rectangle_list
        self.star_list = star_list

#these lists are passed through all methods in Flag class
        
        rectangle_num = f_obj.readline()
        rectangle_num = rectangle_num.strip()
        rectangle_int = int(rectangle_num)
        self.rectangle_int = rectangle_int

#this number is passed through all methods and tells how many rectangles we need
        
        count = 0
        while count < rectangle_int:
            line = f_obj.readline()
            line = line.strip()
            line = line.split(', ')
            self.rectangle_list.append(line)
            count += 1

#we append the rectangle specifications to the rectangle list
        
        star_num = f_obj.readline()
        star_num = star_num.strip()
        star_int = int(star_num)
        self.star_int = star_int

#the same things were done to stars as were to rectangles
        
        count = 0
        while count < star_int:
            line = f_obj.readline()
            line = line.strip()
            line = line.split(', ')
            self.star_list.append(line)
            count += 1


        
    def __str__(self):
        '''used to create the output string'''
        String = 'Rectangles \n'
        count = 0
        while count < self.rectangle_int:
            String += "x:%s, y:%s, w:%s, h:%s, c:%s \n" % (int(self.rectangle_list[count][0]),int(self.rectangle_list[count][1]),int(self.rectangle_list[count][2]),int(self.rectangle_list[count][3]),self.rectangle_list[count][4])
            count += 1

        String += 'Stars \n'
        count = 0
        while count < self.star_int:
            String += "x:%s, y:%s, a:%s, c:%s \n" % (int(self.star_list[count][0]),int(self.star_list[count][1]),int(self.star_list[count][2]),self.star_list[count][3])
            count += 1

#the specifications are all added to a large multiline string and then returned

        return String

    def draw(self,turtle):
        '''draw the flag based on the given values'''
        count = 0
        while count < self.rectangle_int:
            rectangle = Rectangle(int(self.rectangle_list[count][0]),int(self.rectangle_list[count][1]),int(self.rectangle_list[count][2]),int(self.rectangle_list[count][3]),self.rectangle_list[count][4])
            rectangle.draw(turtle)
            count += 1

        count = 0
        while count < self.star_int:
            star = Star(int(self.star_list[count][0]),int(self.star_list[count][1]),int(self.star_list[count][2]),self.star_list[count][3])
            star.draw(turtle)
            count += 1

#each rectangle and star is drawn as specified 
        

def main():

    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    myFlag_file = open('myFlag.txt')
    myFlag_flag = Flag(myFlag_file)
    print(myFlag_flag)
    myFlag_flag.draw(pen)
    myFlag_file.close()

#the flag file is opened and passed into the Flag class. then it is drawn.


main()


        
        

        
