########################################################################################################
#proj 03
#section 001
#1/29/13
#Functions as a change returning vending machine for the user. Accepts deposits and returns change that
# are multiples of 5 cents.
#receives: A price followed by a deposit to pay this price
#returns: The amount of payment due, change in the form of quarters, nickels and dimes,
# the stock of the vending machine in quarters, nickels, and dimes,
# and the total amount of money in the machine as well as directions if an incorrect entry is made.
########################################################################################################


countnickel_int = 25 # the following establish the stock of the coins in the vending machine

countdime_int = 25

countquarter_int = 25

count1_int = 0

count5_int = 0 

print("Welcome to the vending machine change maker program")#prints the initialization message

print("Change maker initialized")

print("Stock contains: ")

print("25 nickels")
   
print("25 dimes")

print("25 quarters")

print("0 ones")

print("0 fives")


while True:                # establishes the continuation of the price, deposit and change giving process

    print(" ")
    
    price_str = input("Enter a purchase price (xx.xx) or 'q' to quit: ") # prompts the user to input a price


    if price_str == 'q':          # establishes a total if the user quits using the vending machine and ends the process

        totalcent_int = ((count5_int * 500) + (count1_int * 100) + (countquarter_int * 25) \
                         + (countdime_int * 10) + (countnickel_int * 5))

        totaldigdollar_int = (totalcent_int//100)

        totalnum10_int = (totalcent_int - (totaldigdollar_int * 100))

        totaldig10_int = (totalnum10_int//10)

        totaldig1_int = (totalnum10_int - (totaldig10_int * 10))

        print(" ")
        
        print("Thanks for using the magic vending machine!")

        print(" ")
        print("Total: ",totaldigdollar_int, "dollars and", str(totaldig10_int) + str(totaldig1_int), "cents") #prints the total amount in
                                                                                                              # the machine

        break


    price_float = float(price_str)    # turns the input into a floating number

    cent_float = round(price_float * 100) #turns the money value in dollars into cents

    cent_int = int(cent_float) #makes floating number an integer

    if price_float < 0 or cent_float%5 != 0:   #sets up the error message to appear if an illegal value is entered

        print (" ")

        print ("Illegal price: Must be a non - negative multiple of 5 cents")

        continue
    

    if price_float > 0 and cent_float%5 == 0: #initiates the accounting process if a valid entry is made
        
        print(" ")                           #prints the deposit menu
        print("Menu for deposits:")

        print("'n' - deposit a nickel")
        print("'d' - deposit a dime")
        print("'q' - deposit a quarter")
        print("'o' - deposit a one dollar bill")
        print("'f' - deposit a five dollar bill")
        print("'c' - cancel the purchase")
        print(" ")

     
        

           

    while cent_int>0:              #starts a loop for if the amount of the price is greater than 0

        digdollar_int = (cent_int//100)   #prepares the digits of the payment amount to be printed

        num10_int = (cent_int - (100 * digdollar_int))

        dig10_int = (num10_int//10)

        dig1_int = (num10_int - (dig10_int * 10))

        
        changenickel_int = 0 # establishes change amounts if a deposit greater than the price is entered

        changedime_int = 0

        changequarter_int = 0


        print (" ")           # prints the payment message

        print("Payment due: ", digdollar_int, "dollars and", str(dig10_int) + str(dig1_int),"cents")

        print("  ")

               
        deposit_str = input("Indicate your deposit: ") #allows the user to input a deposit


            

        if deposit_str == 'n':               #removes money owed from cent_int and adds the coin or bill added to the stock

            cent_int = cent_int - 5          # for each possible value

            countnickel_int += 1

            continue

        elif deposit_str == 'd':

            cent_int = cent_int - 10

            countdime_int += 1

            continue

        elif deposit_str == 'q':

            cent_int = cent_int - 25

            countquarter_int += 1

            continue

        elif deposit_str == 'o':

            cent_int = cent_int - 100

            count1_int += 1

            continue

        elif deposit_str == 'f':

            cent_int = cent_int - 500

            count5_int += 1
                    
            continue

        elif deposit_str == 'c':      #calculates the amount owed to be returned if the process is cancelled

            cent_int = (cent_int - int(round(price_float * 100)))

            continue

            
            
                

        else:              # ends the process if an illegal deposit value is entered                   

            print("Illegal selection: ", deposit_str)

            continue 


       


    while deposit_str == 'c' or cent_int <= 0:  # continues the process to give change if a deposit greater than the price is entered
                                                # or if the process is cancelled




        if cent_int <= -25 and countquarter_int > 0: #removes money from the stock and designates it as change

            countquarter_int -= 1                   # and decreases the negative cent value of what should be given to the user

            changequarter_int += 1                  # for each denomination

            cent_int += 25

            continue
                  

        elif cent_int <= -10 and countdime_int > 0:

            countdime_int -= 1

            changedime_int += 1

            cent_int += 10

            continue
     

        elif cent_int <= -5 and countnickel_int > 0:

            countnickel_int -=1

            changenickel_int += 1

            cent_int += 5

            continue
    

        elif cent_int == 0:         # if the deposit equals the prices ends the deposit process and prepares change return
                
            if changequarter_int == 0 and changedime_int == 0 and changenickel_int == 0:# if the deposit equals the prices ends the process
                                                                                        #and indicates no change will be returned
                print(" ")

                print("No change")

                print(" ")

                break

            elif changequarter_int != 0 and changedime_int == 0 and changenickel_int == 0: #prints the change that will be returned
                                                                                            # for each coin value
                print(" ")
                print("Please take the change below.")
                print("   ",changequarter_int, "quarters")

                print(" ")                                           #prints the stock of the machine                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break                                  # redirects to the top of the loop if true

            elif changequarter_int != 0 and changedime_int != 0 and changenickel_int == 0:
                       
                print(" ")
                print("Please take the change below.")
                print("   ",changequarter_int, "quarters")
                print("   ",changedime_int, "dimes")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break

            elif changequarter_int == 0 and changedime_int != 0 and changenickel_int != 0:

                print(" ")
                print("Please take the change below.")
                print("   ",changedime_int, "dimes")
                print("   ",changenickel_int, "nickels")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break

            elif changequarter_int != 0 and changedime_int == 0 and changenickel_int != 0:

                print(" ")
                print("Please take the change below.")
                print("   ",changequarter_int, "quarter")
                print("   ",changenickel_int, "nickels")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break

            elif changedime_int != 0 and changequarter_int == 0 and changenickel_int == 0:

                print(" ")
                print("Please take the change below.")
                print("   ",changedime_int, "dimes")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break

            elif changenickel_int != 0 and changedime_int == 0 and changequarter_int == 0:

                print(" ")
                print("Please take the change below.")
                print("   ",changenickel_int, "nickels")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break
                
            
            else:
            
                print(" ")
                print("Please take the change below.")
                print("   ",changequarter_int, "quarters")
                print("   ",changedime_int, "dimes")
                print("   ",changenickel_int, "nickels")

                print(" ")                    
                print("Stock contains: ")
                print("   ",countnickel_int, "nickels")
                print("   ",countdime_int, "dimes")
                print("   ",countquarter_int, "quarters")
                print("   ",count1_int, "ones")
                print("   ",count5_int, "fives")

                print(" ")

                break


        elif cent_int<0: #if there is not enough change in the machine to pay back the user for deposits
                         # alerts them and calculates the amount they should receive from the manager
            


            print(" ")
            print("Machine is out of change.")
            print("See store manager for remaining refund.")

            

            centend_int = -cent_int
            


            digdollarend_int = (centend_int//100)     # calculates the amount that should be received from the manager
            

            num10end_int = (centend_int - (100 * digdollarend_int))
            
            dig10end_int = (num10end_int//10)
         
            dig1end_int = (num10end_int - (dig10end_int * 10))
            
            
            print("Amount due is: ", digdollarend_int, "dollars and", str(dig10end_int) + str(dig1end_int), "cents")

            
            print(" ")                    # prints the remaining stock of the machine
            print("Stock contains: ")
            print("   ",countnickel_int, "nickels")
            print("   ",countdime_int, "dimes")
            print("   ",countquarter_int, "quarters")
            print("   ",count1_int, "ones")
            print("   ",count5_int, "fives")

            print(" ")

            break            #ends the repayment cycle

 
        

