########################################################################
#Section 01
#Project 08
#3/18/13
# Functions as a word completion program to be used in a cell
#phone or similar hardware.
# Receives: a prefix of a word, a text file from whose words 
#a completion dictionary is made and an empty completions dictionary.
# Returns: all possible words from the text file that
#can complete the prefix.
#########################################################################


def fill_completions(c_dict, fd): #a fn that will fill a completions dict of
                                    #words from the selected file

    import string    #import the string module used for error checks and punctuation remove


    key_tup_set = set()  #initiates the set of keys


    word_set = set() #initiates the set of values


    for line in fd: 


        line = line.strip()  #removes \n from lines etc.


        line_news = line.strip('<NEW DOCUMENT>') #strips/ignores the headings


        word_list = line_news.split(' ') #splits the line into a list of words
        

        for word in word_list:


            word = word.lower()  #lowercases each word


            word = word.strip(string.punctuation) #removes punctuation from outside of words
            


            for i in word:


                if i not in string.ascii_letters: #for each index in word if not

                    word = ''    # a letter removes it from the dictionary process


            word = word.strip(string.digits) #strips numbers from any words so they are not in the dictionary

            word_set.add(word) #adds each word to the value set if passes conditions
            

   
    for word in word_set:


        if int(len(word)) > 1: #if word only 1 letter not into the dictionary creation process


            key_tup_set = (set(enumerate(word))) #makes an index letter key tuple from each word

            
                            

            for key_tup in key_tup_set: #for each key


                word_set = set() #create an individual word set
                                   


                if key_tup in c_dict: #if the key is already in the dictionary


                    c_dict[(key_tup)].add(word) #add the word to its set



                else:  
                    
                    word_set.add(word) #if not in the dictionary add the word to its set


                    c_dict[(key_tup)] = word_set #creates the value in the dictionary



    fd = fd.close() #closes the file from which words are taken



def find_completions(prefix, c_dict):  #function to find possible completions


    import string    #import the string module used for error checks


    str_set = set() #return value
        

    prefix_set = set(enumerate(prefix)) #creates an index letter prefix set from prefix


    for key in c_dict:

        str_set = str_set | c_dict[key] #for each key unions the empty set and the keys


    intersection_set = c_dict.keys() & prefix_set #makes an intersection between the prefix keys
                                                #and all the keys in the dict get down to just correct keys
    


    for key in intersection_set: #for these keys containing both of the prefix keys


        str_set = str_set & c_dict[key] #makes a set that is the intersection of the words that could come
                                    #from the prefix and the all of the values in the word set


    return(str_set) #returns the set of words that has the correct possible completions
   


def main(): 


    import string     #import the string module used for error checks
    

    c_dict = dict() #creates an empty completions dictionary


    fd_obj_str = input("please select a file: ") #user input of the file from which words provide key value pairs


    fd_obj_open = open(fd_obj_str, 'r') #reads the file


    fd = fd_obj_open #opens the file


    fill_completions(c_dict, fd) #fills the completion dictionary






    quit_prefix_complete = False # the following continously asks for prefix input 


    count_try_int = 0 #with the filled completions dictionary until a quit '#"

                        #is entered


    while (not quit_prefix_complete):


        print(" ") #allows the user to select another prefix if they have not quit


        prefix = input("Please select a prefix or '#' to quit: ")

        

        if prefix == '#': #ends the process if the user chooses the quit value


            quit_prefix_complete = True


            print(" ")


            print("Thanks for using the word completion tool!")



        elif prefix.isdigit() or prefix in string.punctuation: #informs the user 


            print(" ")      #words with punctuation and numbers are ignored so


            print("This prefix has no completions.") #no word completions


            continue



        else: #if quit is not entered
            

            completion_set = find_completions(prefix, c_dict) #finds the possible word completions for the prefix


            print(" ")


            if completion_set == set():

                print("This prefix has no completions.") #print message the completions set is empty


            else:

                print(completion_set) #prints the list of possible words
            

#main() #TA  will call main?
