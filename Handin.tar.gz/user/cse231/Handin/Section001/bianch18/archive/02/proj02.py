##############################################################
#section 001
#1/21/13
#project 02
#calculates if a 6-digit number SLAYER gives 3*SLAYER = LAYERS
#receives: a 6-digit number
#returns 3*SLAYER value LAYERS value and whether the guess is correct
#incorrect or has an invalid number of digits invalid 
##############################################################

print("Guess a six-digit number SLAYER so that the following equation is true,") # displays 

print("where each letter stands for the digit in the position shown: ") #direction to the user 

print(" ")  # adds spaces in between print lines

print(" ")

print("SLAYER + SLAYER + SLAYER = LAYERS") # displays the formula

print(" ") # adds space

guess_str = input("Enter your guess for SLAYER: ") #displays the prompt

guess_int = int(guess_str) #converts the string to an int value

a_int = (guess_int*3) # caculates the value SLAYER+SLAYER+SLAYER

dig1_int = (guess_int%10) # determines the ones digit of SLAYER

num10_int = (guess_int//10) # determines the number of tens in SLAYER

dig10_int = (num10_int%10) # and so on for each digit in SLAYER

num100_int = (guess_int//100)

dig100_int = (num100_int%10)

num1000_int = (guess_int//1000)

dig1000_int = (num1000_int%10)

num10000_int = (guess_int//10000)

dig10000_int = (num10000_int%10)

num100000_int = (guess_int//100000)

dig100000_int = (num100000_int%10)

layers_int = (100000*dig10000_int) + (10000*dig1000_int) + (1000*dig100_int)\
             + (100*dig10_int) + (10*dig1_int) + (dig100000_int)     # determines LAYERS value 

if guess_int <= 99999:      # alerts the user if an invalid number of digits is entered
    print("Your guess is incorrect: ")
    print("SLAYER must be a 6-digit number")

elif layers_int != a_int:         # alerts the user if the guess is incorrect
    print("Your guess is incorrect: ")
    print("SLAYER + SLAYER + SLAYER= ", a_int) # displays the 3*SLAYER guess value
    print("LAYERS = ", layers_int) # displays the LAYERS guess value

else:
    print("Your guess is correct") # Tells the user they are right! They must be pretty smary
    print("SLAYER + SLAYER + SLAYER= ", a_int) # displays the 3*SLAYER guess value
    print("LAYERS = ", layers_int) # displays the LAYERS guess value

print("Thanks for playing!") # Thank you!
