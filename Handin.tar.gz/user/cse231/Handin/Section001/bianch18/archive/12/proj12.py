##################################################################
#Section 1
#Project 12 - Honors Project
#4/22/13
#Functions as a method to graph temperature average
# highs and lows for months and to graph temperature
# vs solar radiation for the month of june in Charleston, MO.
#Recieves: Text files containing temperature and
# solar radiation data for a number of years
#Returns: A floating bar graph of average temperature
# highs and lows and a ine graph comparing temperature
# to solar radiation
###################################################################


import matplotlib.pyplot as plt #imports necessary for string manipulation

import numpy as np #and graphing

import pylab as p

import string

month_list = [31,29,31,30,30,31,31,31,30,31,30,31] #list of days per month for avg


def get_day_temps(count_month_int, temp_file_obj):

    '''A function used to get the high and low temperatures for each day in month.
Arguments: an integer used to count to ensure its the correct month, a file containing
temperature values'''

    month_max_temp_list = []
    
    month_min_temp_list = []

    month_both_temp_list = []


    for day in range(0,month_list[count_month_int]): #for each day in the month resets list of temps

        day_temp_list = [] #looking for avg daily temp
        

        for hour in range(0,24): #for each hour this loop parses data in a line to
                                    #retrieve the desired temp data

            hour_str = temp_file_obj.readline()

  

            hour_data_str = ''

            i_count = 0

            
            


            for i in hour_str: #parses/formats into a string for programmer use

               
                
                if i.isdigit() or i == '.':
                    hour_data_str += i

                    if i == '.':
                        hour_data_str += hour_str[i_count+1]
                        break

                    elif hour_str[i_count + 1].isdigit() or hour_str[i_count + 1] == '.': #this is not what I want
                        pass
                      

                    else:
                        hour_data_str += ' '

                i_count += 1

            

            hour_data_list = hour_data_str.split(' ') #makes each readline's nonspace values a list

            

            hour_temp = hour_data_list[4] #temperature value for hour

            

            day_temp_list.append(hour_temp) #daily temperature list

           


            

        max_day_temp = max(day_temp_list) #highest day temp is max temp

        max_day_temp = float(max_day_temp)

        min_day_temp = float(min(day_temp_list)) #lowest day temp is min temp



        month_max_temp_list.append(max_day_temp) #list of all high and low temps for month

        month_min_temp_list.append(min_day_temp)



    month_both_temp_list.append(month_max_temp_list) #creates one universal list of both max

    month_both_temp_list.append(month_min_temp_list)  #and min

    

    return(month_both_temp_list) 
    




def get_temp_avg_high(month_both_temp_list, count_month_int):
    '''A function used to calculate the average high temperature
for a month. Arguments: List of high and low temps for each day in month
Integer counting to ensure only desired month data is used'''

    max_month_temp_list = month_both_temp_list[0] #the max list in the list of list

 


    avg_max_temp = ((sum(max_month_temp_list))/(month_list[count_month_int])) #sums/days in month


    return(avg_max_temp) #average high for the month


def get_temp_avg_low(month_both_temp_list, count_month_int):
    '''A function used to calculate the average low temperature
for a month. Arguments: List of high and low temps for each day in month
Integer counting to ensure only desired month data is used'''

    
    low_month_temp_list = month_both_temp_list[1] #pulls out min list from list of lists

    avg_low_temp = ((sum(low_month_temp_list))/month_list[count_month_int]) #sum temps/days in month

    return(avg_low_temp) #avg low for month


def get_hour_solar_rad(solar_rad_file_obj):
    '''A function used to get the solar radiation values for each hour in a
selected month of june. Arguments: a file object containing solar radiation data'''

    val_rad = 0 #initial hourly solar radiation value

    rad_dict = dict() #dictionary in which to enter key: hr, value: solar radiation

    for hour in range(0,744): #goes through each hour of month of june

    
        rad_str = solar_rad_file_obj.readline() #reads an hour data line

        i_count = 0

        rad_data_str = ''

        

        for i in rad_str: #makes line into a string of the values

          
                
            if i.isdigit() or i == '.':
                
                rad_data_str += i


                if rad_str[i_count + 1].isdigit() or rad_str[i_count + 1] == '.': #keeps # and .
                    pass
                    

                else:
                    rad_data_str += ' '

            i_count += 1

           

        rad_data_list = rad_data_str.split(' ') #makes the values in the string a list

     

        cur_val_rad = int(rad_data_list[4]) #the current radiation value

        key_rad_time = rad_data_list[3] #the time of the reading


        if key_rad_time in rad_dict: #if the time is in the dictionary

            rad_dict[(key_rad_time)] += cur_val_rad #current radiation values are added to all previous

        else:
            rad_dict[(key_rad_time)] = cur_val_rad #if not a new key value pair is made


    return(rad_dict) #the dictionary of each hour and its total solar radiation over june


def get_solar_rad_avg(rad_dict):
    '''A function used to get the average solar radiation of each hour in the
month of june. Arguments: a dictionary containing each hour and its total
solar radiation over the month'''

    avg_rad_dict = dict() #an empty dictionary to hold avg rad as a value, hr as key

    for key in rad_dict: #for each hour

        avg_rad_dict[key] = ((float(rad_dict[(key)]))/31) #total radiation/# days june


    return(avg_rad_dict) #returns avg radiation


def get_hour_june_temp(temp_file_obj):
    '''A function used to get the temperature value sum for each hour
in the days of the month of june. Arguments: a file containing temperature
values for each hour in the year'''

    val_temp = 0 

    temp_dict = dict() 

    for hour in range(0,744): #a loop to read each hours data in june

    
        temp_str = temp_file_obj.readline()

        i_count = 0

        temp_data_str = ''

        

        for i in temp_str: #a for loop similar to the previous to make each line into a formatted 
                            #string
              
                
            if i.isdigit() or i == '.':
              
                temp_data_str += i



                if temp_str[i_count + 1].isdigit() or temp_str[i_count + 1] == '.': #ignores all but
                    pass         #numbers and .
                  

                else:
                   
                    temp_data_str += ' '

            i_count += 1

         

        temp_data_list = temp_data_str.split(' ') #makes the string of values a list

     

        cur_val_temp = float(temp_data_list[4]) #withdraws the hours temperature

        key_temp_time = temp_data_list[3] #withdraws the time


        if key_temp_time in temp_dict: #if the time is in dictionary adds the temp value

            temp_dict[(key_temp_time)] += cur_val_temp #to previous to get total temp for that hour over the month

        else: #adds the time as a key if its not there
            temp_dict[(key_temp_time)] = cur_val_temp


    return(temp_dict) #dict with key hour, value total sum temperature


def get_june_temp_avg(temp_dict):

    '''A function to get the average temperature for each hour in the month
of june. Argument: a dictionary of each hour with total sum temperature'''

    avg_temp_dict = dict() #dictionary to store avg temps

    for key in temp_dict: #for each hour

        avg_temp_dict[key] = ((float(temp_dict[(key)]))/31) #avg= total temp/ # days


    return(avg_temp_dict) #dictionary key: hour, value: avg temp



def main():

    '''A main function to draw both graphs and run functions to get
necessary data'''

    fin_avg_max_list = []

    fin_avg_min_list = []

    temp_file_obj = open('temperature.txt', 'r') #opens the file

    useless_str = temp_file_obj.readline() #reads the unused label lines

    other_useless_str = temp_file_obj.readline()



    year_max_temp_list = []

    year_min_temp_list = []




    for count_month_int in range(0,12): #for each month gets lists avg highs and lows to big list
        
        
        month_both_temp_list = get_day_temps(count_month_int, temp_file_obj) #uses get day temps
       


        avg_max_temp = get_temp_avg_high(month_both_temp_list, count_month_int) #gets the avg high 

        fin_avg_max_list.append(avg_max_temp) #appends to avg high list


        avg_low_temp = get_temp_avg_low(month_both_temp_list, count_month_int) #gets avg low

        fin_avg_min_list.append(avg_low_temp) #appends to list




    bar_top_list = fin_avg_max_list #avg max_list

    bar_bot_list = fin_avg_min_list #avg min_list

    temp_file_obj = temp_file_obj.close()


    #for graph float bar

    y_list = [] #list for y values

    barfig = p.figure() #selects pylab to make figure

    ax1 = barfig.add_subplot(1,1,1) #creates a plot to draw figure

    N = len(fin_avg_max_list) #makes the number x values the number of values in list

    ind = range(N) #will center bars at x values

    k = [bar_bot_list[0], bar_bot_list[1], bar_bot_list[2], bar_bot_list[3], bar_bot_list[4], bar_bot_list[5], bar_bot_list[6], bar_bot_list[7], bar_bot_list[8], bar_bot_list[9], bar_bot_list[10], bar_bot_list[11]]

    #above finds the bottom of each bars value

    for val in range(0,12): #for each month in the year finds the y value as a length avg max temp - avg min

        y = float(bar_top_list[val]) - float(bar_bot_list[val])

        y_list.append(y)

    #below is list of y values

    y = [y_list[0], y_list[1], y_list[2], y_list[3], y_list[4], y_list[5], y_list[6], y_list[7], y_list[8], y_list[9], y_list[10], y_list[11]]
        
    ax1.bar(ind,y,bottom =k,align='center', width=0.5) # bar graph bars centered at x width 0.5, floating

    ax1.set_ylabel('Average Temp') #y axis label

    ax1.set_title('Charleston, MO - 2012') #title

    ax1.set_xticks(ind) #centers ticks on bars, below are month labels

    group_labels = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december']

    ax1.set_xticklabels(group_labels) #orients and fits months

    barfig.autofmt_xdate()

    p.show() #shows and saves the graph

    barfig.savefig('temp.png')

    p.close()
    
    
    
    #for line comparison graph

    temp_file_obj = open('temperature.txt', 'r') #reopens temp file

    useless_str = temp_file_obj.readline() #gets out useless lines

    other_useless_str = temp_file_obj.readline()


    for temp_month in range(1,3648): #reads and discards lines all the way up to june but sees temps
        temp_str = temp_file_obj.readline()

        temp_month = temp_str[7] 
    

    june_temp_dict = get_hour_june_temp(temp_file_obj) #finds all of the hourly temperatures in june


    avg_june_temp_dict = get_june_temp_avg(june_temp_dict) #finds average hourly temps in june


    #now onto solar radiation
    
    solar_rad_file_obj = open('solar_radition.txt', 'r') #QP I had to change m2 to m^2 so python could read file

    useless_str = solar_rad_file_obj.readline() #reads and ignores useless strings

    useless_str = solar_rad_file_obj.readline()

    useless_str = solar_rad_file_obj.readline()

    useless_str = solar_rad_file_obj.readline()

    rad_str = solar_rad_file_obj.readline()

  


    rad_month = int(rad_str[7]) #sets initial starting day in the year

    rad_data_str = ''

    i_count = 0
            
    for rad_month in range(1,3648): #number of lines hours that must be read to reach june
        rad_str = solar_rad_file_obj.readline()

        rad_month = rad_str[7] #finds solar rad but does not use later





    rad_dict = get_hour_solar_rad(solar_rad_file_obj) #finds the hourly solar radiation data for june

    avg_rad_dict = get_solar_rad_avg(rad_dict) #finds average hourly solar rad data


    #now for the second line comparison graph of avg hourly temp in june to avg hourly solar rad

    x_one_list = []

    y_one_list = []

    line_fig = p.figure() #tells pyplot to initiate figure drawing

    ax1 = line_fig.add_subplot(1,1,1) #initialize plit

    ind = range(0,24) #there will be 24 x values needed

    

    for key in avg_june_temp_dict: #for each key which is an hour in the avg temp dict

        key = float(key) #makes hour a float

        x_one_list.append(key) #appends keys to a list

        x_one_sort_list = sorted(x_one_list) #sorts them to start at 1am and go to midnight

        

    for val in x_one_sort_list: #for each value gets it back to key form

        val = str(int(val))

        y_one_list.append((avg_june_temp_dict[val])) #pulls out the hourly average temp1 value

    



    for value in range(0,24): #for each hour makes the hour value for the axis label into a 1-2 digit #

        x_one_sort_list[value] = (float(x_one_sort_list[value])/100)


    #x values entered in x below, y value in y

    x = [x_one_sort_list[0], x_one_sort_list[1], x_one_sort_list[2], x_one_sort_list[3], x_one_sort_list[4], x_one_sort_list[5], x_one_sort_list[6], x_one_sort_list[7], x_one_sort_list[8], x_one_sort_list[9], x_one_sort_list[10], x_one_sort_list[11], x_one_sort_list[12], x_one_sort_list[13], x_one_sort_list[14], x_one_sort_list[15], x_one_sort_list[16], x_one_sort_list[17], x_one_sort_list[18], x_one_sort_list[19], x_one_sort_list[20], x_one_sort_list[21], x_one_sort_list[22], x_one_sort_list[23]]

    y = [y_one_list[0], y_one_list[1], y_one_list[2], y_one_list[3], y_one_list[4], y_one_list[5], y_one_list[6], y_one_list[7], y_one_list[8], y_one_list[9], y_one_list[10], y_one_list[11],y_one_list[12], y_one_list[13], y_one_list[14], y_one_list[15], y_one_list[16], y_one_list[17],y_one_list[18], y_one_list[19], y_one_list[20], y_one_list[21], y_one_list[22], y_one_list[23]]
        
    


    ax1.plot(x,y, marker = 'o', color='b') #plots the points on the graph

    ax1.plot(x,y, linestyle = '-', color='b') #plots the line through the points to the graph 

    ax1.set_ylabel('Average Temp', color ='b') #y axis label

    ax1.set_title('Charleston, MO - 2012') #title

    ax1.set_xlabel('Hour') #x axis label

    ax1.set_xticks(ind) #centers and sets hours as x tick labels

    group_labels = x

    ax1.set_xticklabels(group_labels)

    for t1 in ax1.get_yticklabels(): #makes each tick label blue on the y axis
        t1.set_color('b')


    #now for list of solar rad as y 

    y_two_list = [] #sets y list empty

    ax2 = ax1.twinx() #using same x's for the plot


    for val in x_one_sort_list: #for each hour value get it back into original key form

        y_two_list.append(float(avg_rad_dict[str(int(val*100))])) #find solar rad value and append to list of ordered values


    #below are ordered solar rad values for y values in graph    

    y_two = [y_two_list[0], y_two_list[1], y_two_list[2], y_two_list[3], y_two_list[4], y_two_list[5], y_two_list[6], y_two_list[7], y_two_list[8], y_two_list[9], y_two_list[10], y_two_list[11], y_two_list[12], y_two_list[13], y_two_list[14], y_two_list[15], y_two_list[16], y_two_list[17], y_two_list[18], y_two_list[19], y_two_list[20], y_two_list[21], y_two_list[22], y_two_list[23]]


    #graphing process

    ax2.plot(x, y_two, marker='o', linestyle='-', color='r') #graphs the data points in red and draws a line through them

    ax2.set_ylabel('Average Solar Radiation', color='r') #right side solar rad label

    for t2 in ax2.get_yticklabels(): #makes each tick label on right red
        t2.set_color('r')

    line_fig.autofmt_xdate() #orients the labels

    p.show() #shows and saves a figure of the graph

    line_fig.savefig('temp and solar rad.png')

    #p.close() #can be used to close the figure


main()




