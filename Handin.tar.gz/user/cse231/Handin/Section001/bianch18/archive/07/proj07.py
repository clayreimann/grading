#########################################################################
#Section 01
#Project 07
#3/11/13
#Functions as a word scrambling tool for text documents etc.
#receives: A file to be opened and read,  and
# a file to be written to
#returns: A file with a sample of text with words scrambled
# that is with their interior letters scrambled but with the first
# and last letters and punctuation in the same place
########################################################################



def scramble_word(word_str): #function to scramble individual words

    import random #imports the module to allow randomized shuffling

    import string # imports the module to distinguish punctuation


    scramble_list = [] #list of letters to be scrambled

    punctpos_list = [] #stores punctuation character position
        
    punctchar_list = [] #stores punctuation character

    count_int = 0 # count to track punctuation char position



    if int(len(word_str)) < 4: # if word less than 4 long doesn't need shuffle

        string = word_str


    else:


        for char in word_str: #for each letter in word


            if char in string.punctuation: #check if its punctuation

                punctchar_list.append(char) #append to special list


                punctpos_list.append(count_int) # and position


                count_int += 1



            else: #append the letter to list of letters to be scrambled
                scramble_list.append(char)

                count_int += 1

        

        last_list = [] #to store last letter of word


        string_list = []


        scramble_str = ''.join(scramble_list) #transforms scramble list to str


        string_list.append(scramble_str[0]) #maintains first letter position


        last_list.append(scramble_str[-1]) #stores last letter


        last_str = ''.join(last_list) #makes it a string


        scramble2_list = list(scramble_list[1:-1]) #list of middle letters to scramble

        

        random.shuffle(scramble2_list) #scrambles the list


        scramble2_str = ''.join(scramble2_list) #makes the list a str


        string_list.append(scramble2_str) #appends the str to a new list with the first char in beginning


        string_list.append(last_str) #appends the last char to end after the scramble

      

        string = ''.join(string_list) #makes the list a string of the scrambled word w/o punctuation


        string_list = list(string) #makes the string a list


        countinsert_int = 0 #count of where to insert punctuation



        for char in punctchar_list: #puts punctuation back in rightful place in word

            string_list.insert((punctpos_list[countinsert_int]), char)


            countinsert_int += 1



        string = ''.join(string_list) #makes the list of letters with punctuation into
        
                                        #into a string of scrambled word    

    return(string) #returns the string of the scrambled word




def scramble_line(line_str): #for each line in the text doc puts words through 


    string = ''   #scramble word


    list_of_words = line_str.split(" ")  #distinguishes words by space separating them



    for word in list_of_words: #for each word in the line

        word_str = word

        
        newstring_str = scramble_word(word_str) #puts the word through scramble


        string = string + newstring_str + ' ' #adds it to a new string of scrambled words


    return(string) #returns of string that is a line of scrambled words




def open_read_file(file_name_str): #Got this from Punch, might need to chng       

    opened_file_bool = False #sets the boolean as false until the file is opened

    count_try_int = 0


    while (not opened_file_bool): #loop to repeatedly ask for input

        try:


            if count_try_int < 1: #tries the initial entry


                count_try_int += 1


                input_file_name_str = file_name_str 


            input_file_obj = open(input_file_name_str) #opens the file


            opened_file_bool = True #if the file is opened changes boolean to true makes
                                    #loop exit
            

        except IOError: # catch for IOerror if file chosen not available


            print("Bad file name, try again")


            input_file_name_str = input("Open what file to read: ") #user input correction
       


    else:                              #as loop is exited renames file obj and returns filename and

        file_object = input_file_obj   #opened file


        return(file_object)



def main(): #do specs and must get from entire txt to single line somewhere
    

    output_file_object = input("Choose a file to write: ") # file user wants to write to


    file_name_str = input("Open what file to read: ") #asks for user input of file to be read


    file_object = open_read_file(file_name_str)    #sets the file object as the file to be read


    file_obj_str = file_object.read() #reads the input file object

  

    list_of_lines = file_obj_str.split('  ') #splits txt by line

    out_file_obj = open(output_file_object, "w") # write mode for output file object



    for line in list_of_lines: #for each line puts through scramble line fn

        
        line_str = line 


        scramble_line_str = scramble_line(line_str)


        scrambled_line_str = scramble_line_str 


        out_file_obj.write(scrambled_line_str + '\n') #writes each scrambled line and carriage return line feed

        
    out_file_obj.close() #closes the file

    
        
       

    #main() TA will do


