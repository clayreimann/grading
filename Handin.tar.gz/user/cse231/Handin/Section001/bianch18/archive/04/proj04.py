#########################################################################
#Section 001
#project 04
#2/4/13
#Functions as a sequence alignment program for bases of DNA. Accepts
# any letter to represent a base.
#receives: two strings of nucleic acid bases and the entry or deletion
# of indels.
#returns: The the number of matches and mismatches between the two
# strings.
#########################################################################

one_str = input("string 1: ")  # Allows the user to input two chains of

two_str = input("string 2: ")  # nucleic acid bases.

print(" ")  # adds space

while True:        #Initiates a loop compare strings or add or delete indels 

    one_str = one_str.lower() #ensures that strings are lower case even if

    two_str = two_str.lower() #previous mismatches existed


    print("What do you want to do:")           # prints the selection menu

    print("                       ", "a", "(add indel)")

    print("                       ", "d", "(delete indel)")

    print("                       ", "s", "(score)")

    print("                       ", "q", "(quit)"),

    selection_str = input("Enter your selection: ") #allows the user to input a

    print(" ")                                      #selection

    

    if selection_str == 'a': #intiates a command series to add an indel
                                                  
        choice_str = input("Work on which string (1 or 2): ") 

        if choice_str == '1':    

            position_int = int(input("Before what index: ")) #allows input for indel position

            if position_int >= len(one_str): #alerts the user to an error if the 

                print("Error: Index not in string") #user tries to insert outside the chain

            else: # adds an indel after the position specified

                one_str = str(one_str[:(position_int)] + '-' + one_str[(position_int):]) 

                print(one_str)
            

        elif choice_str == '2': #mirrors the process if an indel is added in

            position_int = int(input("Before what index: ")) #string two

            if position_int >= len(two_str):

                print("Error: Index not in string")

            else:

                two_str = str(two_str[:(position_int)] + '-' + two_str[(position_int):]) 

                print(two_str)
            
                                   

    elif selection_str == 'd': # initiates a command process to delete indels

        choice_str = input("Work on which string (1 or 2): ") 

        if choice_str == '1':

            position_int = int(input("Delete what index: ")) #user choice of indel to be deleteed

            if str(one_str[position_int]) != '-': #alerts of an error if the object in the 

                print("Error: object other than indel deleted") #chosen index isn't an indel

            else: #removes the position index occupied by the indel from the string

                one_str = str(one_str[:position_int] + one_str[(position_int + 1):])

                print(one_str)
            

        elif choice_str == '2': #repeats the above process is string two is chosen
            
            position_int = int(input("Delete before what index: "))

            if str(two_str[position_int]) != '-':

                print("Error: object other than indel deleted")

            else: 

                two_str = str(two_str[:position_int] + two_str[(position_int + 1):])

                print(two_str)
            


    elif selection_str == 's':  #initiates the command process to score two strings 


        countmatch_int = 0 #starts counts for matches and mismatches

        countmismatch_int = 0

        index_int = 0 #as well as the index being read for matching

        i_str = str(one_str[0]) #intiates the comparison variable for string 1

     

        j_str = str(two_str[0]) #intiates the comparison variable for string 2

        
        

        while len(one_str) < len(two_str): # adds indels to even out string lengths 

            one_str = one_str + '-' # if string 1 is less than string 2

            continue

        while len(two_str) < len(one_str): # adds indels to even out string length

            two_str = two_str + '-' # if string 2 is less than string 1

            continue

      
        

        while ((index_int + 1) <= len(one_str)) and ((index_int + 1) <= len(two_str)): # intiates a 

            i_str = str(one_str[index_int]) #while loop to compare/score string 1 and 2 until each

            j_str = str(two_str[index_int]) #index has been gone throug

            

            
            if (i_str != j_str) or (i_str == '-') or (j_str == '-'): #if the i variable doesn't equal                 

                countmismatch_int += 1 # j variable or if an indel is present counts a mismatch and                                


                i_str = i_str.upper() # capitalizes the objects in question


                one_str = one_str[0:index_int] + i_str + one_str[(index_int + 1):] #creates a new string

            
                j_str = j_str.upper() #with the capitalized objects included


                two_str = two_str[0:index_int] + j_str + two_str[(index_int + 1):]

               
                index_int += 1 #increases the index variable for each time the loop is gone through

       
            


            elif i_str == j_str: # if the i variable is the same to the j variable

                countmatch_int += 1 # adds one to the number of matches

                index_int += 1 #increases the index variable for each time the loop is gone through

              

                
            continue                                                  
                    

        print("Matches: ", countmatch_int, "Mismatches: ", countmismatch_int) # prints matches a mismatches

        print(one_str) # displays both of the strings

        print(two_str)

        print(" ")
            

    elif selection_str == 'q': # if the user chooses to quit displays a thank you and exits

        print("Goodbye. Thanks for using the Sequence Alignment Program")

        break
    
   


            
                                                  
