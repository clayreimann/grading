##################################################################
#Section 01
#Project 11
#4/15/13
#A program that uses the google map api and urllib to present data about tours between cities
# of driving, walking, and biking in terms of distance covered, equality, and other mathematical
# operations such as addition and multiplication
#Receives: A tour string to be entered in the url to be transmitted through google API
# using the url library
#Returns: Data regarding to a user created tour or relating two user created tours
####################################################################



import urllib.request #imports to withdraw, transmit filter data from google API

import string




class Tour(object):
    '''Class of Tours - that is trips from one city to multiple other cities, either walking
driving or biking.'''
    



    def __init__(self, *city_str):
        '''Method to create an instance of a tour. Argument a string/tuple of cities of which
the tour consists'''

        

        if type(city_str[0]) == tuple: #checks for entrance of multiple cities to make up a tour 

            city_str = city_str[0] #the city is the first component of the tuple

            
            
        self.city_str = city_str


        self.city_list = []


        self.city_list = list(self.city_str) #adds all component cities of tour to list

    
        self.num_city = len(self.city_list) #determines the number of cities/tour

        


        self.first_city = self.city_list[0] #determines the first city in a tour


        self.last_city = self.city_list[self.num_city -1] #determines the last city in a tour
        




    def distance(self, mode_str = 'driving'):
        '''A method to calculate the total distance covered in a tour between multiple
cities, whether biking driving or walkig. Argument: mode of transportation'''


        self.town_list = [] #a list in which only cities of location will be place

        self.st_list = [] #a list in which only states of locations will be placed

        web_str = '' #a str to be entered into urllib to interact w/ google api

        total_dist = 0 #the total distance of a tour

       

        i = 0 #a count for the number of times each location has been split into city and state components



        for city in self.city_str:
       

            self.loc_list = city.split(',')


            self.cit_str = self.loc_list[0] #splits location into city and later state


            self.cit_str = self.cit_str.replace(' ', '+') #replaces any spaces between words with + to be entered in url format


            self.st_str = self.loc_list[1]


            self.st_str = self.st_str.strip()


            self.town_list.append(self.cit_str) #adds each city to a list of cities alone


            self.st_list.append(self.st_str) #adds each town to a list of towns alone


            i += 1






        for j in range (0,i-1): #a loop to compose a total tour distance from the sum of distances between consecutive cities

           
            

            web_str = self.town_list[j] + '+' + self.st_list[j] + "&destinations=" + self.town_list[j+1] + '+' + self.st_list[j+1] + "&mode=" + mode_str + "&sensor=false" #url entry str



            web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins="+web_str) #web object syntax to be opened and read


            results_str = str(web_obj.read())

           

            web_obj.close() #closes the web object after reading

        

            results_list = results_str.split('\\n') #sepearates the google API return text


            dist_str = ''


            dist_str = results_list[9] #selects the string containing tour distance in meters


            dist_str.strip()


            dist_list = dist_str.split(':')


            dist_list_val = dist_list[1] #selects the string containing the number distance value


            dist_list_val = dist_list_val.strip()


            if dist_list_val.isdigit(): #makes sure the value of that index contains only numbers
                
                

                dist_list_val = int(dist_list_val)


            else: #Error raised if it is not an number type
                
                print("Error:") #raise value exception error

                raise ValueError('The query response does not contain a distance value.')



            total_dist += dist_list_val #adds the distance between two cities in question to that of total tour



        if i == 1: #if only one city is present in the tour then there is no distance

            

            raise ValueError('The query response does not contain a distance value.') #raise an error for no int in distance place

            


        return(total_dist) #returns the distance of the tour




    def __str__(self):
        '''A method to create a string displaying the cities in the tour'''


        count_int = 0 #integer to count number cities to be displayed

        form_str = ''

        

        while count_int < (self.num_city-1): #goes through each city and adds it to the form string

            form_str += str((self.city_list[count_int]))

            form_str += '; '

            count_int += 1 


        while count_int < self.num_city: #for the final city no semi-colon is added after

            form_str += str((self.city_list[count_int]))

            count_int += 1


        return(form_str) #returns the form string





    def __repr__(self):

        ''' A method used for debugging to format the string of cities returned''' 

        count_int = 0 #near identical mechanism to string method

        form_str = ''


        while count_int < (self.num_city-1):

            form_str += (self.city_list[count_int])

            form_str += '; '

            count_int += 1 


        while count_int < self.num_city:

            form_str += (self.city_list[count_int])

            count_int += 1


        return(form_str) #returns the repr string




    def __add__(self, second_tour):

        '''A method used to add another tour to an orignal user defined tour. Argument: Another user defined tour'''

        

        if  type(second_tour) == Tour: #makes sure a tour is added to first
            

            city_list = self.city_list.copy() #copies the city list


            for value in second_tour.city_list: #each city in the second tour is added to the list of the first tour

                city_list.append(value)                

            

            city_tup = tuple(city_list) #makes the list a tuple


            t4 = Tour(city_tup) #Assigns the intiated tour

        
        return(t4) #returns the extended tour



    def __mul__(self, cycle_int):
        '''A method used to repeatedly concatenate a tour. Argument: A non-negative integer that will
multiply to the tour.'''


        if type(cycle_int) == int: #checks to ensure the value is an int


            if cycle_int >= 0: #checks for non negative


                prod_city_tup = tuple(self.city_list) * cycle_int #concatenates the list of cities in the tour


                t5 = Tour(prod_city_tup)

        


            else: #raises an error if the int is non negative

                print("ValueError")

                raise ValueError('The integer entered cannot be negative.')

                


        else: #raises an error if the value is not an int

            print("TypeError")

            raise TypeError('The argument entered is not an integer.')
            
        return(t5) #returns the tour that has been concatenated

    


    def __rmul__(self, cycle_int):
        '''A method to multiply a value number by the original value. Argument: An integer to multiply the tour by'''
        

        prod_city_tup = (tuple(self.city_list)).__mul__(cycle_int) #uses the mul method to find the concatenation product

        t6 = Tour(prod_city_tup)

        return(t6) #returns concatenation product



    def __gt__(self, another_tour):

        '''Compares the driving distance of an original tour to that of a user defined tour. Argument: Another user
defined tour'''
        

        another_tour_tup = tuple(another_tour.city_list) #makes the second tour cities into a tuple


        t7 = Tour(another_tour_tup) #makes a tour of that list


        another_distance = t7.distance() #finds the distance of the second tour


        first_distance = self.distance() #finds the original tour distance


        if first_distance > another_distance: #if orig > sec its true

            return(True)


        else: #if not its false
            return(False)



    def __lt__(self, next_tour):
        
        '''Compares the driving distance of an orignal tour to that of another used defined
tour to see if one is less than the other. Argument: the next tour in question.'''

        next_tour_tup = tuple(next_tour.city_list) # Same setup mechanism as greater than


        t8 = Tour(next_tour_tup)


        next_distance = t8.distance()


        first_distance = self.distance()


        if first_distance < next_distance: #returns true if orig less than second

            return(True)


        else: #else False
            
            return(False)


    def __eq__(self, then_tour):
        '''Compares the original tour to another tour to see if both are tours of the exact
same cities in the exact same order. Argument: The other tour than the original'''

        then_tour_tup = tuple(then_tour.city_list) #makes a tuple of list of cities in the new city list

        

        first_tour_tup = tuple(self.city_list) #tuple of orginal city list

   

        if then_tour_tup == first_tour_tup: #check for exact equality of city order in tour

            return(True) 

        else: #if not equal returns false
            return(False)

        





def main():
    '''A main function to run through each of the Tour class methods produced above.'''


    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA") #checks uses the str method as well as init in making tours
    t2 = Tour("Oakland, CA")
    t3 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    print("t1: {}\nt2:{}\nt3:{}".format(t1,t2,t3))

    print(" ")

    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000), round(t1.distance('bicycling')/1000), round(t1.distance('walking')/1000))) #uses the 
                                                                                                                                            #distance method

    print("Using driving distances from here on.")
    print(" ")

    t4 = t1 + t2 #uses the add mehtod
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t4 == t1 + t2:", t4 == t1 + t2)

    #print("t2 driving distance:", round(t2.distance()/1000),"km") #will raise ValueError if uncommented no distance value contained

    t5 = t1 * 2
    print(" ")
    print("t5 = t1 * 2:", t5)
    print("t5 driving distance:", round(t5.distance()/1000),"km") #uses the mul method

    t6 = 2 * t1
    print(" ")
    print("t6 = 2 * t1:", t6)
    print("t6 driving distance:", round(t6.distance()/1000),"km") #uses the rmul method


    #print(" ")

    #t7 = t3 * -3                        #will raise value error for multiplication if uncommented

    #print("t7 driving distance:", round(t7.distance()/1000), "km")



    #print(" ")

    #t8 = t1 * 'hi mom'                 # will raise type error for multiplication if not commented

    #print("t8 driving distance:", round(t8.distance()/1000), "km")
    

    gt_bool_str = t1 > t6 #uses gt method

    print(" ")

    print("t1 > t6 is a: ", gt_bool_str, "statement")



    lt_bool_str = t1 < t6 #uses lt method

    print(" ")
    
    print("t1 < t6 is a: ", lt_bool_str, "statement")
    


    eq_bool_str = t2 == t3 #uses eq method

    print(" ")
    
    print("t2 == t3 is a:", eq_bool_str, "statement")



    two_eq_bool_str = t1 == t3 #uses eq method with true result

    print(" ")
    
    print("t1 == t3 is a:", two_eq_bool_str, "statement")
    

main()
