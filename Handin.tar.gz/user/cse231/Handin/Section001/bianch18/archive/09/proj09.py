#####################################################################
#Section 01
#Project 09
#3/25/13
#Functions as a seahaven solitaire game constructor that
# compels the user to follow the game rules and tells them if they
# have won after setting the game up
#Receives: A Deck of cards with empty foundations, cells, and
# tableau and basic card play data.
#Returns: A fully functioning seahaven solitaire game that allows
# user input for commands for specific moves and provides hints
# if incorrect commands are entered.
#####################################################################

import cardsBasic #imports the module necessary for card use and data

def setup(): #a function to set up the game
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """

    my_deck = cardsBasic.Deck() #creates the deck


    my_deck.shuffle() #well shuffled game setup


    foundation = [[],[],[],[]] #creates foundation lists


    cell = [[], [], [], []] #creates 4 cell lists


    tableau = [[], [], [], [], [], [], [], [], [], []] #creates 1o tableau lists
    

    count_deal_int = 0 #a count to keep track of # cards dealt



    while not my_deck.is_empty():
            

            a_card = my_deck.deal() #deals a card to the tableau


            tableau[count_deal_int%10].append(a_card) #deals one row at a time


            count_deal_int += 1 

            

    return foundation, tableau, cell #returns the created game spaces



                                            #got this from Punch

def print_game(foundation, tableau,cell): #prints out the created game spaces
    """
    parameters: a tableau, a foundation and a cell 
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """

    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')


def print_rules(): #Prints the rules for user. Got this from Punch
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

    

def move_to_foundation(tableau,cell,foundation,t_col,f_col, r): #move card to foundation
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''

    if r == 't2f': #A tableau to foundation move

        move_card = tableau[t_col - 1].pop() #removes the card from selected tableau col

        

        from_rank = move_card.get_rank() #the rank of the card

  

        if foundation[f_col - 1] != []: #if the foundation moving to is not empty


            last_foundation = foundation[f_col - 1][-1] #the last card facing user in


            to_rank = last_foundation.get_rank() #the col and its rank

            

        
            

            if from_rank == to_rank + 1 and move_card.equal_suit(last_foundation) == True:

                foundation[f_col - 1].append(move_card) #the card can be moved to the


                return(True) #the foundation if of same suit and 1 less rank



            else: #If the conditions are not met the move cannot be made
                

                tableau[t_col - 1].append(move_card) #returns card to where it came from


                return(False) #returns false bool to play fn to print error message

                

        else: #if the foundation column is empty


            if from_rank == 1: #only an ace must be moved to the foundation

                foundation[f_col - 1].append(move_card) # moves card to foundation


                return(True)



            else: #if not an ace return the card and return false
                
                tableau[t_col - 1].append(move_card)


                return(False)



    else: # if a cell to foundation move is selected

        move_card = cell[t_col - 1].pop() #removes the card from the cell 


        from_rank = move_card.get_rank() #the rank of the card 



        if foundation[f_col - 1] != []: #if the foundation isn't empty
            

            last_foundation = foundation[f_col - 1][-1] #the last card in foundation 


            to_rank = last_foundation.get_rank() #the rank of last foundation card




            if from_rank == to_rank + 1 and move_card.equal_suit(last_foundation) == True:


                foundation[f_col - 1].append(move_card) #if the moving card is one more rank


                return(True) #and the same suit as the card in foundation ... True



            else: #If conditions not true return false
                
                cell[t_col - 1].append(move_card)


                return(False)



        else:


            if from_rank == 1: #if the foundation is empty only an ace can be moved there


                foundation[f_col - 1].append(move_card)


                return(True)


            else: #any other card than ace invalid move

                
                cell[t_col - 1].append(move_card)


                return(False)
        


def move_in_tableau(tableau,t_col_source,t_col_dest): #move card from tableau col to other col
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''


    move_card = tableau[t_col_source - 1].pop() #the moving card is removed from tableau column


    from_rank = move_card.get_rank() #the moving card's rank


    if tableau[t_col_dest - 1] == []: #if the tableau column is empty




        if from_rank == 13: #only a king may be moved


            tableau[t_col_dest - 1].append(move_card)


            return(True)
        


        else: #if not a king the move is invalid
            
            tableau[t_col_source - 1].append(move_card) #return the card to initial tableau column

            return(False)


    else:
        

        last_tab_to = tableau[t_col_dest - 1][-1] #the tableau card the moving card goes on top of
         

        to_rank = last_tab_to.get_rank() #that cards rank

        

        

        if (from_rank + 1 == to_rank and move_card.equal_suit(last_tab_to)): #if the move follows the

            tableau[t_col_dest - 1].append(move_card) #aforementioned rules it goes to the new

            return(True) #tableau column


        else: #if the move is invalid
            
            tableau[t_col_source - 1].append(move_card) #return the card to initial tableau column

            return(False)




def move_to_cell(tableau,cell,t_col,c_col): #moves cards from tableau to cell
     
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    
    move_tab_card = tableau[t_col - 1].pop() #removes the card from tableau column list


    
           
    if cell[c_col - 1] == []: #if the cell is empty
        

        cell[c_col - 1].append(move_tab_card) #moves any card to the cell


        return(True)

    

    else: #if the cell is not empty the move is invalid
        

        tableau[t_col - 1].append(move_tab_card) #returns the card to the tableau column


        return(False)



def move_to_tableau(tableau,cell,t_col,c_col): #moves card from cell to tableau
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''

    move_card = cell[c_col - 1].pop() #removes the card from the cell column


    from_rank = move_card.get_rank() #rank of the card



    if tableau[t_col - 1] == []:

        if from_rank == 13: #only a king can be moved to an empty tableau from cell


            tableau[t_col - 1].append(move_card)


            return(True)


        else: #if the moving card is not a king

            cell[c_col - 1].append(move_card) #returns the card to its cell


            return(False)

            
    else:

        last_tab_to = tableau[t_col - 1][-1] #the card that the former cell card goes ontop of
        

        to_rank = last_tab_to.get_rank() #rank of that card

        


        if (from_rank + 1 == to_rank and move_card.equal_suit(last_tab_to)): #if the move meets


            tableau[t_col - 1].append(move_card) #the conditions cell_rank 1 less and same suit


            return(True) #valid move


        else: #if requires not met returns card to cell and false bool returned
            
            cell[c_col - 1].append(move_card)

            return(False)
        
    
            


def show_help(): #help menu for user moves. I took this from Punch
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    print(" ")

    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)




def play(): #Initiates game play and continues it

    import cardsBasic #imports the cardsBasic module for properties use


    print_rules() #prints the rules
    
    
    foundation, tableau , cell = setup() #intiates the setup of the game no print


    show_help() #gives the user a help menu





    not_win_bool = True #boolean user hasn't won yet


    while True:#while the user hasn't won keep playinh


        if not foundation[0] == [] and not foundation[1] == [] and not foundation[2] == [] and not foundation[3] == []:


            found1_score = foundation[0][-1].get_rank() #variables to signal break if win achieved

            found2_score = foundation[1][-1].get_rank()

            found3_score = foundation[2][-1].get_rank()

            found4_score = foundation[3][-1].get_rank()


            if found1_score == 13 and found2_score == 13 and found3_score == 13 and found4_score == 13:

                not_win_bool = False #if all kings in the foundations the user has won

                continue #goes to top of loop, breaks out, prints thanks

        
            
        else: #game play
            
            print_game(foundation, tableau, cell) #prints the game


            response = input("Command (type 'h' for help): ") #allows user input command


            response = response.strip() #strips the response of unecessary \n etc


            response_list = response.split() #splits the command parts by spaces




            if len(response_list) > 0: #if any command is entered



                r = response_list[0] #r is the first element



                if r == 't2f': #tableau to foundation command


                    t_col = 0 #intiates vars


                    f_col = 0
                    

                    t_col = response_list[1]


                    f_col = response_list[2]


                    t_col = int(t_col) #the column integer numbers of the moves


                    f_col = int(f_col)

                    


                    move_bool = move_to_foundation(tableau, cell, foundation, t_col, f_col, r) #the boolean of the move 


                    if move_bool == False: #if its false


                        print(" ")

                        print("Error: This move violates the rules. Please make another move.")

                        continue #print an error message


                    else: #good move

                        continue


                    

                elif r == 't2t': #tableau to tableau move
                    
                    
                    t_col_source = 0 #intiates vars

                    t_col_dest = 0


                    t_col_source = response_list[1] 

                    t_col_dest = response_list[2]
                    

                    t_col_source = int(t_col_source) #ints of the move columns

                    t_col_dest = int(t_col_dest)
                    

                    move_bool = move_in_tableau(tableau, t_col_source, t_col_dest) #move bool of called function

                    

                    if move_bool == False:#if false move bool returned

                        print(" ") #error message

                        print("Error: This move violates the rules. Please make another move.")

                        continue



                    else: #good move

                        continue



                elif r == 't2c': #tableau to cell move

                    t_col = 0 #intiates move vars

                    c_col = 0


                    t_col = response_list[1] 

                    c_col = response_list[2]


                    t_col = int(t_col) #move column ints from response

                    c_col = int(c_col)



                    move_bool = move_to_cell(tableau, cell, t_col, c_col) #calls respective fn


                    if move_bool == False:

                        print(" ") #error message

                        print("Error: Unempty cell can't be used. Please make another move.")

                        continue



                    else:

                        continue



                elif r == 'c2t': #cell to tableau move

                    c_col = 0 #intiates vars

                    t_col = 0


                    c_col = response_list[1] 

                    t_col = response_list[2]


                    t_col = int(t_col) #move columns  chosen in response as ints 

                    c_col = int(c_col)



                    move_bool = move_to_tableau(tableau,cell,t_col,c_col) #it's fn called for bool


                    if move_bool == False:

                        print(" ") #error message

                        print("Error: Move violates rules. Please make another move.")

                        continue

                    else:
                        continue




                elif r == 'c2f': #cell to foundation move

                    t_col_str = 0 #intiates vars

                    f_col_str = 0


                    t_col_str = response_list[1]

                    f_col_str = response_list[2]


                    t_col = int(t_col) #ints of move column values selected in response

                    f_col = int(f_col)


                    #calls move_to_foundation fn returns move bool
                    move_bool = move_to_foundation(tableau, cell, foundation, t_col, f_col, r)


                    if move_bool == False:

                        print(" ") #prints error message if false

                        print("Error: Move violates rules. Please make another move.")

                        continue


                    else:
                        continue


                elif r == 'q': #if the user quits the game breaks play cycle

                    break


                elif r == 'h': #shows help menu to the user

                    show_help()


                else: #incorrect command format

                    print(" ")

                    print('Unknown command:',r) #prints help

                    print("Please enter a command in the correct format: x2y row# row#.")


            else: #incorrect empty command made

                print(" ")

                print("Unknown Command:",response)

                print("Please enter command with length 3 'words'.")
                

    print('Thanks for playing') #thank you message




play() #implements the game


        
