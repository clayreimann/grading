
##########################################
#David Bianchi
#section 001
#1/14/13
#project 01
##########################################

num_str1 = input("Please give me a Richter scale measure: ")   # gives the prompt for the Richter value


num_float = float(num_str1)                          # floating number entered by the user


print("Richter measure: ", num_str1)               # prints the Richter measure label followed by the floating number


num_str2 = (10**(1.5*float(num_str1)+4.8))      # calculates the equivalence in joules for the floating number richter value


print("Equivalence in joules: ", num_str2)         # displays the equivalence in joules label followed by the value


num_str3 = ((num_str2)/(4.184e9))                 # calculates the equivalence in tons of TNT to the floating number richter value 


print("Equivalence in Tons of TNT: ", num_str3)    # displays the label Equivalence in tons of TNT followed by the value


print("      ")                                    # displays a blank line


num_float2 = 1          # value used to compose the chart

num_float3 = 5          # value used to compose the chart

num_float4 = 9.1        # value used to compose the chart

num_float5 = 9.2        # value used to compose the chart

num_float6= 9.5         # value used to compose the chart

a_float = (10**(1.5*(num_float2)+4.8))  # variable used to represent the energy corresponding to num_float 2
           
b_float = ((a_float)/(4.184e9)) # variable used to represent the tons of TNT corresponding to a_float

c_float = (10**(1.5*(num_float3)+4.8)) # variable used to represent the energy corresponding to num_float 3

d_float = (c_float)/(4.184e9) # variable used to represent the tons of TNT corresponding to c_float

e_float = (10**(1.5*(num_float4)+4.8)) # variable used to represent the energy corresponding to num_float 4

f_float = (e_float)/(4.184e9) # variable used to represent the tons of TNT corresponding to e_float

g_float = (10**(1.5*(num_float5)+4.8)) # variable used to represent the energy corresponding to num_float 5

h_float = (g_float)/(4.184e9) # variable used to represent the tons of TNT corresponding to g_float

i_float = ((10**(1.5*(num_float6)+4.8))) # variable used to represent the energy corresponding to num_float 6

j_float = (i_float)/(4.184e9) # variable used to represent the tons of TNT corresponding to i_float

print("Richter", "      ", "Joules", "                      ", "TNT") # displays the titles of the chart           
print(num_float2, "         ", a_float, "               ", b_float) # displays the values of the chart
print(num_float3, "         ", c_float, "             ", d_float) # displays the values of the chart
print(num_float4, "       ", e_float, "    ", f_float) # displays the values of the chart
print(num_float5, "       ", g_float, "    ", h_float) # displays the values of the chart
print(num_float6, "       ", i_float, "  ", j_float) # displays the values of the chart


