###################################################################################
#Section 01
#Project 05
#2/11/13
#Functions as a hexagonal tesselation producing graphics program
#receives: two colors of the hexagons to be drawn
# and the number of hexagons to be present in each row which
# is the number of rows that will appear
#returns: A graphic tesselation made up of hexagons
#####################################################################################

import math   #imports the packages/modules that will be utilized later

import turtle

import time

turtle.speed(0) #sets turtle to draw at the highest speed when activated

def get_color_choice(): #defines the first that will return the color choices

    print("Choices for colors to use are: ") #prints a color choice menu for the user

    print("red")

    print("green")

    print("blue")

    colorcycle_int = 0 #intiates a count of how many colors have been chosen


    
    
    color1_str = input("Please enter your choice: ") #allows the user to input a color choice

    while colorcycle_int < 1: #starts a loop for the the 1st choice to ensure a valid choice is made

        if color1_str == 'red' or color1_str == 'green' or color1_str == 'blue':

            colorcycle_int += 1



        else: #if an invalid choice is entered reprompts the user showing them the invalid choice

            color1_str = input(color1_str + " " + "is not a legal choice. Please try again: ")

            continue



    color2_str = input("Please enter your choice: ") #allows the user to input a second choice


    while colorcycle_int < 2: #starts a loop for the the 2nd choice to ensure a valid choice is made


        if color2_str == 'red' or color2_str == 'green' or color2_str == 'blue':

            colorcycle_int += 1

            return(color1_str, color2_str)


        else: #if an invalid choice is entered reprompts the user showing them the invalid choice
    
            color2_str = input(color2_str + " " +  "is not a legal choice. Please try again: ")

            continue


def get_number_hexagons(): #defines a function that returns the number of hexagons per row and # rows to be drawn

    hexcycle_int = 0 #initiates a count to repeat a while loop and invalid choice is entered

    numberhex_str = input("Please enter a number of hexagons per row: ") # allows the user to input a choice

    while hexcycle_int < 1:

        if (int(numberhex_str) >= 4 and int(numberhex_str) <= 20): #restricts correct choice


            hexcycle_int += 1

            numberhex_int = (int(numberhex_str)) #prepares the number of hexagons to be returned as an int

            return(numberhex_int)


        else: #continually reprompts the user if an invalid choice is made

            numberhex_str = input("It should be between 4 and 20. Please try again: ")

            continue
        
def draw_hexagon(x, y, side_len, pen, color): #defines a function that returns a hexagon image

        pen.fillcolor(color) #selects the pen color to be drawn for the hexagons
        
        pen.goto(x,y) #selects the start position for turtle
        
        pen.down() #the following translations and angles produce a regular hexagon

        pen.left(30)

        pen.forward(side_len)

        pen.left(60)

        pen.forward(side_len)

        pen.left(60)

        pen.forward(side_len)

        pen.left(60)

        pen.forward(side_len)

        pen.left(60)

        pen.forward(side_len)

        pen.left(60)

        pen.forward(side_len)

        pen.end_fill()

        pen.up #lifts the turtle pen to stop the drawing


color1st_str, color2nd_str = get_color_choice() #sets the returns from the 1st function as the colors to be used

numberhex_int = get_number_hexagons() #sets the return from the 2nd function to be the # of hexagons per row



counthex_int = 0 #initiates counts for the number of hexagons drawn

countrow_int = 0 #and the number of rows drawn

d_float = (500.0/(numberhex_int))  #the diameter of a hexagon



s_float = (d_float/2.0) / (math.cos(math.pi/6.0)) #the side length of a hexagon

q_float = math.sqrt((s_float)**2  - (d_float/2)**2) #the distance from the bottom vertex up to a line intersecting the 

                                                    #next nearest vertices
while countrow_int < numberhex_int: #starts a loop to repeatedly draw the correct # of rows of hexagons

    turtle.up()        
        
    while counthex_int < numberhex_int:#a loop to draw hexagons in a row
    
        turtle.seth(0)  #sets the turtle in the right direction

        turtle.begin_fill()

        turtle.up()

        if countrow_int%4 > 1: #allows the first color used to alternate every other two for the first two times in the diagonal pattern
            
            if counthex_int%2 == 0: #ensures every other hexagon is a different color
                
                color = color1st_str

            else:
                
                color = color2nd_str
        else: #sets the first color of the row to alternate for the other two times
            
            if counthex_int%2 != 0: #alternates color for every other hexagon

                color = color1st_str

            else:
                
                color = color2nd_str


        if countrow_int%2 == 0: #gives one starting x position for every other hexagon row and different y position
            
            draw_hexagon(-200 + ((counthex_int) * d_float), 150 - (countrow_int * (s_float + q_float)),s_float, turtle, color) #inputs earlier

                                    #returns into the draw hexagon function to produce the tessalation. 

            

        else: #gives a different starting x position for every other hexagon row and different y position
            
            draw_hexagon(-200 + ((counthex_int) * d_float) - (d_float/2), 150 - (countrow_int * (s_float + q_float)),s_float, turtle, color)

            #inputs earlier returns into the draw hexagon function to produce the tessalation. 


        counthex_int += 1 #increases the count of number of hexagons drawn per row

        continue


    countrow_int += 1 #increases the count of number rows drawn when one is completed


    counthex_int = 0 #resets the count of number of hexagons drawn per row


    turtle.up #lifts the pen


time.sleep(5) #fades the image after a time

    
