#####################################################################################
#Section 01
#Project 06
#2/25/13
#Functions as a program to data mine through a text file
# of apple stock data since its inception.
#receives: a file to be opened and the column of data in
# the file to be analyzed.
#returns: The six highest values of the column selected and the
# six lowest values of the column rounded to two decimal places
######################################################################################

def get_input_descriptor(): # function to prompt for filename and open it for input
                            # returns a file descriptor attached to opened file

    opened_file_bool = False #sets the boolean as false until the file is opened

    while (not opened_file_bool): #loop to repeatedly ask for input

        try:

            input_file_name_str = input("Open what file: ") #user input

            input_file_obj = open(input_file_name_str) #opens the file

            opened_file_bool = True #if the file is opened changes boolean to true makes
                                    #loop exit
            
        except IOError: # catch for IOerror if file chosen not available
            print("Bad file name, try again")
       

    else:                              #as loop is exited renames file obj and returns filename and
        file_object = input_file_obj   #opened file

        return(file_object)


def get_data_list(file_object, column_number):     # reads apple data and gathers the data in a
                                                    # date value tuple

    file_object_str = file_object.read()     #reads the open file object of data


    file_object.close() #closes the file!


    file_object_str.strip()     #strips the empty lines and spaces from the final


    list_of_lines = file_object_str.split('\n') #splits the file by lines carriage return


    list_of_tuples = [] #initiates list of tuples


    for line in list_of_lines:    #for loop to go through list and form tuples

        temp_list_data = line.split(',') #splits lines by comma


        list_of_tuples.append((temp_list_data[0], temp_list_data[column_number])) 


    list_of_tuples.pop(0) #removes the day from the date of the tuple


    return(list_of_tuples) #returns the list of date, data value tuples



def average_data(list_of_tuples):      # averages the data for each month and generates a list


    month_total_list = []              # of tuples of data avg, month:year


    tuple_of_avgs = []


    for data_tuple in list_of_tuples:   #by date in the tuple makes each date contain only month year
        
        date_str = data_tuple[0]   #makes dates portion of the tuple a string


        list_of_dates = date_str.split('-') #based off of whats in txt split by -


        list_of_dates.reverse()


        list_of_dates.pop(0) 


        date_str = list_of_dates[0] + '-' + list_of_dates[1]   # produces hyphenized month yr string


        bool_month_exist = False  #sets a boolean to false before for loop is entered


        for month_list in month_total_list: # for each month in the list of totals for the month

            if month_list[1] == date_str:

                month_list[0] += float(data_tuple[1])  #the data for the date with that month is compiled

                month_list[2] += 1 #adds one to the number of days in the month, 3rd portion of tuple

                bool_month_exist = True #establishes an area for the month in the list
                

        if bool_month_exist == False: #makes a list for a new month's data

            month_total_list.append([float(data_tuple[1]), date_str, 1])


    month_avg_tup = []


    for month_list in month_total_list: #for each month_list in the total list averages the data

        month_avg_tup.append((month_list[0] / month_list[2], month_list[1])) #divides data by num of days 3rd thing in

                                                                            #tuple

    return(month_avg_tup)  # returns a tuple of the avg data for each month and the date                                     
        

def main():               # function to call the get unput, prompt column average, call avg_data, print
                            # 6 highest and 6 lowest avgs

    file_object = get_input_descriptor()  #calls the get input descriptor


    column_number_entry = input("What column: ") #asks the user to input column of data to be worked on


    column_number = int(column_number_entry) #converts column number to an integer


    my_list = get_data_list(file_object, column_number) #calls the get data list fn


    my_average_list = average_data(my_list) #calls the average data fn


    my_average_list.sort() #sorts the data that has been averaged
    

    print(" ")

    print("Lowest 6 for column", column_number)  # prints the title for lowest scores


    for i in range(0,6):  # iterates through the six lowest values in average list to print in order

        print("Date:", (my_average_list[i])[1] ,", Value: {0:.2f}".format(float((my_average_list[i])[0]))) #prints the data

                                                                                    #and value as a two dec place str


    my_average_list.reverse() #reverses the list of avg data so highest values are 1st in order

    print(" ")

    print("Highest 6 for column", column_number) #title


    for j in range(0,6):# iterates through six highest values to print in order

        print("Date:", (my_average_list[j])[1] ,", Value: {0:.2f}".format(float((my_average_list[j])[0]))) #prints the data

                                                                                    #and value as a two dec place str


        
#main() #don't need this TA will type in

    

