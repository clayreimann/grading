########################################################################
#Section 01
#Project 10
#4/8/13
#A program for making the images of flags containing stars and
# rectangles using the turtle module to draw.
#Receives: A text file containing data in the form of:
# number of rectangles \n rectangle data (with number of lines
# equal to # of rectangles \n, number of stars, \n star data
# (with number of lines corresponding to # of stars)
#Returns: A string describing the flag drawn in terms of
# rectangle and star characteristics and the flag depictions.
##########################################################################

#How do i make turtle arrow disappear from drawing?


import turtle #turtle module to be used for drawing

import time #time used to clear screen etc.


class Star(object) :
    ''' A class used to create and store instances of the stars that are
contained in a flag and to return a string of data for each star'''
    
    def __init__(self, x, y, arm_length, color):
        '''Method used to create an instance of a star, inputs described below'''

        self.x = x #the x coord. of the center

        self.y = y #the y coord. of the center

        self.star_tag = 'Star' #descriptor of object

        self.arm_start = float(x) + ((float(arm_length))/2.35), float(y) + ((float(arm_length))/3.236) #where to start drawing
                                                                                                        #star arm
        self.arm_length = arm_length #length of the stars arm

        self.star_color = color #stars color
        
        
    def draw(self, turtle):
        '''Method used to make a depiction of the star with the turtle, parameters the object
and the turtle'''

        turtle.up()

        turtle.goto(self.arm_start) #starting point

        turtle.seth(0) #face horizontal

        turtle.down() #begin drawing

        turtle.color(self.star_color) #color commands

        turtle.begin_fill()

        turtle.forward(self.arm_length) #draws each arm periodically while making the correct angular

        turtle.right(144) #turns

        turtle.forward(self.arm_length)

        turtle.left(72)

        turtle.forward(self.arm_length)

        turtle.right(144)

        turtle.forward(self.arm_length)

        turtle.left(72)

        turtle.forward(self.arm_length)

        turtle.right(144)

        turtle.forward(self.arm_length)

        turtle.left(72)

        turtle.forward(self.arm_length)

        turtle.right(144)

        turtle.forward(self.arm_length)

        turtle.left(72)

        turtle.forward(self.arm_length)

        turtle.right(144)

        turtle.forward(self.arm_length)

        turtle.end_fill() #stop coloring

        
        
    def __str__(self):
        '''A method to return a string that describes the star instance drawn'''

        return '%s%s%s%s%s' % (self.star_tag, 'x:', self.x, ', y:', self.y, ', arm:', self.arm_length, ', color:', self.star_color) 




class Rectangle(object) :

    '''A class with which to create instances and store data of each rectangle object to be drawn'''



    def __init__(self, x, y, width, height, color):

        '''Method to create an instance of a rectangle. Parameters, x coord. center of rectangle, y coord. center
of rectangle, width rectangle, height rectangle, color rectangle'''

        self.x = x #center coords

        self.y = y

        self.start_corner = float(x) - (float(width)/2), float(y) + (float(height)/2) #calculation of position of top left
                                                                                        # rectangle corner

        self.width = width

        self.height = height

        self.rectangle_color = color

        self.rect_tag = 'Rectangle' #object title
        




    def draw(self, turtle):
        '''Method used to create images of rectangles using the turtle. Parameter turtle'''

        turtle.up()

        turtle.goto(self.start_corner) #moves the turtle to starting place without drawing

        turtle.seth(0) #sets the turtle horizontally

        turtle.down() #begins drawing with correct color

        turtle.color(self.rectangle_color)

        turtle.begin_fill()
    
        turtle.forward(self.width)

        turtle.right(90)

        turtle.forward(self.height)

        turtle.right(90)

        turtle.forward(self.width)

        turtle.right(90)

        turtle.forward(self.height)

        turtle.end_fill() #ends the drawing/coloration

        

    def __str__(self):
        '''Method used to return a string that defines the data used to create the retangle'''

        return '%s%s%s%s%s%s'% (self.rect_tag, 'x:', self.x, ', y:', self.y, ', width:', self.width, ', height:', self.height, ', color:', self.rectangle_color)




class Flag(object) :
    '''Class using the rectangle and star class instances to create instances of flags
and store/combine the data for each flag'''



    def __init__(self, f_obj):
        '''Method used to create an instance of a flag. A parameter is the opened file object
containing the data for how the flag is to be drawn with stars and rectangles'''

        num_rectangles_str = f_obj.readline() #obtains number of rectangles from text file first line

        self.num_rectangles = int(num_rectangles_str)

        count_rect = 0

        self.rectangle_flag_list = []



        while count_rect < self.num_rectangles: #adds each of the next rectangle lines as a list to a list of lists

            self.rectangle_line = f_obj.readline()

            self.rectangle_line = self.rectangle_line.strip() #strips whitespace

            self.rectangle_list = self.rectangle_line.split(',') #splits on comma

            self.rectangle_flag_list.append(self.rectangle_list)

            count_rect += 1

    

        

        num_stars_str = f_obj.readline() #reads the next line after rectangles in text file for # stars

        self.num_stars = int(num_stars_str)

        count_star = 0

        self.star_flag_list = []


        while count_star < self.num_stars: #makes each of the next read lines into lists that go into a
                                            #list of lists describing the stars in the flag

            self.star_line = f_obj.readline()

            self.star_line = self.star_line.strip()

            self.star_list = self.star_line.split(',') #splits the data in individual star list by comma

            self.star_flag_list.append(self.star_list)

            count_star += 1

        
        

    def draw(self, turtle):
        '''Method used to create the image of the flag with the turtle module.
parameters: the turtle used for drawing'''


        import turtle

        turtle = turtle.Turtle() #activates the turtle in this method



        for self.rectangle_list in self.rectangle_flag_list: #for each rectangle sets vars equal to specified
                                                            #data position in the list
            
            self.txt_x = int((self.rectangle_list[0]).strip())

            self.txt_y = int((self.rectangle_list[1]).strip())

            self.txt_width = int((self.rectangle_list[2]).strip())

            self.txt_height = int((self.rectangle_list[3]).strip())

            self.txt_color = (self.rectangle_list[4]).strip()

            rectangle_image = Rectangle(self.txt_x, self.txt_y, self.txt_width, self.txt_height, self.txt_color) #draws
            
            rectangle_image.draw(turtle) #the rectangle using the rectangle class


        for self.star_list in self.star_flag_list: #for each star sets vars equal to specified data position in 

            self.txt_x = int((self.star_list[0]).strip()) #star list

            self.txt_y = int((self.star_list[1]).strip())

            self.txt_arm_length = int((self.star_list[2]).strip())

            self.txt_color = (self.star_list[3]).strip()


            

            star_image = Star(self.txt_x, self.txt_y, self.txt_arm_length, self.txt_color) #draws the stars using the star

            star_image.draw(turtle) #class and turtle





    def __str__(self):
        '''Method used to return a string containing the rectangle and star data of
the flag drawn in a neatly formatted manner'''
    

        multi_str = '' #string used to hold the data to be returned

        multi_str += "Rectangles \n" #first line only contains word rectangles

  

        
        for self.rectangle_list in self.rectangle_flag_list: #for each rectangle in rectangle list
                                                        #adds to multi str line containing data and lables and 
                                                       #starts a new line for next rectangle

            multi_str += 'x:'+  self.rectangle_list[0] + ', y:' + self.rectangle_list[1] + ', width:' + self.rectangle_list[2] + ', height:' + self.rectangle_list[3] + ', color:' + self.rectangle_list[4] + '\n'

        


        multi_str += "Stars \n"        # adds line containg only word stars to str


        for self.star_list in self.star_flag_list: #for each star in star list adds a line containing data
                                                    #and labels and starts a new line for next star

            multi_str += 'x:' +  self.star_list[0] + ', y:' + self.star_list[1] + ', a:' + self.star_list[2] + ', color:' + self.star_list[3] + '\n'


        return(multi_str) #returns the flag descriptor string

        




def main(): #I got this from Punch
    '''A function used to complete the entire process of drawing and returning
descriptors for each flag'''

    turtle.clearscreen()
    
    pen = turtle.Turtle()

    pen.speed('fastest')
    
    senegal_file = open('senegal.txt') #opens text file

    senegal_flag = Flag(senegal_file) #creates the flag image data to be stored

    print(senegal_flag)   #prints the flag descriptor

    senegal_flag.draw(pen) #draws the flag

    pen.hideturtle()

    senegal_file.close()

    time.sleep(2)   # delay so you can see your flag

    turtle.clearscreen()


    panama_file = open('panama.txt') #same process as for senegal flag

    panama_flag = Flag(panama_file)

    print(panama_flag) 

    panama_flag.draw(pen)

    pen.hideturtle()

    panama_file.close()
    
    time.sleep(2)

    turtle.clearscreen()


    my_file = open('myFlag.txt') #process repeated again with software designer created

    my_flag = Flag(my_file) #text file - the flag of ghana

    print(my_flag)

    my_flag.draw(pen)

    pen.hideturtle()

    my_file.close()

    
    

main()       
