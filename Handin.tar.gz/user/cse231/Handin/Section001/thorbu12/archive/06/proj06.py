# Section 1
# February 23rd, 2013
# Project 6
# The Following Program prompts the user
# for a file to open(table.csv) and
# then for the column they wish to work with.
# The program then generates a list of the six
# highest and lowest monthly averages
# for that column
list_of_tuples=list()
month_sum=list()
def get_input_descriptor():
    while True:
        try:
            file_name=input("Please give me the name of the file you wish to open: ")
            file_object=open(file_name, "r")
            break
        except FileNotFoundError:
            print("File Not found, please enter a valid file name(table.csv)")
    return file_object
def get_data_list(file_object,column_number):
    iteration=0
    for element in file_object:
        element=element.strip()
        element=element.split(',')
        data_tuple=element[0],element[column_number]
        if iteration != 0:
            list_of_tuples.append(data_tuple)
        iteration+=1
    file_object.close()
    return list_of_tuples
def average_data(list_of_tuples):
    data_sum=0
    month_iteration=0
    summed_tuple=0,0
    for i in range(0,(len(list_of_tuples))):
        date=list_of_tuples[i][0]
        data=list_of_tuples[i][1]
        current_year=(date.split('-'))[0]
        current_month=(date.split('-'))[1]
        if i == 0:
            previous_month=current_month
        if current_month == previous_month:
            data_sum+=(float(data))
            month_iteration+=1
            date2=str(current_month)+'-'+str(current_year)
        else:
            data_sum=data_sum/month_iteration
            data_sum=float(("{:.2f}".format(data_sum)))
            summed_tuple=date2,data_sum
            month_sum.append(summed_tuple)
            data_sum=0
            month_iteration=1
            data_sum+=float(data)
        previous_month=(date.split('-'))[1]
    else:
        data_sum=data_sum/month_iteration
        data_sum=float(("{:.2f}".format(data_sum)))
        summed_tuple=date2,data_sum
        month_sum.append(summed_tuple)
        data_sum=0
        month_iteration=1
        data_sum+=float(data)
def main():
    file_object=get_input_descriptor()
    while True:
        column_number=int(input("Which Column do you wish to work with?\nOpen(1)\nHigh(2)\nLow(3)\nClose(4)\nVolume(5)\nAdj Close(6)\n: "))
        if column_number >6 or column_number <1 :
            print("Column number must be between 1 and 6")
            continue
        else:
            break
    get_data_list(file_object,column_number)
    average_data(list_of_tuples)
    swapped_tuple=list()
    for i in range(0,len(month_sum)):
        year=month_sum[i][0]
        value=month_sum[i][1]
        tuple_rev=value,year
        swapped_tuple.append(tuple_rev)
    sorted_tuple=sorted(swapped_tuple)
    print("The Six smallest monthly values for column ",column_number," are:")
    for i in range(0,6):
        print("Month",sorted_tuple[i][1],"Value",sorted_tuple[i][0])
    print("The six largest monthly values for column",column_number," are:")
    for i in range(0,6):
        print("Month",sorted_tuple[len(sorted_tuple)-i-1][1],"Value",sorted_tuple[len(sorted_tuple)-i-1][0])
        
main()

