# Section 1
# March 17th, 2013
# Project 8
# 
# The following program will attempt to autocorrect
# a prefix supplied by the user based on the words
# in the text file ap_docs.txt. If ap_docs.txt is
# not available the program prompts for the text file to 
# use in its place.
# 
# 
c_dict={}
import string
def fill_completions(c_dict, fd): # Generates a dictionary of (index,letter):{words}
    for line in fd:
        line = line.strip()
        word_list = line.split()
        for word in word_list:
            word = word.lower()
            word = word.strip(string.punctuation)
            if word.isalpha() and len(word)>1:
                for enum_tuple in enumerate(word):
                    if enum_tuple in c_dict:
                        set_1=c_dict[enum_tuple]
                        set_1.add(word)
                        c_dict[enum_tuple]=set_1
                    else:
                        set_1=set()
                        set_1.add(word)
                        c_dict[enum_tuple]=set_1
    fd.close()
def find_completions(prefix, c_dict): # Takes the intersection of each (index,letter)
    letter_iteration=0                # value from the prefix supplied,
    pretty_print_list=list()          # then prints out the possible words
    possible_wordset=set()
    for letter in prefix:
        if letter_iteration==0:
            while True:
                try:
                    possible_wordset=c_dict[letter_iteration,letter].copy()
                    break
                except KeyError:             # Prevents error message if c_dict[letter_iteration,letter] does not exist
                    possible_wordset=set()   # If the key does not exist the proper response is "No matches Found".
                    break                    # By emptying the set this ensures that that will be the case in line 58.
            letter_iteration+=1 
        else:
            while True:
                try:
                    possible_wordset&=c_dict[letter_iteration,letter] #Intersection command
                    break
                except KeyError:           # Same purpose as above. If the index,letter key does not exist
                    possible_wordset=set() # in c_dict this will catch the KeyError.(ex 'kkkkkkkkkkkkk' will cause KeyError: (12,'k') if
                    break                  # ap_docs was used to fill the dicitonary)
            letter_iteration+=1  
    for word in possible_wordset:
        pretty_print_list.append(word)
        pretty_print_list.sort()
    if pretty_print_list==[]:
        print("No matches Found")
    else:
        for word in pretty_print_list:
            print(word)
    print('\n')
def open_read_file(): # Opens ap_docs.txt or prompts for an alternate file if
    file_problem=0    # ap_docs.txt can't be found
    quit1=0
    while True: 
        try:
            file_object=open('ap_docs.txt', "r")
            break
        except FileNotFoundError:
            print("ap_docs.txt not found")
            file_problem=1
            break
    if file_problem==1:
        while quit1==0:
            try:
                file_name=input("Please give me the name of the file you wish to open in place of ap_docs.txt or press # to quit: ")
                if file_name=='#':
                    quit1=1
                    continue
                file_object=open(file_name, "r")
                break
            except FileNotFoundError:
                print(file_name," was not found\n")
        else:
          file_object=''  
    return file_object
def main():  # calls open_read_file and fill_completions, then repeatedly
             # runs find_completions until prompted to quit
    file=open_read_file()
    if file=='':
        print('\n')
    else:
        fill_completions(c_dict,file)
        while True:
            prefix=input("Please give me a prefix for word prediction or # to quit: ")
            if prefix=='#':
                break
            else:
                if prefix.isalpha():
                    find_completions(prefix, c_dict)
                else:
                    print('\nPlease use alphabetical characters only')
                    continue
    print('\nProgram has Quit')
main()
