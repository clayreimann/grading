# Section 1
# April 21st, 2013
# Honors Project 12
# 
# The Following Program demonstrates
# the use of matplotlib and pyplot
# to graph temperature and solar
# radiation, in addition to
# the data interpretation
# required to utilize the text files
# Graphs are saved to the local directory
# of this file as 'Plot1.png', and 'Plot2.png'
import string
import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
def grab_temp():
    '''Opens the temperature.txt file, returns a list'''
    temp_file=open('temperature.txt')
    temp_line_list=list()
    word_list=list()
    for line in temp_file:
        line=line.strip()
        word_list=line.split()
        for word in word_list:
            word=word.lower()
            word=word.strip(string.punctuation)
        temp_line_list.append(word_list)
    temp_file.close()
    return temp_line_list
def grab_rad():
    '''Opens the solar_radition.txt file, returns a list'''
    rad_file=open('solar_radition.txt') # Left Spelling Error in provided file
    rad_line_list=list()
    for line in rad_file:
        line=line.strip()
        word_list=line.split()
        for word in word_list:
            word=word.lower()
            word=word.strip(string.punctuation)
        rad_line_list.append(word_list)
    rad_file.close()
    return rad_line_list
def high_low_temp(temp_list): #[2] is the first day
    '''Generates a list of tuples of the form avg_high,avg_low for each month'''
    iteration=0
    day_list=list()
    list_of_days=list()
    high_low_list=list()
    for line in temp_list:  #Generates a New List of lists with the form [Day][Hourly Temperatures]          
        if iteration==0 or iteration==1:
            iteration+=1
        else:
            current_day=temp_list[iteration][1]
            if iteration==2:
                previous_day=current_day
            if current_day==previous_day:
                day_list.append(temp_list[iteration][4])
            if int(current_day)==int(previous_day)+1 or int(current_day)<int(previous_day):
                list_of_days.append(day_list)
                day_list=list()
                previous_day=current_day
                day_list.append(temp_list[iteration][4])
            iteration+=1
    list_of_days.append(day_list) #Last day_list is not appended properly by my for loop
    for day in list_of_days: #Finds the High and Low Temperatures for each Day
        iteration=0
        for hour in day:
            if iteration==0:
                high=hour
                low=hour
                iteration+=1
            if hour>high:
                high=hour
            if hour<low:
                low=hour
        temp_tuple=high,low
        high_low_list.append(temp_tuple)
    #print(len(temp_list),len(list_of_days),len(high_low_list))
    month_end_list=[0,31,60,91,121,152,182,213,244,274,305,335,366]
    iteration=1
    current_month=1
    high=0
    low=0
    avg_highlow_list=list()
    for temptuple in high_low_list: #Calculates the average of the Highs and Lows per month
        if iteration in month_end_list:
            denom=month_end_list[current_month]-month_end_list[current_month-1]
            temporary_tuple=high/denom,low/denom
            avg_highlow_list.append(temporary_tuple)
            current_month+=1
            high=0
            low=0
        temphigh,templow=temptuple
        high+=float(temphigh)
        low+=float(templow)
        iteration+=1
    return avg_highlow_list
def plot1(avg_highlow_list): #Generates and saves first Graph
    '''Generates Floating Bar Graph of Avg High and Low per Month'''
    fig=plt.figure()
    highlist=list()
    lowlist=list()
    numlist=[1,3,5,7,9,11,13,15,17,19,21,23]
    for line in avg_highlow_list:
        high,low=line
        highlist.append(high)
        lowlist.append(low)
    plt.bar(numlist,highlist,bottom=lowlist)
    plt.ylabel('Average Temperature')
    plt.xticks(numlist,['January','February','March','April','May','June',
                        'July','August','September','October','November',
                        'December'],rotation=25)
    plt.xticks
    plt.title('Charleston,MO - 2012')
    plt.savefig('plot1.png')
    #plt.show()
def plot2(June_temp,June_rad): #Generates and saves second Graph
    '''Generates graph of avgerage hourly temperature and solar radiation for June 2012'''
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    t = np.arange(0, 24, 1)
    ax1.plot(t, June_temp, 'b.')
    ax1.plot(t, June_temp, 'b-')
    ax1.set_xlabel('Hour')
    ax1.set_ylabel('Average Temp', color='Blue')
    for tl in ax1.get_yticklabels():
        tl.set_color('Blue')
    ax2 = ax1.twinx()
    ax2.plot(t, June_rad, 'r.')
    ax2.plot(t, June_rad, 'r-')
    ax2.set_ylabel('Average Solar Radiation', color='Red')
    for tl in ax2.get_yticklabels():
        tl.set_color('Red')
    plt.title('Charleston,MO - June 2012')
    plt.savefig('Plot2.png')
    #plt.show()
def solar_stuff(rad_list,temp_list):
    '''Returns a tuple of the form temp_list,rad_list'''
    June_list=list()
    hour_avg=[100,200,300,400,500,600,700,800,900,1000,1100,1200,1300,1400,1500,1600,1700,1800,1900,2000,2100,2200,2300,2400]
    rad_sum_list=list()
    for i in range(0,len(rad_list)):
        if 3652<=i<=4371: # Finds Values for the Month of June based on Hours
            June_list.append(rad_list[i][:])
    for hour in hour_avg:                                                 # Averages the Values for each Hour using a nested for loop,
        sumval=0                                                          # June_list is iterated 24 times a a result
        for i in range(0,len(June_list)): # Runs through June_list        # If the data to be evaluated was very large I would use a dictionary
            if hour==int(June_list[i][3]):                                # instead; since the dictionary would need to be converted into a list  
                sumval+=float(June_list[i][4])                            # and the data for this project is not very large I kept the nested 
        rad_sum_list.append(sumval/30)                                    # for loop
    June_list=list()
    temp_sum_list=list()
    for i in range(0,len(temp_list)):
        if 3652<=i<=4371:
            June_list.append(temp_list[i][:])
    for hour in hour_avg:
        sumval=0
        for i in range(0,len(June_list)):
            if hour==int(June_list[i][3]):
                sumval+=float(June_list[i][4])
        temp_sum_list.append(sumval/30)
    return temp_sum_list,rad_sum_list
def main():
    '''Calls each Function'''
    temp_list=grab_temp()
    rad_list=grab_rad()
    avg_highlow_list=high_low_temp(temp_list)
    plot1(avg_highlow_list)
    June_temp,June_rad=solar_stuff(rad_list,temp_list)
    plot2(June_temp,June_rad)
    print("Graphs saved as Plot1 and Plot2 to Location of this Program")
main()
