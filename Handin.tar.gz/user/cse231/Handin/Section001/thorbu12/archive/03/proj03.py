# Section 1
# January 26th, 2013
# Project 3
# The following program simulates a vending machine
# by prompting the user for the cost of the item
# and then for the change to pay for it.
#
# The program consists of a while loop which contains
# a check on the user's input, and then two more
# nested while loops, one for when the user is
# depositing change, and the other to determine the
# amount of change the user is returned.
nickels=25
dimes=25
quarters=25
ones=0
fives=0
user_2=0
fives_ref = 0
ones_ref = 0
quarters_ref = 0
dimes_ref = 0 
nickels_ref = 0
while True :
    user_str = input("Please Enter the Cost of the Item(xx.xx) or press 'q' to quit: ")
    if user_str =="q":
        Stock=(nickels*.05 + dimes*.1 + quarters*.25 + ones*1 + fives*5)
        Stock_dol=Stock//1
        Stock_cent=round((Stock % 1)*100)
        print("Machine contains",Stock_dol,"Dollars And",Stock_cent,"Cents")
        break
    user_2=round((float(user_str))*100)
    if (user_2 < 0) or ((user_2 % 5) != 0) :
        print("Error, price must be positive and divisble by 5 cents")
        user_2=round((float(input("Please Enter the Cost of the Item(xx.xx) or press 'q' to quit: "))*100))
    print("Menu for deposits:\n'n' - deposit a nickel\n'd' - deposit a dime\n",
          "'q' - deposit a quarter\n'o' - deposit a one dollar bill\n'f' - deposit a five dollar bill\n'c' - cancel the purchase")
    payment = 0
    while payment < user_2 :
        deposit= input("Please deposit change:  ")
        if deposit == 'n':
            payment += 5
            nickels += 1
            if ((user_2 - payment)/100) >0:
                print("Remaining Due", (user_2 - payment)/100)
        elif deposit == 'd':
            payment += 10
            dimes += 1
            if ((user_2 - payment)/100) >0:
                print("Remaining Due", (user_2 - payment)/100)
        elif deposit == 'q':
            payment += 25
            quarters += 1
            if ((user_2 - payment)/100) >0:
                print("Remaining Due", (user_2 - payment)/100)
        elif deposit == 'o':
            payment += 100
            ones += 1
            if ((user_2 - payment)/100) >0:
                print("Remaining Due", (user_2 - payment)/100)
        elif deposit == 'f':
            payment += 500
            fives += 1
            if ((user_2 - payment)/100) >0:
                print("Remaining Due", (user_2 - payment)/100)
        elif deposit == 'c':
            print("Cancelling purchase,",payment/100, "to be deposited in change")
            user_2 = 0
            change= (payment - user_2)
            break
        else:
            print ("error, invalid input\n")
    else:
        change= (payment - user_2)
    fives_ref = 0
    ones_ref = 0
    quarters_ref = 0
    dimes_ref = 0 
    nickels_ref = 0        
    while change > 0 :
        if change // 25 > 0 and quarters >0:
            change -= 25
            quarters -= 1
            quarters_ref += 1
        elif change // 10 > 0 and dimes >0:
            change -= 10
            dimes  -= 1
            dimes_ref  += 1
        elif change // 5 > 0 and nickels >0:
            change -= 5
            nickels -= 1
            nickels_ref += 1
        else:
            if nickels_ref != 0 or dimes_ref != 0 or quarters_ref != 0 or ones_ref !=0 or fives_ref !=0:
                print("Please Take Change Below")
            else:
                print("No Change Due")
            if nickels_ref != 0 :
                print (nickels_ref, "nickels")
            if dimes_ref !=0:
                print(dimes_ref, "dimes")
            if quarters_ref !=0:
                print(quarters_ref,"quarters")
            if ones_ref !=0:
                print(ones_ref, "ones")
            if fives_ref !=0:
                print(fives_ref, "fives")
                
            print("Machine is out of change, see manager for remaining balance due of", (change/100)//1,"Dollars And",round(((change/100)%1)*100),"Cents")
            print("Machine Change Stock:\n nickels:",nickels,"\n dimes:",dimes,"\n quarters:",
            quarters,"\n ones:",ones,"\n fives:",fives,"\n")
            break
    else:
        if nickels_ref != 0 or dimes_ref != 0 or quarters_ref != 0 or ones_ref !=0 or fives_ref !=0:
            print("Please Take Change Below")
        else:
            print("No Change Due")
        if nickels_ref != 0 :
             print (nickels_ref, "nickels")
        if dimes_ref !=0:
            print(dimes_ref, "dimes")
        if quarters_ref !=0:
            print(quarters_ref,"quarters")
        if ones_ref !=0:
            print(ones_ref, "ones")
        if fives_ref !=0:
            print(fives_ref, "fives")
        print("Machine Change Stock:\n nickels:",nickels,"\n dimes:",dimes,"\n quarters:",
      quarters,"\n ones:",ones,"\n fives:",fives,"\n")
