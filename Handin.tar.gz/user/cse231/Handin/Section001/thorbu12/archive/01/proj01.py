print("Chris Thorburn \nSection 001H \nJanuary 9th 2013 \nProject 1")
num_str1 = input('Please enter a value on the Richter magnitude scale:')
num_float = float(num_str1)
print("Richter Value", num_str1, 
      "\nEquivalent Energy In Joules:",10**((1.5*num_float)+4.8),
      "\nEquivalent Tons of TNT:",(10**((1.5*num_float)+4.8)/(4.184*10**9)),
      "\n\nRichter Value:",1,
      "\nEquivalent Energy in Joules:",10**((1.5*1)+4.8),
      "\nEquivalent Tons of TNT:",(10**((1.5*1)+4.8)/(4.184*10**9)),
      "\n\nRichter Value:",5,
      "\nEquivelent Energy in Joules:",10**((1.5*5)+4.8),
      "\nEquivelent Tons of TNT:",(10**((1.5*5)+4.8)/(4.184*10**9)),
      "\n\nRichter Value:",9.1,
      "\nEquivalent Energy in Joules:",10**((1.5*9.1)+4.8),
      "\nEquivalent Tons of TNT:",(10**((1.5*9.1)+4.8)/(4.184*10**9)),
      "\n\nRichter Value:",9.2,
      "\nEquivelent Energy in Joules:",10**((1.5*9.2)+4.8),
      "\nEquivelent Tons of TNT:",(10**((1.5*9.2)+4.8)/(4.184*10**9)),
      "\n\nRichter Value:",9.5,
      "\nEquivalent Energy in Joules:",10**((1.5*9.5)+4.8),
      "\nEquivalent Tons of TNT:",(10**((1.5*9.5)+4.8)/(4.184*10**9)),)
      
