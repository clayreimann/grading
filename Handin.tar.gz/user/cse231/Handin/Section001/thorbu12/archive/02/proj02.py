  ##################################################################
  #  Section 1
  #  January 19th, 2013
  #  Computer Project #2
  #  The Following Program prompts the user for a solution to the Slayer word puzzle.
  #  The Program then checks their solution by calculating the 'Layers' value
  #  and determining whether this value matches the 'Slayer+Slayer+Slayer' value
  ##################################################################
user=int(input("Please guess what six digit number corresponds to 'slayer' \nif slayer+slayer+slayer must equal layers: "))
r= user%10
e=(user//10)%10
y=(user//100)%10
a=(user//1000)%10
l=(user//10000)%10
s=(user//100000)%10

slayer=(user+user+user)
layers=(s+10*r+100*e+1000*y+10000*a+100000*l)

if (slayer)==(layers) :
    print("Correct!")
    print("Your 'Slayer' value:",user,"\nSlayer+Slayer+Slayer:",slayer, "\nCalculated Layers:", layers)
    print(slayer,"equals",layers)
    
else :
    print("Sorry, try again")
    print("Your 'Slayer' value:",user,"\nSlayer+Slayer+Slayer:",slayer, "\nCalculated Layers:", layers)
    print(slayer,"does not equal",layers)
    
