# Section 1
# March 10th, 2013
# Project 7
# The following Program takes a text file and scrambles
# the interior letters of the words, in addition
# to leaving punctuation untouched.
#
# The program prompts the user for the name
# of the file they wish to write the scrambled
# text to, and the name of the text file to
# be scrambled.
import random
def scramble_word(word_str):  # Performs the scramble operation word by word
    iteration=0
    iteration2=0
    return_str=''
    Original_list=list(word_str)
    shuffle_list=list()
    shuffle_index=list()
    start_punct=0
    end_punct=0
    if Original_list[0].isalpha()==False:
            start_punct=1
    if Original_list[len(word_str)-1].isalpha()==False:
            end_punct=1
    for char in word_str:
        if iteration==1:
            if start_punct==1:
                iteration+=1
                continue
        if iteration==len(word_str)-2:
            if end_punct==1:
                iteration+=1
                continue
        if iteration > 0:
            if iteration!=len(word_str)-1:
                if char.isalpha():
                    shuffle_list.append(char)
                    shuffle_index.append(iteration)
        iteration+=1
    random.shuffle(shuffle_list)
    for index in shuffle_index:
        Original_list[index]=shuffle_list[iteration2]
        iteration2+=1
    return_str=''.join(Original_list)
    return return_str
def scramble_line(line_str): # Takes the text file and returns a list
                             # composed of each word
    line_list=list()
    word_list=list()
    word_1=''
    iteration_line=0
    iteration_word=0
    for line in line_str:
        line=line.strip()
        iteration_line+=1
        for word in line:
            iteration_word+=1
            if word != ' ':
                word_1+=word
            else:
                if len(word_1) > 3:
                    word_1=scramble_word(word_1)
                word_list.append(word_1)
                if iteration_word < len(line):
                    word_1=''
            if iteration_word==len(line):
                if len(word_1) > 3:
                    word_1=scramble_word(word_1)
                word_list.append(word_1)
    line_str.close()
    return ' '.join(word_list)
def open_read_file(): # Prompts for the file until a valid name is entered
    while True:
        try:
            file_name=input("Please give me the name of the file you wish to open: ")
            file_object=open(file_name, "r")
            break
        except FileNotFoundError:
            print("File Not found, please enter a valid file name")
    return file_object
def main(): # Begins program, handles writing the text to a file and
            # calls on the programs in the required order
    print("This program will read a text file, scramble the interior letters of the word, and write a new text file")
    write_file=input("What would you like to name the scrambled file?: ")+'.txt'
    file=open_read_file()
    scrambled=scramble_line(file)
    print("The following will be saved as",write_file)
    print(scrambled)
    file_to_write=open(write_file,"w")
    file_to_write.write(scrambled)
    file_to_write.close()
main()
    
