# Section 1
# February 11th, 2013
# Project 5
# The Following program prompts the user for the
# number of hexagons n in a n x n tesselation, and then
# for two colors with which to alternate between the rows
#
# Note that the way in which the program draws the tesselation
# causes overlap during the drawing, but does not effect the end image.
import turtle
import time
import math

def color_options():
    print("Choose two colors from the following:\n'red'\n'blue'\n'green'")
def get_num_hexagons():
    while True:
        user_num=input("Please Enter a Value between 4 and 20: ")
        if user_num.isdigit():
            user_num=int(user_num)
            if user_num >= 4 and user_num <= 20:
                break
            else:
                print("Error, input must be between 4 and 20")
                continue
        else:
            print("Errory, input must be an integer")
            continue
    return user_num

def get_color_choice1():
    while True:
        color_options()
        user_color1=input("Please choose the first color for the Tesselation: ")
        if user_color1 == 'red' or user_color1 == 'blue' or user_color1 == 'green':
            break
        else:
            print("Error, invalid color choice for Color 1")
            continue
    return user_color1
def get_color_choice2():
    while True:
        user_color2=input("Please choose the second color for the Tesselation: ")
        if user_color2 == 'red' or user_color2 == 'blue' or user_color2 == 'green':
            break
        else:
            print("Error, invalid color choice for Color 2")
            continue
    return user_color2
def draw_hexagon(x,y,side_len,pen,color):
    turtle.speed(9001)
    turtle.pencolor(0,0,0)
    turtle.up()
    turtle.goto(x,y)
    turtle.fillcolor(color)
    turtle.begin_fill()
    turtle.seth(90)
    turtle.down()
    turtle.forward(side_len)
    turtle.seth(90+60)
    turtle.forward(side_len)
    turtle.seth(90+2*60)
    turtle.forward(side_len)
    turtle.seth(90+3*60)
    turtle.forward(side_len)
    turtle.seth(90+4*60)
    turtle.forward(side_len)
    turtle.seth(90+5*60)
    turtle.forward(side_len)
    turtle.end_fill()
def draw_Tesselation(grid_num,Color1,Color2,s,L1,L2):
    w=0
    p=1
    o=.5-(.5*p)
    while w <= L1:
        z=0
        x=(250/grid_num)*o
        y=((250*math.sqrt(3))/grid_num)*w
        s=(500/(math.sqrt(3)*hexagon_num))
        while z <= L1:
            if p==1:
                color=Color1
            else:
                color=Color2
            draw_hexagon(x,y,s,turtle,color)
            z+=1
            x+=(500/grid_num)
        else:
            x=(250/grid_num)*o
            z=0
        while z < L2:
            if p==1:
                color=Color1
            else:
                color=Color2
            draw_hexagon(x,y,s,turtle,color)
            z+=1
            x-=(500/grid_num)
        else:
            x=(250/grid_num)*o
            z=0
        w+=1
        p=-p
        o=.5-(.5*p)
    else:
        w=0
        p=1
        o=.5-(.5*p)
        while w < L2:
            z=0
            x=(250/grid_num)*o
            y=((250*math.sqrt(3))/grid_num)*-w
            s=(500/(math.sqrt(3)*hexagon_num))
            while z <= L1:
                if p==1:
                    color=Color1
                else:
                    color=Color2
                draw_hexagon(x,y,s,turtle,color)
                z+=1
                x+=(500/grid_num)
            else:
                x=(250/grid_num)*o
                z=0
            while z < L2:
                if p==1:
                    color=Color1
                else:
                    color=Color2
                draw_hexagon(x,y,s,turtle,color)
                z+=1
                x-=(500/grid_num)
            else:
                x=(250/grid_num)*o
                z=0
            w+=1
            p=-p
            o=.5-(.5*p)
        else:
            w=0
            p=1
            o=.5-(.5*p)


hexagon_num=get_num_hexagons()
color1=get_color_choice1()
color2=get_color_choice2()
right_of_center=hexagon_num//2
left_of_center=hexagon_num - hexagon_num//2
S=((500/math.sqrt(3))*hexagon_num)
        
draw_Tesselation(hexagon_num,color1,color2,S,left_of_center,right_of_center)

        


