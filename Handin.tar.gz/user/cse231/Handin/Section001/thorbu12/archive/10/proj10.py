# Section 1
# March 7th, 2013
# Project 10
# 
# The following program will print a Flag
# using an input file, provided the format
# of the file is as specified in the project
# description 
# 
# As docstrings were used '#' Annotation
# is minimal compared to previous projects
#

import turtle
import time
class Star(object):
    '''
Star Class. Takes the Parameters x,y,arm_length,color
'''
    def __init__(self,x,y,arm_length,color):
        '''
Set Constructor. Generates the x,y variables as well as the start point
'''
        self.start=(int(x)+(float(arm_length)/3.236)),(int(y)+(float(arm_length)/2.35))
        self.x=int(x)
        self.y=int(y)
        self.arm=int(arm_length)
        self.color=color.strip()
    def draw(self,turtle): #Note that turtle was passed in the main function as pen and is not a global variable
        '''
Draws the Provided Star using Turtle
'''
        turtle.up()
        turtle.color(self.color)
        turtle.goto(self.start)
        turtle.seth(0)
        turtle.down()
        turtle.begin_fill()
        turtle.forward(self.arm)
        turtle.seth(216)
        turtle.forward(self.arm)
        turtle.seth(288)
        turtle.forward(self.arm)
        turtle.seth(144)
        turtle.forward(self.arm)
        turtle.seth(216)
        turtle.forward(self.arm)
        turtle.seth(72)
        turtle.forward(self.arm)
        turtle.seth(144)
        turtle.forward(self.arm)
        turtle.seth(0)
        turtle.forward(self.arm)
        turtle.seth(72)
        turtle.forward(self.arm)
        turtle.seth(288)
        turtle.end_fill()
    def __str__(self):
        '''
Returns a single Line String with specifications of the Star
'''
        return ('%s%s%s%s%s%s%s%s%s'% ('Star ','x:',self.x,' y:',self.y,' arm:',self.arm,' color:',self.color))
class Rectangle(object):
    '''
Rectangle Class. Takes the parameters x,y,width,height,color
'''
    def __init__(self,x,y,width,height,color):
        '''
Set Constructor. Creates the vertices variables for .draw to utilize
'''
        self.x=int(x)
        self.y=int(y)
        self.width=int(width)
        self.height=int(height)
        self.color=color.strip()
        self.vert1=int(x)-.5*int(width),int(y)+.5*int(height)
        self.vert2=int(x)+.5*int(width),int(y)+.5*int(height)
        self.vert3=int(x)+.5*int(width),int(y)-.5*int(height)
        self.vert4=int(x)-.5*int(width),int(y)-.5*int(height)
    def draw(self,turtle): #Note that turtle was passed in the main function as pen and is not a global variable
        '''
Draws the Rectangle Using Turtle
'''
        turtle.up()
        turtle.goto(self.vert1)
        turtle.color(self.color)
        turtle.down()
        turtle.begin_fill()
        turtle.goto(self.vert2)
        turtle.goto(self.vert3)
        turtle.goto(self.vert4)
        turtle.goto(self.vert1)
        turtle.end_fill()
    def __str__(self):
        '''
Returns a single line string containing the specifications for the Rectangle
'''
        return '%s%s%s%s%s%s%s%s%s%s'%('Rectangle: x:',self.x,' y:',self.y,' width:',self.width,' height:',self.height,' color:',self.color)
class Flag(object):
    '''
Flag Class. Requires Star and Rectangle Class to Work
'''
    def __init__(self,file_object):
        '''
Reads the file and seperates the star and rectangle specifications into two lists
'''
        self.list_of_lines=list()
        self.rectangle_list=list()
        self.star_list=list()
        line_count=0
        for line in file_object:
            line=line.strip()
            if line_count==0:
                rect_num=int(line)
            if line_count==rect_num+1:
                star_num=int(line)
            self.list_of_lines.append(line)
            line_count+=1
        for i in range(0,rect_num):
            self.rectangle_list.append(self.list_of_lines[i+1])
        for i in range(0,star_num):
            self.star_list.append(self.list_of_lines[i+rect_num+2])
        for i in range(0,len(self.rectangle_list)):
            x,y,width,height,color=self.rectangle_list[i].split(',')
            self.rectangle_list[i]=Rectangle(x,y,width,height,color)
        for i in range(0,len(self.star_list)):
            x,y,arm_length,color=self.star_list[i].split(',')
            self.star_list[i]=Star(x,y,arm_length,color)
    def draw(self,turtle): #Note that turtle was passed in the main function as pen and is not a global variable
        '''
Calls draw for the star and rectangle Class
'''
        for i in range(0,len(self.rectangle_list)):
            self.rectangle_list[i].draw(turtle)
        for i in range(0,len(self.star_list)):
            self.star_list[i].draw(turtle)
    def __str__(self):
        '''
Returns a multi-line string containing specifications of all rectangles and stars involved
'''
        self.print_str='"Rectangles\n'
        for i in range(0,len(self.rectangle_list)):
            self.print_str+=(str(self.rectangle_list[i]))
            self.print_str+='\n'
        self.print_str+='Stars\n'
        for i in range(0,len(self.star_list)):
            self.print_str+=(str(self.star_list[i]))
            if i==len(self.star_list)-1:
                self.print_str+='"'
            self.print_str+='\n'
        return self.print_str
def main():
    '''
Sets up turtle and calls on the Flag Class
'''
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()
    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()
main()


