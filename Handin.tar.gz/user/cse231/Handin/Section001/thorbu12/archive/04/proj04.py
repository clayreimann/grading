# Section 1
# February 2nd, 2013
# Project 4
# The following program prompts the user for two
# alphabetical sequences and then allows the user to
# score the number of matches/mismatches between the
# two or add and remove indels with the intent of
# improving the scoring.
#
# The program consists of two while loops. The first
# loop checks that the sequences are of alphabetical
# characters only and also adds indels to the ends
# of the  sequences if they are not of the
# same length to begin with.
#
# The second while loop consists of an if/elif/elif/elif/else
# boolean set; the first two booleans each contain
# a second nested if/elif/else set and a while
# loop. The third boolean runs the scoring command and
# consists of a for loop with an if/else set nested
# in the for loop. The second-to-last boolean is the quit
# command and the final boolean is only used if an invalid command was entered 
while True:
    print("Please give me two sequences of alphabetical characters to compare of whatever length you want")
    print("After entering the two sequences you will be able to compare the two and add or delete indels as you see fit")
    prompt_1=input("Give me the first sequence: ")
    prompt_2=input("Give me the second sequence: ")
    inttest=0
    for inttest_1 in prompt_1:
        if inttest_1.isalpha()==False:
            print("Error, input must be composed of alphabetical characters")
            inttest+=1
    for inttest_2 in prompt_2:
        if inttest_2.isalpha()==False:
            print("Error, input must be composed of alphabetical characters")
            inttest+=1
    if inttest ==0:
        string_1=prompt_1.lower()
        string_2=prompt_2.lower()
        while len(string_1) != len(string_2):
            if len(string_1) < len(string_2):
                string_1=string_1 + '-'
            if len(string_2) < len(string_1):
                string_2=string_2 + '-'
        break

while True:
    user_choice=input("What do you want to do:\na (add indel)\nd (delete indel)\ns (score)\nq (quit)\n\n: ")
    if user_choice =='a':
        string_choice=input("Which string do you want to work on. 1 or 2?: ")
        if string_choice =='1':
            print("Working on String 1")
            location_choice=int(input("Before which index do you wish to add an indel?: "))
            string_1=string_1[:(location_choice_int)] + '-' + string_1[(location_choice_int):]
        elif string_choice=='2':
            print("Working on String 2")
            location_choice=int(input("Before which index do you wish to add an indel?: "))
            string_2=string_2[:(location_choice)] + '-' + string_2[(location_choice):]
        else:
            print("Error, input must be '1' or '2'")
            continue
        while len(string_1) != len(string_2):
            if len(string_1) < len(string_2):
                if string_2[-1] =='-':
                    string_2=string_2[:-1]
                else:
                    string_1=string_1 + '-'
            if len(string_2) < len(string_1):
                if string_1[-1] =='-':
                    string_1=string_1[:-1]
                else:
                    string_2=string_2 +'-'
    elif user_choice =='d':
        string_choice=input("Which string do you want to work on. 1 or 2?: ")
        if string_choice =='1':
            print("Working on String 1")
            location_choice=int(input("What is the index of the indel you wish to delete?: "))
            if string_1[location_choice] != '-':
                print("Error, you can only delete indels")
                continue
            string_1=string_1[:(location_choice)] + string_1[(location_choice+1):]
            continue
        elif string_choice =='2':
            print("Working on String 2")
            location_choice=int(input("What is the index of the indel you wish to delete?: "))
            if string_2[location_choice] != '-':
                print("Error, you can only delete indels")
                continue
            string_2=string_2[:(location_choice)] + string_2[(location_choice+1):]
        else:
            print("Error, input must be '1' or '2'")
        while len(string_1) != len(string_2):
            if len(string_1) < len(string_2):
                if string_2[-1] =='-':
                    string_2=string_2[:-1]
                else:
                    string_1=string_1 + '-'
            if len(string_2) < len(string_1):
                if string_1[-1] =='-':
                    string_1=string_1[:-1]
                else:
                    string_2=string_2 +'-'
    elif user_choice =='s':
        print("Scoring Now")
        iteration=0
        Matches=0
        Mismatches=0
        string_scored_1=string_1[:].upper()
        string_scored_2=string_2[:].upper()
        for string1_score in string_1:
            string2_score=string_2[iteration]
            if string1_score == string2_score:
                Matches+=1
                string_scored_1=string_scored_1[:iteration] + string1_score.lower() + string_scored_1[iteration+1:]
                string_scored_2=string_scored_2[:iteration] + string2_score.lower() + string_scored_2[iteration+1:]
            else:
                Mismatches+=1
            iteration+=1
        print("Matches",Matches,"\nMismatches",Mismatches)
        print("Sequence 1",string_scored_1,"\nSequence 2",string_scored_2)
                
    elif user_choice =='q':
        print("Program is now quitting")
        break
    else:
        print("Error, input was not valid, please try again")
        continue
        
        
    

    
