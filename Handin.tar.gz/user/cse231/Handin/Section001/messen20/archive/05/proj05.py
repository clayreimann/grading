#Section 1
#Project 5: Hexagons
#2/10/13


import turtle
import math

def get_num_hexagons(): #Function to get the number of hexagons wanted by user
    while True:
        num = input("Please enter a number of hexagons per row (4-20): ")
        num = int(num) #Get the number as a string and convert it to an int
        if num >=4 and num <=20:
            return num
            break
        else:
            print("Invalid number, try again")
            continue
        # if the number is in the designated range, accept it
        # else, try again until it is correct

def get_color_choice(): #Function to get the color wanted by the user
    while True:
        color = input("Please give a color for the hexagons: ")
        if color == "yellow" or color == "red" or color == "green" or \
           color == "blue":
            return color #If the color is one of the colors available, break the loop and return the value
            break
        else:
            print("Invalid color, try again")
            continue #If not valid, try again until it is

def draw_hexagon(x, y, side_length, pen, color): #Function that draws one hexagon
    pen.speed(10) #Speed up the pen
    pen.up() #Pick up the pen
    pen.goto(x,y) #Pen goes to desired location
    pen.color("black")#Gives black outline to hexagon 
    pen.down()
    pen.begin_fill()#Begins to fill the object
    pen.goto( x+side_length*math.sin(math.pi/3), \
              y+side_length*math.cos(math.pi/3)) #moves to the first hexagon point
    pen.goto(x+side_length*math.sin(math.pi/3), \
             y+side_length*math.cos(math.pi/3)+side_length)
    pen.goto(x, y+2*side_length*math.cos(math.pi/3)+side_length) #Moves to the second hexagon point
    pen.goto(x- side_length*math.sin(math.pi/3), \
             y+side_length*math.cos(math.pi/3)+side_length) #Moves to the third hexagon point
    pen.goto(x- side_length*math.sin(math.pi/3), \
             y+side_length*math.cos(math.pi/3)) #Moves to the fourth hexagon point
    pen.goto(x,y) #Goes back to original point
    pen.color(color) #Sets the fill color
    pen.end_fill() #Fills the object
    pen.up() #Picks up the pen to make sure it does not draw anywhere else

def draw_grid(x,y): #Draws the grid starting at coordinate x,y
    row = 0 #tracks number of rows
    column = 0 #tracks number of columns
    color_index = 1 #tracks the color to allow alternation
    column_index = 0 #tracks the column to know how to shift 
    column_index2 = 1 #tracks the column to help get diagonal colors
    num = get_num_hexagons() #Get the user input for the number of hexagons
    width = 500/num #Width of each hexagon
    side_length = (width/2)/math.cos(math.pi/6) #Side length calculated for each hexagon
    color = get_color_choice() #First Color choice
    color_2 = get_color_choice() #Second color choice
    intermediate_var = 0 #Intermediate variable for color swap
    
    while column < num: #While there aren't as many columns as requested
        n_initial = x
        m_initial = y #Sets the initial position so it can be shifted later
        while row < num: #While the number of hexagons in the row are less than the prompted number
            if color_index % 2 == 1:#if the index is even
                draw_hexagon(x,y, side_length, turtle, color)
                x += width #draws it, then moves over one width
                row +=1 #Adds to the row index
                color_index +=1#Adds to the color index
            else:#If index is odd, makes it so every other cell is a differing color
                draw_hexagon(x,y, side_length, turtle, color_2)
                x+= width #Draws it then moves it
                row +=1
                color_index +=1 #Adds to the indexes
        else:#when the loop is done
            column +=1
            row = 0 #Reset the row index, add one to the column counter
            if column_index%2 == 0: #If column index is even
                x= n_initial+side_length*math.sin(math.pi/3)
                y= m_initial+side_length*math.cos(math.pi/3)+side_length
                column_index +=1 #Moves it to the position for the next row
            else: #If column index is odd
                x = n_initial-side_length*math.sin(math.pi/3)
                y = m_initial+side_length*math.cos(math.pi/3)+side_length
                column_index +=1 #Moves it to the other position for the rows
            if column_index2 == 0: #If the column index 2 is zero
                intermediate_var = color
                color = color_2
                color_2= intermediate_var
                column_index2 = 1 #swaps the colors
            else: #If the column index 2 is not zero
                column_index2=0
            
                

draw_grid(-150,-150)



              
