import string

def fill_completions(my_obj, my_dict):
    for my_line in my_obj:
        my_line = my_line.strip()
        my_list = my_line.split(" ")
        for my_word in my_list:
            my_word = my_word.lower()
            for obj in my_word:
                if obj in string.punctuation or obj in string.digits or len(my_word) ==1:
                    my_word = ""
            for letter in my_word:
                if (my_word.index(letter), letter) not in my_dict:
                    my_dict[(my_word.index(letter), letter)] = {my_word}
                else:
                    my_dict[(my_word.index(letter), letter)].add(my_word)
    
                
def find_completions(prefix, my_dict):
    prefix = list(prefix)
    my_list2 = []
    count = 0
    for obj in prefix:
        my_key = count, obj
        if my_key in my_dict.keys():
            my_list2.append(my_dict[my_key])
        count +=1
    new_set = set(my_list2[0])
    for obj in range(1,len(my_list2)):
        new_set &= my_list2[obj]
    my_list3 =  list(new_set)
    my_str = ", ".join(my_list3)
    return my_str
                
        
def main():               
    my_dict = {}
    my_file = open("ap_docs.txt", "r")
    fill_completions(my_file, my_dict)
    while True:
        prefix = input("Give me a prefix, or enter '#' to quit: ")
        if prefix != "#":
            my_str = find_completions(prefix, my_dict)
            if my_str == "":
                print("No completions known, try again")
            else:
                print("Possible matches: " + my_str)
        else:
            break

main()
