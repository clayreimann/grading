#Section 1
#Project 7
#2/27/13

import random
import string
# import the string and random module for later use

def scramble_word(word_str): #scrambles a single word
    if word_str == "": #if the word is "" (blank) returns that same ""
        return word_str
    else: #else
        my_word = word_str.strip() #strips the word of any extraneous characters
        my_list = list(my_word) #list of all of the characters in the word
        my_list2 = my_list[:] #second list equivalent to the first list
        my_length = len(my_list) #length of the list
        for obj in my_list2:#for every character in the word list
            if obj in string.punctuation:
                my_list2.remove(obj) #removes the character if it is punctuation
        my_shuffled_letters = my_list2[1:-1] #everything but the first and last letter
        random.shuffle(my_shuffled_letters) #randomizes those letters
        if my_list2 != [] and my_length != 1: #if there are letters in my_list2 ie. my_list
            # wasn't all punctuation and it isn't a one letter word
            my_shuffled_letters = my_list2[0] + ''.join(my_shuffled_letters) + my_list2[-1] #adds back the first and last letters
            if my_shuffled_letters == my_word: #if it shuffles back to the same word, return the first word (for two letter word detection)
                return my_word
            else:
                my_shuffled_letters = list(my_shuffled_letters) #list the letters of the word
                count = 0 #counter variable
                for obj in my_list:
                    if obj in string.punctuation: #if the original list obj is punctuation
                        my_shuffled_letters.insert(count, obj) #insert the punctuation in its original position
                    count += 1
                my_word2 = ''.join(my_shuffled_letters) #joins the list
                return my_word2 #sends out my_word2, the shuffled word
        else:
            return my_word #sends out the original word
            
        

def scramble_line(line_str): # scrambles a whole line of text
    my_line = line_str.strip() #strips the extraneous characters off the line
    my_list = my_line.split(" ") #splits the line into a list based on spaces
    count = 0 # count variable
    for obj in my_list: # every obj in the list
        my_list[count] = scramble_word(obj) #replaces the object with the scrambled word
        count +=1 #increases count
    my_line = " ".join(my_list) #joins the list back together using spaces
    return my_line #returns the scrambled line

def open_read_file(file_name_str): #opens only a valid file
    x = True #true variable
    while x == True: #while the true variable is true
        try:
            file_obj = open(file_name_str, "r") #opens the file to read
            x = False #sets x to false, breaks the loop
        except IOError: #if the file doesn't open
            print("Try again, invalid file name")
            file_name_str = input("What file do you wish to scramble?") #try again
    return file_obj #returns the whole file object

def main(): #main function of program
    file_name_str = input("What file do you wish to scramble? ") #gets the file name
    file_obj = open_read_file(file_name_str) #tests to see if it will open, if it doesn't, it will try again
    file_out_list = file_name_str.split(".") #splits the file name
    file_out = file_out_list[0] + "scrambled." + file_out_list[-1] #adds scrambled to the file name
    file_out_obj = open(file_out, "w") #opens file scrambled for writing
    for line in file_obj:#for every line inside the reading file obj
        my_line = scramble_line(line) #scrambles the line
        file_out_obj.write(my_line + "\n") #writes the line in the out file obj
    file_obj.close() #closes the reading file
    file_out_obj.close() #closes the writing file

main()
            
