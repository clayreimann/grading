#Section 1: Lab 11: GPS
#4/14/13

import urllib.request
import string

class Tour(object):
    def __init__(self, *cities):
        """ Constructs a Tour. Creates a tuple of the cities on the tour,
        then converts the tuple into a list of the cities in the format that
        is used in the url for googlemaps"""
        self.cities = cities
        cities_list = []
        for obj in cities:
            city = obj.split(", ")
            for obj in city:
                city_name = obj.split(" ")
                city[city.index(obj)] = "+".join(city_name)
            city = "+".join(city)
            cities_list.append(city)           
        self.cities_list = cities_list

    def distance(self,mode="driving"):
        """Using the instance of the tour, parses the output of the url request to find
        to find the distance for that leg of the tour, and then repeats for every
        leg of the tour"""
        count = len(self.cities_list)
        distance = 0
        for obj in range(0, count-1):
            web_obj =urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&mode={}&sensor=false".format(self.cities_list[count-2], self.cities_list[count-1], mode))
            results_str = str(web_obj.read())
            web_obj.close()
            results_list = results_str.split("\\n")
            my_str = ""
            for obj in results_list[9]:
                if obj in string.digits:
                    my_str += obj
            if my_str == "":
                raise ValueError("No distance found")
            else:
                distance += int(my_str)
            count -=1
        return distance

    def __str__(self):
        """Returns a string of the obj in a presentable format"""
        my_list = []
        for obj in self.cities:
            my_list.append(obj)
        my_str = "; ".join(my_list)
        return my_str

    def __repr__(self):
        """Returns a string of the obj in a presentable format for the console"""
        my_list = []
        for obj in self.cities:
            my_list.append(obj)
        my_str = "; ".join(my_list)
        return my_str

    def __add__(self, tour):
        """Allows you to add destinations from one tour to the end of another tour,
        then returns a new tour of those destinations"""
        my_list = []
        for obj in self.cities:
            my_list.append(obj)
        for obj in tour.cities:
            my_list.append(obj)
        my_tuple = tuple(my_list)
        t = Tour()
        t.cities = my_tuple
        cities_list = []
        for obj in my_tuple:
            city = obj.split(", ")
            for obj in city:
                city_name = obj.split(" ")
                city[city.index(obj)] = "+".join(city_name)
            city = "+".join(city)
            cities_list.append(city)
        t.cities_list = cities_list
        return t

    def __mul__(self, p_int):
        """Repeats the tour for the specified number of times, using the
        same destinations"""
        if type(p_int) != int:
            raise TypeError("Must be an int to multiply")
        elif p_int < 0:
            raise ValueError("Must be positive")
        else:
            my_str = ":".join(self.cities_list)
            my_str += ":"
            my_str *= p_int
            self.cities_list = my_str.split(":")
            self.cities_list.pop()
            my_list = []
            for count in range(0,p_int):
                for obj in self.cities:
                    my_list.append(obj)
            my_tuple = tuple(my_list)
            t = Tour()
            t.cities = my_tuple
            t.cities_list = self.cities_list
            return t

        for obj in cities:
            city = obj.split(", ")
            for obj in city:
                city_name = obj.split(" ")
                city[city.index(obj)] = "+".join(city_name)
            city = "+".join(city)
            cities_list.append(city)  


    def __rmul__(self, p_int):
        """Multiplies in the opposite order"""
        value = self.__mul__(p_int)
        return value

    def __gt__(self, tour):
        """specifies whether one tour's distance is greater than anothers"""
        if self.distance() > tour.distance():
            return True
        else:
            return False

    def __lt__(self,tour):
        """Specifies whether one tour's distance is less than another's"""
        if self.distance() < tour.distance():
            return True
        else:
            return False

    def __eq__(self, tour):
        """Specifies whether one tour's distance is equal to another's"""
        if self.cities_list == tour.cities_list:
            return True
        else:
            return False

def main():
    """Goes through to present all of the functions"""
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2: {}\nt3: {}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(
    round(t1.distance()/1000), round(t1.distance('bicycling')/1000),
    round(t1.distance('walking')/1000)))
    print(t2.distance())
    print("Using driving distances from here on.")
    t4 = t1 + t2
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t4 == t1 + t2:", t4 == t1 + t2)
    print("t4 > t1:", t4>t1)
    print("t2 < t4:", t2<t4)
    print("t1:", t1, "\nDistance: ", t1.distance())
    print("t1*2:", t1*2, "\nDistance: ", (t1*2).distance())
    print("t4:", t4)
    print("5*t4:", 5*t4)

main()
