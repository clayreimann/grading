#Section 1: Project 10
#4/6/13

import turtle
import time

class Rectangle(object): #Class describing a rectangle
    def __init__(self, x, y, width, height, color = "black"):
        """Sets the rectangle's height, width, color, and center
           coordinates"""
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def draw(self, pen):
        """Draws the instance rectangle based on its characteristics using turtle"""
        pen.up()
        pen.goto(self.x+self.width/2, self.y + self.height/2)
        pen.seth(270)
        pen.down()
        pen.fillcolor(self.color)
        pen.pencolor(self.color)
        pen.begin_fill()
        pen.forward(self.height)
        pen.right(90)
        pen.forward(self.width)
        pen.right(90)
        pen.forward(self.height)
        pen.right(90)
        pen.forward(self.width)
        pen.end_fill()


    def __str__(self):
        """Returns a string detailing the characteristics of the rectangle"""
        return "Rectangle x:{}, y:{}, width:{}, height:{}, color:{}".format(self.x,self.y,self.width,self.height,self.color)

class Star(object): #Class describing a five pointed symetrical star
    def __init__(self, x,y,arm_length,color="black"):
        """Creates a star instance with a certain arm length, color, and center point"""
        self.x = x
        self.y= y
        self.arm_length = arm_length
        self.color = color

    def draw(self, pen):
        """Draws the five pointed star using turtle and geometry to find the next points"""
        pen.up()
        pen.goto(self.x+self.arm_length/3.236, self.y+self.arm_length/2.35)
        pen.seth(0)
        pen.down()
        pen.fillcolor(self.color)
        pen.pencolor(self.color)
        pen.begin_fill()
        count = 0
        pen.forward(self.arm_length)
        while count < 5:
            pen.right(144)
            pen.forward(self.arm_length)
            pen.left(72)
            pen.forward(self.arm_length)
            count +=1
        pen.end_fill()

    def __str__(self):
        """Returns a string describing the star's characteristics"""
        return "Star x:{}, y:{}, arm:{}, color:{}".format(self.x,self.y,self.arm_length,self.color)

class Flag(object):
    def __init__(self,f_obj):
        """Defines the characteristics of the flag. Has three main values
associated with the object: the file obj of the flag, a dictionary containing
rectangles, and a dictionary containing stars """
        self.f_obj = f_obj
        rect_dict = {}
        star_dict = {}
        my_line = self.f_obj.readline()
        my_int = int(my_line.strip())
        count = 0
        while count < my_int:
            my_rect_coords = (self.f_obj.readline()).strip()
            my_list = my_rect_coords.split(",")
            for obj in my_list:
                my_list[my_list.index(obj)] = obj.strip()
            my_rect = Rectangle(int(my_list[0]), int(my_list[1]), int(my_list[2]), int(my_list[3]), my_list[4])
            rect_dict[count] = my_rect
            count+=1
        my_line = self.f_obj.readline()
        my_int = int(my_line.strip())
        count = 0
        while count < my_int:
            my_star_coords = (self.f_obj.readline()).strip()
            my_list = my_star_coords.split(",")
            for obj in my_list:
                my_list[my_list.index(obj)] = obj.strip()
            my_star = Star(int(my_list[0]), int(my_list[1]), int(my_list[2]), my_list[3])
            star_dict[count] = my_star
            count+=1
        self.rect_dict = rect_dict
        self.star_dict = star_dict

    def draw(self, pen):
        """Draws every item in the rectangle dictionary, then every item in the star dictionary"""
        for obj in self.rect_dict:
            self.rect_dict[obj].draw(pen)
        for obj in self.star_dict:
            self.star_dict[obj].draw(pen)
        pen.up()
        pen.goto(-500,500)

    def __str__(self):
        """Returns a string formating the rectangles attributes and star attributes into a multiline
string"""
        my_str = "Rectangles \n"
        for obj in self.rect_dict:
            x = self.rect_dict[obj].x
            y = self.rect_dict[obj].y
            w = self.rect_dict[obj].width
            h = self.rect_dict[obj].height
            c = self.rect_dict[obj].color
            my_str += "x:{}, y:{}, w:{}, h:{}, c:{} \n".format(x,y,w,h,c)
        my_str += "Stars \n"
        for obj in self.star_dict:
            x = self.star_dict[obj].x
            y = self.star_dict[obj].y
            a = self.star_dict[obj].arm_length
            c = self.star_dict[obj].color
            my_str += "x:{}, y:{}, a:{}, c:{} \n".format(x,y,a,c)
        return my_str
            
        
def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag) #Prints the flag of Senegal
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag) #Prints the flag of Panama
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)   #delay so you can see your flag
    turtle.clearscreen()
    usa_file = open('myFlag.txt')
    usa_flag = Flag(usa_file)
    print(usa_flag) #Prints the Great Star Flag of 1818
    usa_flag.draw(pen)
    usa_file.close()
    
main()
