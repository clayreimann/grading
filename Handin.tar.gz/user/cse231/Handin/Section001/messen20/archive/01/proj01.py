#Section 1
#Project 1

num_str = input("Insert Richter Scale Measurement (Must be a number): ") #Ask user for Richter Measurement
num_float = float(num_str)

j = 10**((1.5*num_float)+4.8) #Convert measurement entered to Joules then to Tons of TNT
t = j/(4.184e9)

print("Richter Measure: ", num_float)
print("Equivalence in Joules: ", j)
print("Equivalence in Tons of TNT: ", t)

print()
print("Richter            Joules                          TNT")

num_float = 1 #Reset num_float to values required for the table by reprinting the previous code with the wanted value.
j = 10**((1.5*num_float)+4.8)
t = j/(4.184e9)
print(num_float, "          ", j, "           ", t)


num_float = 5
j = 10**((1.5*num_float)+4.8)
t = j/(4.184e9)
print(num_float, "          ", j, "           ", t)

num_float = 9.1
j = 10**((1.5*num_float)+4.8)
t = j/(4.184e9)
print(num_float, "        ", j, "        ", t)

num_float = 9.2
j = 10**((1.5*num_float)+4.8)
t = j/(4.184e9)
print(num_float, "        ", j, "        ", t)

num_float = 9.5
j = 10**((1.5*num_float)+4.8)
t = j/(4.184e9)
print(num_float, "        ", j, "       ", t)
