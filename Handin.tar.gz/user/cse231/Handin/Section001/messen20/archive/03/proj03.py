#Section 1
#1/22/13
#Lab 3: Vending Machine

print("Welcome to the vending maching change make program!")
print("Change maker initialized!!")

n = 25 #nickels
d = 25 #dimes
q = 25 #quarters
o = 0 # One dollar
f = 0 # Five dollars
total = n*5 + d*10 + q*25 + o*100 +f*500
# Declare the variables for all the coins, dollars, and total

print("Stock contains: ")
print("   ", n, " nickels")
print("   ", d, " dimes")
print("   ", q, " quarters")
print("   ", o, " ones")
print("   ", f, " fives") #Print the amount of cash in register
print()

while True: #Continues until broken

    price_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")
 #Ask for the price of the object
    if price_str == "q":
        break #end it because of user input
    else:
        price = round(float(price_str)*100) #Converts price to be only in cents
        
    if price%5 != 0:
        print("Illegal price: Must be a non-negative multiple of 5 cents.")
        print()
        continue #back to start to reinput a valid price

    else:
        print()
        print("Menu for deposits:")
        print("  'n' - deposit a nickel")
        print("  'd' - deposit a dime")
        print("  'q' - deposit a quarter")
        print("  'o' - deposit a one dollar bill")
        print("  'f' - deposit a five dollar bill")
        print("  'c' - cancel the purchase")
        print() #Print out the menu for change

        dollars = price//100
        cents = price%100
        amount_paid= 0

        while price > 0:
            
            print("Payment due: ", end='')           
            if dollars == 0:
                print(cents, " cents")
            else:
                print(dollars, " dollars and ", cents, " cents") #Display price
            deposit = input("Indicate your deposit: ") #prompt for the payment
               
            if deposit != 'n' and deposit !='d' and deposit != 'q' \
               and deposit != 'o' and deposit != 'f' and deposit !='c':
                print("Illegal selection: ", deposit)
                continue
            #Checks to make sure it is a wanted value, and if not, reprompted.
            else:
                if deposit == 'n':
                    price -= 5
                    n += 1
                    amount_paid +=5
                    #Deposits a nickel, deducts 5 cents from price
                elif deposit == 'd':
                    price -= 10
                    d+=1
                    amount_paid +=10
                    #Deposits a dime, deducts 10 cents from price
                elif deposit == 'q':
                    price -= 25
                    q+=1
                    amount_paid+=25
                    #Deposits a quarter, deducts 25 cents from price
                elif deposit == 'o':
                    price -= 100
                    o+=1
                    amount_paid+=100
                    #Deposits a one dollar bill, deducts dollar from price
                elif deposit == 'f':
                    price -= 500
                    f+=1
                    amount_paid+=500
                    #Deposits a five dollar bill, deducts five dollars from price
                elif deposit =='c':
                    break
                #Cancels the purchase, breaks the loop
            dollars = price//100
            cents = price%100
        print()
        print("Please take the change below.")

        qu = 0
        di = 0
        ni = 0
        
        if price == 0:
            print(" No change due.")
            print()
            #No change due if there was exact change given
        elif deposit =='c':
            if amount_paid == 0:
                print(" No change due.")
                #no change due if nothing was paid
            while amount_paid >= 25 and q>0:
                amount_paid -= 25
                q -= 1
                qu +=1
                continue
            #Finds the number of quarters needed for change
            while d > 0 and amount_paid >= 10:
                amount_paid -=10
                d -=1
                di +=1
                continue
            #Finds the number of dimes needed for change
            while n > 0 and amount_paid>= 5:
                amount_paid -=5
                n -=1
                ni +=1
                continue
            #Finds the number of nickels needed for change
            else:
                #When that loop is over, either all change is given or amount
                #owed is 0
                if amount_paid == 0:
                    if qu > 0:
                        print(qu, " quarters")
                    if di > 0:
                        print(di, " dimes")
                    if ni >0:
                        print(ni, " nickels")
                    print()
                    #Nothing else owed
                else:
                    if qu > 0:
                        print(qu, " quarters")
                    if di > 0:
                        print(di, " dimes")
                    if ni >0:
                        print(ni, " nickels")
                    print()
                    print("Out of change, see store manager")
                    if amount_paid//100 > 0:
                        print("Amount owed: ", amount_paid//100, \
                              " dollars and ", amount_paid%100, " cents")
                        print()
                    else:
                        print("Amount owed: ", amount_paid%100, " cents")
                        print()
                        #Shows what is still owed to customer
        else:
            price *=-1 #Price will be negative at this point
            while price>= 25 and q > 0:
                price -= 25
                q -= 1
                qu +=1
                continue
            #Finds quarters owed due to change until out of quarters or no more
            #is owed
            while d > 0 and price >= 10:
                price -=10
                d -=1
                di +=1
                continue
            #Finds dimes owed until out or no more is owed
            while n > 0 and price >= 5:
                price -=5
                n -=1
                ni +=1
                continue
            #Finds  nickels owed until out or no more is owed
            else:
                if price == 0:
                    if qu > 0:
                        print(qu, " quarters")
                    if di > 0:
                        print(di, " dimes")
                    if ni >0:
                        print(ni, " nickels")
                    print()
                    #Displays coins given as change, no more owed
                else:
                    if qu > 0:
                        print(qu, " quarters")
                    if di > 0:
                        print(di, " dimes")
                    if ni >0:
                        print(ni, " nickels")
                    print()
                    print("Out of change, see store manager")
                    if price//100 > 0:
                        print("Amount owed: ", price//100, " dollars and ",\
                          price%100, " cents")
                        print()
                    else:
                        print("Amount owed: ", price%100, " cents")
                        print()
                    #Displays coins given, and the amount still owed
    print("Stock contains: ")
    print("   ", n, " nickels")
    print("   ", d, " dimes")
    print("   ", q, " quarters")
    print("   ", o, " ones")
    print("   ", f, " fives")
    print()
    total = n*5 + d*10 + q*25 + o*100 +f*500
    #Displays stock and recalculates total before starting again
print()
print("Total amount in vending machine: ", total//100, " dollars and ", \
      total%100, " cents")
#Ends program by displaying total in the machine
