#Project 4: DNA


string_one = input("String 1: ")
string_two = input("String 2: ")
#Ask the users for the strings to compare

string_one = string_one.lower()
string_two = string_two.lower()
#make everything lowercase to make next steps easier to understand

while True:
    correct=0
    incorrect=0
    length=0
    count=0
    print("What do you want to do?")
    print("          a (add indel)")
    print("          d (delete indel)")
    print("          s (score)")
    prompt = input("          q (quit) : ")
#Ask user what they want to do
    if prompt == "q":
        break #End the program if q is entered
    
    elif prompt == "s":
        #s was entered
        if len(string_one) > len(string_two):
            length = len(string_one)
            equal = len(string_one) - len(string_two)
            string_two = string_two + "-"*equal
        else:
            length = len(string_two)
            equal = len(string_two) - len(string_one)
            string_one = string_one + "-"*equal
        #set the length of the string so that no errors occur
        while count <= length-1:
            if string_one[count] == string_two[count] and string_one[count] =="-":
                string_one = string_one[:count] + string_one[count+1:]
                string_two = string_two[:count] + string_two[count+1:]
            #If two indels are in line, delete them
            elif string_one[count] == string_two[count] and string_one[count]!="-":
                correct +=1
            #If two non-indels are in ine, mark them as correct
            else:
                incorrect +=1
                string_one = string_one[:count] + string_one[count].upper() \
                             +string_one[count+1:]
                string_two = string_two[:count] + string_two[count].upper() \
                             +string_two[count+1:]
            #Mark anything else as incorrect, convert the letter to uppercase
            count +=1
            #Increase counting variable until string is completed
        print()
        print("Matches: ", correct, " Mismatches: ", incorrect)
        print("String 1: ", string_one)
        print("String 2: ", string_two)
        string_one = string_one.lower()
        string_two = string_two.lower()
        #Prints everything, then convert back to lowercase for next run
        
    elif prompt == "a":
        #A was entered
        which = input("Work on which string (1 or 2): ")
        #Ask which string 
        if which == "1":#String one entered
            indel = input("Before what index: ")
            indel = int(indel) #Ask where they want the indel, then convert
            #to a number
            string_one = string_one[:indel] +"-"+string_one[indel:]
            #Change string to add indel at desired point
        elif which == "2":#String two entered
            indel = input("Before what index: ")
            indel = int(indel) #Ask where they want the indel, then convert
            #to a number
            string_two = string_two[:indel] +"-"+string_two[indel:]
            #Change string to add indel at desired point
            
    elif prompt == "d":
        which = input("Work on which string (1 or 2): ")#Ask for which string
        if which == "1":
            indel = input("Before what index: ") 
            indel = int(indel) #Ask which indel they want gone, convert it
            #to a number
            if string_one[indel] == "-":
                string_one = string_one[:indel] + string_one[(indel+1):]
            else:
                print("Nothing deleted, no indel present")
            #Change string if it is an indel, otherwise do nothing 
        elif which == "2":
            indel = input("Before what index: ")
            indel = int(indel)
            #Ask which indel they want gone, convert it to a number
            if string_two[indel] == "-":
                string_two = string_two[:indel] + string_two[(indel+1):]
            else:
                print("Nothing deleted, no indel present")
            #Change string if it is an indel, otherwise do nothing 
    print() #add a line between the next loop

    
