#Section 1
#Lab 2: SLAYER
#1/20/13
print("Guess a six-digit number SLAYER so that " \
      "the following equation is true,")
print("where
      each letter stands for the digit in the position shown: ")
print()
print("SLAYER + SLAYER + SLAYER = LAYERS")
print()

slayer_str = input("Enter your guess for SLAYER: ")
slayer_int = int(slayer_str)

if slayer_int // 100000 != 0:
    slayer_s = (slayer_int//100000)%100000
    slayer_l = (slayer_int//10000)%10
    slayer_a = (slayer_int//1000)%10
    slayer_y = (slayer_int//100)%10
    slayer_e = (slayer_int//10)%10
    slayer_r = (slayer_int%10)

    layers_actual = slayer_l*100000 + slayer_a*10000 + slayer_y*1000 + \
                    slayer_e*100 + slayer_r*10 + slayer_s

    layers_int = slayer_int*3

    if layers_int == layers_actual:
        print("Correct!")
        print("SLAYER+SLAYER+SLAYER = ", layers_int)
        print("LAYERS = ", layers_actual)
    else:
        print("incorrect...")
        print("SLAYER+SLAYER+SLAYER = ", layers_int)
        print("LAYERS = ", layers_actual)
else:
    print("incorrect...")
    print("There must be 6 numbers in SLAYER")
    
        
