#Section 1: Honor's Project
#4/22/13

import matplotlib
import pylab
import numpy 


class sortedDict(dict):
    """Modified sortedDict so that the keys will be type int,
and sorted that way. There is no need to change any other part of dict"""
    def sort(self):
        lst = [(int(k),v) for k,v in self.items()]
        lst.sort()
        return lst

def temperature():
    file_obj = open("temperature.txt", "r")
    file_obj.readline()
    file_obj.readline()
    """Opens and reads the first two lines of temperature.txt,
    which do not contain any data"""
    my_dict = {}
    for line in file_obj:
        line = line.strip()
        my_list = line.split()
        my_tuple = tuple(my_list[0:-2])
        temp = float(my_list[-1])
        if my_tuple not in my_dict:
            my_dict[my_tuple] = [temp]
        else:
            my_dict[my_tuple].append(temp)
    file_obj.close()
    """Creates a dictionary of all the temperatures using the days as the key,
    and deleting the hours. This means that there are 24 values for 1/1/2012,
    as a list"""
    month_min_max = {}
    for obj in my_dict:
        if obj[0] in month_min_max:
            month_min_max[obj[0]][0].append(max(my_dict[obj]))
            month_min_max[obj[0]][1].append(min(my_dict[obj]))
        else:
            month_min_max[obj[0]] = [[max(my_dict[obj])], [min(my_dict[obj])]]
    average_minmax = sortedDict()
    for obj in month_min_max:
        avg = sum(month_min_max[obj][0])/len(month_min_max[obj][0])
        min_avg = sum(month_min_max[obj][1])/len(month_min_max[obj][1])
        average_minmax[obj]= [avg, min_avg]
    """Creates a dict that can be sorted of the averages for each month"""
    x_values = numpy.arange(12)
    key_list = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    value_list = average_minmax.sort()
    y_list = [val[0]-val[1] for key, val in value_list]
    b_list = [val[1] for key,val in value_list]
    bar_width = .5
    pylab.xticks(x_values+bar_width/2.0,key_list,rotation=45)
    pylab.ylabel("Average Temp")
    pylab.title("Charleston, MO - 2012")
    pylab.bar(x_values, y_list, width=bar_width, bottom=b_list)
    pylab.savefig('temp.png')
    """Plots and saves the file as temp.png"""
    
def solar():
    file_obj = open("temperature.txt", "r")
    for obj in range(3650):
        file_obj.readline()
    my_dict = {}
    for obj in range(720):
        line = file_obj.readline()
        line = line.strip()
        my_list = line.split()
        my_tuple = my_list[-2]
        temp = float(my_list[-1])
        if my_tuple not in my_dict:
            my_dict[my_tuple] = [[temp], []]
        else:
            my_dict[my_tuple][0].append(temp)
    file_obj.close()
    """Opens the temperature file, gets to the June data, and enters it into a dict based on
    the hour of the day it was collected"""
    avg_dict = sortedDict()
    file_obj2 = open("solar_radition.txt", "r")
    for obj in range(3484):
        try:
            file_obj2.readline()
        except UnicodeDecodeError:
            pass
    for obj in range(720):
        line = file_obj2.readline()
        line = line.strip()
        my_list = line.split()
        my_tuple = my_list[-2]
        temp = float(my_list[-1])
        my_dict[my_tuple][1].append(temp)

    
    file_obj2.close()
    """Opens the second file, and enters it into the same dict as the first one
    as a second list to the first list"""
    for obj in my_dict:
        avg1 = sum(my_dict[obj][0])/len(my_dict[obj][0])
        avg2 = sum(my_dict[obj][1])/len(my_dict[obj][1])
        avg_dict[obj] = [avg1,avg2]

    avg = avg_dict.sort()
    """Averages all the hours, and sorts them based on time, converting the keys
    to ints so it is sorted in the correct way"""
    fig = pylab.figure()

    ax1 = fig.add_subplot(111)
    t = numpy.arange(1, 25, 1)
    s1 = [val[0] for key,val in avg]
    ax1.plot(t, s1, 'b.-')
    ax1.set_xlabel('Hour')

    ax1.set_ylabel('Average Temp', color='b')
    for tl in ax1.get_yticklabels():
        tl.set_color('b')


    ax2 = ax1.twinx()
    s2 = [val[1] for key,val in avg]
    ax2.plot(t, s2, 'r.-')
    ax2.set_ylabel('Average Solar Radiation', color='r')
    for tl in ax2.get_yticklabels():
        tl.set_color('r')
    pylab.title("Charleston, MO - 2012")
    pylab.savefig("solar.png")
    """Saves the file as solar.png, which has two plotted data sets on the same graph
    with different axis values"""
temperature()
solar()
