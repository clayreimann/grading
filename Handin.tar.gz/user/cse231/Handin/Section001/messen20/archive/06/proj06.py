#Section 1
#2/23/13
#Project 6: Stock Prices


def get_input(): #gets the user input for what file to analyze
    test = False
    while test == False: #keeps looping until test changes
        try:
            my_File = input("Open what file: ")
            my_File_obj = open(my_File, "r") #tries to open the given file
            test = True #changes test if it does open
        except IOError:
            print("Try again") #asks the user to try again if it won't open
    return my_File_obj #returns the object of the file

def get_data_list(file_obj, column_num): # gets all the data from the input column for all dates
    file_obj.readline() #skips the first line that contains no data
    my_tuple_list = [] #declares my_tuple_list as a list
    for line in file_obj:
        line = line.strip()# strips everyline of its extraneous characters
        my_list = line.split(",") #splits the data into a list
        my_date = my_list[0] #gets the date 
        my_columns = my_list[:] #gets all the columns
        my_value = my_columns[column_num] # sets the value wanted based on the column input
        my_value_float = round(float(my_value), 2) #floats the new value, and rounds it to two decimal places
        my_tuple = my_date, my_value_float #creates a tuple of the date and wanted data
        my_tuple_list.append(my_tuple) #adds the tuple to the list
    return my_tuple_list # returns the created tuple list

def average_data(my_list): #averages the data of a tuple list
    count = 0 #count variable for intems in the list
    for obj in my_list:
        my_date = obj[0] #sets the date to the first object in each tuple
        my_date_list = my_date.split("-") #splits into a list based on -'s
        my_date_list.remove(my_date_list[2]) #removes the day number
        my_date = my_date_list[1] + ":" +my_date_list[0] #reorders the date as month:year
        my_list[count] = my_date, obj[1] #changes the tuple in the list to be the new tuple
        count += 1 #increases count to the next obj number
    my_list.sort() #arranges the list to be in the correct order based on the date
    count = 0 #resets the count variable
    count2 = 1 #new count variable for finding the averages
    average = 0 #average variable
    my_tuple_list = [] #new tuple list for this function
    my_tuple = 0,0 #declares a tuple variable for later use
    for obj in my_list:
        if obj[0] != my_list[count-1][0]:#if the date doesn't match the date of the obj before it
            if obj != my_list[0]: #if the obj is not the first number of the list
                average = (round(average/count2,2)) #finds the average and rounds it
                my_tuple = average, my_list[count-1][0] #creates a tuple of the average and the date
                my_tuple_list.append(my_tuple) #adds the tuple to the earlier list
            average = round(obj[1], 2) #sets the average to be the current obj value
            count2 = 1 #resets count2 for net set of averages
        else:
            average += round(obj[1], 2) # adds to the average variable
            count2 += 1 #adds to the second count variable
        count += 1 #adds to the count variable to keep track of obj numbers
    return my_tuple_list
    
def main(): #main function for the program
    my_file_obj = get_input() #finds the file that the user wants to use
    column_num = int(input("What column: ")) #finds the column the user wants
    my_tuple_list = get_data_list(my_file_obj, column_num) #creates a tuple list of the data using get_data_list funciton
    my_tuple_list2 = average_data(my_tuple_list) #creates a new tuple list of the averages
    my_tuple_list2 =  sorted(my_tuple_list2) #sorts the list from low to high averages
    print("Lowest 6 for column ", column_num)
    for obj in my_tuple_list2[0:6]:
        print("Date: ", str(obj[1]) + ", Value: " + str(obj[0])) #prints the lowest six averages and dates
    print()
    print("Highest 6 for column ", column_num)
    my_tuple_list2.reverse() #reverses the order of the list
    for obj in my_tuple_list2[0:6]:
        print("Date: ", str(obj[1]) + ", Value: " + str(obj[0])) #prints the highest 6 averages and dates
    my_file_obj.close() #closes the file

    
main() #executes main function
