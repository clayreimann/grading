###Project 10
### Section 001
### 4/7/13

import turtle
import time

class Flag(object):
    def __init__(self, f_obj):
        rect_num = f_obj.readline()
        rect_num = int(rect_num.strip())
        x = 0
        self.rectangles = []
        while x < rect_num:
            rect_line = f_obj.readline()
            rect_line = rect_line.strip()
            rect_list = rect_line.split(',')
            for element in rect_list:
                element = element.strip()
            x_coord = int(rect_list[0])
            y_coord = int(rect_list[1])
            width = int(rect_list[2])
            height = int(rect_list[3])
            color = str(rect_list[4])
            color = color[1:]
            new_rect = Rectangle(x_coord, y_coord, width, height, color)
            self.rectangles.append(new_rect)
            x += 1
        star_num = f_obj.readline()
        star_num = int(star_num.strip())
        self.stars= []
        x = 0
        while x < star_num:
            star_line = f_obj.readline()
            star_line = star_line.strip()
            star_list = star_line.split(',')
            for element in star_list:
                element = element.strip()
            x_coord = int(star_list[0])
            y_coord = int(star_list[1])
            arm_length = int(star_list[2])
            color = str(star_list[3])
            color = color[1:]
            new_star = Star(x_coord, y_coord, arm_length, color)
            self.stars.append(new_star)
            x += 1

    def draw(self, turtle):
        for element in self.rectangles:
            element.draw(turtle)
        for element in self.stars:
            element.draw(turtle)
        
    def __str__(self):
        print("Rectangles")
        for element in self.rectangles:
            element.__str__()
        print("Stars")
        for element in self.stars:
            element.__str__()
        return ''

class Rectangle(object):
    def __init__(self, x, y, width, height, color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def draw(self, turtle):
        turtle.up()
        turtle.fillcolor(self.color)
        startx = self.x + self.width/2
        turtle.setx(startx)
        starty = self.y + self.height/2
        turtle.sety(starty)
        turtle.down()
        turtle.begin_fill()
        angle = 270
        x = 0
        while x < 2:
            turtle.setheading(angle)
            turtle.forward(self.height)
            angle -= 90
            turtle.setheading(angle)
            turtle.forward(self.width)
            angle -= 90
            x += 1
        turtle.end_fill()

    def __str__(self):
        print("x:",self.x,", y:",self.y,", w:",self.width,", h:", self.height,", c:", self.color)

class Star(object):
    def __init__(self, x, y, arm_length, color):
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color

    def draw(self, turtle):
        turtle.up()
        turtle.fillcolor(self.color)
        startx = self.x + self.arm_length/3.236
        turtle.setx(startx)
        starty = self.y + self.arm_length/2.35
        turtle.sety(starty)
        x = 0
        turtle.down()
        turtle.begin_fill()
        angle = 0
        while x < 5:
            turtle.setheading(angle)
            turtle.forward(self.arm_length)
            angle -= 144
            turtle.setheading(angle)
            turtle.forward(self.arm_length)
            angle += 72
            x += 1
        turtle.end_fill()

    def __str__(self):
        print("x:",self.x,", y:",self.y,", a:",self.arm_length,", c:", self.color)

def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)
    turtle.clearscreen()
    my_file = open('myFlag.txt')
    my_flag = Flag(my_file)
    print(my_flag)
    my_flag.draw(pen)
    my_file.close()
