#Section 001
#1/16/13
#Project 2

#explain program and prompt for guess
print('Guess a six-digit number SLAYER so that the following equation is' \
      ' true, where each letter stands for the digit in the position shown:')
print('')
print('SLAYER + SLAYER + SLAYER = LAYERS')
print('')
slayer_str = input('Enter your guess for SLAYER: ')
slayer_int = int(slayer_str)

#check for 6 digit number

if slayer_int // 100000 < 1:
    print('Your guess is incorrect:')
    print('Slayer must be a 6-digit number.')
#check if slayer3 = layers
else:
    slayer3_int = slayer_int *3
    r_int = slayer_int % 10
    e_int = (slayer_int // 10) % 10
    y_int = (slayer_int // 100) % 10
    a_int = (slayer_int // 1000) % 10
    l_int = (slayer_int // 10000) % 10
    s_int = (slayer_int // 100000) % 10
    layers_int = s_int + r_int * 10 + e_int * 100 + y_int * 1000 + a_int * 10000 + l_int * 100000
    if layers_int == slayer3_int:
        print('Your guess is correct:')
        print('SLAYER + SLAYER + SLAYER = ', slayer3_int)
        print('LAYERS = ', layers_int)
    else:
        print('Your guess is incorrect:')
        print('SLAYER + SLAYER + SLAYER = ', slayer3_int)
        print('LAYERS = ', layers_int)
print('Thanks for playing.')
