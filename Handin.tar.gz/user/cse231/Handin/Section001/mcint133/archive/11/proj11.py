###Project 13
###Section 001
###4-14-2013

import urllib.request
import string

class Tour(object):
    def __init__(self, *destination):
        '''takes tour order and puts it into a list for each instance'''
        #check for tuple within tuple from __add__
        if type(destination[0]) == tuple:
            new_tup = destination[0]
            self.dest = new_tup
        else:
            self.dest = destination
        
    def distance(self, mode = 'driving'):
        '''find total distance to reach each destination depending on the mode of travel'''
        try:
            self.dist = 0
            urlstr = 'http://maps.googleapis.com/maps/api/distancematrix/json?'
            x = 0
            self.dist = 0
            #create web address for ordered origin and destination combinations
            while x < (len(self.dest)-1):
                orig_list = self.dest[x].split()
                dest_list = self.dest[x+1].split()
                orig_str = orig_list[0]
                y = 1
                #create origin reference for web address
                while y < len(orig_list):
                    orig_str = orig_str + '+' + orig_list[y]
                    y += 1
                dest_str = dest_list[0]
                y = 1
                #create destination reference for web address
                while y < len(dest_list):
                    dest_str = dest_str + '+' + dest_list[y]
                    y += 1
                #send web address and receive data
                web_obj = urllib.request.urlopen(urlstr+'origins='+orig_str+'&destinations='+dest_str+'&mode='+mode+'&sensor=false')
                results_str = str(web_obj.read())
                #parse results
                result_list = results_str.split('"value" : ')
                result2_list = result_list[1].split()
                dist = result2_list[0]
                dist = dist[:-2]
                self.dist += float(dist)
                x += 1
            return self.dist
        except IndexError:
            print('No distance could be calculated')

    def __str__(self):
        '''create string for printing'''
        retstr = self.dest[0]
        x = 1
        #make string of destinations for printing
        while x < len(self.dest):
            retstr = retstr + '; ' + self.dest[x]
            x += 1
        return retstr

    def __repr__(self):
        '''call print()'''
        return self.__str__()

    def __add__(t1, t2):
        '''add tours together'''
        #check for beginning and ending cities being the same then add tours
        if t1.dest[-1] == t2.dest[0]:
            tour_tup = t1.dest[:-1] + t2.dest
        else:
            tour_tup = t1.dest + t2.dest
        return Tour(tour_tup)

    def __mul__(self, other):
        '''multiplies a tour by an integer'''
        try:
            #check for errors
            if other < 0:
                raise ValueError
            if type(other) != int:
                raise TypeError
            x = 1
            orig = self.dest
            #loop to add destinations to each other
            while x < other:
                self.dest = self.dest + orig
                x += 1
        except ValueError:
            print('Must multiply by a non-negative integer')
        except TypeError:
            print('Must multiply by a non-negative integer')

    def __rmul__(self, other):
        '''call __mul__'''
        self.__mul__(other)

    def __gt__(self, other):
        '''compare driving distance of two tours'''
        if self.distance() > other.distance():
            return True
        else:
            return False

    def __lt__(self, other):
        '''compare driving distance of two tours'''
        if self.distance() < other.distance():
            return True
        else:
            return False

    def __eq__(self, other):
        '''check for same desinations in same order for two tours'''
        same = True
        x = 0
        #false if destination tuples are different lengths
        if len(self.dest) != len(other.dest):
            same =  False
        else:
            #false if destinations are not in same order
            while x < len(self.dest):
                if self.dest[x] != other.dest[x]:
                    same = False
                x += 1
        return same

def main():
    #test all scenarios
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2:{}\nt3:{}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(
    round(t1.distance()/1000), round(t1.distance('bicycling')/1000),
    round(t1.distance('walking')/1000)))
    print("Using driving distances from here on.")
    print("t4 = t1 + t3")
    t4 = t1 + t3
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t4 == t1 + t2:", t4 == t1 + t3)
    print("t4 < t1:", t4 < t1)
    print("t4 > t1:", t4 > t1)
    print("t1 * 3")
    t1 * 3
    print("t1: ", t1)
    print("3 * t3")
    3 * t3
    print("t3: ", t3)
    
    
