###Project 12
###Sec 001
###4-20-13

import numpy as np
import matplotlib.pyplot as plt

def temp_data(file):
    #throwaway header lines 
    throwaway = file.readline()
    throwaway2 = file.readline()
    #init variables to track data
    day = 1
    month = 1
    high = 0
    dayhigh_list = []
    avghigh_list = []
    low = 100
    daylow_list = []
    avglow_list = []
    for line in file:
        line = line.strip()
        line_list = line.split()
        #check for high and low within day
        if int(line_list[1]) == day:
            if float(line_list[4]) > high:
                high = float(line_list[4])
            if float(line_list[4]) < low:
                low = float(line_list[4])
        #start checking for next day
        elif int(line_list[1]) != day and int(line_list[0]) == month:
            #add highs and lows
            dayhigh_list.append(high)
            daylow_list.append(low)
            day += 1
            high = 0
            low = 100
            if float(line_list[4]) > high:
                high = float(line_list[4])
            if float(line_list[4]) < low:
                low = float(line_list[4])
        #start checking for next month
        else:
            day = 1
            month += 1
            x = 0
            lsum = 0
            hsum = 0
            high = 0
            low = 0
            #calculate average highs and lows
            while x < len(dayhigh_list):
                lsum += daylow_list[x]
                hsum += dayhigh_list[x]
                x += 1
            hsum = hsum/len(dayhigh_list)
            lsum = lsum/len(daylow_list)
            avghigh_list.append(hsum)
            avglow_list.append(lsum)
            #reset high and low lists
            if month != 12:
                for element in dayhigh_list:
                    dayhigh_list.remove(element)
                for element in daylow_list:
                    daylow_list.remove(element)
                if float(line_list[4]) > high:
                    high = float(line_list[4])
                if float(line_list[4]) < low:
                    low = float(line_list[4])
    #calculate highs and lows for december
    while x < len(dayhigh_list):
        lsum += daylow_list[x]
        hsum += dayhigh_list[x]
        x += 1
    hsum = hsum/len(dayhigh_list)
    lsum = lsum/len(daylow_list)
    avghigh_list.append(hsum)
    avglow_list.append(lsum)
    return avghigh_list, avglow_list
        
def solar_data(file):
    #throwaway header lines 
    throwaway = file.readline()
    throwaway2 = file.readline()
    throwaway3 = file.readline()
    throwaway4 = file.readline()
    #init variables
    solar_list = []
    average_list = []
    x = 0
    y = 0
    #go through file and get data
    for line in file:
        line = line.strip()
        line_list = line.split()
        #get data from June
        if int(line_list[0]) == 6:
            #check for existing data
            if y < 24:
                solar_list.append(float(line_list[4]))
                y += 1
            #add data to list
            else:
                solar_list[x] = solar_list[x] + float(line_list[4])
                x += 1
        if x == 24:
            x = 0
    x = 0
    #average data
    while x < len(solar_list):
        average_list.append(solar_list[x]/30)
        x += 1
    return average_list

def bar_graph(y_data1, y_data2):
    #set constant values
    bar_width = 0.5
    plt.title('Charleston, MO - 2012')
    month_list = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    x_values = np.arange(len(month_list))
    #plot graph
    plt.xticks(x_values+bar_width/2.0, month_list, rotation=45)
    plt.bar(x_values, y_data1, bottom = y_data2, width = bar_width, color = 'b')
    plt.savefig('temp.png')

def dot_plot(y_data1, y_data2):
    fig = plt.figure()
    plt.title('Charleston, MO - June 2012')
    ax1 = fig.add_subplot(111)
    t = np.arange(len(y_data1))
    s1 = y_data1
    ax1.plot(t, s1, 'b')
    ax1.set_xlabel('Hour')
    ax1.set_ylabel('Average Temp')
    for t1 in ax1.get_yticklabels():
        t1.set_color('b')
    ax2 = ax1.twinx()
    s2 = y_data2
    ax2.plot(t, s2, 'r')
    ax2.set_ylabel('Average Solar Radiation')
    for t1 in ax2.get_yticklabels():
        t1.set_color('r')
    plt.savefig('radiation.png')

#open, run and close files    
file_obj = open('temperature.txt')
avghigh_list, avglow_list = temp_data(file_obj)
file_obj.close()
file_obj = open('temperature.txt')
solar_list = solar_data(file_obj)
file_obj.close()
file_obj = open('solar_radition.txt')
temp_list = solar_data(file_obj)
file_obj.close()
#modify data for bar graph
newhigh_list = []
x = 0
while x < len(avghigh_list):
    newhigh_list.append(avghigh_list[x]-avglow_list[x])
    x += 1
#plot bar graph
bar_graph(newhigh_list, avglow_list)
#plot dot plot
dot_plot(temp_list, solar_list)
