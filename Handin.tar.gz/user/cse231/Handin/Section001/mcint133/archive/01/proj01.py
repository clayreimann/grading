#manual input

num_str = input("Please enter a Richter scale measure: ")
num_float = float(num_str)
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print("Richter scale measure: ", num_float)
print("Equivalence in joules: ", joules_float)
print("Equivalence in Tons of TNT: ", tnt_float)

#set values

print("")
print("Richter        Joules                      TNT")
num_float = 1
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print(num_float, "        ", joules_float, "      ", tnt_float)
num_float = 5
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print(num_float, "        ", joules_float, "      ", tnt_float)
num_float = 9.1
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print(num_float, "      ", joules_float, "   ", tnt_float)
num_float = 9.2
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print(num_float, "      ", joules_float, "   ", tnt_float)
num_float = 9.5
joules_float = 10**(1.5*num_float+4.8)
tnt_float = joules_float/4.184e9
print(num_float, "      ", joules_float, "  ", tnt_float)
