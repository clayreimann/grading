#Section 001
#1/31/13
#Project 4

#get strings from user
string1_str = input("String 1: ")
string2_str = input("String 2: ")

#get into the loop
com_str = ''
while com_str != 'q':
    #user does something to the string
    print("What do you want to do:")
    print("a (add indel)")
    print("d (delete indel)")
    print("s (score)")
    com_str = input("q (quit): ")
    #check for illegal input
    if com_str != 'a' and com_str != 'd' and com_str != 's' and com_str != 'q':
        print("Invalid command input")
    #adding
    elif com_str == 'a':
        change_str = input("Work on which string (1 or 2): ")
        add_str = input("Before what index: ")
        add_int = int(add_str)
        if change_str == '1':
            #check for entry errors
            if add_int > len(string1_str):
                print("Invalid index value. String 1 is not that long.")
            #add to string1
            else:
                string1_str = string1_str[:add_int] + '-' + string1_str[add_int:]
        elif change_str == '2':
            #check for errors
            if add_int > len(string2_str):
                print("Invalid index value. String 2 is not that long.")
            #add to string2
            else:
                string2_str = string2_str[:add_int] + '-' + string2_str[add_int:]
    #deleting
    elif com_str == 'd':
        change_str = input("Work on which string (1 or 2): ")
        del_str = input("Delete what index: ")
        del_int = int(del_str)
        if change_str == '1':
            #check for entry errors
            if string1_str[del_int] != '-':
                print("You cannot delete that character.")
            elif del_int > len(string1_str):
                print("Invalid index value. String 1 is not that long.")
            #delete from string1
            else:
                string1_str = string1_str[:del_int] + string1_str[del_int + 1:]
        elif change_str == '2':
            #check for errors
             if string2_str[del_int] != '-':
                print("You cannot delete that character.")
             elif del_int > len(string2_str):
                print("Invalid index value. String 1 is not that long.")
            #delete from string2
             else:
                string2_str = string2_str[:del_int] + string2_str[del_int + 1:]

    #scoring
    elif com_str == 's':
        #make temporary strings
        temp1_str = string1_str
        temp2_str = string2_str
        matches_int = 0
        mismatches_int = 0
        x = 0
        if len(string1_str) > len(string2_str):
            while x < len(string1_str) - len(string2_str):
                temp2_str = temp2_str + '-'
                x += 1
        elif len(string2_str) > len(string1_str):
            while x < len(string2_str) - len(string1_str):
                temp1_str = temp1_str + '-'
                x += 1
        x = 0
        while x < len(temp1_str):
            if temp1_str[x] == temp2_str[x]:
                matches_int += 1
            else:
                mismatches_int += 1
                if temp1_str[x] != '-':
                    temp1_str = temp1_str[:x] + temp1_str[x].upper() + temp1_str[x+1:]
                elif temp2_str != '-':
                    temp2_str = temp2_str[:x] + temp2_str[x].upper() +  temp2_str[x+1:]
            x += 1
        print("Matches: ", matches_int, "  Mismatches: ", mismatches_int)
        print(temp1_str)
        print(temp2_str)
