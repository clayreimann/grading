#Sec 001
#Project 9
#3/25/13

import cardsBasic

def setup():
    #import deck
    my_deck = cardsBasic.Deck()
    #shuffle deck
    my_deck.shuffle()
    #list of 4 empty lists to build oredered cards on
    foundation = [[],[],[],[]]
    #list of 10 lists full of random cards
    tableau = [[],[],[],[],[],[],[],[],[],[]]
    x = 0
    while not my_deck.is_empty():
        tableau[x].append(my_deck.deal())
        x += 1
        if x % 10 == 0:
            x = 0
    #list of 4 empty lists for temp card placement
    cell = [[],[],[],[]]
    return foundation,tableau,cell

def move_to_foundation(tableau,foundation,t_col,f_col):
    valid = False
    #check for ace addition
    if tableau[t_col][-1].get_rank() == 1 and foundation[f_col] == []:
        move = tableau[t_col].pop()
        foundation[f_col].append(move)
        valid = True
    #check for validity of move and make move
    elif tableau[t_col][-1].equal_suit(foundation[f_col][-1]) == True:
        if tableau[t_col][-1].get_rank() == (foundation[f_col][-1].get_rank() + 1):
            valid = True
            move = tableau[t_col].pop()
            foundation[f_col].append(move)
    return valid

def move_to_cell(tableau,cell,t_col,c_col):
    valid = False
    #check if column is empty and make move
    if cell[c_col] == []:
        move = tableau[t_col].pop()
        cell[c_col].append(move)
        valid = True
    return valid

def move_to_tableau(tableau,cell,c_col,t_col):
    valid = False
    #check for validity and make move
    if tableau[t_col] == [] and cell[c_col][-1].get_rank() == 13:
        move = cell[c_col].pop()
        tableau[t_col].append(move)
        valid = True
    elif cell[c_col][-1].equal_suit(tableau[t_col][-1]) == True:
        if cell[c_col][-1].get_rank() == (tableau[t_col][-1].get_rank() - 1):
            move = cell[c_col].pop()
            tableau[t_col].append(move)
            valid = True
    return valid
    
def is_winner(foundation):
    #counter to check for full foundations
    full = 0
    end = False
    #check if each foundation is full
    for element in foundation:
        print(len(element))
        if len(element) == 13:
            full += 1
    #win message
    if full == 4:
        end = True
    return end

def move_in_tableau(tableau,t_col_source,t_col_dest):
    valid = False
    #check for validity and make move
    if tableau[t_col_dest] == [] and tableau[t_col_source][-1].get_rank() == 13:
        move = tableau[t_col_source].pop()
        tableau[t_col_dest].append(move)
        valid = True
    if tableau[t_col_source][-1].equal_suit(tableau[t_col_dest][-1]) == True:
        if tableau[t_col_source][-1].get_rank() == (tableau[t_col_dest][-1].get_rank() - 1):
            valid = True
            move = tableau[t_col_source].pop()
            tableau[t_col_dest].append(move)
    return valid
        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    #prints rules
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    #prints game instructions
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
    end = False   
    show_help()
    while end == False:
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        if len(response_list) > 0:
            r = response_list[0]
            #run all possible inputs and check for illegal inputs
            if r == 't2f':
                try:
                    source = int(response_list[1]) - 1
                    dest =  int(response_list[2]) - 1
                    valid = move_to_foundation(tableau, foundation, source, dest)
                    if valid == False:
                        print("Invalid move")
                except IndexError:
                    print("Invalid index value.")
                except ValueError:
                    print("Invalid type of value.")
            elif r == 't2t':
                try:
                    source = int(response_list[1]) - 1
                    dest =  int(response_list[2]) - 1
                    valid = move_in_tableau(tableau, source, dest)
                    if valid == False:
                        print("Invalid move")
                except IndexError:
                    print("Invalid index value.")
                except ValueError:
                    print("Invalid type of value.")
            elif r == 't2c':
                try:
                    source = int(response_list[1]) - 1
                    dest =  int(response_list[2]) - 1
                    valid = move_to_cell(tableau, cell, source, dest)
                    if valid == False:
                        print("Invalid move")
                except IndexError:
                    print("Invalid index value.")
                except ValueError:
                    print("Invalid type of value.")
            elif r == 'c2t':
                try:
                    source = int(response_list[1]) - 1
                    dest =  int(response_list[2]) - 1
                    valid = move_to_tableau(tableau, cell, source, dest)
                    if valid == False:
                        print("Invalid move")
                except IndexError:
                    print("Invalid index value.")
                except ValueError:
                    print("Invalid type of value.")
            elif r == 'c2f':
                try:
                    source = int(response_list[1]) - 1
                    dest =  int(response_list[2]) - 1
                    valid = move_to_foundation(cell, foundation, source, dest)
                    if valid == False:
                        print("Invalid move")
                except IndexError:
                    print("Invalid index value.")
                except ValueError:
                    print("Invalid type of value.")
            elif r == 'q':
                break
            elif r == 'h':
                show_help()
            else:
                print('Unknown command:',r)
        else:
            print("Unknown Command:",response)
        end = is_winner(foundation)
    print('Thanks for playing')

play()


        
    

