# Sec 001
# Project 6
# 2-18-13

#get file to open
def get_input_descriptor():
    opened_file_bool = False
    #run loop while file has not successfully opened
    while opened_file_bool == False:
        filename_str = input("Read what file: ")
        try:
            file_obj = open(filename_str, 'r')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again")
    #when file has opened return oject with name and opened file
    else:
        return file_obj

#read data
def get_data_list(file_obj, col_int):
    #take out header line
    line1 = file_obj.readline()
    data_list = []
    #read all data in and create tuples for desired data
    for line in file_obj:
        line.strip()
        line_list = line.split(',')
        date_list = line_list[0].split('/')
        month = int(date_list[0])
        year = int(date_list[2])
        col_data = float(line_list[col_int-1])
        data = month, year, col_data
        data_list.append(data)
    return data_list

#analyze data
def average_data(data_list):
    data_piece1 = data_list[0]
    month1 = data_piece1[0]
    sum_int = 0
    sum_list = []
    day = 0
    #loop though data list
    for data in data_list:
        month = data[0]
        if month == month1:
            sum_int += data[2]
            day += 1
        else:
            sum_avg = sum_int / day
            sum_avg = round(sum_avg, 2)
            sum_data = sum_avg, month1, data[1]
            sum_list.append(sum_data)
            day = 1
            month1 = month
            sum_int = data[2]
    #sort and return data list
    sorted_list = sorted(sum_list)
    return sorted_list

#get and open file       
file_obj = get_input_descriptor()
#get column to analyze
col_int = int(input("What column: "))
col_int += 1
#create data list
data_list = get_data_list(file_obj, col_int)
sum_list = average_data(data_list)
#print lowest data from sorted list
print("Lowest 6 for column ", col_int - 1)
x = 0
while x < 6:
    print("Date: ", sum_list[x][1], "-", sum_list[x][2], ", Value: ", sum_list[x][0])
    x += 1
print("")
#print highest data from sorted list
print("Highest 6 for column ", col_int - 1)
x = len(sum_list) - 1
while x > len(sum_list) - 7:
    print("Date: ", sum_list[x][1], "-", sum_list[x][2], ", Value: ", sum_list[x][0])
    x -= 1
