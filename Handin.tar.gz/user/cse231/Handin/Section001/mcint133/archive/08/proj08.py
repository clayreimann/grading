### Sec 001
### 3/17/13
### Project 8

import string

#function to create word set
def fill_completions(read_file, c_dict):
    new_list = []
    #getting words by stripping and splitting lines
    for line in read_file:
        line = line.strip()
        word_list = line.split()
        #cutting words
        for word in word_list:
            punct_bool = True
            x = 0
            #checks for front punctuation
            while punct_bool == True and x < len(word)-1:
                if word[x] in string.punctuation:
                        x += 1
                else:
                    punct_bool = False
            punct_bool = True
            y = len(word)-1
            if word == word[:x]:
                y = y
            #checks for end punctuation
            else:
                while punct_bool == True and y > 0:
                    if word[y] in string.punctuation:
                        y -= 1
                    else:
                        punct_bool = False
            word = word[x:y+1]
            word = word.lower()
            #filter words
            if word.isalpha() == True:
                if len(word) >= 2:
                    if (word not in new_list) == True:
                        new_list.append(word)
                        x = 0
                        #create tuples for keys in dictionary and add words
                        for char in word:
                            if (x,char) not in c_dict.keys():
                                c_dict[x,char] = set()
                                c_dict[x,char].add(word)
                            else:
                                c_dict[x,char].add(word)
                            x += 1

def find_completions(prefix, c_dict):
    set2 = set()
    x = 0
    #check dictionary for sets
    for char in prefix:
        set1 = set()
        set1 = c_dict[x,char]
        if x == 0:
            set2 = set1
        #intersect sets
        else:
            set2 = set2 & set1
        x += 1
    return set2

def main():
    #open file
    read_file = open('ap_docs.txt')
    c_dict = {}
    #create word list
    fill_completions(read_file, c_dict)
    #input what to complete
    prefix = input('Please enter a prefix to find completions for: ')
    #get completion set
    completions_set = find_completions(prefix, c_dict)
    #output
    print("Possible completions: ", completions_set)
    read_file.close()
