# Sec 001
# 2-7-13
# Proj 05

#import drawing feature and math functions
import turtle
import math
import time

#prompt user for number of hexagons
def get_num_hexagons():
    hex_int = 0
    while hex_int < 4 or hex_int > 20:
        hex_int = int(input("Enter number of hexagons between 4 and 20: "))
        if hex_int < 4 or hex_int > 20:
            print("That number is not between 4 and 20")
    return hex_int

#prompt user for color function
def get_color_choice():
    color1t = ''
    color2t = ''
    #give user color options
    print("Color options are:")
    print("forest green")
    print("black")
    print("tomato")
    print("")
    #loop until valid color is entered for color1 and color2
    while color1t != 'forest green' and color1t != 'black' and color1t != 'tomato':
        color1t = input("Please enter the first color you would like to use: ")
        if color1t != 'forest green' and color1t != 'black' and color1t != 'tomato':
            print("That color is not an option")
    while color2t != 'forest green' and color2t != 'black' and color2t != 'tomato':
        color2t = input("Please enter the second color you would like to use: ")
        if color2t != 'forest green' and color2t != 'black' and color2t != 'tomato':
            print("That color is not an option")
        elif color1t == color2t:
            print("That color has already been chosen")
            color2t = ''
    return color1t, color2t

#draw the hexagon
def draw_hexagon(width, xpos, ypos):
    #calculate side length
    side = (width/2)/math.sin(math.pi/3)
    #set starting x position
    turtle.up()
    turtle.setx(xpos)
    turtle.sety(ypos)
    #set starting angle
    angle = 150
    turtle.setheading(angle)
    #pen down and start fill
    turtle.down()
    turtle.begin_fill()
    count_hex = 0
    #draw each side of the hexagon
    while count_hex < 6:
        turtle.forward(side)
        angle -= 60
        turtle.setheading(angle)
        count_hex += 1
    turtle.end_fill()

#set drawing speed
turtle.speed(5)
#get colors of hexagons
color1 , color2 = get_color_choice()
#get number of hexagons
hexagons_int = get_num_hexagons()
#calculate width of hexagons
d = 500/hexagons_int
side = (d/2)/math.sin(math.pi/3) 
#set x and y to center tessellation
starty = 250
#loop through each row of hexagons
row = 0
while row < hexagons_int:
    if row % 2 == 0:
        startx = -250
        #change position of y to line up tessellation
        starty -= side
        starty -= side * math.cos(math.pi/3)
        count_draw = 0
        while count_draw < hexagons_int:
            #change colors of hexagons
            if count_draw % 2 != 0:
                turtle.fillcolor(color1)
                draw_hexagon(d, startx, starty)
            else:
                turtle.fillcolor(color2)
                draw_hexagon(d, startx, starty)
            #change poition of next hexagon
            startx += d
            count_draw += 1
    else:
        startx = -250 + (d/2)
        #change position of y to line up tessellation
        starty -= side
        starty -= side * math.cos(math.pi/3)
        count_draw = 0
        while count_draw < hexagons_int:
            #change color of hexagons
            if count_draw % 2 != 0:
                turtle.fillcolor(color1)
                draw_hexagon(d, startx, starty)
            else:
                turtle.fillcolor(color2)
                draw_hexagon(d, startx, starty)
            #change poition of next hexagon
            startx += d
            count_draw += 1
    row += 1
time.sleep(5)

    
