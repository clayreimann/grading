### Sec 001
### 3/7/13
### Project 7

import string
import random

#scramble the middle characters of words
def scramble_word(word):
    #takes list of letters and randomizes their position in the list
    letter_list = list(word)
    random.shuffle(letter_list)
    #puts list back together to form scrambled word
    scramble = ''.join(letter_list)
    return scramble

#read out line and separate words
def scramble_line(read_file):
    line_scrambled = ''
    #takes line out of file
    for line in read_file:
        word_list = line.split()
        #takes 3+ letter words out of line
        for word in word_list:
            if len(word) > 3:
                punct_bool = True
                x = 0
                #checks for front punctuation
                while punct_bool == True and x < len(word)-1:
                    if word[x] in string.punctuation:
                        x += 1
                        punct_bool = False
                    else:
                        punct_bool = False
                punct_bool = True
                y = len(word)-1
                if word == word[:x]:
                    y = y
                #checks for end punctuation
                else:
                    while punct_bool == True and y > 0:
                        if word[y] in string.punctuation:
                            y -= 1
                            punct_bool = False
                        else:
                            punct_bool = False
                #cuts word for only letters that will be scrambled
                word_copy = word[x+1:y]
                word_scrambled = scramble_word(word_copy)
                word_scrambled = word[:x+1] + word_scrambled + word[y:] + ' '
                line_scrambled += word_scrambled
            else:
                line_scrambled += word + ' '
    return line_scrambled

#open read file for scrambling
def open_read_file():
    opened_file_bool = False
    #run loop while file has not successfully opened
    while opened_file_bool == False:
        read_filename = input("Read what file: ")
        try:
            file_obj = open(read_filename, 'r')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again")
    #when file has opened return oject with name and opened file
    else:
        return file_obj

#open file to write scrambled text to
write_filename = input("Name of file to write to: ")
write_file = open(write_filename, 'w')
#open file to read text out of
read_file = open_read_file()
line = scramble_line(read_file)
#writes to file
write_file.write(line)
#closes files
read_file.close()
write_file.close()
