#intoduce program

print("Welcome to the vending machine change maker program")
print("Change maker initialized.")

#initialize stock of change

nstock_int = 25
dstock_int = 25
qstock_int = 25
ostock_int = 0
fstock_int = 0

print(nstock_int, " nickels")
print(dstock_int, " dimes")
print(qstock_int, " quarters")
print(ostock_int, " ones")
print(fstock_int, " fives")
#start loop
price_str = 0
while price_str != 'q':
    
    #get price from user
    price_str = input("Enter the purchase price (xx.xx) or `q' to quit: ")

    #check for 'q'
    if price_str == 'q':
        print("Total: ", fstock_int * 5 + ostock_int + (qstock_int * 25 + dstock_int * 10 + nstock_int * 5) // 100, " dollars and ", (qstock_int * 25 + dstock_int * 10 + nstock_int * 5) % 100, " cents")
    else:
        
    #convert price to dollars and cents
        price_float = float(price_str)
        price_int = round(price_float * 100)
        #check for illegal input
        if (price_int % 5) != 0 or price_int <= 0:
            print("Illegal price: Must be a non-negative multiple of 5 cents.")
            print("")
        else:
            #start deposit and change return process
            print("Menu for deposits:")
            print("'n' - deposit a nickel")
            print("'d' - deposit a dime")
            print("'q' - deposit a quarter")
            print("'o' - deposit a one dollar bill")
            print("'f' - deposit a five dollar bill")
            print("'c' - cancel the purchase")
            print("")

            #user pays
            deposit_str = 0
            paid_int = 0
            while deposit_str != "c" and paid_int < price_int:
                print("Payment due: ", (price_int - paid_int) // 100, " dollars and ", (price_int - paid_int) % 100, " cents")
                deposit_str = input("Indicate your deposit: ")
                if deposit_str != 'n' and deposit_str != 'd' and deposit_str != 'q' and deposit_str != 'o' and deposit_str != 'f' and deposit_str != 'c':
                    print("Illegal selection: ", deposit_str)
                else:
                    #change amount paid and stock of money
                    if deposit_str == 'f':
                        paid_int += 500
                        fstock_int += 1
                    elif deposit_str == 'o':
                        paid_int += 100
                        ostock_int += 1
                    elif deposit_str == 'q':
                        paid_int += 25
                        qstock_int += 1
                    elif deposit_str == 'd':
                        paid_int += 10
                        dstock_int += 1
                    elif deposit_str == 'n':
                        paid_int += 5
                        nstock_int += 1
                    #determine change
                    if paid_int >= price_int:
                        change_int = paid_int - price_int
                        print("Please take change below.")
                        #no change
                        if change_int == 0:
                            print("No change due.")
                        #change due
                        elif change_int < (qstock_int * 25 + dstock_int * 10 + nstock_int * 5):
                            #quarters
                            if change_int >= 25 and qstock_int > 0:
                                qdue_int = change_int // 25
                                if qdue_int > qstock_int:
                                    change_int = change_int - (qstock_int * 25)
                                    qstock_int = 0
                                    print(qstock_int, " quarters")
                                else:
                                    change_int = change_int - (qdue_int * 25)
                                    qstock_int -= qdue_int
                                    print(qdue_int, " quarters")
                            #dimes
                            if change_int >= 10 and dstock_int > 0:
                                ddue_int = change_int // 10
                                if ddue_int > dstock_int:
                                    change_int = change_int - (dstock_int * 10)
                                    dstock_int = 0
                                    print(dstock_int, " dimes")
                                else:
                                    change_int = change_int - (ddue_int * 10)
                                    dstock_int -= ddue_int
                                    print(ddue_int, " dimes")
                            #nickels
                            if change_int >= 5 and nstock_int > 0:
                                ndue_int = change_int // 5
                                if ndue_int > nstock_int:
                                    change_int = change_int - (nstock_int * 5)
                                    nstock_int = 0
                                    print(nstock_int, " nickels")
                                else:
                                    change_int = change_int - (ndue_int * 5)
                                    nstock_int -= ndue_int
                                    print(ndue_int, " nickels")
                        else:
                            #quarters
                            if change_int >= 25 and qstock_int > 0:
                                qdue_int = change_int // 25
                                if qdue_int > qstock_int:
                                    change_int = change_int - (qstock_int * 25)
                                    print(qstock_int, " quarters")
                                    qstock_int = 0
                                else:
                                    change_int = change_int - (qdue_int * 25)
                                    qstock_int -= qdue_int
                                    print(qdue_int, " quarters")
                            #dimes
                            if change_int >= 10 and dstock_int > 0:
                                ddue_int = change_int // 10
                                if ddue_int > dstock_int:
                                    change_int = change_int - (dstock_int * 10)
                                    print(dstock_int, " dimes")
                                    dstock_int = 0
                                else:
                                    change_int = change_int - (ddue_int * 10)
                                    dstock_int -= ddue_int
                                    print(ddue_int, " dimes")
                            #nickels
                            if change_int >= 5 and nstock_int > 0:
                                ndue_int = change_int // 5
                                if ndue_int > nstock_int:
                                    change_int = change_int - (nstock_int * 5)
                                    print(nstock_int, " nickels")
                                    nstock_int = 0
                                else:
                                    change_int = change_int - (ndue_int * 5)
                                    nstock_int -= ndue_int
                                    print(ndue_int, " nickels")
                            #not enough to compensate
                                print("Machine is out of change.")
                                doldue_int = change_int // 100
                                cendue_int = change_int % 100
                                print("See store manager for remaining refund.")
                                print("Amount due is: ", doldue_int, " dollars and ", cendue_int, " cents")
                    if deposit_str == 'c':
                        print("Please take change below.")
                        #no change
                        if paid_int == 0:
                            print("No change due.")
                        #change due
                        elif paid_int < (qstock_int * 25 + dstock_int * 10 + nstock_int * 5):
                            #quarters
                            if paid_int >= 25 and qstock_int > 0:
                                qdue_int = paid_int // 25
                                if qdue_int > qstock_int:
                                    paid_int = paid_int - (qstock_int * 25)
                                    qstock_int = 0
                                    print(qstock_int, " quarters")
                                else:
                                    paid_int = paid_int - (qdue_int * 25)
                                    qstock_int -= qdue_int
                                    print(qdue_int, " quarters")
                            #dimes
                            if paid_int >= 10 and dstock_int > 0:
                                ddue_int = paid_int // 10
                                if ddue_int > dstock_int:
                                    paid_int = paid_int - (dstock_int * 10)
                                    dstock_int = 0
                                    print(dstock_int, " dimes")
                                else:
                                    paid_int = paid_int - (ddue_int * 10)
                                    dstock_int -= ddue_int
                                    print(ddue_int, " dimes")
                            #nickels
                            if paid_int >= 5 and nstock_int > 0:
                                ndue_int = paid_int // 5
                                if ndue_int > nstock_int:
                                    paid_int = paid_int - (nstock_int * 5)
                                    nstock_int = 0
                                    print(nstock_int, " nickels")
                                else:
                                    paid_int = paid_int - (ndue_int * 5)
                                    nstock_int -= ndue_int
                                    print(ndue_int, " nickels")
                        else:
                            #quarters
                            if change_int >= 25 and qstock_int > 0:
                                qdue_int = change_int // 25
                                if qdue_int > qstock_int:
                                    change_int = change_int - (qstock_int * 25)
                                    print(qstock_int, " quarters")
                                    qstock_int = 0
                                else:
                                    change_int = change_int - (qdue_int * 25)
                                    qstock_int -= qdue_int
                                    print(qdue_int, " quarters")
                            #dimes
                            if change_int >= 10 and dstock_int > 0:
                                ddue_int = change_int // 10
                                if ddue_int > dstock_int:
                                    change_int = change_int - (dstock_int * 10)
                                    print(dstock_int, " dimes")
                                    dstock_int = 0
                                else:
                                    change_int = change_int - (ddue_int * 10)
                                    dstock_int -= ddue_int
                                    print(ddue_int, " dimes")
                            #nickels
                            if change_int >= 5 and nstock_int > 0:
                                ndue_int = change_int // 5
                                if ndue_int > nstock_int:
                                    change_int = change_int - (nstock_int * 5)
                                    print(nstock_int, " nickels")
                                    nstock_int = 0
                                else:
                                    change_int = change_int - (ndue_int * 5)
                                    nstock_int -= ndue_int
                                    print(ndue_int, " nickels")
                            #not enough to compensate
                                print("Machine is out of change.")
                                doldue_int = change_int // 100
                                cendue_int = change_int % 100
                                print("See store manager for remaining refund.")
                                print("Amount due is: ", doldue_int, " dollars and ", cendue_int, " cents")
            print("")
            print("Stock contains:")
            print(nstock_int, " nickels")
            print(dstock_int, " dimes")
            print(qstock_int, " quarters")
            print(ostock_int, " ones")
            print(fstock_int, " fives")
