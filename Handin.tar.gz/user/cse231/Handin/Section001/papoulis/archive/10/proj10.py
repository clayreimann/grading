#section 001H
#4/8/2013
#proj10

import turtle 
import string
import time

class Star(object):

    def __init__(self, x, y, arm_length, color):
        self.xcoor=x
        self.ycoor=y
        
        self.point_init=x,y
        self.color=color
        self.alen=arm_length
    def draw (self, pen):
        pen.fillcolor(self.color)
        pen.up()
        pen.goto(self.point_init)
        pen.seth(90)
        pen.forward((self.alen)/2.35)
        pen.seth(0)
        pen.forward((self.alen)/3.236)
        pen.down()
        pen.begin_fill()#pen is ready to draw the star
        pen.forward(self.alen)
        pen.right(144)
        pen.forward(self.alen)
        pen.left(72)
        pen.forward(self.alen)
        pen.right(144)
        pen.forward(self.alen)
        pen.left(72)#bottom of star between legs
        pen.forward(self.alen)
        pen.right(144)
        pen.forward(self.alen)
        pen.left(72)
        pen.forward(self.alen)
        pen.right(144)
        pen.forward(self.alen)
        pen.left(72)
        pen.forward(self.alen)
        pen.right(144)
        pen.forward(self.alen)
        pen.end_fill()
        pen.up()        
    def __str__(self):
        return "x:%s y:%s arm:%s c:%s" % (self.xcoor, self.ycoor, self.alen, self.color)
        

class Rectangle(object):
    def __init__(self,x,y,width,height,color):
        self.xcoor=x
        self.ycoor=y
        
        self.point_init=x,y
        self.color=color
        self.vert=height#vertical momvement
        self.horz=width#perpendicular movement
        
    def draw (self, pen):
        pen.fillcolor(self.color) 
        pen.up()
        pen.goto(self.point_init)
        #moving to bottom left corner
        pen.seth(180)
        pen.forward((self.horz)/2)
        pen.seth(270)
        pen.forward((self.vert)/2)
        #pen is now at the bottom left corner
        pen.seth(90)
        pen.down()
        pen.begin_fill()
        pen.forward(self.vert)
        pen.seth(0)
        pen.forward(self.horz)
        pen.seth(270)
        pen.forward(self.vert)
        pen.seth(180)
        pen.forward(self.horz)
        pen.end_fill()
        pen.up()
    def __str__(self):
        return "x:%s y:%s w:%s h:%s c:%s" % (self.xcoor, self.ycoor, self.horz, self.vert, self.color)
        

class Flag(object):

    def __init__(self, file_object):
        rectangles=[]
        stars=[]
        cnt_switch=0
        for line in file_object:
            line=line.strip()
            data_list=line.split(',')
            if len(data_list)==5:#rectangles
                cnt=0
                while cnt<4:#turning rectangles coordinates into int
                    data_list[cnt]=float(data_list[cnt])
                    cnt+=1

                data_list[4]=data_list[4].strip()#striping color
                self.recdata=Rectangle(data_list[0],data_list[1],data_list[2],data_list[3],data_list[4])#storing data
                rectangles.append(self.recdata)         

                
            if len(data_list)==4:#stars
                cnt=0
                while cnt<3:#turning rectangles coordinates into int
                    data_list[cnt]=float(data_list[cnt])
                    cnt+=1

                data_list[3]=data_list[3].strip()#striping color
                self.stardata=Star(data_list[0],data_list[1],data_list[2],data_list[3])#storing data
                stars.append(self.stardata)

                
        self.rec_list=rectangles
        self.star_list=stars

    def draw (self, turtle):
        for element in self.rec_list:#drawing all rectangles
            element.draw(turtle)

        for element in self.star_list:#drawing all stars
            element.draw(turtle)
        
        
    def __str__(self):
        recs=''
        sta=''
        for element in self.rec_list:
            recs=recs+str(element)+'\n'

        for element in self.star_list:
            sta=sta+str(element)+'\n'
        
        return "Rectangle\n%s\nStars\n%s" % (recs,sta)



def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    myFlag_file = open('myFlag.txt')
    myFlag_flag = Flag(myFlag_file)
    print(myFlag_flag)
    myFlag_flag.draw(pen)
    myFlag_file.close()

    
main()
