#section 001H
#2/25/2013
#proj05

def get_input_descriptor ():   
    file_str = input("Enter a file to open: ")
    while True:
        try:
            file_obj = open(file_str, "r")
            print("Opened the file", file_str)
            break
        except IOError:
            print("Failed to open file, please try again")
            file_str = input("Enter a file to open: ")
    return (file_obj)


def get_data_list (file_object,column_number):
    date_data=[]
    next (file_object)#this is to skip the the first line with the column information
    for line in file_object:
        line=line.strip()
        line_list=line.split(',')#spliting line into a list
        num_int=float(line_list[column_number])
        date_data.append((line_list[0],num_int))
    return (date_data)

def average_data (date_data):
    dateYM_data=[]
    #sorting data
    for i in date_data:
        element=i
        dateYMD_str=element[0]
        price_int=element[1]
        dateYMD_str=dateYMD_str.strip()
        dateYMD_list=dateYMD_str.split('-')
        dateYM_str=dateYMD_list[0]+dateYMD_list[1]#combining year and month to one number for sorting later
        dateYM_int=int(dateYM_str)#turing to int for sorting
        dateYM_data.append((dateYM_int,price_int))
    dateYM_data.sort()

    copydata=dateYM_data
    avg_dateYM_data=[]
    #start loop for averaging month
    while True:
        cnt=0
        tempavg=[]
        sum_price=0

        for x in copydata:#isolating month
            active_date=copydata[0][0]
            if x[0]==active_date:
                cnt=cnt+1
                tempavg.append(x)
        
        for a in tempavg:#averaging month price
            price=a[1]
            sum_price+=price
        #computing average
        avgpriceformonth=sum_price/len(tempavg)
        avgmonth=(active_date,avgpriceformonth)
        avg_dateYM_data.append(avgmonth)

        if cnt==len(copydata):
            break
        else:
            copydata=copydata[(cnt):]

    price_dateMY=[]
    for b in avg_dateYM_data:
        avgprice=b[1]
        date_int=b[0]
        date_str=str(date_int)
        avgdate=date_str[4:]+'-'+date_str[:4]
        avgtup=(avgprice,avgdate)
        price_dateMY.append((avgtup))

    return(price_dateMY)

def main():
    file_obj=get_input_descriptor()
    column_number=0
    while True:#loop to make sure the number entered is 1-6
        if 1<=column_number<=6:
            break
        else:
            column_number=int(input('Please select column (1-6) for analysis: '))
        
    data_list=get_data_list(file_obj,column_number)
    avgdata=average_data(data_list)
    avgdata.sort()
    lastindex=int(len(avgdata)-1)


    print('Lowest 6 for column',column_number)
    cnt=0
    while cnt<6:
        dataprint=avgdata[cnt][0]
        dateprint=avgdata[cnt][1]
        cnt+=1
        print('Date:',dateprint,', Value:',"%.2f" % dataprint)

    cnt=0
    print('Highest 6 for column',column_number)
    while cnt<6:
        dataprint=avgdata[lastindex-cnt][0]
        dateprint=avgdata[lastindex-cnt][1]
        print('Date:',dateprint,', Value:',"%.2f" % dataprint)
        cnt+=1
    file_obj.close()
main()
