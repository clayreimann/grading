#section 001H
#3/25/2013
#proj09


import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    foundation = [[],[],[],[]]
    cell = [[],[],[],[]]

    tableau=[[],[],[],[],[],[],[],[],[],[]]
    
    my_deck=cardsBasic.Deck()
    my_deck.shuffle()
    #building tableau
    while (my_deck.cards_count())!=0:
        tableau[0].append(my_deck.deal())
        tableau[1].append(my_deck.deal())
        tableau[2].append(my_deck.deal())
        tableau[3].append(my_deck.deal())
        tableau[4].append(my_deck.deal())
        tableau[5].append(my_deck.deal())
        tableau[6].append(my_deck.deal())
        tableau[7].append(my_deck.deal())
        tableau[8].append(my_deck.deal())
        tableau[9].append(my_deck.deal())
    tableau[2]=tableau[2][0:5]
    tableau[3]=tableau[3][0:5]
    tableau[4]=tableau[4][0:5]
    tableau[5]=tableau[5][0:5]
    tableau[6]=tableau[6][0:5]
    tableau[7]=tableau[7][0:5]
    tableau[8]=tableau[8][0:5]
    tableau[9]=tableau[9][0:5]
    
    
    
    return foundation,tableau,cell


def move_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''

    tab_col=tableau[(t_col-1)]#isolating column from tableau
    found_col=foundation[(f_col-1)]#isolating column from foundation
    if len(tab_col)>=1:#checking to see if tableau is empty
        
        if len(found_col)>=1:#avoiding error if foundation is empty
            if len(tab_col)>=1:
                

                if (tab_col[-1].get_rank()-1)==(found_col[-1].get_rank()) and tab_col[-1].get_suit()==found_col[-1].get_suit():
                    boolean=True
                else:
                    boolean=False
            else:
                boolean=False
            
        else:#empty foundation, must be ace
            if tab_col[-1].get_rank()==1:
                boolean=True
            else:
                boolean=False
            
    else:
        boolean=False

    if boolean==True:
        foundation[(f_col-1)].append(tableau[(t_col-1)].pop())
                   
    

    return(boolean)


def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    tab_col=tableau[(t_col-1)]#isolating column from tableau
    cell_col=cell[(c_col-1)]#isolating one cell from the others

    if len(cell_col)>=1:
        boolean=False
    else:
        boolean=True


    if boolean==True:
        cell[(c_col-1)].append(tableau[(t_col-1)].pop())      

    
    return (boolean)

def move_to_tableau(tableau,cell,c_col,t_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    tab_col=tableau[(t_col-1)]#isolating column from tableau
    cell_col=cell[(c_col-1)]#isolating one cell from the others
    
    if len(cell_col)>=1:#making sure there is somthing in the cell

        if len(tab_col)>=1: # making sure somthing is in the tableau column
            
            if ((cell_col[-1]).get_rank()+1)==(tab_col[-1]).get_rank() and (cell_col[-1]).get_suit()==(tab_col[-1]).get_suit():
                boolean=True
            else:
                boolean=False

        else:
            if cell_col[-1].get_rank()==13:#must be king in order to put card in empty cell
                boolean=True
            else:
                boolean=False
        
    else:
        boolean=False

    if boolean==True:
        tableau[(t_col-1)].append(cell[(c_col-1)].pop())

    
    return (boolean)
        

def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    numberofcards=foundation[0]+foundation[1]+foundation[2]+foundation[3]
    if len(numberofcards)==52:
        win=True
    else:
        win=False
    return win


def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    tab_col_source=tableau[t_col_source-1]
    tab_col_dest=tableau[t_col_dest-1]


    if len(tab_col_source)>=1 and len(tab_col_dest)>=1:
        
        if ((tab_col_source[-1].get_rank())+1)==(tab_col_dest[-1].get_rank()) and (tab_col_source[-1]).get_suit()==(tab_col_dest[-1]).get_suit():
            boolean=True
        else:
            boolean=False
    else:
        if len(tab_col_dest)==0 and tab_col_source[-1].get_rank()==13:#this is to move king from tab to empty tab
            boolean=True
        else:
            boolean=False

    if boolean==True:
        tableau[(t_col_dest-1)].append(tableau[(t_col_source-1)].pop())

    return (boolean)
        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
         

    

    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    while True:
        # Uncomment this next line. It is commented out because setup doesn't do anything so printing doesn't work.
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        r = response_list[0]
        if len(response_list)==3:
            if response_list[1].isdigit() and response_list[2].isdigit():
                response_list[1]=int(response_list[1])
                response_list[2]=int(response_list[2])
                
                if r == 't2f' and 0<=response_list[1]<=10 and 0<=response_list[2]<=4:
                    #x= True
                    t_col= int(response_list[1])
                    f_col= int(response_list[2])
                    if move_to_foundation(tableau,foundation,t_col,f_col):
                        pass

                    else:
                        print('invalid move')
                elif r == 't2t' and 0<=response_list[1]<=10 and 0<=response_list[2]<=10:
                    t_col_source= int(response_list[1])
                    t_col_dest= int(response_list[2])
                    if move_in_tableau(tableau,t_col_source,t_col_dest):
                        pass
                    else:
                        print('invalid move')
                                          
                elif r == 't2c' and 0<=response_list[1]<=10 and 0<=response_list[2]<=4:
                    t_col= int(response_list[1])
                    c_col= int(response_list[2])
                    if move_to_cell(tableau,cell,t_col,c_col):
                        pass
                    else:
                        print('invalid move')
                elif r == 'c2t' and 0<=response_list[1]<=4 and 0<=response_list[2]<=10:
                    t_col= int(response_list[1])
                    c_col= int(response_list[2])
                    if move_to_tableau(tableau,cell,t_col,c_col):
                        pass
                    else:
                        print('invalid move')
                elif r == 'c2f' and 0<=response_list[1]<=4 and 0<=response_list[1]<=4:
                    t_col= int(response_list[1])
                    f_col= int(response_list[2])
                    if move_to_foundation(cell,foundation,t_col,f_col):
                        pass
                    else:
                        print('invalid move')
                elif r == 'q':
                    break
                elif r == 'h':
                    show_help()
                else:
                    print('Unknown command:',response)
            else:
                print("Unknown Command:",response)
        elif len(response_list)==1:
            if r == 'q':
                break
            elif r == 'h':
                show_help()
            else:
                print('Unknown command:',response)
            
        else:
            print("Unknown Command:",response)
        #chekcing if the game has been won
        if is_winner(foundation):
            print('You won!')
            break
        else:
            continue
    print('Thanks for playing')

play()


        
    

