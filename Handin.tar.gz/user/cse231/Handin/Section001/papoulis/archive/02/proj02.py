#input, this is where you get the integer
print('Guess a six-digit number SLAYER so that following equation is true,')
print('where each letter stands for the digit in the position shown:')
print('')
print('SLAYER + SLAYER + SLAYER = LAYERS')
print('')
print('')
num=int(input('Enter your guess for SLAYER: '))

#SLAYER calculation to get each digit seperate
S=num//100000
L=(num//10000)%10
A=(num//1000)%10
Y=(num//100)%10
E=(num//10)%10
R=num%10

#correct
if num==142857:
    print('Your guess is correct:')
    print('SLAYER + SLAYER + SLAYER = ',3*num)
    print('LAYERS = ',L*100000+A*10000+Y*1000+E*100+R*10+S)
    print('Thanks for playing!')

#error
elif num<=100000 or num>1000000:
    print('Your guess is incorrect: ')
    print('SLAYER must be a 6-digit number.')
    print('Thanks for playing!')

#incorrect
else:
    print('Your guess is incorrect:')
    print('SLAYER + SLAYER + SLAYER = ',3*num)
    print('LAYERS = ',L*100000+A*10000+Y*1000+E*100+R*10+S)
    print('Thanks for playing!')
