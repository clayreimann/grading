#section 001H
#3/25/2013
#proj11.py

import urllib.request

class Tour(object):
    def __init__(self,loc1,*loc2):
           
        loc1_list=loc1.split()
        for element in loc1_list:
            element=element.strip(',')
            element=element.strip()
        self.loc1='+'.join(loc1_list)#all spaces and commas are gone, put in '+' in

        dest_list=[]
        loc2_list=[]
        if len(loc2)!=0:
            if type(loc2[0])==list:#preventing error from add function
                loc2=tuple(loc2[0])
            for tup in loc2:
                dest_list.append(tup)
                for element in dest_list:
                    
                    el_list=element.split()
                    for el in el_list:
                        el=el.strip(',')
                        el=el.strip()#for some reason, the comma is staying....
                    loc2_element='+'.join(el_list)
                loc2_list.append(loc2_element)
                            
        

            #used for str,not coverting to have +
        else:
            loc2==False
        self.loc2_list=loc2_list#list of locatoins ready for    
        self.loc1_str=loc1
        self.loc2_str=loc2


    def distance(self, method='driving'):
        
#doing loc1 and the first element in loc2
        url='http://maps.googleapis.com/maps/api/distancematrix/json?origins='+str(self.loc1)+'&destinations='+str(self.loc2_list[0])+'&mode='+str(method)+'&sensor=false'
        web_obj=urllib.request.urlopen(url)
        data=web_obj.read()
        response=data.decode("UTF-8")
        web_obj.close()
        
        response_list=response.split('\n')#breaking at lines
        dist_line=response_list[8]#isolating line with distance data
        dist_list=dist_line.split('"')
        if len(dist_list)<4:
            raise ValueError('ValueError in distance')
        distance_str=dist_list[3]#isolating distance with unit
        distance_str=distance_str[:-2]#removing unit NOTE THAT UNITS ARE IN KM
        distance_str=distance_str.strip()
        dist_str=''
        for char in distance_str:
            if char in ['0','1','2','3','4','5','6','7','8','9']:#isolating number characters 
                dist_str=dist_str+char
        dist_int=int(dist_str)
            
            #loop for adding the
        cnt1=0
        cnt2=1
        
        while cnt2<len(self.loc2_list) and len(self.loc2_list)>1:
            url='http://maps.googleapis.com/maps/api/distancematrix/json?origins='+str(self.loc2_list[cnt1])+'&destinations='+str(self.loc2_list[cnt2])+'&mode='+str(method)+'&sensor=false'
            web_obj=urllib.request.urlopen(url)
            data=web_obj.read()
            response=data.decode("UTF-8")
            web_obj.close()
            response_list=response.split('\n')#breaking at lines
            dist_line=response_list[8]#isolating line with distance data
            dist_list=dist_line.split('"')
            distance_str=dist_list[3]#isolating distance with unit
            distance_str=distance_str[:-2]#removing unit NOTE THAT UNITS ARE IN KM
            distance_str=distance_str.strip()
            dist_str=''
            for char in distance_str:
                if char in ['0','1','2','3','4','5','6','7','8','9']:#isolating number characters 
                    dist_str=dist_str+char
            
            dist_temp=int(dist_str)
            dist_int=dist_int+dist_temp                                                                        
            cnt1+=1
            cnt2+=1
        dist_int=dist_int*1000
        
        return dist_int
    
    def __str__(self):
        loc2str=''
        if len(self.loc2_str)!=0:
            for element in self.loc2_str:
                loc2str=loc2str+element+'; '
        else:
            loc2str=''
        return str(self.loc1_str)+'; '+loc2str

    def __repr__(self):
        loc2str=''
        for element in self.loc2_str:
            loc2str=loc2str+element+'; '
        return str(self.loc1_str)+'; '+loc2str


    def __add__(self,tour):#make sure the argument 2 is a tuple
        el1=self.loc1_str
        el2=self.loc2_str
        el2=list(el2)
        add_el1=[tour.loc1_str]
        add_el2=tour.loc2_str
        add_el2=list(add_el2)
        el2_new=el2+add_el1+add_el2
        return Tour(el1,el2_new)

    def __gt__(self,tour):
        t1=self.distance()
        t2=tour.distance()
        return t1>t2

    def __lt__(self,tour):
        t1=self.distance()
        t2=tour.distance()
        return t1<t2


    def __mul__(self,mult):
        if type(mult)!=int:
            raise TypeError('TypeError in mul')
        
        if mult<0:
            raise ValueError('ValueError in mul')
        cnt=1
        
        while cnt<mult:
            self=self+self
            cnt+=1
        return self

    def __rmul__(self,other):
        return self.__mul__(other)

    def __eq__(self,tour):
        el1_a=self.loc1
        el1_b=tour.loc1
        el2_a=self.loc2_list
        el2_b=tour.loc2_list

        if el1_a==el1_b:
            con1=True
        cnt=0
        for element in el2_a:
            if element==el2_b[cnt]:
                con2=True

        if con2==True and con1==True:
            boo=True
        return boo

def main():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print('t1:',t1)
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000), round(t1.distance('bicycling')/1000),round(t1.distance('walking')/1000)))
    print("Using driving distances from here on.")
    t4 = t1 + t2
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t4 == t1 + t2:", t4 == t1 + t2)

    print('t1*2=',t1*2)
    print('2*t1=',2*t1)

    print('t1>t4:',t1>t4)
    
    print('t1<t4:',t1<t4)
    
    try:
        errindistance()
    except ValueError as err_msg:
        print (err_msg)

    try:
        typeerrinmul()
    except TypeError as err_msg:
        print (err_msg)

    try:
        valerrinmul()
    except ValueError as err_msg:
        print (err_msg)

def errindistance():
    x=Tour('nocity,nostate','Lansing, MI')
    print('trying to get distance of error test tour:', x.distance())

def typeerrinmul():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    a='abc'
    print(t1*a)

def valerrinmul():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    
    print(t1*-1)

main()




    
