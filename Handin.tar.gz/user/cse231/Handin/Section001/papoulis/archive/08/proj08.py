# proj08
# 3/14/13
# Section 001H

import string


#BEWARE, THIS TAKES FOREVER TO GET C_DICT
def fill_completions (c_dict, fd):#note: dictionary is empty when entered

    key_master_list=[]
    word_list=[]

    for line in fd:#getting line
        line=line.strip()
        line_list=line.split()   
        for word in line_list:#isolating word
            word=word.strip(string.punctuation)
            word=word.lower()

            letter_list=list(word)
            num_switch=0
            for letter in letter_list:#checking word for punctuation
                if letter in string.punctuation:
                        num_switch+=1
                
                else:
                    continue
            if num_switch==False and len(word)>1:#if there is puctuation, this will not run
                key_list=list(enumerate(word))
                key_master_list=key_list+key_master_list
                word_list.append(word)

    key_set=set(key_master_list)
    word_set=set(word_list)

    for key in key_set:#matching key with words
        matchlist=[]
        
        for element in word_set:
            if (len(element)-1)>=key[0]:
                
                if key[1]==element[key[0]]:

                    matchlist.append(element)
            else:
                continue

        c_dict[key]=matchlist

def find_completions (prefix, c_dict):
    master_set=set([])
    prefix_key=list(enumerate(prefix))
    for key in prefix_key:
        if len(master_set)==0:
            
            master_set=set(c_dict[key])#when master set is empty
        else:
            master_set=master_set&set(c_dict[key])#when master set has info
        
    return(master_set)
    

def open_file(file_str):
    while True:
        try:
            file_obj = open(file_str, "r")
            print("Opened the file", file_str)
            break
        #reprompts for file name if there is an error
        except IOError:
            print("Failed to open file, please try again")
            file_str = input("Enter a file to open: ")
    return (file_obj)
            
def main():
    file_str=input('Please input the file name to build dictionary:')
    fd=open_file(file_str)
    c_dict={}
    fill_completions (c_dict, fd)
    
    while True:#running until '#' is entered
        prefix=input('Insert prefix or type "#" to terminate program: ')
        if prefix=='#':
            break
        else:
            match_list=find_completions (prefix, c_dict)
            print(match_list)
    

main()

            
        


            
