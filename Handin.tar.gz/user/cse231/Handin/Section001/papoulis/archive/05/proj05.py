#section 001H
#2/11/2013
#proj05

import turtle
import math
import time

def get_color_choice():    
    col_str=input('Please enter your choice: ')
    while True:
        if col_str=='red' or col_str=='green' or col_str=='blue':
            break
        else:
            print(col_str,end="")
            col_str=input(' is not a legal chocie. Please try again: ')
    return col_str
            
def get_num_hexagons():
    numhex=input('Please enter a number of hexagons per row: ')
    while True:
        if numhex.isdigit()==True:
            numhex=int(numhex)
            if 4<=numhex<=20:
                break
            else:
                numhex=input('It should be between 4 and 20. Please try again: ')
        else:
            numhex=input('It should be between 4 and 20. Please try again: ')
    numhex=int(numhex)
    return numhex


def draw_hexagon(x, y, side_len, pen, color):
    cnt=0
    turtle.speed(50)
    turtle.up()
    turtle.goto(x,y)
    turtle.down()
    pen.fillcolor(color)
    pen.begin_fill()
    pen.setheading(210)
    while cnt<6:
        pen.forward(side_len)
        pen.right(60)
        cnt+=1
    pen.end_fill()
    

##########################^^functions defined^^#########################

print('Choices for colors to use are:')
print('\tred')
print('\tblue')
print('\tgreen')



col1=get_color_choice()
col2=get_color_choice()
num_hex=get_num_hexagons()

side_len=(250/num_hex)/math.sin(math.pi/3)

x=-200
y=175
colswitch=1
ycount=0
#tessellation

while ycount<num_hex:
    xcount=0
#generating row
    while xcount<num_hex:
        if colswitch%2==1:
            draw_hexagon(x, y, side_len, turtle, col1)
        else:
            draw_hexagon(x, y, side_len, turtle, col2)
        x=x+(500/num_hex)
        xcount+=1
        colswitch+=1
#stagering hexagons
    if round(x-(500/num_hex)*xcount)==-200:
         x=-200+(500/num_hex)/2
    else:
        x=-200
#changing row
    ycount+=1
    y=y-side_len-(side_len*math.cos(math.pi/3))



turtle.hideturtle()
time.sleep(10)

turtle.bye()







    












