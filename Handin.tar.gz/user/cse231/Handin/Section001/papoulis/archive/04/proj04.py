#proj04 
#2/4/2013 
#section 001H 



str1=input('Please input string 1:') 
str2=input('Please input string 2:') 

print('\nString 1:',str1) 
print('String 2:',str2) 
while True:     


    print('\nWhat do you want to do?') 
    print('\ta (add indel)') 
    print('\td (delete indel)') 
    print('\ts (score)') 
    com=input('\tq (quit): ') 

#quiting program 
    if com=='q': 
        print('Program terminated') 
        break 
#adding an indel 
    elif com=='a': 
        select_str=int(input('Work on which string (1 or 2): ')) 
        if select_str==1: 
            while True: 
                ind_add=int(input('Before what index: ')) 
                if 0<=ind_add<=len(str1): 
                    str_upper=str1[:ind_add] 
                    str_lower=str1[ind_add:] 
                    str1=str_upper+'-'+str_lower 
                    break 
                else: 
                    print('Error, out of range') 
        elif select_str==2: 
            while True: 
                ind_add=int(input('Before what index: ')) 
                if 0<=ind_add<= len(str2): 
                    str_upper=str2[:ind_add] 
                    str_lower=str2[ind_add:] 
                    str2=str_upper+'-'+str_lower 
                    break 
                else: 
                    print('Error, out of range') 
         
#deleting an indel 
    elif com=='d': 
        select_str=int(input('Work on which string (1 or 2): ')) 
        if select_str==1: 
            while True: 
                ind_delete=int(input('Delete what index: ')) 
                if str1[ind_delete]=='-': 
                    str_upper=str1[0:ind_delete] 
                    str_lower=str1[ind_delete+1:] 
                    str1=str_upper+str_lower 
                    break 
                else: 
                    print('Error, please select an indel') 
        elif select_str==2: 
            while True: 
                ind_delete=int(input('Delete what index: ')) 
                if str2[ind_delete]=='-': 
                    str_upper=str2[0:ind_delete] 
                    str_lower=str2[ind_delete+1:] 
                    str2=str_upper+str_lower 
                    break 
                else: 
                    print('Error, please select an indel') 

#scoring the strings 
    elif com=='s': 
        count=0 
         
        str1_score=str1 
        str2_score=str2 

        str1_new='' 
        str2_new='' 
        matches=0 
        mismatches=0 
        #making string the same size 
        while len(str1_score)>len(str2_score): 
            str2_score=str2_score+'-' 
        while len(str2_score)>len(str1_score): 
            str1_score=str1_score+'-' 
        #checking character in string for the score 
        while len(str1_score)>count: 
            if str1_score[count]==str2_score[count]: 
                str1_new=str1_new+str1_score[count] 
                str2_new=str2_new+str2_score[count] 
                count+=1 
                matches+=1 
            else: 
                str1_new=str1_new+str1_score[count].upper() 
                str2_new=str2_new+str2_score[count].upper() 
                count+=1 
                mismatches+=1 
        print('\nMatches: ',matches,' Mismatches: ',mismatches) 


        print('String 1:',str1_new) 
        print('String 2:',str2_new) 
    else: 
        print('Error, please select from menu') 




            
            
        
