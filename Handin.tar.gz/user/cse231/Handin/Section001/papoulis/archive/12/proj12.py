#proj12
# 4/22/13
# Section 001H


from matplotlib.ticker import FuncFormatter
from pylab import *

#data organization:[((month,day,year),max,min),((day,month,year),max,min)]....
list_dmyt=[]
list_hour_temp=[]
file_obj = open('temperature.txt', "r")
for line in file_obj:
    line=line.strip()
    data=line.split()
    if data[0].isdigit() and len(data)==5:
        data_dmyt=((int(data[0]),int(data[1]),int(data[2])),float(data[4]))
        list_dmyt.append(data_dmyt)#((month,day,year),temperature)

    if data[0]=='6':#this is for the 2nd graph
        append_data=(int(data[3]),float(data[4]))
        list_hour_temp.append(append_data)

        




    

day_active=list_dmyt[0][0]
data_temp=[]
list_d=[]#average min max of each day
for data in list_dmyt:
    if data[0]==day_active:
        data_temp.append(data[1])
        
        
    else:
        max_day=max(data_temp)
        min_day=min(data_temp)
        append_data=((day_active),max_day,min_day)
        list_d.append(append_data)
        day_active=data[0]
        data_temp=[]
        data_temp.append(data[1])
        
#list_d= (month,day,year),max,min

#now finding the average high and low for each month
active_month=1
max_sum=0
min_sum=0
cnt=0
data_month_avg=[]
for data in list_d:
    
    if data==list_d[-1]:
        max_avg=max_sum/cnt
        min_avg=min_sum/cnt
        data_append=((active_month,data[0][2]),max_avg,min_avg)
        data_month_avg.append(data_append)
    elif data[0][0]==active_month:
        max_sum+=data[1]
        min_sum+=data[2]
        cnt+=1
        
    else:
        max_avg=max_sum/cnt
        min_avg=min_sum/cnt
        data_append=((active_month,data[0][2]),max_avg,min_avg)
        data_month_avg.append(data_append)
        active_month+=1
        max_sum=0
        min_sum=0
        cnt=0
#data_month_avg=[((month,year),max,min)...]
##############
list_hdyma=[]
file_obj = open('solar_radition.txt', "r")
for line in file_obj:
    line=line.strip()
    data=line.split()

    if data[0]=='6' and len(data)==5:
        data_hdyma=int(data[3]),int(data[1]),int(data[2]),int(data[0]),float(data[4])
        list_hdyma.append(data_hdyma)#(hour,day,year,month,avg)JUNE ONLY



list_hdyma.sort()

active_hour=100
temp_sum=0
cnt=0
list_avg_h=[]#time,temp
for data in list_hdyma:#isolating data for june
    if data==list_hdyma[-1]:
        avg_hr=temp_sum/cnt
        data_append=(active_hour,avg_hr)
        list_avg_h.append(data_append)
            
    elif data[0]==active_hour:
        temp_sum+=data[4]
        cnt+=1
    else:
        avg_hr=temp_sum/cnt
        data_append=(active_hour,avg_hr)
        list_avg_h.append(data_append)
        cnt=0
        temp_sum=0
        active_hour+=100
        temp_sum+=data[4]
        cnt+=1




#first graph
#data_month_avg=[((month,year),max,min)...]
x =     arange(12)
top=[]
bot=[]
for data in data_month_avg:
    bot.append(data[2])
    diff=data[1]-data[2]
    top.append(diff)
ylabel('Average Temp')
title('Charleston,MO-2012')
bar(x, top, bottom=bot)
xticks( x+.45,  ('January','Feburary','March','April','May','June','July','August','Septemper','October','Novemeber','December'),rotation=45 )
plt.savefig('temp.pdf')
plt.close()


####
list_hour_temp.sort()
active_hour=100
temp_sum=0
cnt=0
list_avg_h_temp=[]
for data in list_hour_temp:#getting avg of temp data for each hour
    if data==list_hour_temp[-1]:
        avg_hr=temp_sum/cnt
        data_append=(active_hour,avg_hr)
        list_avg_h_temp.append(data_append)
            
    if data[0]==active_hour:
        temp_sum+=data[1]
        cnt+=1
    else:
        avg_hr=temp_sum/cnt
        data_append=(active_hour,avg_hr)
        list_avg_h_temp.append(data_append)
        cnt=0
        temp_sum=0
        active_hour+=100
        temp_sum+=data[1]
        cnt+=1
####

#second graph
#list_avg_h and list_avg_h_temp=[(hr,avg)....]

solar=[None]
for data in list_avg_h:
    solar.append(data[1])

temp=[None]
for data in list_avg_h_temp:
    temp.append(data[1])


fig = plt.figure()
ax1 = fig.add_subplot(111)
ax1.plot(temp[0:-1],'b.-')
ax1.set_xlabel('Hour')
# Make the y-axis label and tick labels match the line color.
ax1.set_ylabel('Average Temp', color='b')
for tl in ax1.get_yticklabels():
    tl.set_color('b')


ax2 = ax1.twinx()
ax2.plot(solar,'r.-')
ax2.set_ylabel('Average Solar Radiation', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
title('Charleston,MO-2012')
plt.savefig('solarVtemp.pdf')
plt.close()






        
            
