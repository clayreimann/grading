print('Welcome to the vending machine change maker program')
print('Change maker initialized')
price_str=('start')

#start quantity
n=25
d=25
q=25
o=0
f=0

while True:
    print(' ')
    print('Stock contains:')
    print('     ',n,'nickles')
    print('     ',d,'dimes')
    print('     ',q,'quarters')
    print('     ',o,' ones')
    print('     ',f,' fives')
    print(' ')


#input price   
    price_str=input('\nEnter the purchase price (xx.xx) or "quit" to exit the program: ')

#q check
    if price_str =='quit':
        break
    else:
        price=int(float(price_str)*100)

#multiple of 5 and above zero check
        if price%5==0 and price>0:
            print('\nMenu for deposits:')
            print('"n" - deposit a nickel')
            print('"d" - deposit a dime')
            print('"q" - deposit a quarter')
            print('"o" - deposit a one dollar bill')
            print('"f" - deposit a five dollar bill')
            print('"c" - cancel the purchase')
            print(' ')
            print('payment due: $', price_str)

#temporary coin/bill values (reset every run through of loop)
            ntemp=0
            dtemp=0
            qtemp=0
            otemp=0
            ftemp=0

#giving change after purchase, variable reset
            nc=0
            dc=0
            qc=0
#pre defining cancel price
            price_cancel=0
            while price>0:
#deposit input
                deposit=input('Indicate your deposit: ')
#adjusting price, adjusting temporary coin payment, then printing what you have left
                if deposit==('n'):
                    price-=5
                    ntemp+=1
                    if price>0:
                        print('Payment due: ',price//100,'dollars and ',price-(price//100)*100,' cents')
                elif deposit==('d'):
                    price-=10
                    dtemp+=1
                    if price>0:
                        print('Payment due: ',price//100,'dollars and ',price-(price//100)*100,' cents')
                elif deposit==('q'):
                    price-=25
                    qtemp+=1
                    if price>0:
                        print('Payment due: ',price//100,'dollars and ',price-(price//100)*100,' cents')
                elif deposit==('o'):
                    price-=100
                    o+=1
                    otemp+=1
                    if price>0:
                        print('Payment due: ',price//100,'dollars and ',price-(price//100)*100,' cents')
                elif deposit==('f'):
                    price-=500
                    ftemp+=1
                    f+=1
                    if price>0:
                        print('Payment due: ',price//100,'dollars and ',price-(price//100)*100,' cents')
#getting out of deposit loop
                elif deposit==('c'):
                    print('purchase canceled, please take change below')

                    price_cancel=ntemp*5+dtemp*10+qtemp*25+otemp*100+ftemp*500
#giving back change after cancellation of payment
                    while (price_cancel//25)>=1 and q>0:
                        price_cancel-=25
                        q-=1
                        qc+=1
                    while (price_cancel//10)>=1 and d>0:
                        price_cancel-=10
                        d-=1
                        dc+=1
                    while (price_cancel//5)>=1 and n>0:
                        price_cancel-=5
                        n-=1
                        nc+=1
                    break
                
                else:
                    print('invalid input')
                if price==0:
                    print('No change')

#adding payment to machine
            n=n+ntemp
            d=d+dtemp
            q=q+qtemp


#giving change if required
           
            price=price*(-1)
            while (price//25)>=1 and q>0:
                price-=25
                q-=1
                qc+=1
            while (price//10)>=1 and d>0:
                price-=10
                d-=1
                dc+=1
            while (price//5)>=1 and n>0:
                price-=5
                n-=1
                nc+=1

            if nc>0 or dc>0 or qc>0: 
                print('\nPlease take change below')
            if nc>0:
                print(nc,' nickles')
            if dc>0:
                print(dc,' dimes')
            if qc>0:
                print(qc,' quarters')


            if price>0:
                print('The machine is out of change')
                print('See store manager for remaining refund')
                print('Payment due from manager: ',price//100,'dollars and ',price-(price//100)*100,' cents')
            if price_cancel>0:
                print('The machine is out of change')
                print('See store manager for remaining refund')
                print('Payment due from manager: ',price_cancel//100,'dollars and ',price_cancel-(price_cancel//100)*100,' cents')
                    

#invalid entry, print and return to price input
        else:
            print('Illegal price: Must be a non-negative multiple of 5 cents')
#total in machine upon exit
Total=n*5+d*10+q*25+o*100+f*500
print('Total: ',Total//100,'dollars and ',Total-(Total//100)*100,' cents')
