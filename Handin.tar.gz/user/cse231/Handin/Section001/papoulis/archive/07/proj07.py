#section 001H
#3/11/2013
#proj07

import random


def open_read_file(file_str):
    while True:
        try:
            file_obj = open(file_str, "r")
            print("Opened the file", file_str)
            break
        #reprompts for file name if there is an error
        except IOError:
            print("Failed to open file, please try again")
            file_str = input("Enter a file to open: ")
    return (file_obj)

def scramble_word(word):
    
    word_list=list(word)

    punc_index=[]
    cnt=0
    for i in word_list:#indexing the punctuation
        if i in [',','-','_','"',"'",'.',':','?','(',')','[',']','{','}']:
            punc_index.append((cnt,i))
        cnt+=1
    letter_list=[]

    
    for x in word_list:#generating word without puctuation
        if x in ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']:
        
            letter_list.append(x)
    if len(letter_list)>0: #takes off terminal letters, scrambles remaining letters, then reforms the word with terminal letters
        letterstart=list(letter_list[0])
        letterend=list(letter_list[len(letter_list)-1])
        letter_list_striped=letter_list[1:(len(letter_list)-1)]
        random.shuffle(letter_list_striped)
        shuffled_word_list=letterstart+letter_list_striped+letterend

        for punc in punc_index:
            shuffled_word_list.insert(punc[0],punc[1])
        shuffled_word=''.join(shuffled_word_list)
    else: #if the string was just punctuation, it resets the word to avoid error
        shuffled_word=word


    #if single letter word, automaticly resets to avoid glitch
    if len(word)==1:
        shuffled_word=word    
    return (shuffled_word)

def scramble_line (line):
    #turning line into list
    line_list=line.split()
    line_list_scrambled=[]
    #for loop to scramble each word
    for word in line_list:
        word_scrambled=scramble_word(word)
        line_list_scrambled.append(word_scrambled)
    #reforming line
    line_scrambled=' '.join(line_list_scrambled)
    return (line_scrambled)

def main():
    #prompting for write file name
    file_write_str=input('Please input the file name to write too: ')
    file_write = open(file_write_str, "w")
    file_str=input('Please input the file name to read and scramble:')
    file_obj=open_read_file(file_str)
    for line in file_obj:#for loop writing to new file
        line_scrambled=scramble_line(line)
        line_write='\n'+line_scrambled
        file_write.write(line_write)
        
    file_obj.close()
    file_write.close()


main()
    
    
