#Spiro Papoulis

richt_inp=input ('Please input the Richter scale measure: ')
richt_flo= float (richt_inp)

energy=10**(1.5*richt_flo+4.8)
tonTNT=energy/(4.184*10**9)

print ('Richter measure:', richt_flo)
print ('Equivalencein joules: ', energy)
print ('Equivalence in tons of TNT: ', tonTNT)

a=1
b=5
c=9.1
d=9.2
e=9.5
print(' ')
print ('Richter      ','Joules                      ','TNT')
print (a,'       ',10**(1.5*a+4.8),'       ',(10**(1.5*a+4.8))/(4.184*10**9))
print (b,'       ',10**(1.5*b+4.8),'       ',(10**(1.5*b+4.8))/(4.184*10**9))
print (c,'     ',10**(1.5*c+4.8),'    ',(10**(1.5*c+4.8))/(4.184*10**9))
print (d,'     ',10**(1.5*d+4.8),'    ',(10**(1.5*d+4.8))/(4.184*10**9))
print (e,'     ',10**(1.5*e+4.8),'   ',(10**(1.5*e+4.8))/(4.184*10**9))
