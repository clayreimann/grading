# Project 2
# Guess and Check Program
# By Mark Mangliers

#Define function and variable to loop
loopvar = True
def test():
    
    #initialize variables used to verify correct input
    gotdigits = False
    gotint = False

    #While loop until correct input is detected
    while gotdigits == False:
        #reset variables for new input
        gotdigits = False
        gotint = False
        slayer = 0
        slaystr = input("""
Please enter a 6 digit number that satisfies the following expression:
SLAYER + SLAYER + SLAYER = LAYERS

""")
        #Bonus: Checks and prints all solutions if CHEAT is entered
        if slaystr == 'CHEAT':
            i=0
            solutions = list()

            for i in range(100000,1000000):
                d1 = i%10
                d2 = i//10%10
                d3 = i//100%10
                d4 = i//1000%10
                d5 = i//10000%10
                d6 = i//100000%10
                layers = d6+d1*10+d2*100+d3*1000+d4*10000+d5*100000

                if i*3 == layers:
                    solutions.append(i)
            print('\nSolutions are: ',solutions)
            
        else:
            #Test if input can be converted to an integer and do so
            try:
                int(slaystr)
                gotint=True
                slayer = int(slaystr)
            except ValueError:
                gotint=False

            #confirm that the input is 6 digits and provide user feedback
            if gotint != True:
                print("\nThat wasn't an integer! Try again...")
            elif gotint != False and 100000 <= slayer <= 999999 :
                gotdigits = True
            elif gotint != False and slayer > 999999 or slayer < 100000:
                print("\nThat wasn't 6 digits! Try again... ")
        

    #Receive digits and calculate solution
    d1 = slayer%10
    d2 = slayer//10%10
    d3 = slayer//100%10
    d4 = slayer//1000%10
    d5 = slayer//10000%10
    d6 = slayer//100000%10
    layers = d6+d1*10+d2*100+d3*1000+d4*10000+d5*100000

    #check solution and congratulate user
    print("\nSLAYER+SLAYER+SLAYER =", 3*slayer)
    print("LAYERS = ", layers)

    if 3*slayer == layers :
        print("\nYour guess was correct!")
        print('BONUS PRIZE! Type "CHEAT" as your input for SLAYERS to have the program check for all integer solutions!')

    if 3*slayer != layers:
            print("\nYour guess was incorrect.")

    #The program asks the player if they would like to play again based on y/n
    answerReceived = False
    while answerReceived == False :
        answerReceived = False
        answer = input("\nWould you like to play again?\ny = yes\nn = no\n")
        if answer == 'y':
            answerReceived = True
        elif answer == 'n':
            answerReceived = True
            loopvar = False
        else:
            print("\nI'm sorry, I didn't understand your answer. Please try again.\n")

#Loop the function until the user decides to quit
while loopvar == True:
    test()
    

