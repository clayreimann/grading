#CSE 231 Section 001
#Project 11
#Due 4/15/2013

import urllib.request

class Tour(object):
    def __init__(self, *cities):
        """Stores each destination passed to the instance as a tuple"""
        self.city_tuple = cities

    def __str__(self):
        """Prints each destination contained in the instance"""
        return '; '.join(self.city_tuple)

    def __repr__(self):
        """Prints each destination contained in the instance"""
        return '; '.join(self.city_tuple)

    def distance(self, mode='driving'):
        """Calculates the total distance going from each city to the next"""
        #Recreate tuple into list replacing spaces with '+'
        self.city_list = ['+'.join(x.split()) for x in self.city_tuple]
        self.mode = mode
        self.url = 'http://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&mode={}&sensor=false'
        self.stops = len(self.city_tuple)
        self.total_dist = 0
        while True:
            #Format the url string and retrieve the web object
            self.new_url = self.url.format(
                    self.city_list[self.stops-2],self.city_list[self.stops-1],self.mode
                    )
            self.web_obj = urllib.request.urlopen(
                self.new_url
                )
            self.results = str(self.web_obj.read())
            self.web_obj.close()
            self.start = self.results.find('value')+9
            #If value isn't found, find returns -1
            if self.start == 8:
                raise ValueError ('Unable to retrieve distance between given cities')
            self.end = self.results.find('\\n', self.start,-1)
            #Use found strings to slice out the distance value
            self.results = int(self.results[self.start:self.end])
            self.total_dist += self.results
            self.stops -= 1
            #Repeat until each stop has been calculated
            if self.stops < 2:
                return self.total_dist

    def __add__(self, other):
        """Adds the destinations of one Tour to the first and returns a new Tour"""
        try:
            destinations = list(self.city_tuple)+list(other.city_tuple)
        except AttributeError:
            raise TypeError ("Tour instances may only be added to other instances of the same class")
        return Tour(*destinations)

    def __mul__(self,other):
        """Repeats the stops on a Tour by a given multiple and returns as new Tour"""
        try:
            destinations = list(self.city_tuple)*other
            if other <= 0:
                raise ValueError ("Cannot multiply by non-positive integers")
        except TypeError:
            raise TypeError ("Cannot multiply by non-integer values")
        return Tour(*destinations)

    def __rmul__(self,other):
        """Repeats the stops on a Tour by a given multiple and returns as new Tour"""
        try:
            destinations = list(self.city_tuple)*other
            if other <= 0:
                raise ValueError ("Cannot multiply by non-positive integers")
        except TypeError:
            raise TypeError ("Cannot multiply by non-integer values")
        return Tour(*destinations)
    
    def __gt__(self,other):
        """Compares the distance of two tours"""
        if self.distance() > other.distance():
            return True
        else:
            return False

    def __lt__(self,other):
        """Compares the distance of two tours"""
        if self.distance() < other.distance():
            return True
        else:
            return False

    def __eq__(self,other):
        """Checks to see if two tours are exactly equal"""
        if self.city_tuple == other.city_tuple:
            return True
        else:
            return False

def main():
    """Main demos the Tour class. Comments are in place to show where each method is being tested"""
    #__init__
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    
    #__str__
    print("t1: {}\nt2: {}\nt3: {}\n".format(t1,t2,t3))

    #__repr__
    print(repr(t1))
    print()
    
    #distance() with mode variation
    #NOTE: This biking distance varies from the proj11 example
    #however, the distance here is correct; google's distances may have changed
    #since creating the proj11 specifications
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km\n".format(
    round(t1.distance()/1000), round(t1.distance('bicycling')/1000),
    round(t1.distance('walking')/1000)))
    print("Using driving distances from here on.\n")
    
    #__add__
    t4 = t1 + t2
    print("t4 = t1 + t2")
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km\n")
    
    #__eq__
    print("t4 == t1 + t2: ", t4 == t1 + t2)
    
    #__lt__
    print("t4 < t1: ", t4 < t1)
    print("t1 < t4: ", t1 < t4)

    #__gt__
    print("t4 > t1: ", t4 > t1)
    print("t1 > t4: ", t1 > t4,)
    print()

    #__mul__
    print("t3 * 2: ", t3*2)

    #__rmul__
    print("3 * t2: ", 3*t2)
    print()


