#CSE 231 Section 001H
#Honors Section Project (Project 12)
#Due 4/18/2013

import matplotlib.pyplot as plt

def get_monthly_data(text):
    """Returns average monthly high and low values as a dictionary in the form key: (high, low)"""
    #initialize counters and lists to store temporary data
    current_month = 1
    current_day = 1
    day_temps = []
    month_maxes = []
    month_mins = []
    result = {}
    for line in text:
        #Clean each line of the file
        values = line.strip().split()
        for i in range(0,len(values)):
            values[i] = values[i].strip()
        #Throw out bad lines of the file
        try:
            int(values[0])
        except ValueError:
            continue
        #gather temperatures for each day
        if int(values[1]) == current_day:
            day_temps.append(float(values[4]))
        else:
            #find daily high and low and store each day for the month
            day_max = max(day_temps)
            day_min = min(day_temps)
            current_day = values[1]
            day_temps = []
            day_temps.append(float(values[4]))
            month_maxes.append(day_max)
            month_mins.append(day_min)
            current_day = int(values[1])
            #If the month has changed, find the high and low for the previous month
            #and store it in the result dictionary
            if int(values[0]) != current_month:
                month_max = sum(month_maxes)/len(month_maxes)
                month_min = sum(month_mins)/len(month_mins)
                result[current_month] = [month_max,month_min]
                month_maxes = []
                month_mins = []
                current_month = int(values[0])
    #Final pass for december
    month_max = sum(month_maxes)/len(month_maxes)
    month_min = sum(month_mins)/len(month_mins)
    result[current_month] = [month_max,month_min]            
    return result

def get_hourly_data(file,month=6):
    """Returns average hourly data for a given month as a sorted list of tuples"""
    june_hourly = {}
    current_day = 1
    count = 0
    for line in file:
        #Clean each line of the file
        values = line.strip().split()
        for i in range(0,len(values)):
            values[i] = values[i].strip()
        #Throw out bad lines of the file
        try:
            int(values[0])
        except ValueError:
            continue
        #Gather hourly data in a dictionary for easy storage
        if int(values[0]) == month:
            try:
                june_hourly[int(values[3])] += float(values[4])
            except KeyError:
                june_hourly[int(values[3])] = float(values[4])
            count+=1
        elif int(values[0]) > 6:
            count /= 24
            break
    #Average the value for each hour
    for hour,total in june_hourly.items():
        june_hourly[hour] /= count
    june_hourly = sorted(tuple(june_hourly.items()))
    return june_hourly

def main():
    """Implements the get_monthly_data and get_hourly_data to generate two graphs as .png files"""
    
    #Open temperatures for monthly highs and lows
    highlow_file = open('temperature.txt')
    temp_data = get_monthly_data(highlow_file)
    highlow_file.close()

    #reopen temperatures to receive hourly data for june
    june_temp_file = open('temperature.txt')
    june_temp = get_hourly_data(june_temp_file)
    june_temp_file.close()

    #open solar data to receive hourly data for june
    solar_file = open('solar_radition.txt')
    june_solar = get_hourly_data(solar_file)
    solar_file.close()

    #Create, label, and save the stacked bar graph
    bar_graph = plt.figure()
    ax = bar_graph.add_subplot(111)
    ax.bar([1.5*x+0.5 for x in range(0,12)], [x[0]-x[1] for x in temp_data.values()],
                         width=0.8,bottom = [x[1] for x in temp_data.values()])
    plt.xticks([1.5*x+0.9 for x in range(0,12)],('January', 'February', 'March','April','May','June','July','August','September','October','November', 'December'),rotation=35)
    ax.set_ylabel('Average Temperature')
    ax.set_title('Charleston, MO 2012')
    plt.gcf().subplots_adjust(bottom=0.15)
    plt.savefig('Average_Temp.png')

    #Create and label the temperature data for the scatter plot
    scatter_plot = plt.figure()
    ax1 = scatter_plot.add_subplot(111)
    ax1.plot([x[0]/100 for x in june_temp], [y[1] for y in june_temp],'b-o')
    ax1.set_ylabel('Average Temperature')
    ax1.set_xlabel('Hour')
    ax1.set_title('Charelston, MO - June 2012')
    ax1.yaxis.label.set_color('blue')
    ax1.tick_params(axis='y', colors='b')

    #Create and label the solar data for the scatter plot
    ax2 = ax1.twinx()
    ax2.plot([x[0]/100for x in june_solar], [y[1] for y in june_solar],'r-o')
    ax2.set_ylabel('Average Solar Radiation')
    ax2.yaxis.label.set_color('r')
    ax2.tick_params(axis='y', colors='red')

    #Save the graph for june's data
    plt.savefig('June_Hourly.png')

main()
