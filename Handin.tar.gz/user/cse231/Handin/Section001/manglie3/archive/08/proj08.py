#Project 08
#Due March 18
#CSE 231 Sec 001
import string
import re

def fill_completions(c_dict, fd):
    #Words list to easily check which words have already been processed
    words_list = set()
    for line in fd:
        for word in line.split():
            word = word.strip()
            word = word.strip(string.punctuation)
            word = word.lower()
            if word not in words_list:
                words_list.add(word)
                #Regular expression to limit words to numerics, dashes, and apostrophes
                if len(word) > 1 and bool(re.match("^[a-z,-]*$",word)):
                    #Commented out non-regular expression method
                    """for letter in word:
                        if letter.isdigit():
                            continue
                    else:"""
                    index = 0
                    for letter in word:
                        if (index, letter) in c_dict:
                            c_dict[(index,letter)].add(word)
                        else:
                            c_dict[(index,letter)] = {word}
                        index+=1
    
def find_completions(prefix, c_dict):
    result = set()
    keys = [(index, prefix[index]) for index in range(0,len(prefix))]
    #Try to catch characters that aren't in the dictionary (I.E. word[0] = '?')
    try:
        result = c_dict[keys[0]].copy()
        for key in keys:
            result &= c_dict[key]
    except (KeyError, IndexError):
        return set()
    return result

def main():
    #Open file, fill dictionary, close file when finished
    read_file = open('ap_docs.txt','r')
    c_dict = {}
    fill_completions(c_dict, read_file)
    read_file.close()
    while True:
        prefix = input("\nPlease enter a prefix to search for ('#' to quit): ")
        print()
        if prefix == '#':
            break
        #Process the input to make lowercase and remove any punctuation (generally shouldn't affect results)
        prefix = prefix.lower()
        prefix = prefix.strip()
        #Sort the returned set for alphabetical printing (remove "sorted()" for default printing)
        completions = sorted(find_completions(prefix, c_dict))
        if completions == list() or completions == set():
            print("I'm sorry, no matches were found.")
        else:
            #Print in three columns (Credit to Dr. Punch for general idea, referenced from lecture example)
            columns = 0
            for word in completions:
                print('{:25s}'.format(word), end=' ')
                if columns == 2:
                    print()
                    columns = 0
                else:
                    columns+= 1
            print()
main()
