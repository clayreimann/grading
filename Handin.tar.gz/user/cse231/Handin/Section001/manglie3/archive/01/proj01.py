#Print Program Info
print("Richter Scale Converter\nBy Mark Mangliers\nProject 01\n")

#Receive and convert input
numString = input("Please enter a number on the Richter Scale: ")
numFloat = float(numString)
joules = 10**(1.5*numFloat+4.8)
tnt = joules/(4.184*10**9)

#Return input to user
print("\nA measure of", numString, "on the Richter scale is equal to", joules, "joules and", tnt, "tons of TNT.\n")

#Calculate and provide sample numbers
j1 = 10**(1.5*1+4.8)
j5 =10**(1.5*5+4.8)
j91 =10**(1.5*9.1+4.8)
j92 =10**(1.5*9.2+4.8)
j95 =10**(1.5*9.5+4.8)

tn1=j1/(4.184*10**9)
tn5=j5/(4.184*10**9)
tn91=j91/(4.184*10**9)
tn92=j92/(4.184*10**9)
tn95=j95/(4.184*10**9)

print("Richter           Joules                     TNT")
print("1          ",j1,"       ",tn1)
print("5          ",j5,"       ",tn5)
print("9.1        ",j91,"    ",tn91)
print("9.2        ",j92,"    ",tn92)
print("9.5        ",j95,"   ",tn95)
