#Project 3 - Vending Machine Simulation

print("Initializing vending machine simulator...")

#Initialize the vending machines stock
stockQuar = 25
stockNick = 25
stockDime = 25
stockOnes = 0
stockFive = 0
#Amount owed is an additional variable for tracking the total amount the machine could not repay
#for the purposes of calculating end profit
amountOwed = 0

#Execute the program until user quits
while True:
    print("""\nMachine stock contains:
""", stockNick, """Nickels
""", stockDime, """Dimes
""", stockQuar, """Quarters
""", stockOnes, """One dollar bills
""", stockFive, """Five dollar bills""")

    #while loop to determine whether the user quits and to verify that the input is a non-negative multiple of 5
    validPrice = False
    while validPrice == False:
        priceStr = input("\nPlease enter purchase price [Non negative multiple of 5 cents] or 'q' to quit: ")

        #If the user quits, the loop breaks, bypassing the else statement and skipping to the final few lines of code
        if priceStr == 'q' or priceStr == 'quit' or priceStr == 'Quit' or priceStr == 'QUIT':
            break
        
        priceFlo = round(float(priceStr)*100)
        
        if priceFlo < 0 or priceFlo % 5 != 0:
            print("I'm sorry, that price was invalid. Try again.")
            continue
        else:
            validPrice = True

    else:
        print("""\nMenu for payment:
'n' - pay a nickel
'd' - pay a dime
'q' - pay a quarter
'o' - pay one dollar
'f' - pay five dollars""")
        #Store original price in case refund is requested
        priceOrig = priceFlo

        #while loop until the user has completed payment
        while priceFlo > 0:

            #Series of statements to print remaining amount due, but skips dollars or cents if amount is 0
            if priceFlo > 0:
                print("\nPayment due: ", end="")
                if priceFlo//100 !=0:
                    print(priceFlo//100, "dollars ", end="")
                    if priceFlo%100!=0:
                        print("and", priceFlo%100, "cents")
                    else:
                        print("\n")
                elif priceFlo%100 !=0:
                    print(priceFlo%100, "cents")
            
            payment = input("Please enter your payment one dollar/coin at a time: ")

            #Series of if statements to determine how the program should react
            #Adds money to stock and subtracts from amount owed
            if payment == 'n':
                stockNick += 1
                priceFlo -= 5
            elif payment == 'd':
                stockDime +=1
                priceFlo -= 10
            elif payment == 'q':
                stockQuar += 1
                priceFlo -= 25
            elif payment == 'o':
                stockOnes += 1
                priceFlo -= 100
            elif payment == 'f':
                stockFive += 1
                priceFlo -=500
            #Special case for cancel: calculates amount paid so far so a refund can be returned
            elif payment == 'c':
                priceFlo = priceFlo-priceOrig
            else:
                print("Invalid input")
        #Else executes once payment is fulfilled        
        else:

            #Calculates if change is due and begins finding coins if change is due
            changeDue = priceFlo*-1
            if changeDue != 0:

                #Calculates the amount of each coin the machine should/can return
                #Subtracts remaining amount due as it goes, removes coins from stock
                quarDue = changeDue//25
                if quarDue > stockQuar:
                    quarDue = stockQuar
                changeDue -= 25*quarDue
                stockQuar -= quarDue

                dimeDue = changeDue//10
                if dimeDue > stockDime:
                    dimeDue = stockDime
                changeDue -= 10*dimeDue
                stockDime -= dimeDue

                nickDue = changeDue//5
                if nickDue > stockNick: 
                    nickDue = stockNick
                changeDue -= 5*nickDue
                stockNick -= nickDue
                
                #Tells user change given, skips coins which aren't returned
                print("\nPlease take your change:\n")
                if quarDue != 0:
                    print(quarDue, "quarters")
                if dimeDue != 0:
                    print(dimeDue, "dimes")
                if nickDue != 0:
                    print(nickDue, "nickels")

                #If exact change could not be given, tells user to collect remaining from management
                if changeDue > 0:
                    print("\nThe machine has run out of change, please see a manager to receive your remaining refund.")
                    #Tracks amount owed by management
                    amountOwed += changeDue
                    #Same as "payment due" print statements, but for amount owed this cycle
                    print("\nAmount owed: ", end="")
                    if changeDue//100 !=0:
                        print(changeDue//100, "dollars ", end="")
                        if changeDue%100!=0:
                            print("and", changeDue%100, "cents")
                        else:
                            print("\n")
                    elif changeDue%100 !=0:
                        print(changeDue%100, "cents")
            #If no change due, skips the above and tells user nothing is due
            else:
                print("\nNo change due")
            continue
    #Break statement will only be hit if above while-else is broken, allowing the program to end when the user quits
    break

#Calculates money left in the machine, amount owed by management, and the profit made by the machine.

machineTotal = 25*stockQuar+10*stockDime+5*stockNick+100*stockOnes+500*stockFive
profit = machineTotal-1000-amountOwed
print("\nRemaining money in machine:", machineTotal//100, "dollars and", machineTotal%100, "cents")
print("Amount owed by management:", amountOwed//100, "dollars and", amountOwed%100, "cents")
print("Total profit is:", profit//100, "dollars and", profit%100, "cents")
