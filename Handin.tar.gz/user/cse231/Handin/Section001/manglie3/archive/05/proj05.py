#Project 5 CSE 231 Section 01
#Due Feb 11th

#Import relevant modules
import turtle
import math
import time

#Function to print selection options, cleaner to separate from code
def colorMenu():
    print("""Legal choices for color seclection include:
   red
   blue
   yellow
   green""")

#Queries for an integer from 4 to 20 and returns the value
def getNumHexagons():
    while True:
        choice = input("\nPlease enter the number of hexagons per row to be drawn [4 to 20]: ")
        if choice.isdigit() == True and 4 <= int(choice) <= 20:
            return(int(choice))
        else:
            print(choice, "is not a legal choice")
            continue

#Queries for a color from among a set of valid options and returns the string
def getColorChoice():
    legal = ['red','green','yellow','blue']
    while True:
        choice = input("\nPlease select your color choice: ")
        if choice not in legal:
            print(choice, "is not a legal choice")
            continue
        else:
            return(choice)

#Draws a single hexagon with black outline and a fill color.
def drawHexagon(x, y, length, pen, color):
    pen.speed(0)
    pen.setheading(90)
    pen.color('black')
    pen.up()
    pen.goto(x,y)
    pen.down()
    pen.begin_fill()
    for i in range(1,7):
        pen.forward(length)
        pen.left(60)
    pen.color(color)
    pen.end_fill()
    pen.color('black')
    pen.up()

#Calls the input functions to gather information for image
colorMenu()
colors = [getColorChoice(),getColorChoice()]
number = getNumHexagons()

#Calculates the length of each side and initializes starting coordinates
#Values are rounded to help the turtle follow a nicer path, though this may
#sacrifice accuracy of the exact row width
sideLength = round(500/2/number*(1/math.cos(math.pi/6)))
xCoor = round(-250+500/number)
yCoor = round(250-500/number)

#Begins row count. Stagger is used for tracking which rows to indent
#and i is used to alternated between the two colors in the colors list.
yDrawn = 0
i = 0
stagger = True

#Draws until all rows are completed
while yDrawn < number:
    xDrawn = 0
    #Draws until an individual row is filled
    while xDrawn < number:
        drawHexagon(xCoor, yCoor, sideLength, turtle, colors[i])
        xDrawn+=1
        #-1 to correct for minor rounding error
        xCoor+=round(500/number)-1
        #This sequence for i will alternate between 0 and 1 to cycle through the list
        i += 1
        i = i%2
    #Initializes the next row, alternating indents
    else:
        yDrawn+=1
        yCoor = yCoor - sideLength - round(sideLength*math.sin(math.pi/6),5)
        if stagger == True:
            xCoor = round(-250+500/number - 500/number/2)
            stagger = False
        else:
            xCoor = round(-250+500/number)
            #if the row is not staggered, i is shifted to its next value
            #to create the diagonal rows pattern instead of the vertical columns
            i+=1
            i = i%2
            stagger = True

#Waits 15 seconds to analyze the image and then closes the image
time.sleep(15)
turtle.bye()
        
