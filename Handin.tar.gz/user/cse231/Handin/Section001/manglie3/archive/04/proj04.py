#Project 4

while True:
    print("This program will allow you to edit strings with indel operations.")
    print("""\n======================================================
PLEASE NOTE: the strings will be altered after each cycle as follows:
Matching (redundant) indels will be removed
Extra indels at the end of string will be removed
Indels will be added to the strings if necessary to make them of equal length
All strings entered will be converted to lowercase

These operations may make it appear as though your add/delete operations
are functioning improperly; however, the program simply automatically cleans
the strings after each user operation.
======================================================\n""")
    #Asks the user if they would like to use ATCG mode, with error checking
    while True:
        print("ATCG mode forces the user to input only ATCG characters in order to simulate a biological envrionment.\n")
        choice = input("Would you like to activate ATCG mode ['y' or 'n']?")
        if choice != 'y' and choice != 'n':
            print("\nI'm sorry, your response could not be recognized. Try again.\n")
            continue
        else:
            break
    #Gets inputs, error checks if ATCG mode is activated
    while True:
        strings = [input("\nPlease enter your first string: "), input("Please enter your second string: ")]
        if choice == 'y':
            check = ['a', 'A', 't', 'T', 'c', 'C', 'g', "G", '-']
            valid = True
            for item in strings:
                for char in item:
                    if (char in check) == False:
                        valid = False
            if valid == False:
                print("I'm sorry, your strings did not consist of just ATCG")
                continue
        break

    #initializes strings to lower case
    strings[0] = strings[0].lower()
    strings[1] = strings[1].lower()

    
    while True:
        #Truncates extraneous indels and adds indels to make strings equal in length
        while strings[0][len(strings[0])-1]=='-':
            strings[0] = strings[0][:-1]
        while strings[1][len(strings[1])-1]=='-':
            strings[1] = strings[1][:-1]
        while len(strings[0]) > len(strings[1]):
            strings[1] = strings[1]+'-'
        while len(strings[1]) > len(strings[0]):
            strings[0] = strings[0]+'-'

        #Finds if an indel exists at the same index in both strings
        #Deletes this redundant indel in both strings
        index = 0
        while index < len(strings[0]):
            if strings[0][index] == strings[1][index] and strings[0][index] == '-':
                seg1 = strings[0][:index]
                seg2 = strings[0][index+1:]
                strings[0] = seg1 + seg2
                seg1 = strings[1][:index]
                seg2 = strings[1][index+1:]
                strings[1] = seg1 + seg2
                index-=1
            index+=1

      #Prints strings and menus
        print("\nString 1:", strings[0], "\nString 2:",strings[1])
        choice = input("""\nMenu:
   a: add indel
   d: delete indel
   s: check score
   q: quit

   Your choice: """)

        #exits with break
        if choice == 'q':
            break

        #initiates add indel sequence
        elif choice == 'a':
            while True:
                #selects string or returns to main menu
                selectStr = input("\nAdd: Which string would you like to work on [c to cancel]? ")
                if selectStr == 'c':
                    break
                #Verifies that input is valid [integer between 1 and 2]
                elif selectStr.isdigit() == True and 1 <= int(selectStr) <=2:
                    selectInt = int(selectStr)
                    while True:
                        #selects index or returns to menu
                        print("\nAdd to string", selectInt, ": Which index would you like to insert to? [c to cancel]: ", end="")
                        index = input()
                        if index == 'c':
                            break

                        #verfies that input is valid [integer that is valid index]
                        #adds an indel after splitting the string in two
                        elif index.isdigit() == True and int(index) < len(strings[selectInt-1]):
                            index = int(index)
                            seg1 = strings[selectInt-1][:index]
                            seg2 = strings[selectInt-1][index:]
                            strings[selectInt-1] = seg1+ '-' + seg2
                            break
                        #Asks the user for new input if index is invalid
                        else:
                            print("I'm sorry, please enter an integer that corresponds to an index in your string")
                            continue
                else:
                    #asks the user for new input if string is invalid
                    print("Invalid input; please enter 1 or 2 to select a string")
                    continue
                break

        #initiates delete indel sequence
        elif choice == 'd':
            while True:
                #selects string or returns to main menu
                selectStr = input("\nDelete: Which string would you like to work on [c to cancel]? ")
                if selectStr == 'c':
                    break
                #verifies that string selection is valid
                elif selectStr.isdigit() == True and 1 <= int(selectStr) <=2:
                    selectInt = int(selectStr)
                    while True:
                        #asks for index or returns to menu
                        print("\nDelete from string", selectInt, ": Which index would you like to insert to? [c to cancel]: ", end="")
                        index = input()
                        if index == 'c':
                            break
                        #verifies that index is valid and index is an indel
                        elif index.isdigit() == True and int(index) < len(strings[selectInt-1]) and strings[selectInt-1][int(index)] == '-':
                            index = int(index)
                            seg1 = strings[selectInt-1][:index]
                            seg2 = strings[selectInt-1][index+1:]
                            strings[selectInt-1] = seg1 + seg2
                            break
                        else:
                            #asks user for new input if index isn't valid
                            print("I'm sorry, please enter a positive index that corresponds to an indel in your string")
                            continue
                else:
                    #asks user for new input if string isn't valid
                    print("Invalid input; please enter 1 or 2 to select a string")
                    continue
                break

        #initiates scoring sequence            
        elif choice == 's':
            #initiates values for scoring and displaying scored strings
            matches = 0
            mismatches = 0
            scoredStr1 = ''
            scoredStr2 = ''

            #for loop cycles through each index of the strings and compares their values
            #loop scores even matching indels as mismatches
            #loop reconstructs strings as it goes, capitalizing mismatches
            for index in range(0,len(strings[0])):
                if strings[0][index] == strings[1][index] and strings[0][index] != '-' and strings[1][index] != '-':
                    matches += 1
                    scoredStr1 += strings[0][index]
                    scoredStr2 += strings[1][index]
                else:
                    mismatches += 1
                    scoredStr1 += strings[0][index].upper()
                    scoredStr2 += strings[1][index].upper()
            #Returns scoring information to user
            print("""\nMismatches are capitalized, matches remain lower case.
\n----------------
Scored strings:
  """, scoredStr1, """
  """, scoredStr2)
            score = round(100*matches/len(strings[0]))
            print("\n   Matches:", matches, "\n   Mismatches:", mismatches, "\n   Score:", score, "%\n----------------")

        else:
            #returns to main menu if menu option was invalid
            print("I'm sorry, your entry was invalid. Try again.")
            continue
    
    break
