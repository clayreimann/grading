#Project 07
#Section 001
#Due March 11th
#Submitted  February 28th

import string
import random

#Attempts to open a file
def open_read_file(file_name_str):
    try:
        file = open(file_name_str)
    except FileNotFoundError:
        print("I'm sorry, that file wasn't found; try again.\n")
        return
    except OSError:
        print("Eh, you broke something? Try again.\n")
        return
    return file

#Scrambles a line letter by letter, reconstructing the line
def scramble_line(line):
    scramble = ''
    word_list = line.split()
    for word in word_list:
        new_word = scramble_word(word)
        scramble+= new_word+' '
    return scramble

#Scrambles a letter, maintaining ANY punctuation as well as first and final letters
def scramble_word(word):
    if len(word) >3:
        word_list = list(word)
        
        #Initialized storage for letters
        first_and_last_letters = []
        punctuation = []

        #retrieve first and last letters
        for index in range(0, len(word_list)):
            if word_list[index] in string.ascii_letters:
                first_and_last_letters.append((index, word_list.pop(index)))
                break
            
        for index in range(len(word_list)-1, 0,-1):
            if word_list[index] in string.ascii_letters:
                first_and_last_letters.append((index+1, word_list.pop(index)))
                break
        
        #Retrieve punctuation
        adjust = 0
        i = 0
        while i < len(word_list):
            if word_list[i] in string.punctuation:
                punctuation.append((i+adjust, word_list.pop(i)))
                adjust+=1
            else:
                i+=1
                
        random.shuffle(word_list)

        #Insert first, last, and any puncuation
        for letter in punctuation:
            word_list.insert(letter[0], letter[1])
        for letter in first_and_last_letters:
            word_list.insert(letter[0], letter[1])
        scramble = ''.join(word_list)
        return scramble
    else:
        return word

#Calls prior functions to scramble a text file
def main():
    descriptor = input("Please enter a file to write: ")
    write_file = open(descriptor, 'w')
    
    while True:
        descriptor = input("Please enter file to be read: ")
        read_file = open_read_file(descriptor)
        #If no value returned, repeat loop
        if type(read_file).__name__ == 'NoneType':
            continue
        else:
            break
        
    for line in read_file:
        write_file.write(scramble_line(line)+'\n')
        
    write_file.close()
    read_file.close()
