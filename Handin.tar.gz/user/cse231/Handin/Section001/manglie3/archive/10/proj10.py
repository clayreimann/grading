#Project 10
#CSE 231 Section 001
#4/8/2013

import turtle
import time

class Star(object):
    """A class containing information to draw a star shape"""
    def __init__(self, x=0, y=0, arm_length=100, color='black', angle=0):
        """Assigns the stars paramaters"""
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color
        self.angle = angle
        
    def __str__(self):
        """Returns information on the instance of the Star"""
        return "Star x:{}, y:{}, arm:{}, color:{}".format(self.x, self.y, self.arm_length, self.color)

    def draw(self, turtle):
        """Draws a star with given paramaters"""
        turtle.pu()
        turtle.color(self.color)
        turtle.goto(self.x,self.y)
        turtle.setheading(0)
        #Added functionality for receiving an angle after color for some flags
        turtle.right(self.angle)
        turtle.left(90)
        turtle.forward(int(self.arm_length/2.35))
        turtle.right(90)
        turtle.forward(int(self.arm_length/3.236))
        turtle.pd()
        turtle.begin_fill()
        for i in range(0,5):
            turtle.forward(self.arm_length)
            turtle.right(144)
            turtle.forward(self.arm_length)
            turtle.left(72)
        turtle.end_fill()

    def string(self):
        """Returns a string without the star label, for use in the flag __str__()"""
        return "x:{}, y:{}, arm:{}, color:{}".format(self.x, self.y, self.arm_length, self.color)

class Rectangle(object):
    """A class containing the information necessary to draw a rectangle shape"""
    def __init__(self, x=0,y=0,width=100, length=50, color='black', angle=0):
        """Initializes paramaters for a rectangle"""
        self.x=x
        self.y=y
        self.width=width
        self.height=length
        self.color=color
        self.angle = angle
        
    def __str__(self):
        """Returns a string describing the instance of the rectangle"""
        return "Rectangle x:{}, y:{}, width:{}, height:{}, color:{}".format(self.x, self.y, self.width,self.height, self.color)

    def draw(self,turtle):
        """Draws the rectangle"""
        turtle.pu()
        turtle.goto(self.x,self.y)
        turtle.setheading(0)
        #Added functionality for drawing at an angle
        turtle.right(self.angle)
        turtle.left(90)
        turtle.forward(int(self.height/2))
        turtle.right(90)
        turtle.forward(int(self.width/2))
        turtle.right(90)
        turtle.color(self.color)
        turtle.pd()
        turtle.begin_fill()
        for i in range(0,2):
            turtle.forward(self.height)
            turtle.right(90)
            turtle.forward(self.width)
            turtle.right(90)
        turtle.end_fill()

    def string(self):
        """For use in constructing the flag __str__()"""
        return "x:{}, y:{}, width:{}, height:{}, color:{}".format(self.x, self.y, self.width,self.height, self.color)

class Flag(object):
    """A class that can be passed rectangles and stars to draw a flag through a text file"""
    def __init__(self, file):
        """Iterates through the file receiving each rectangle/star object"""
        self.object_list = []
        self.rect = True
        #Once for rectangles, once for stars
        for repeat in range(0,2):
            #Grab and store the number of each for printing purposes
            #self.readlen is used to tell the how many more lines to iterate
            if self.rect == True:
                self.rec_num = int(file.readline())
                self.readlen = self.rec_num
            else:
                self.star_num = int(file.readline())
                self.readlen = self.star_num
            #If no objects exist, go back and begin the next segment
            if self.readlen != 0:
                for line in range(0,self.readlen):
                    #Take the paramaters as a list
                    paramaters = file.readline().strip().split(',')
                    for index in range(0,len(paramaters)):
                        paramaters[index] = paramaters[index].strip()
                        #Make paramaters into integers if possible
                        try:
                            paramaters[index] = int(paramaters[index])
                        except ValueError:
                            pass
                    #Pass the paramaters to the proper class type and store in a list
                    if self.rect == True:
                        self.object_list.append(Rectangle(*paramaters))
                    else:
                        self.object_list.append(Star(*paramaters))
            self.rect=False
                
    def draw(self, turtle):
        #Draws all shapes in the flag
        for shape in self.object_list:
            shape.draw(turtle)

    def __str__(self):
        #Prints all shapes in the flag
        string = 'Rectangles ({})\n'.format(self.rec_num)
        for rectangle in self.object_list[0:self.rec_num]:
            string += rectangle.string()+'\n'
        string+= '\nStars({})\n'.format(self.star_num)
        for star in self.object_list[self.rec_num:self.star_num+self.rec_num]:
            string += star.string()+'\n'
        return string
        
def main():
    """Prints two given flags and myFlag.txt"""
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed(0)
    
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()
    time.sleep(4)   # delay so you can see your flag
    
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()
    time.sleep(4)

    turtle.clearscreen()
    my_file = open('myFlag.txt')
    my_flag = Flag(my_file)
    print(my_flag)
    my_flag.draw(pen)
    my_file.close()

def construct_america():
    """Writes a myFlag.txt with specifications for the American flag"""
    """Note: rounding correction designed for a default height of 338"""
    america = open("myFlag.txt", 'w')
    america.write('14\n')
    scale = input("NOTE: values other than default may not scale perfectly\nEnter width for scale (Default = 338): ")
    scale = int(scale)
    scale = scale - scale%26
    scale = int(scale)
    print(scale)
    rectangles = ''
    #create red and white stripes
    width = scale*1.9
    height = scale*1/13
    x = 0
    y = 0.5*scale-1/26*scale
    color = 'red'
    for i in range(0,13):
        items = [x,y,width,height,color]
        for item in range(0,len(items)):
            try:
                items[item] = int(items[item])
            except ValueError:
                pass
            items[item] = str(items[item])
        rectangles = rectangles+ ','.join(items)+'\n'
        y -= 1/13*scale
        if color == 'red':
            color = 'cornsilk'
        else:
            color = 'red'
    #create blue box
    width = 0.76*scale+scale/338*2
    height = 7/13*scale-scale/338
    x= -scale*1.9/2+0.76*scale/2
    y = 0.5*scale-7/26*scale+scale/338
    color = 'blue'
    items = [x,y,width,height,color]
    for item in range(0,len(items)):
        try:
            items[item] = int(items[item])
        except ValueError:
            pass
        items[item] = str(items[item])
    rectangles = rectangles+ ','.join(items)+'\n'

    america.write(rectangles)
    #Begin stars
    america.write('50\n')
    x = -1.9/2*scale+0.063*scale
    y = 0.5*scale-0.054*scale
    arm_length = 0.0616*scale/2*4/5
    color = 'cornsilk'
    row = 6
    stars = ''
    for i in range(0,9):
        for i in range(0,row):
            items = [x,y,arm_length,color]
            for item in range(0,len(items)):
                try:
                    items[item] = int(items[item])
                except ValueError:
                    pass
                items[item] = str(items[item])
            stars = stars+ ','.join(items)+'\n'
            x += 2*0.063*scale
        if row == 6:
            row = 5
            x = -1.9/2*scale+0.063*scale*2
        else:
            row = 6
            x = -1.9/2*scale+0.063*scale
        y -= 0.054*scale
    america.write(stars)

    america.close()
    
main()
