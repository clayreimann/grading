#project 6
#CSE 231 Section 1
#Due 2/25/2013

#Prompt for file name until valid file is found
def get_input_descriptor():
    while True:
        descriptor = input("Please enter file to be imported: ")
        try:
            file = open(descriptor)
        except FileNotFoundError:
            print("I'm sorry, that file wasn't found; try again.\n")
            continue
        except IOError:
            print("I don't ever get an IO error but I threw in this catcher just in case.\n")
            continue
        except OSError:
            print("Eh, you broke something? Try again.\n")
            continue
        return file

#Iterate over lines of file, appending tuples into a list
def get_data_list(file_object, column):
    file_object.readline()
    data_list = []
    for line in file_object:
        line = line.strip()
        line_items = line.split(',')
        
        #For future support of operations on dates
        if column != 0:
            line_items[column] = float(line_items[column])
            
        data_point = line_items[0], line_items[column]
        data_list.append(data_point)

    #No more reads required; file closed
    file_object.close()
    return data_list

#Iterate through each day, compiling monthly data
def average_data(data_list):
    #initialize counting variables and list
    average_list = []
    position = 0
    month_count = 1
    month_total = 0
    
    for point in data_list:
        #Split current date into year/month/day
        date_list = point[0].split('-')

        #Split NEXT date; if next date does not exist, finish loop
        try:
            next_date = data_list[position+1][0].split('-')
        except IndexError:
            month_total+=point[1]
            average = month_total / month_count
            average_set = average, date_list[1]+':'+date_list[0]
            average_list.append(average_set)
            break

        #Continue counting if month is equal
        if date_list[1] == next_date[1]:
            month_total+=point[1]
            month_count+=1
            position+=1
            continue

        #If month changes, calculate total, create and append tuple, reset counts
        else:
            month_total+=point[1]
            average = month_total / month_count
            average_set = average, date_list[1]+':'+date_list[0]
            average_list.append(average_set)
            position+=1
            month_total = 0
            month_count = 1
    return average_list

def column_menu():
    print("""
Valid columns to be parsed:
   1: Open
   2: High
   3: Low
   4: Close
   5: Volume
   6: Adjusted Close""")

def main():
    file_object = get_input_descriptor()
    column_menu()

    #Prompt for column number until valid integer received
    while True:
        column = input("\nPlease enter a column to be parsed [1-6]: ")
        if column.isdigit() == True:
            column = int(column)
        else:
            print("Invalid input; try again.")
            continue
        if column < 1 or column > 6:
            print("Invalid input; try again.")
            continue
        else:
            break
        
    all_data = get_data_list(file_object, column)
    average_list = average_data(all_data)

    #Sort the averaged list and print lowest and highest values
    sorted_list = sorted(average_list)
    print("\nLowest 6 for column ", column, ':', sep='')
    for i in range(0,6):
        print('Date:', sorted_list[i][1], 'Value:', round(sorted_list[i][0],2))
    print("\nHighest 6 for column ", column, ':', sep='')
    for i in range(1,7):
        i = -1*i
        print('Date:', sorted_list[i][1], 'Value:', round(sorted_list[i][0],2))

main()

