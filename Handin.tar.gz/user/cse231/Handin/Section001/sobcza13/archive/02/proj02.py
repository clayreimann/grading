############################################################################################################
# CSE231 001H
# sobcza13
# Project 2
# 1/21/2013
# Objectives:
# 1. Ask user for a six digit integer value
# 2. Ensure that the integer value is in fact a six digit integer value and if it is
#    not then inform the user that the value is invalid
# 3. Determine if the user SLAYER value makes the following true: SLAYER + SLAYER + SLAYER = LAYERS
# 4. Inform the user whether
#    a. they are correct or incorrect
#    b. what SLAYER + SLAYER + SLAYER equals using input value and
#    c. what LAYERS would equal using input value 
###########################################################################################################

# This segment prints the instructions to the user

print("Guess a six digit integer, SLAYER, so that the following equation is true,") 
print("where each letter stands for the digit in the position shown:")
print("")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print("")

# This segment asks the user to input a value and tells the program that the input value is an integer

num_str = input("Enter your guess for SLAYER:")         
num_int = int(num_str)

# This if/elif statement ensures that the value input is 6 digits.
# If it is not the program halts. If it is the program continues with its calculations.

if num_int < 100000 or num_int > 999999:        
    print("Your guess is incorrect:")           
    print("SLAYER must be a 6-digit number.")  
    print("Thanks for playing.") 
                                                                                           
elif num_int < 999999 and num_int > 100000:                                                  
    
    ones_place = num_int % 10                          # This segment assigns each numeral in the input value 
    tens_place = (num_int // 10) % 10                  # to a variable name so that each numeral can then 
    hundreds_place = (num_int // 100) % 10             # be assigned to the arbitrary letters S-L-A-Y-E-R
    thousands_place = (num_int // 1000) % 10
    ten_thousands_place = (num_int // 10000) % 10
    hundred_thousands_place = (num_int // 100000) % 10
 
    S = hundred_thousands_place                       # Assigns the numerals in the input value to the letters S-L-A-Y-E-R
    L = ten_thousands_place                           # This makes the layers_int equation easier to follow. 
    A = thousands_place
    Y = hundreds_place
    E = tens_place
    R = ones_place

    layers_int = (100000 * L) + (10000 * A) + (1000 * Y) + (100 * E) + (10 * R) + (1 * S) # Rearranges SLAYER to LAYERS


   # This if/else statement checks to see if SLAYER + SLAYER + SLAYER = LAYERS. If this is true     
   # then the program informs the user that their guess was correct, prints out the number value     
   # of SLAYER + SLAYER + SLAYER, and prints out the value of LAYERS       
   # If the input value assigned to S-L-A-Y-E-R does not make SLAYER + SLAYER + SLAYER = LAYERS 
   # true then the program informs the user that their guess is incorrect and prints out the
   # number values for SLAYER + SLAYER + SLAYER and LAYERS 
    
    if S == (3 * R) % 10 \
       and R == (((3 * E) + (3 * R // 10)) % 10) \
       and E == (((3 * Y) + (3 * E // 10)) %10) \
       and Y == (((3 * A) + (3 * Y // 10)) % 10) \
       and A == (((3 * L) + (3 * A // 10)) % 10) \
       and L == (((3 * S) + (3 * L // 10)) % 10):
        print("Your guess is correct:")
        print("SLAYER + SLAYER + SLAYER =" , num_int * 3)
        print("LAYERS =" , layers_int)
        print("Thanks for playing.")
        
    else:
        print("Your guess is incorrect:")                  
        print("SLAYER + SLAYER + SLAYER =" , num_int * 3)  
        print("LAYERS =" , layers_int)                      
        print("Thanks for playing.")




