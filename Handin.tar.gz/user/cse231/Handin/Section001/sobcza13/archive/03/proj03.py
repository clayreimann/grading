#CSE231 001H
#Project 3
#1.28.2013
#sobcza13
#Algorithm:
#1)Prints the amount of change in the vending machine and prompts the user for a price.
#   -Program checks to make sure that the price is a positive value that is divisible by five
#   -If the input value is illegal it prompts the user for another price
#2) Program prints a deposit menu and prompts the user to make a deposit
#   -If the deposit is less than the price the program prints out the remaing amount due
#   -Until the deposit is greater than or equal to the input price the program will reprompt for additonal deposits
#3)Once change has been returned to the user the program prints out the reamining change stock in the machine
#4) Program will prompt user to see manager for remaining change due if the machine runs out of change


#This segment prints out the initial stock in the vending machine. 
print("Welcome to the vending machine change maker program.")
print("Change maker initialized.")
print("Stock contains:")

num_fives_left = 0
num_ones_left = 0
num_quarters_left = 25
num_dimes_left = 25
num_nickels_left = 25
      
print(num_nickels_left, "nickels")
print(num_dimes_left, "dimes")
print(num_quarters_left, "quarters")
print(num_ones_left, "ones")
print(num_fives_left, "fives")


#While the user does not enter 'q' the program asks the user to enter a price or 'q' to quit. 
price_str = ""
      
while price_str != 'q': 
    price_str = input("Enter the purchase price (xx.xx) or 'q' to quit:")

    total_in_machine_float = ((num_fives_left * 5) + (num_ones_left * 1) + (num_quarters_left * 0.25) + \
                        (num_dimes_left * 0.10) + (num_nickels_left * 0.05))
    
    #If the user enters 'q' the program prints the total amount of money in the vending machine.
    if price_str == 'q':
      print("Total:", int(total_in_machine_float), "dollars and", round(total_in_machine_float * 100 % 100 / 100), "cents")
      
    #The following algorithm is performed if the user inputs anything but 'q'.
    else:
      price_float = float(price_str)
      price_float = round(price_float * 100)
      
    #If the user enters a negative number the program informs them that they cannot enter a negative number
    #and the program reprompts the user for a price or 'q'      
      if price_float < 0:
          print("Illegal price. Prices cannot be negative.")

    #If the user enters a number that is not divisible by 5 the program informs the user that the input value must be divisible by 5
    #and the program reprompts the user for a price or 'q'
      elif price_float %5 != 0:
          print("Illegal price: Must be a non-negative multiple of 5 cents.")
          
    #If the value that the user inputs is positive and divisible by 5 the program prints a menu of deposits
    #and asks the user to input a deposit
      else:
          #While the input price is greater than the amount deposited, the program will continue to prompt the user for an additional deposit
          deposit_float = 0

          while price_float > deposit_float:

              
              print("Menu for deposits:")
              print('n', " - deposit a nickel")
              print('d', " - deposit a dime")
              print('q', " - deposit a quarter")
              print('o', " - deposit a one dollar bill")
              print('f', " - deposit a five dollar bill")
              print('c', " - cancel the purchase")

              #This assigns the deposit keys to their corresponding numerical values for making change later in the program. 
              
              deposit_str = input("indicate your deposit:")
              
              n = 5
              d = 10
              q = 25
              o = 100
              f = 500
              c = ""

              #This segment informs the user that they have entered an illegal deposit selection. User will be prompted to enter another deposit.
              if deposit_str != n and deposit_str != d and deposit_str != q and deposit_str != o and deposit_str != f and deposit_str != c:
                  print("Illegal selection.")
                  
              while price_float != deposit_float:
                    
                    #This segment subtracts a quarter from the initial price, subtracts a quarter from the stock, and prints the amount still owed
                    if price_float // 25 > 0:
                        
                        if price_float // 25 < num_quarters_left:
                            quarters_dispensed = (price_float - 25) // 25
                            num_quarters_left -= 1
                                
                        else:
                            quarters_dispensed = num_quarters_left
                            num_quarters_left = num_quarters_left - quarters_dispensed
                            
                            
                        price_float -= 25
                        payment_due = price_float - deposit_float
                        print("You still owe: ", price_float // 100, "dollars and", price_float % 100, "cents") 
                        break #If I don't put a break here it's an infinite loop but if I do, it only does the math for quarters, even if I deposit a nickel, etc.

                    #This segment subracts a dime from the initial price, subracts a dime from the stock, and prints out the amount still owed    
                    elif price_float // 10 > 0:
                        
                        if price_float // 10 < num_dimes_left:
                            dimes_dispensed = (price_float - 10) // 10
                            num_dimes_left = num_dimes_left - dimes_dispensed
                            
                        else:
                            dimes_dispensed = num_dimes_left
                            num_dimes_left = num_dimes_left - dimes_dispensed
                            
                        price_float = price_float - (dimes_dispensed * 10)
                        payment_due = price_float - deposit_float
                        print("You still owe: ", price_float // 100, "dollars and", price_float % 100, "cents")
                        break

                    #This segment subtracts a nickel from the initial price, subracts a nickel from the stock, and prints out the amount still owed
                    elif price_float // 5 > 0:
                        if price_float // 5 < num_nickels_left:
                            nickels_dispensed = (price_float - 5) // 5
                            num_nickels_left = num_nickels_left - nickels_dispensed
                               
                        else:
                            nickels_dispensed = num_nickels_left
                            num_nickels_left = num_nickels_left - nickels_dispensed
                            
                        price_float = price_float - (nickels_dispensed * 5)
                        payment_due = price_float - deposit_float
                        print("You still owe: ", price_float // 100, "dollars and", price_float % 100, "cents")
                        break

                    #This segment caculates change due if the amount deposited is greater than the amount owed
                    elif price_float < deposit_float:
                        change_due = deposit_float - price_float
                        print("Please take the change below:", price_float // 100, "dollars and", price_float % 100, "cents")

                    #This segment tells the user that they have given exact change    
                    elif price_float == deposit_float:
                        print("No change.")
                    #This segment tells the user that the machine is out of change, informs the user to collect the rest of their change from the
                    #manager, and prints out how much change is still owed to the user
                    else:
                        print("Machine is out of change.")
                        print("See store manger for remaining refund.")
                        print("Amount due is:", price_float // 100, "dollars and", price_float % 100, "cents")

              #This segment should print out the updated change stock after each deposit           
              print("Stock contains:")
              print(num_nickels_left, "nickels")
              print(num_dimes_left, "dimes")
              print(num_quarters_left, "quarters")
              print(num_ones_left, "ones")
              print(num_fives_left, "fives") 
                     





                        

