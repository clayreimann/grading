# CSE231 001H
# Project #9
# 3/25/2013
# sobcza13
# Algorithm: 
#    1) Setup for the game seahaven by creating several categories of lists:
#        a) four foundation lists, one for each suit in a deck of cards
#        b) ten tableau lists into which the 52 cards are dealt as evenly as possible (five per list, two lists will have six)
#        c) four cell lists- a single card can be placed into each list and must be moved before a new card can be placed in a specific list
#   2) Uses a series of functions to describe the rules of the game Seahaven to Python
#        - the goal of the game is to move cards from the tableau and cells so that each suit ends up in a stack from Ace to King in the foundations
#        - a card can be moved from one tableau stack to another or from a cell to a tableau stack provided that it matches the color of the top card
#          in the tableau column onto which it wishes to add itself AND provided that it is of the rank immediately below the rank of said top card
#        - a card may move from a tableau to a cell but if all cells are full a card must be removed from a cell before another card may be added
#        - once a card is placed into a foundation it may not be removed
#        - cards from cells and tableau columns may be placed into foundations provided a card:
#               a) matches the suit of the top card in the foundation onto which it wishes to add itself
#               b) is of the rank immediately above the rank of the top card in the foundation column onto which it wishes to add itself
#
#######################################################################################################################################################################



import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    foundation_list_1 = []
    foundation_list_2 = []
    foundation_list_3 = []
    foundation_list_4 = []

    total_foundation = [ foundation_list_1,  foundation_list_2,  foundation_list_3,  foundation_list_4 ]

    tableau_list_1 = []
    tableau_list_2 = []
    tableau_list_3 = []
    tableau_list_4 = []
    tableau_list_5 = []
    tableau_list_6 = []
    tableau_list_7 = []
    tableau_list_8 = []
    tableau_list_9 = []
    tableau_list_10 = []

    total_tableau = [  tableau_list_1, tableau_list_2, tableau_list_3, tableau_list_4, tableau_list_5,
                       tableau_list_6, tableau_list_7, tableau_list_8, tableau_list_9, tableau_list_10 ]

    cell_list_1 =[]
    cell_list_2 =[]
    cell_list_3 =[]
    cell_list_4 =[]

    total_cell = [ cell_list_1, cell_list_2, cell_list_3, cell_list_4 ]

    #foundation = None # place holder
    #tableau = None # place holder
    #cell = None # place holder

    return total_foundation,total_tableau,total_cell

#I didn't shuffle or deal the deck because to my understanding we were supposed to focus on writing the rules, not how to write a program that would allow
#the game to run.
def move_to_foundation(total_tableau,total_foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''
    #need to know what the top card in the specific foundation is in order to do error checking
    #since we're appending card values to the end of the foundation list, the top card is the last value in the specific foundation_list
    bottom_card_in_f_col = total_foundation[f_col][-1]
    #removing card from end of specific list within total_tableau
    move_card = total_tableau[t_col].pop()

    #add the card removed from the specific tableau column to end of specific list (column) in total_foundation
    #if the cards are the same color and the card being moved to the foundation is higer in rank by 1
    if move_card.get_suit() == bottom_card_in_f_col.get_suit():
        if move_card.get_rank() == bottom_card_in_f_col.get_rank() +1:
            total_foundation[f_col].append(move_card)

    else:
        print("Illegal move.")
        return False
    return True

    ##pass

#I added this function because it did not make since to me how the previous function could also
#move a card from a cell to a foundation so I wrote an additioanl function to complete this task
def move_to_foundation(total_cell, total_foundation, c_col, f_col):
    bottom_card_in_f_col = total_foundation[f_col][-1]
    move_card = total_cell[c_col].pop()
    if move_card.get_suit() == bottom_card_in_f_col.get_suit():
        if move_card.get_rank() == bottom_card_in_f_col.get_rank() +1:
            total_foundation[f_col].append(move_card)

    else:
        print("Illegal move.")
        return False
    return True

def move_to_cell(total_tableau,total_cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    #the only issue with moving a card from a tableau to a cell is if the chosen cell is already full then the move is invalid
    move_card = total_tableau[t_col].pop()
    if total_cell[c_col] == []:
        total_cell[c_col].append(move_card)

    else:
        print("Cell is full. Invalid move.")
        return False
    return True
    ##pass

def move_to_tableau(total_tableau,total_cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    bottom_card_in_t_col = total_tableau[t_col][-1]
    move_card = total_cell[c_col].pop()
    if move_card.get_suit() == 'd' or move_card.get_suit() == 'h':
        if bottom_card_in_t_col.get_suit() == 'd' or bottom_card_in_t_col.get_suit() == 'h':
            if move_card.get_rank() == bottom_card_in_t_col.get_rank() -1:
                total_tableau[t_col].append(move_card)

            else:
                return False
                print("Invalid move.")
        else:
            return False
            print("Invalid move. Color does not match.")
    elif move_card.get_suit() == 'c' or move_card.get_suit() == 's':
        if bottom_card_in_t_col_dest.get_suit() == 'c' or bottom_card_in_t_col_dest.get_suit() == 's':
            if move_card.get_rank() == bottom_card_in_t_col_dest.get_rank() -1:
                total_tableau[t_col_dest].append(move_card)

            else:
                return False
                print("Invalid move.")
        else:
            return False
            print("Invalid move. Color does not match.")

    return True
    ##pass


def is_winner(total_foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    if len(foundation_list_1) == 14 and len(foundation_list_2) == 14 and len(foundation_list_3) == 14 and len(foundation_list_4) == 14:

        print("You win!")
    else:
        return False
    return True

    ##pass


def move_in_tableau(total_tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    bottom_card_in_t_col_dest = total_tableau[t_col_dest][-1]
    move_card = total_tableau[t_col_source].pop()
    if move_card.get_suit() == 'd' or move_card.get_suit() == 'h':
        if bottom_card_in_t_col_dest.get_suit() == 'd' or bottom_card_in_t_col_dest.get_suit() == 'h':
            if move_card.get_rank() == bottom_card_in_t_col_dest.get_rank() -1:
                total_tableau[t_col_dest].append(move_card)

            else:
                return False
                print("Invalid move.")
        else:
            return False
            print("Invalid move. Color does not match.")
    elif move_card.get_suit() == 'c' or move_card.get_suit() == 's':
        if bottom_card_in_t_col_dest.get_suit() == 'c' or bottom_card_in_t_col_dest.get_suit() == 's':
            if move_card.get_rank() == bottom_card_in_t_col_dest.get_rank() -1:
                total_tableau[t_col_dest].append(move_card)

            else:
                return False
                print("Invalid move.")
        else:
            return False
            print("Invalid move. Color does not match.")

    return True

    ##pass

def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    for c in cell:

        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''

    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')

    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
     t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)

def play():
    '''
    main program. Does error checking on the user input.
    '''
    print_rules()
    total_foundation, total_tableau, total_cell = setup()

    show_help()
    while True:
        print_game(total_foundation, total_tableau, total_cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        if len(response_list) > 0:
            r = response_list[0]
            if r == 't2f':
                t_col = (int(response_list[1]) -1) #subtracting 1 because a list begins with element 0 so if user wants to work with 1st column in the tableau
                f_col = (int(response_list[2]) -1) #they are actually working with element 0 in list 'total_tableau'
                #I get a TypeError here: function asks for four arguments and 0 are given
                total_tableau, total_foundation, t_col, f_col = move_to_foundation()
                #pass # you implement
            elif r == 't2t':
                t_col_source = (int(response_list[1]) -1)
                t_col_dest = (int(response_list[2]) -1)
                total_tableau, t_col_source, t_col_dest = move_in_tableau()
                #pass # you implement
            elif r == 't2c':
                t_col = (int(response_list[1]) -1)
                c_col = (int(response_list[2]) -1)
                total_tableau, total_cell, t_col, c_col = move_to_cell()
                #pass # you implement
            elif r == 'c2t':
                #pass # you implement
            elif r == 'c2f':
                c_col = (int(response_list[1]) -1)
                f_col = (int(response_list[2]) -1)
                total_cell, total_foundation, c_col, f_col = move_to_foundation()
                #pass # you implement
            elif r == 'q':
                break
            elif r == 'h':
                show_help()
            else:
                print('Unknown command:',r)
            #every time the user inputs a valid command the program prints the top card in each column i.e. the last card in each list
            #within the tableau, foundation, and cell
            print(total_tableau[:][-1], total_foundation[:][-1], total_cell[:][-1])
            #every time the user inputs a valid command and a card is moved, the program should check to see if the user has won the game
            #by calling the is_winner function
            total_foundation = is_winner()
        else:
            print("Unknown Command:",response)
    print('Thanks for playing')

play()





