
###########################################################################
# CSE231 001H
# Project 5
# 2/11/2013
# sobcza13
# Objectives:
# 1) prompt user for number of hexagons to draw
#       -re-prompt if input number is not in range
# 2) prompt user for two colors
#       -re-prompt if color choice is not legal
# 3) draw a row of x hexagons and replicate that row x times to create
#    a tessellation where x is the number of hexagons that the user inputs
# 4) alternate the color of the hexagons using the two colors selected by the user
##########################################################################

import turtle
import time
import math

# prompts the user for two colors
# re-prompts the user if either color is not a legal choice
def get_color_choice():
    first_color_str = input("First color choice: ")

    red = 'red'
    blue = 'blue'
    green = 'green'

    while( not (first_color_str == red or first_color_str == blue or first_color_str == green )):
        print(" ' ", first_color_str, " ' ", "is not a legal color. Please try again.")
        first_color_str = input("First color: ")

    second_color_str = input("Second color choice: ")

    while( not (second_color_str == red or second_color_str == blue or second_color_str == green )):
        print(" ' ", second_color_str, " ' ", "is not a legal color. Please try again.")
        second_color_str = input("Second color: ")

    return first_color_str, second_color_str

# asks the user to input the number of hexagons used to create a tessellation
# x hexagons long and x hexagons wide where x is the value input by the user
# note that here x is called num_hexagons_int
def get_num_hexagons():
    num_hexagons_str = input("How many hexagons per row?")
    num_hexagons_int = int(num_hexagons_str)

    while num_hexagons_int < 4 or num_hexagons_int > 20:
         num_hexagons_str = input("It should be between 4 and 20. Please try again: ")
         num_hexagons_int = int(num_hexagons_str)

    return num_hexagons_int
# adjusts the side length of the template hexagon so that regardless of how
# many hexagons make the tessellation, the printout will fit on the computer screen
###def side_len(num_hexagons_int):
###    num_hexagons_int = get_number_hexagons()
###    side_len = 500 / num_hexagons_int

###    return side_len

# draws the template hexagon the color of the first color the user inputs
def draw_hexagon(x, y, side_len, first_color_str, pen):
    turtle.up()
    turtle.goto(x, y)
    turtle.seth(150)
    turtle.down()
    turtle.color(first_color_str)
    turtle.begin_fill()
    turtle.speed(2)
    turtle.forward(side_len)
    turtle.seth(90)
    turtle.forward(side_len)
    turtle.seth(30)
    turtle.forward(side_len)
    turtle.seth(330)
    turtle.forward(side_len)
    turtle.seth(270)
    turtle.forward(side_len)
    turtle.seth(210)
    turtle.forward(side_len)
    turtle.end_fill()
    turtle.up()

#draws the template hexagon, this time the color of the second color the user inputs
def draw_hexagon(x, y, side_len, second_color_str, pen):
    turtle.up()
    turtle.goto(x, y)
    turtle.seth(210)
    turtle.down()
    turtle.color(second_color_str)
    turtle.begin_fill()
    turtle.speed(2)
    turtle.forward(side_len)
    turtle.seth(270)
    turtle.forward(side_len)
    turtle.seth(330)
    turtle.forward(side_len)
    turtle.seth(30)
    turtle.forward(side_len)
    turtle.seth(90)
    turtle.forward(side_len)
    turtle.seth(150)
    turtle.forward(side_len)
    turtle.end_fill()
    turtle.up()

n = 0

# draws a row of hexagons x hexagons long where x is the value input by the user
# alternating the color of each hexagon between the first color the user input
# and the second color the user input
def draw_row_of_hexagons(x, y, num_hexagons_int, side_len, pen):
    for n in range(num_hexagons_int):
        if n %2 == 0:
            draw_hexagon(x, y, side_len, first_color_str, pen)
            x += (2 * side_len * math.cos(math.pi / 6))
            n += 1
        else:
            draw_hexagon(x, y, side_len, second_color_str, pen)
            x += (2 * side_len * math.cos(math.pi / 6))
            n += 1


num_hexagons_int = get_num_hexagons()

first_color_str, second_color_str = get_color_choice()

# I couldn't get the side_len function to work so I used this code to make the
# program operable
side_len = 500 / num_hexagons_int


num_of_rows_int = 0

num_hexagons_int = draw_row_of_hexagons(-500, 450, num_hexagons_int, side_len, turtle)

# this is supposed to replicate the first row of hexagons, resetting the cursor's
# starting point so that a tessellation is created
while num_hexagons_int >= num_of_rows_int:
    if num_of_rows_int %2 == 0:
        num_hexagons_int = draw_row_of_hexagons(x, y, num_hexagons_int, side_len, pen)
        x -= 0.5 * side_len
        y -= (side_len + (0.5* (side_len * math.sqrt(3))))
        num_of_rows_int += 1
    else:
        num_hexagons_int = draw_row_of_hexagons(x, y, num_hexagons_int, side_len, pen)
        x += 0.5 * side_len
        y -= (side_len + (0.5* (side_len * math.sqrt(3))))
        num_of_rows_int += 1



time.sleep(10)
turtle.bye()
