# CSE231 001H
# Project 11 (Final Project)
# sobcza13
# 4/15/2013
# Algorithm:
#   This is a program utilizing a single class, Tour, and iGoogle map API that allows the user to estimate 
#   the distance between cities. The Tour class also allows for:
#       1) additional cities to be added to the tour     
#       2) the distance covered in a tour to be multipled (say if you were calculating a round trip distance) 
#       3) the comparison of the respective distances travelled during two separate tours i.e. is one tour longer/shorter than another
#       4) the comparison of two tours to determine if they are exactly the same, stop for stop
####################################################################################################################################################

import urllib.request 


class Tour(object):
    """
    Defines what arguments are required for the Tour class. (Only one argument, a variable list of locations)
    Receives each location in the form of city, state Ex: New York, NY
    Returns nothing
    """
    
    def __init__(self, *location_str = ''):
        self.*location_str = *location_str
                 
    """
    Calculates the distance between two cities when travelling by foot, bicycle, or car by getting on the web and utilizing
    iGoogle map API 
    Receives mode of transportation
    Returns distance travelled
    Algorithm:
    1) Creates a web address for the desired travel method and retrieves the necessary information 
    2) Iterates through the retrieved string of information and assigns the distance value to a new string
    3) Returns the distance in the form of a string
    """
    def distance(transport_method):
        state_list = []
        city_list = []
        c_index = 0
        s_index = 0
        count = 0
        char = 0
        distance1_str = ''

        #where there is a space need to add a '+' for the URL
        if char in location_str.isspace():
            location_str = location_str[:char] + "+" location_str[char:]
            location_str.strip("")
            
        for char in location_str:
            #Iterating through location_str, add lower case letters to a specific index in city list
            if char in location_str != "," and char in location_str.islower(): 
               city_list[c_index] += char
               c_index += 1
            #Skip commas
            elif char in location_str == ","
                continue
            #add upper case letters to a specific index in state list
            #when they run out, increase index value
            elif location_str.isupper():
                state_list[s_index] += char
                s_index += 1
                
        
        try:
            if transport_method == "walking":
                     
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] + /
                                "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=walking&sensor=false")
                 
            elif transport_method == "bicycling":
                 
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] + /
                                "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=bicycling&sensor=false")
                 
            elif transport_method == "driving":

                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] + /
                                "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=driving&sensor=false")
                 
            result_str = str(web_obj.read())

            #This segment iterates through the result_str obtained from the reading the URL to locate the distance value
            #I chose to 'hop' through the result_str by ':'s because the distance value should always immediately follow the seventh colon
            for char in result_str:
                if char in result_str = ":":
                    count += 1 #This is counting colons and when the seventh colon is reached, assign each char that follows to a str if it is an int
                        if count == 7:
                            while char is int:
                                distnace1_str += char

                #Iterates through chars in the result str
                char +=1
                 
            return distance1_str 
         
            web_obj.close()

                 
        except ValueError:
            print("Could not calculate distance travelled. No distance value given.")
                 
    """
    Creates a formatted string of all locations from original location list.
    Receives nothing
    Returns a formatted string of all locations from original location list
    Algorithm:
    1) Iterates through the elements in city_list and state_list and adds each to the stops string, first city, then state; in each iteration 
    2) Returns stops_str
    """
    def __str__(self):
        stops_str = ""
        element = 0 
        if element in city_list == "+":
            city_list.remove("+")
                 
        for element in city_list: 
            stops_str = stops_str + element + ","
            
        for element in state_list:
            stops_str = stops_str + element + ";"
            return stops_str[:-1] #because last index will be ';'
    """
    Displays the object of a variable
    Receives nothing
    Returns string method
    """
    def __repr___(self):
            return self.__str__()
    """
    Adds a stop onto the inital trip between city 1 and city 2
    Receives a transport method and the first distance string produced from the distance function
    Returns a string representing the overall distance covered during the tour of >2 cities
    Algorithm:
    1) Receives transport method for additional trip and the distance from the initial trip
    2) Alters the URL so that the second and third city,state tuples in the location list are used and changes the method of transport if necessary
    3) Reads data contained from the generated URL
    4) Extracts the distance travelled value from the data string returned by the URL
    5) Converts the initial distance string and the new distance string to ints, adds them, converts them back into a str, and assigns them to a new string
    6) Retruns that string (overall_distance_str) 
    """            
    def __add__(self, transport_method, self.distance1_str):

        state_list = []
        city_list = []
        c_index = 0
        s_index = 0
        count = 0
        char = 0
        distance2_str = ''

        #where there is a space need to add a '+' for the URL
        if char in location_str.isspace():
            location_str = location_str[:char] + "+" location_str[char:]
            location_str.strip("")
            
        for char in location_str:
            #Iterating through location_str, add lower case letters to a specific index in city list
            if char in location_str != "," and char in location_str.islower(): 
               city_list[c_index] += char
               c_index += 1
            #Skip commas
            elif char in location_str == ","
                continue
            #add upper case letters to a specific index in state list
            #when they run out, increase index value
            elif location_str.isupper():
                state_list[s_index] += char
                s_index += 1
        
        try:
            if transport_method == "walking":
                     #Set index equal to 1 so that destination from first trip becomes origin in second trip
                     #Adds one to the index so that the next city in city_list and next state in state_list become destination 
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[index] + "+" + \
                                                      state_list[index] + "&destinations=" + city_list[index + 1] + "+" + state_list[index + 1] \
                                                      + "&mode=walking&sensor=false")
                 
            elif transport_method == "bicycling":
                
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[index] + "+" + \
                                                      state_list[index] + "&destinations=" + city_list[index + 1] + "+" + state_list[index + 1] \
                                                      + "&mode=bicycling&sensor=false")
                     
            elif transport_method == "driving":
                 
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[index] + "+" + \
                                                      state_list[index] + "&destinations=" + city_list[index + 1] + "+" + state_list[index + 1] \
                                                      + "&mode=driving&sensor=false")

            result_str = str(web_obj.read())
                    
            for char in result_str:
                if char in result_str = ":":
                    count += 1
                        if count == 7:
                            while char is int:
                                distnace2_str += char
                char += 1
     
            #I'm not sure how __add__ works. Right now I have it theoretically (my code never works) set to handle multiple city,state tuples (beyond the initial 2)
            #at a time rather than have __add__ work with only a max of three cities. Not sure if that makes sense...
            index += 1
            
            overall_distance_str = str(int(self.distance1_str) + int(distance2_str))
                 
            return overall_distance_str
         
            web_obj.close()
                          
        except ValueError:
            print("Could not calculate distance travelled. No distance value given.")

    """
    Multiplies a tour distance by an integer
    Receives an integer
    Returns a new distance string
    Algorithm:
    1) Calculates the distance between two cities
    2) Multiples this distance value by an integer
    """
    def __mul__(self, repeat_int):

        state_list = []
        city_list = []
        c_index = 0
        s_index = 0
        count = 0
        char = 0
        distance_str = ''

        #where there is a space need to add a '+' for the URL
        if char in location_str.isspace():
            location_str = location_str[:char] + "+" location_str[char:]
            location_str.strip("")
            
        for char in location_str:
            #Iterating through location_str, add lower case letters to a specific index in city list
            if char in location_str != "," and char in location_str.islower(): 
               city_list[c_index] += char
               c_index += 1
            #Skip commas
            elif char in location_str == ","
                continue
            #add upper case letters to a specific index in state list
            #when they run out, increase index value
            elif location_str.isupper():
                state_list[s_index] += char
                s_index += 1
        try:
            if transport_method == "walking":
                     
                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] \
                                + "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=walking&sensor=false")
                 
            elif transport_method == "bicycling":
                 
                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] \
                                + "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=bicycling&sensor=false")
                 
            elif transport_method == "driving":

                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + city_list[0] + "+" + state_list[0] \
                                + "&destinations=" + city_list[1] + "+" + state_list[1] + "&mode=driving&sensor=false")
                 
            result_str = str(web_obj.read())
                    
            for char in result_str:
                if char in result_str = ":":
                    count += 1
                        if count == 7:
                            while char is int:
                                distnace_str += char

                index +=1
                 
            return distance_str, repeat_int 
         
            web_obj.close()
        
            return distance_str * repeat_int
                 
        except TypeError:
            print("Must provide an integer.")
     
        except ValueError:
            print("Must provide a non-negative number.")
         
    def __rmul__(self, repeat_int):
        state_list = []
        city_list = []
        c_index = 0
        s_index = 0
        count = 0
        char = 0
        distance_str = ''

        #where there is a space need to add a '+' for the URL
        if char in location_str.isspace():
            location_str = location_str[:char] + "+" location_str[char:]
            location_str.strip("")
            
        for char in location_str:
            #Iterating through location_str, add lower case letters to a specific index in city list
            if char in location_str != "," and char in location_str.islower(): 
               city_list[c_index] += char
               c_index += 1
            #Skip commas
            elif char in location_str == ","
                continue
            #add upper case letters to a specific index in state list
            #when they run out, increase index value
            elif location_str.isupper():
                state_list[s_index] += char
                s_index += 1
            
        try:
            if transport_method == "walking":
                     
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + location_list[0][0] + "+" + location_list[0][1] + /
                                "&destinations=" + location_list[1][0] + "+" + location_list[1][1] + "&mode=walking&sensor=false")
                 
            elif transport_method == "bicycling":
                 
                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + location_list[0][0] + "+" + location_list[0][1] + /
                                "&destinations=" + location_list[1][0] + "+" + location_list[1][1] + "&mode=bicycling&sensor=false")
                 
            elif transport_method == "driving":

                     web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins=" + location_list[0][0] + "+" + location_list[0][1] + /
                                "&destinations=" + location_list[1][0] + "+" + location_list[1][1] + "&mode=driving&sensor=false")
                 
            result_str = str(web_obj.read())
                    
            for char in result_str:
                if char in result_str = ":":
                    count += 1
                        if count == 7:
                            while char is int:
                                distnace_str += char

                index +=1
                 
            return distance_str 
         
            web_obj.close()

            return repeat_int, distance_str
                 
        except TypeError:
            print("Must provide an integer.")
     
        except ValueError:
            print("Must provide a non-negative number.")

                 
def main():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("sacramento, CA", "Oakland, CA")
    
    print("t1: {}\nt2::{}\nt3:{}".format(t1,t2,t3)
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance('driving')/ 1000), \
                                                                            round(t1.distance('bicycling') / 1000)
                                                                            round(t1.distance('walking') / 1000)))
    t4 = t1 + t2
    print("t4:", t4)
          print("t4 driving distance:", round(t4. distance()/1000),"km")
          print("t4 == t1 + t2:", t4 == t1 + t2)

    t5 = t3 * 2
    print("t5:", t5)
    print("t5 == t3 * 2", t5 == t3 * 2) 
