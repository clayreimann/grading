#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      sobcza13
#
# Created:     18/03/2013
# Copyright:   (c) sobcza13 2013
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

def main():
    pass

if __name__ == '__main__':
    main()

##CSE231 001H
##Project 8
##3/18/2013
##sobcza13
##Algorithm:
##    1) Opens a file to read text from
##    2) Generates a dictionary that contains:
##        a) each word read from the file
##        b) a list of tuples corresponding to each word
##           -- each tuple contains a letter from that word and its corresponding
##              index value
##    3) Continuously prompts the user for a prefix string until the user enters
##         '#' in which case the program closes
##    4) Compares the input prefix to the list of tuples generated for each word
##         read from the file and generates a list of possible words based on that
##         prefix (think of T9 texting)

import string

"""
Reads the file opened by the main function line by line, word by word.
Creates a dictionary in which the key is a list of tuples where each tuple
contains a letter and its index value and the value is the word that correspond
to that list of tuples. All words in the file should be added to the dictionary.

Receives:
    1) an empty dictionary
    2) an opened file to read from

Returns: nothing

Algorithm:
    1) Creates an empty dictionary
    2) Creates an empty list in which to store the index-letter tuples that will
       be generated for each word
    3) Reads through the file opened by main line by line
    4) Converts each line to a sequence of strings, each string corresponding to
       a word. (Splits the line at every space)
    5) Converts each word to lowercase
    6) Removes all punctuation marks from each word string
    7) For each word creates a list of tuples
       -- each tuple contains a letter from the word and its corresponding index
          value
    8) Adds each list of tuples to the dictionary as a key and each
       corresponding word as a value
"""

def fill_completions(c_dict, fd):
    c_dict = {}
    list_of_indexed_letters_tuples = []
    index = 0

    for line in file_obj:
        fd.readline()
        line = line.strip()
        word_list = line.split()

        for word in word_list:
            word.lower()
            word.strip(string.punctuation)

            if len(word) < 2:
                break

            elif char in word.isdigit():
                break

            else:
                for char in word:

                    while index < len(word):
                        letter = word[index]
                        indexed_letters_tuple(index, letter)
                        list_of_indexed_letters_tuples.append(indexed_letters_tuple)
                        index += 1

                if word in c_dict:
                    words_with_prefix_set = c_dict[word].add(list_of_indexed_letters_tuples)

                else:
                    words_with_prefix_set = c_dict[word] = {list_of_indexed_letters_tuples}

"""
Compares the prefix input by the user to the list of tuples generated from each
word in the file and assembles a set of words that have the same prefix as the
prefix that the user input

Receives:
    1) prefix string (input by the user)
    2) the dictionary of words and their corresponding (letter, index)
       tuples that was created by the fill_completions function

Returns:
    1) a set of words (strings) in which each word has the prefix input by the
       user

Algorithm:

"""
def find_completions(input_prefix_str, c_dict):
    word_pre
    for value in c_dict.keys():
        while len(input_prefix_str) < len(word_prefix_str)



    return set_of_strings

"""
Prints a list of words which share the same prefix as the prefix that
the user input.

Receives:
    1) Prefix from the user
    2) Set of words (each word is a string) from the dictionary (generated from
       the file) which share the prefix that the user inputs
       -- this set of words is returned from the find_completions function

Returns: nothing

Algorithm:
    1) Opens a file and reads text from it.
    2) Prompts user for a prefix.
    3) Calls the fill_completions and find_completions functions in order to
       compare the prefix to the dictionary of words generated from the file.
    4) Prints a set of words from the dictionary that share the same prefix as
       the prefix entered by the user.
    5) Continuously prompts the user for a prefix and generates the set of words
       from the file matching the prefix until the user enters '#' when prompted
       to enter a prefix.
       -- When '#' is entered, the program ends and the file is closed.
"""
def main():
    fd = open("ap_docs.txt", "r")

    if prefix_str != "#"
        prefix_str = input("Please input a prefix: ")
        fill_completions(c_dict, fd)
        set_of_strings = find_completions(prefix_str, c_dict)
        print(set_of_strings)
    else:
        print("Closing Program")
        fd.close()




