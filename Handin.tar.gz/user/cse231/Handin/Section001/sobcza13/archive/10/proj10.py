# CSE231 001H
# Project #10
# 4/8/2013
# sobcza13
# Algorithm: 
#    -utilizes a star class and rectangle class to draw a flag using turtle
#    -reads data from a text file to provide the arguments for the star and rectangle classes
#
#######################################################################################################################

import turtle
import time


class Star(object):
    """
       Defines what arguments are required of the star class
       Receives the arguments of the star class:
           -a center point (x,y)
           -the arm length of the star
           -the color the star will be
       Returns nothing
    """
    def __init__(self, x = 0, y = 0, arm_length = 0, color = ''):
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color
        self.starting_point = (self.x, self.y)
        self.tag = ""
        
    """
       Tells turtle how to draw a star
           Receives arguments from the star class
           Returns nothing
           Algorithm:
               -starts at the starting point
               -starting point is the center of the star
               -moves cursor to the border of the star
               -draws star
    """
    def draw(self, pen):
        pen.color(self.color)
        if pen.pos() != self.starting_point:
            pen.up()
            pen.goto(self.starting_point)
            pen.down()
        pen.begin_fill()
        pen.left(90)
        pen.forward(self.arm_length / 2.85)
        pen.right(90)
        pen.forward((self.arm_length / 3.236) + self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.end_fill()
        pen.setheading(0)
        pen.up()
        
    """
    Creates the format for printing out the arguments of each individual star
        Receives the arguments from the star class
        Returns what will be printed out 
    """
    def __str__(self):
        return """%s
                  x:%s, y:%s, a:%s, c:%s""" % (self.tag, self.x, self.y, self.arm_length, self.color)
        
        
class Rectangle(object):
    """
    Defines what arguments are required of the rectangle class
       Receives the arguments of the rectangle class:
           -a center point (x,y)
           -the width of the rectangle
           -the height of the rectangle
           -the color the rectangle will be
       Returns nothing
    """
    def __init__(self, x = 0, y = 0, width = 0, height = 0, color = ''):
        self.x = x
        self.y = y
        self.starting_point = (self.x, self.y)
        self.width = width
        self.height = height
        self.color = color
        self.tag = ""

    """
    Tells the turtle how to draw a rectangle
        Receives arguments from the rectangle class
        Returns nothing
        Algorithm:
           -starts at the starting point
           -the starting point is the center of the rectangle
           -moves turtle to the border of the rectangle
           -draws the rectangle
    """
    def draw(self, pen):
        pen.color(self.color)
        if pen.pos() != self.starting_point:
            pen.up()
            pen.goto(self.starting_point)
            pen.down()
        pen.begin_fill()
        pen.left(90)
        pen.forward(self.height / 2)
        pen.right(90)
        pen.forward(self.width / 2)
        pen.right(90)
        pen.forward(self.height)
        pen.right(90)
        pen.forward(self.width)
        pen.right(90)
        pen.forward(self.height)
        pen.right(90)
        pen.forward(self.width / 2)
        pen.end_fill()
        pen.setheading(0)
        pen.up()
        
    """
    Creates the format for printing out the arguments of each individual rectangle
        Receives the arguments from the rectangle class
        Returns what will be printed out 
    """
    def __str__(self):
        return """%s
                  x:%s, y:%s, w:%s, h:%s, c:%s""" % (self.tag, self.x, self.y, self.width, self.height, self.color)
        
        
class Flag(object):
    """
    Defines what arguments are required of the flag class
       Receives the arguments of the flag class:
           -an open text file from which the program reads the values for the arguments required by the
            rectangle class and the star class
       Returns nothing
       Algorithm:
           -reads from the text file line by line
               -each line contains the arguments for a specific star/rectangle except for the lines
                that denote how many rectangles or stars will be included in the drawing
          -each line is assigned to a list as a string, rectangles are added to one list, stars to another
    """
    def __init__(self, f_obj):
        self.f_obj = f_obj
        self.f_obj.readline()
        self.rectangle_list = []
        self.star_list = []
        self.tag = "Flag:"
        for line in self.f_obj:
            line = line.strip()
            line = line.split(',')
            if len(line) == 1:
                continue
            elif len(line) == 5:
                r = Rectangle(int(line[0]), int(line[1]), int(line[2]), int(line[3]), line[4]) #this is an element of the rectangle list
                self.rectangle_list.append(r)                                                  #the index values correspond to the arguments of the rectangle class
            elif len(line) == 4:
                s = Star(int(line[0]), int(line[1]), int(line[2]), line[3])                    #this is an element of the star list
                self.star_list.append(s)                                                       #the index values correspond to the arguments of the star class
    """
    Tells Turtle how to draw the flag using the elements from the star and rectangle lists
        -remember that the elements of these list each correspond to the parameters of a single star/rectangle

        Receives processed data from the text file
            -the processed data are the elements of the lists from above
    """          
    def draw(self, pen):
        
        for element in self.rectangle_list:
            element.draw(pen)

        for element in self.star_list:
            element.draw(pen)

    """
    Converts the elements of the lists into strings so that the formatted arguments passed to the rectangle/star
    classes can be printed out nicely

        Receives self
        Returns a string to be printed (see main(): ) 
    """
    def __str__(self):
        rectangle_str = ""
        star_str = ""
        for rectangle in self.rectangle_list:
            rectangle_str += str(rectangle)

        for star in self.star_list:
            star_str += str(star)
            
        flag_str = "Rectangles:" + rectangle_str + "\nStars:" + star_str 
            
        return flag_str
        
"""
Opens a file and uses the data to draw a flag by creating an instance of the Flag class.
Prints the data from the text file in a coherent manner.
Once the flag is drawn, closes the text file utilized as well as Turtle

    Receives nothing
    Returns nothing 
"""
def main():
    f_obj = open('myFlag.txt', 'r')
    f = Flag(f_obj)
    print(str(f))
    pen = turtle.Turtle()
    pen.speed('fastest')
    f.draw(pen)
    time.sleep(5)
    turtle.clearscreen()
    turtle.bye()
    f_obj.close()

main()
    
