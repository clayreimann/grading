# CSE231 001H
# Project 12 (Honors Project)
# 4/22/2013
# sobcza13
# Algorithm:
# 1) Read data from two text files
# 2) Manipulate the data from the two text files to get the necessary data
# 3) Plot the data using Matplotlib
# 4) Save the generated graphs to the directory
#############################################################################################################################

import math

# First must obtain the high and low from every 24hr period 

file_obj = open("temperature.txt", "r")

day_list = []
highs_list = []
lows_list = []

file_obj.readline()

for line in file_obj:
    line = line.strip()
    line = line.split()

    # To ignore the lines containing text, read through the file until character in first column is a number
    if line[0].isdigit():

        # Day_list denotes a 24hr period
        # As program iterates through each line, it appends the value in the fifth column to the day_list
        day_list.append(float(line[4]))

        # When the day_list contains 24 values, meaning a whole day is represented, the max temp for that day is added to the highs_list
        # and the min temp for that day is added to the lows list
        if len(day_list) == 24:
            highs_list.append(max(day_list))
            lows_list.append(min(day_list))

            # Then the day_list is emptied so that another 24 values can be added
            day_list = []

        
                                
start_index = 0
average_high_list = []
average_low_list = []
number_of_days_list = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

# Next must find the average high and average low for each month
# Right now the highs_list and lows_list each contain 365 values
# These must be separated into the respective months of the year
# And then an average high and low for each month must be calculated

for element in number_of_days_list:

    # The tricky part is dealing with the fact that the months of the year have varying numbers of days
    # Going to calculate the monthly average high & monthly average low one month at a time by iterating through
    # the values in the number_of_days_list
    # The number_of_days_list determines the length of the list taken from the highs_list and lows_list during each iteration
    
    # End_index is calculated by adding the respective value from the number_of_days_list to the start index
    # Ex: [0:31] 
    end_index = start_index + element
    
    monthly_highs_temp_list = highs_list[start_index:end_index]
    monthly_lows_temp_list = lows_list[start_index:end_index]

    # Then the start_index becomes the end_index
    # Ex: [31:60]
    start_index = end_index

    # The sum of the monthly high/low temp list is calculated and divided by the number of days in that month
    # i.e. the respective element from the number_of_days_list
    # This gives us the average high and low temp for each month 
    average_high = sum(monthly_highs_temp_list) / element
    average_high_list.append(average_high)
    
    average_low = sum(monthly_lows_temp_list) / element
    average_low_list.append(average_low)
    
# Error Checking:
#print(highs_list)
#print(lows_list)
#print(average_high_list)
#print(average_low_list)

bar_length_list = []

# The bars in the bar graph are floating bars in which the bottom represents the average low for the particular month
# and the top of the bar represents the average high for that month
# To determine the height of the bar to plug into Matplotlib,
# simply take the difference between the top of the bar and the bottom of the bar
# Add these values to a list to plug into Matplotlib

for index in range(12):
    difference = average_high_list[index] - average_low_list[index]
    bar_length_list.append(difference) 
    
file_obj.close()

# Next give Matplotlib the proper information

import matplotlib.pylab as plt
import numpy as np

# Generate 12 bars, one for each month of the year
x = np.arange(12)

# Plot the bars along the x-axis
# Get the respective bar heights from the bar length list
# Get the bottom of the bar from the average_low_list (monthly average low) 
plt.bar(x, bar_length_list, bottom = average_low_list)

# Label each bar, space the labels out, and rotate the label so that they don't run into each other
plt.xticks( x + 0.5,  ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'), rotation = 45)

# Label the y-axis; make the font color blue
plt.ylabel('Average Temperature', color='b')

# Label the bar graph with a title
plt.title('Charleston, MO -June 2012')

# Error Checking: 
#plt.show()

# Save the graph to the directory as an image file
plt.savefig('average_monthly_temp.png')

# Close the graph so that the new graph will not be affected by the old data
plt.close()



file_obj = open('temperature.txt', 'r')

# Next we will only be working with data from June
# We want the average June temperature for each hour
# Ex: the average temperature for 11a.m. in the month of June, the average temperature for 12p.m. in the month of June, etc. 

hourly_list = []
hourly_average_temp_list =[]

# Read through four lines so that the text in the text file is ignored 
file_obj.readline()
file_obj.readline()
file_obj.readline()
file_obj.readline()

# Add each subsequent line in the file to the line_list as an element
line_list = file_obj.readlines()

# Iterate through values 1 through 24
# For each value, multiply by 100 so that the format matches the format of the time listed in the txt file
for i in range(1,25):
    h = i * 100
    hourly_list = []
    
    for line in line_list:
        line = line.strip()
        line = line.split()

        # Iterate through each line in the file until the value in the first column of the line equals 6
        # Meaning we have reached the data for the month of June 
        if int(line[0]) == 6:
            #Error Checking
            #print(line)

            # h = 100 during first iteration
            # If and only if the value in the fourth column of that particular line equals h should the value
            # in the fifth column (temp) be added to the hourly_list
            if int(line[3]) == h: 
                hourly_list.append(float(line[4]))
                
    #Error Checking           
    #print(hourly_list)

    # Calculate the average temperatue for that hour by adding up the temperatures for that hour and
    # dividing by the number of days in June
    # Append the calculated average to the hourly_average_temp_list 
    hourly_average = sum(hourly_list) / 30
    hourly_average_temp_list.append(hourly_average)

    # Now we have iterated through the whole file once
    # Return to the outer for loop, increase h by 100, multiply h by 100, and empty the hourly_list
    # Then iterate through the file again 
    
# Error Checking:
#print(hourly_average_temp_list)

file_obj.close()

# Next we want to calculate the average monthly solar radiation for each hour of the day
# i.e. the average solar radiation during the month of June for 11a.m., 12p.m., etc.
# Use the same exact process as outlined above only this time information is taken from
# the solar_radiation txt file 

file_obj = open('solar_radiation.txt', 'r')

hourly_list = []
hourly_average_sr_list =[]

file_obj.readline()
file_obj.readline()
file_obj.readline()
file_obj.readline()

line_list = file_obj.readlines()

for i in range(1,25):
    h = i * 100
    hourly_list = []
    
    for line in line_list:
        line = line.strip()
        line = line.split()
        
        if int(line[0]) == 6:
            # Error Checking:
            #print(line)
            
            if int(line[3]) == h: 
                hourly_list.append(float(line[4]))

    # Error Checking:            
    #print(hourly_list)
                
    hourly_average = sum(hourly_list) / 30
    hourly_average_sr_list.append(hourly_average)

# Error Checking:
#print(hourly_average_sr_list)

file_obj.close()

# Finally we want to create a plot of the average monthly temp and solar radiation during the month of June for every hour
# To represent this data we will plot two separate lines along the same x-axis (hours) 

import matplotlib.pylab as plt
import numpy as np

fig = plt.figure()
ax1 = fig.add_subplot(111)

# 24 points for each line will be plotted 
t = np.arange(0, 24)

# first line will obtain its y values from the hourly_average_temp_list
# the color of the line is blue 'b', the points will be represented by dots 'o', and a solid line will be drawn '-'
ax1.plot(t, hourly_average_temp_list, 'bo-')

# label the x-axis 'Hour'
ax1.set_xlabel('Hour')

# label the left y-axis 'Average Temperature' and make the font blue
ax1.set_ylabel('Average Temperature', color='b')

# make the yticklabels blue 
for tl in ax1.get_yticklabels():
    tl.set_color('b')

# the two data sets will share the same x-axis
ax2 = ax1.twinx()

# the data for the second y-axis will be taken from the hourly_average_sr_list
# the color of the line will be red 'r', the points will be represented by dots 'o' and a solid line will be drawn '-'
ax2.plot(t, hourly_average_sr_list, 'ro-')

# the second y-axis will be labeled 'Average Solar Radiation' and the font color will be red 
ax2.set_ylabel('Average Solar Radiation', color='r')

# make the yticklabels for the second y-axis red
for tl in ax2.get_yticklabels():
    tl.set_color('r')

# label the graph with a title     
plt.title("Charleston,MO -June 2012")

# Error Checking 
#plt.show()

# save the graph as an image file 
plt.savefig('june_sr_temp_comparison.png')

# close the graph so that future graphs will not be super-imposed over this graph
plt.close()
    
file_obj.close()


