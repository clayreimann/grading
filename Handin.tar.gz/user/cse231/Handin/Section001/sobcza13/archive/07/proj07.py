#CSE231 001H
#Project #7
#3/11/2013
#sobcza13
#Algorithm:
#   1. Prompts the user for a file name. If the user inputs an invalid file name
#      the program reprompts the user for a file name.
#   2. Reads the file line by line.
#   3. For each word longer than 3 letters in the line the program scrambles the inner letters
#      keeping the first letter and last letter the same.
#   4. I was not able to keep punctuation intact.
#   5. Writes the newly scrambled words one by one to a different file of the user's choosing. 
################################################################################################################

import random

"""
   Opens the file from which the user wishes to obtain the data to scramble. The file name is specific.
   If the user does not type the file name properly they are reprompted to type in the file name.
   
   Receives: a string input by the user.
   
   Returns: an opened file from which the program will obtain data to manipulate.

   Algorithm:
       1. Ask the user to input the name of the file they wish the program to obtain data from.
       2. Reprompt the user if the input file name does not exist in the directory.
       3. If the input file name does exist in the directory, the program opens it.
"""

def open_read_file(read_file_name_str):
    
    while read_file_name_str != 'hard.txt':
        read_file_name_str = input("Invalid file name. Read from which file? ")
        
        if read_file_str == 'hard.txt':
            continue
        
    else:
        read_file_name_obj = open('hard.txt', 'r')
        
    return read_file_name_obj

"""
    Takes a word and scrambles the inner letters while keeping the first and last letters the same. (If the word is 3 letters or less the word is not altered.)

    Receives: a word in the form of a string.

    Returns: the same word with the inner letters scrambled and the first and last letters the same.

    Algorithm:
        1. If the word contains more than 3 letters:
                 a) the program examines the inner letters, ignoring the first and last letters
                 b) the program converts this string of innter letters to a list
                 b) the program shuffles this list of letters using the random module (imported at the top of the program)
                 c) the program joins this list of letters (strings) into a single string
                 d) the program returns a string that contains the first letter of the original word, the string of scrambled inner letters, and
                    the last letter of the origninal word
        2. If the word contains 3 letters or less the original word is not altered and the program returns the original word.

"""

def scramble_word(word_str):
    
    if len(word_str) > 3:
        #The following block of commented code is how I would have attempted to handle the matter of keeping all punctuation in its original location(s).
        #This code is based off of where one would normally find said punctuation:
            #An apostrophe indicates a contraction such as found in the word "don't" or "you're". This code attempts to account for both by splitting the original
            #string into a list of strings at the apostrophe. Using the example "don't" the program would scramble the 'o' and 'n' and then assemble a new string:
            #first the first letter of the first string (d), next the scrambled portion, finally the second string which consists of the apostrophe and whatever
            #comes after it. 
        # for char in word_str:
        
            #if char == "'":
                #word_str.split(char)
                    #first_str = word_list[0]
                    #second_str = word_list[-1]
                    # if len(first_str) > 3:
                        #scrambled_str = first_str[1:]
                        #scrambled_list = random.sample(scrambled_str, len(scrambled_str))
                        #middle_of_word_str = ''.join(scrambled_list)
                        #result_str = first_str[0] + middle_of_word_str[:] + second_str[:]
                    
            #This block would deal with a single word in quotes, adjusting the index values so that the first two characters and last two characters are left in their
            #original positions. 
            #elif word_str[0] == '"' and word_str[-1] == '"':
                    #scrambled_str = word_str[2:-2]
                    #scrambled_list = random.sample(scrambled_str, len(scrambled_str))
                    #middle_of_word_str = ''.join(scrambled_list)
                    #result_str = word_str[0:2] + middle_of_word_str[:] + word_str[-2:]
                    
            #If more than one word was included in a quoatation so that any word could have a quote at the beginning or end of it but not both:
            #elif word_str[0] == '"':
                    #scrambled_str = word_str[2:-1]
                    #scrambled_list = random.sample(scrambled_str, len(scrambled_str))
                    #middle_of_word_str = ''.join(scrambled_list)
                    #result_str = word_str[0:2] + middle_of_word_str[:] + word_str[-1]
                    
            #elif word_str[-1] == '"':
                    #scrambled_str = word_str[1:-2]
                    #scrambled_list = random.sample(scrambled_str, len(scrambled_str))
                    #middle_of_word_str = ''.join(scrambled_list)
                    #result_str = word_str[0] + middle_of_word_str[:] + word_str[-2:]
                    
           #Again following puncutation rules one generally finds a period, exclaimation point, or semi-colon at the end of a word. Therefore the part of the string that needs
           #to be scrambled is shortened by one character so that the final letter in the word and the ./! is left in its intial position. 
           #elif char == "." or char == "!" or char == ";":
                    #scrambled_str = word_str[1:-2]
                    #scrambled_list = random.sample(scrambled_str, len(scrambled_str))
                    #middle_of_word_str = ''.join(scrambled_list)
                    #result_str = word_str[0] + middle_of_word_str[:] + word_str[-2:]
                    
           #If the word contains no punctuation:          
           #else:
                #The next four lines of code would have to be indented beneath this else statement
                    
                        
        scrambled_str = word_str[1:-1]
        scrambled_list = random.sample(scrambled_str, len(scrambled_str))
        middle_of_word_str = ''.join(scrambled_list)
        
        result_str = word_str[0] + middle_of_word_str[:] + word_str[-1]

    else:
        result_str = word_str

    #print(result_str)  I am sure this definition works; however, I did not include the punctuation requirement. It was the only definition I was able to test. 
    return result_str

"""
    Reads a line from the file, scrambles each word in the line, and returns a new line containing the scrambled words.

    Receives: a line from the file opened with the open_read_file function.

    Returns: a string consisting of a line of text whose words have been scrambled using the scramble word function.

    Algorithm:
        1. Reads a line of text from the read file
        2. Iterates through each word in the line
        3. Scrambles each word by calling the scramble_word function
        4. Adds each scrambled word to a new list
        5. Converts that list to a string
        6. Returns the line of text as a string which contains the newly scrambled words
"""

def scramble_line(line_str):
    
    new_line_list = []
    
    file_name_obj.readline()
    
    for word_str in line:
        scrambled_word = scramble_word(word_str)
        new_line_list.append(scrambled_word)
        
    new_line_str = ''.join(new_line_list)

    return new_line_str

"""
    Prompts the user for a file to read from and a file to write to, opens these files, reads the file one line at a time,
    for each line iterates through each word, scrambles each word, writes each word to the write to file, closes the read from
    file and the write to file.

    Receives: 2 strings via user input --
              1 string corresponds to the read from file and 1 string corresponds to the write to file
              
    Returns: nothing

    Algorithm:
        1: Prompts the user for a file to read from
        2: Calls the open_read_file function which will keep prompting the user until a file name which
           exists in the directory is entered in which case that file is opened
        3. Prompts the user for a file to write to, opens that file
        4. Reads through the read from file line by line
        5. Calls the scramble_line function (which in turn calls the scramble_word function)
        6. For each line iterates through each word, scrambles the word, writes the word to the write to file
        7. Closes both the read from and write to files once the program has iterated through every word
        8. That last main() means the user is automatically prompted to enter a read from file name --
           the user does not have to first call the main function
"""

def main():
    read_file_name_str = input("Read from which file? ")
    read_file_name_ojb = open_read_file(read_file_name_str)
    
    write_file_name_str = input("Write to which file? ")
    write_file_name_obj = open('blank_doc.txt', 'w')
    
    
    
    for line in read_file_name_obj:
        scrambled_line_list = scramble_line(line_str)

        for word_str in scrambled_line_list:
            write_file_name_obj.write(word_str)
            
    read_file_name_obj.close()
    write_file_name_obj.close()

main()

