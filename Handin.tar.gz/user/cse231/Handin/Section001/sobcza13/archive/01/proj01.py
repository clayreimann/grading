# CSE231 001H
# Project 1
# sobcza13
# Objectives:
# 1) Convert an input Richter measure to Joules of Energy and tons of TNT
# 2) Print table of Richter measure to Joules to tons of TNT values
# 1.14.2013

num_str1 = input("Please give me a Richter scale measure:")

num_float = float(num_str1)
joules = 10**((1.5*num_float)+4.8)
tons_of_tnt = 10**((1.5*num_float)+4.8)/4.184e9

print("Richter scale measure:", num_float)

print("Equivalence in Joules:", joules)

print("Equivalence in tons of TNT:", tons_of_tnt)

"""Receives value and returns same value"""
def richter_measure(richter_float):
    return richter_float

"""Receives richter measure and returns equivalent in Joules"""
def richter_measure_to_joules(richter_float):
    return 10**((1.5*richter_float)+4.8)

"""Receives richter measure and returns equivalent in tons of TNT"""
def richter_measure_to_tons_tnt(richter_float):
    return 10**((1.5*richter_float)+4.8)/4.184e9

print("Richter---------------Joules---------------TNT")
print(richter_measure(1), "          ", richter_measure_to_joules(1), "              ", richter_measure_to_tons_tnt(1))
print(richter_measure(5), "          ", richter_measure_to_joules(5), "            ", richter_measure_to_tons_tnt(5))
print(richter_measure(9.1), "        ", richter_measure_to_joules(9.1), "   ", richter_measure_to_tons_tnt(9.1))
print(richter_measure(9.2), "        ", richter_measure_to_joules(9.2), "   ", richter_measure_to_tons_tnt(9.2))
print(richter_measure(9.5), "        ", richter_measure_to_joules(9.5), " ", richter_measure_to_tons_tnt(9.5)) 


