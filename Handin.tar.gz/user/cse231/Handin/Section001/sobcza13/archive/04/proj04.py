#########################################################################################################################################
#
# CSE231 001H
# Project 4
# 2/4/2013
# sobcza13
# Objectives: 
# 1. Prompt user for two strands of DNA
# 2. Give user the option to either:
#    a) add an indel to one of the strands
#    b) delete an indel to one of the strands
#    c) calculate the number of matches & mismatches between the two strands
#    d) end the program
# 3. Give user an error message if the indel selected for alteration is outside the index of the DNA strand
# 4. Adjust DNA strand length if the two strands entered are of unequal length
#
####################################################################################################################################

# Prompts user for two DNA sequences
dna_sequence_1_str = input("Please give me your first DNA sequence:  ")
dna_sequence_2_str = input("Please give me your second DNA sequence: ")

q = 'q'
s = 's'
d = 'd'
a = 'a'

# If the DNA sequences are not the same length initially, '-'s will be added to the end of the shorter string until they are equal in length
# Then the user will be prompted to add indel, delete indel, compare the 2 DNA sequences, or quit the program
if len(dna_sequence_1_str) > len(dna_sequence_2_str):
    num_of_dashes_int = len(dna_sequence_1_str) - len(dna_sequence_2_str)
    dna_sequence_2_str = dna_sequence_2_str + '-' * num_of_dashes_int

    input_str = input("""Please choose from the following commands:
                      'a' -Add indel
                      'd' -Delete indel
                      's' -Score
                      'q' -Quit:
                      |: """)
    
elif len(dna_sequence_2_str) > len(dna_sequence_1_str):
    num_of_dashes_int = len(dna_sequence_2_str) - len(dna_sequence_1_str)
    dna_sequence_1_str = dna_sequence_1_str + '-' * num_of_dashes_int

    input_str = input("""Please choose from the following commands:
                      'a' -Add indel
                      'd' -Delete indel
                      's' -Score
                      'q' -Quit:
                      |: """)
# If the 2 DNA sequences are of equal length, the user will be immediately prompted to add indel, delete indel,
# compare the 2 DNA sequences, or quit the program immediately after inputing the 2 DNA sequences 
else:
    input_str = input("""Please choose from the following commands:
                      'a' -Add indel
                      'd' -Delete indel
                      's' -Score
                      'q' -Quit:
                      |: """)

while input_str == a or input_str == d or input_str == s or input_str == q:

    # If user selects 'q' the program halts
    if input_str == 'q':
        print("Good bye.")
        break
    
    # If user selects 'a' the program asks user which DNA sequence to alter
    elif input_str == 'a':
         sequence_to_alter_str = input("Which DNA sequence do you wish to alter?, '1' or '2'? ")
         
         # If user wishes to alter first DNA sequence:
         if sequence_to_alter_str == '1':

             # Asks user before what index to insert a '-'
             protein_to_alter_seq1_str = input("Before what index? ")
             protein_to_alter_seq1_int = int(protein_to_alter_seq1_str)
             
            # Prints an error message if the user selects an indel that is outside of the range of that DNA sequence
            # User is re-prompted to add indel, delete indel, compare the two DNA sequences, or quit the program. 
             if protein_to_alter_seq1_int > (len(dna_sequence_1_str) - 1):
                print("Error. Selection not within range.")
                 

             # Splices DNA sequence (string) before the input index value, adds '-', and joins to remainder of DNA sequence (string)
             else:
                dna_sequence_1_str = dna_sequence_1_str[:protein_to_alter_seq1_int] + '-' + dna_sequence_1_str[protein_to_alter_seq1_int:]

             # Re-prompts user to add an indel, delete an indel, compare the 2 DNA sequences, or quit the program
             input_str = input("""Please choose from the following commands:
                  'a' -Add indel
                  'd' -Delete indel
                  's' -Score
                  'q' -Quit:
                  |: """)
             
         # Adds an indel using the same process only this time user wishes to alter the 2nd DNA sequence
         elif sequence_to_alter_str == '2':
             
             protein_to_alter_seq2_str = input("Before what index? ")
             protein_to_alter_seq2_int = int(protein_to_alter_seq2_str)

             if protein_to_alter_seq2_int > (len(dna_sequence_2_str) -1):
                 print("Error. Selection not within range.")
             
             else:
                 dna_sequence_2_str = dna_sequence_2_str[:protein_to_alter_seq2_int] + '-' + dna_sequence_2_str[protein_to_alter_seq2_int:]

             input_str = input("""Please choose from the following commands:
                  'a' -Add indel
                  'd' -Delete indel
                  's' -Score
                  'q' -Quit:
                  |: """)
             
    # If user selects 'd' the progam asks which DNA sequence is to be altered
    elif input_str == 'd':
        sequence_to_alter_str = input("Which DNA sequence do you wish to alter?, '1' or '2'? ") 

        # If sequence 1 is to be altered:
        if sequence_to_alter_str == '1':

            # Program asks which index should be deleted
            protein_to_alter_seq1_str = input("Delete what index? ")                        
            protein_to_alter_seq1_int = int(protein_to_alter_seq1_str)

            # Prints an error message if the user selects an indel that is outside of the range of that DNA sequence
            # User is re-prompted to add indel, delete indel, compare the two DNA sequences, or quit the program
            if protein_to_alter_seq1_int > (len(dna_sequence_1_str) - 1):
                 print("Error. Selection not within range.")

            # Deletes indel at the input index value
            else:
                dna_sequence_1_str = dna_sequence_1_str[:protein_to_alter_seq1_int] + dna_sequence_1_str[(protein_to_alter_seq1_int +1):]

            # Re-prompts user to add an indel, delete an indel, compare the 2 DNA sequences, or quit the program
            input_str = input("""Please choose from the following commands:
                  'a' -Add indel
                  'd' -Delete indel
                  's' -Score
                  'q' -Quit:
                  |: """)
            
        # Deletes an indel using the same process as above only this time user wishes to alter the 2nd DNA sequence     
        elif sequence_to_alter_str == '2':
            protein_to_alter_seq2_str = input("Delete what index? ")
            protein_to_alter_seq2_int = int(protein_to_alter_seq2_str)

            if protein_to_alter_seq2_int > (len(dna_sequence_2_str) - 1):
                 print("Error. Selection not within range.")

            else:
                dna_sequence_2_str = dna_sequence_2_str[:protein_to_alter_seq2_int] + dna_sequence_2_str[(protein_to_alter_seq2_int +1):]

            input_str = input("""Please choose from the following commands:
                  'a' -Add indel
                  'd' -Delete indel
                  's' -Score
                  'q' -Quit:
                  |: """)
            
    # Program will calculate how many indel matches and mismatches there are between DNA sequences 1 and 2
    # By examining each respective indel from each sequence and assembling two altered DNA sequences
    # The altered sequences have a mixture of capital and lowercase letters, the capital letters denoting a mismatched indel pair
    elif input_str == 's':

        # Sets initial score total to 0, sets total number of comparisons to 0, and prompts comparison to start at index 0
        # I chose x, even though it is arbitrary, because the brackets [x] would have looked ridiculous otherwise
        score_int = 0
        num_of_comparisons_int = 0
        x = 0

        # Char is set to arbitrary value
        char = ""

        # The altered strings start empty
        altered_1_str = ""
        altered_2_str = ""

        # Each letter in DNA sequence 1 will be compared to the corresponding index value letter in DNA sequence 2
        for char in dna_sequence_1_str:
            
            # If a specfic index value in DNA sequence 1 equals the same index value in DNA sequence 2:
            # Increase the total score by 1
            # Increase the total number of comparisons by 1
            # Compare the next set of index values
            if dna_sequence_1_str[x] == dna_sequence_2_str[x] and dna_sequence_1_str[x] != '-':
                altered_1_str = altered_1_str + dna_sequence_1_str[x]
                altered_2_str = altered_2_str + dna_sequence_2_str[x]
                score_int += 1
                num_of_comparisons_int += 1
                x += 1
                
            # If the DNA sequence index values do not equal each other because one of them is a '-':
            # The score remains the same
            # The number of comparisons increases by 1
            # The program compares the next set of index values
            elif dna_sequence_1_str[x] != dna_sequence_2_str[x] and dna_sequence_1_str[x] == '-' or dna_sequence_2_str[x] == '-' :
                altered_1_str = altered_1_str + dna_sequence_1_str[x].capitalize()
                altered_2_str = altered_2_str + dna_sequence_2_str[x].capitalize()
                score_int += 0
                num_of_comparisons_int += 1
                x += 1
                 
            # If a specfic index value in DNA sequence 1 does not equal the same index value in DNA sequence 2 and neither is a '-':
            # Total score remains the same
            # Increase the total number of comparisons by 1
            # Compare the next set of index values
            else:   
                altered_1_str = altered_1_str + dna_sequence_1_str[x].capitalize()
                altered_2_str = altered_2_str + dna_sequence_2_str[x].capitalize()
                score_int += 0
                num_of_comparisons_int += 1
                x += 1
                
        # Prints the number of matches and mismatches
        # Prints the altered DNA sequences with capital letters denoting mismatched sequence pairs
        print("Matches: ", score_int, "Mismatches: ", num_of_comparisons_int - score_int)
        print("First altered DNA sequence:  ", altered_1_str)
        print("Second altered DNA sequence: ", altered_2_str)
        
        # Re-prompts user to add indel, delete indel, compare the 2 DNA sequences, or quit the program
        input_str = input("""Please choose from the following commands:
                  'a' -Add indel
                  'd' -Delete indel
                  's' -Score
                  'q' -Quit:
                  |: """)

                

                
            
            
                
                

