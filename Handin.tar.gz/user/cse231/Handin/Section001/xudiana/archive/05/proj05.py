import string

print("Choices for colors to use are:")                                 #menu of colors
print("   red")
print("   blue")
print("   green")
print("   yellow")
print("   orange")
print("   purple")
print("   pink")

def get_num_hexagons ():                                                #function, number of hexagons in row
    num_hex=input("Please enter the number of hexagons per row:")             
    done=True
    while done:
        if num_hex not in string.digits:
            num_hex=input("It should be between 4 and 20. Please try again:")     #invalid input
        elif int(num_hex)>=4 and int(num_hex)<=20:                                  #valid input
            done=False
        else:
            num_hex=input("It should be between 4 and 20. Please try again:")     #invalid input
    return int(num_hex)

def get_color_choice():                                                 #function, colors
    color=str(input("Please enter your choice:"))
    done=True
    while done:
        if color=="red" or color=="blue" or color=="green" or color=="yellow" or color=="orange" or color=="purple" or color=="pink":
            done=False
        else:
            print("'",color,"' is not a legal choice.")
            color=str(input("Please try again:"))                       #invalid input
    return str(color)

def draw_hexagon(x, y, side_len, pen, color):                           #function, drawing hexagons with variables
    turtle.penup()
    turtle.setposition(x,y)
    turtle.pendown()
    turtle.fillcolor(color)
    turtle.begin_fill()
    for _ in range(8):
        turtle.forward(side_len)
        turtle.left(60)                                                 #angle turns of hexagon
    turtle.end_fill()
    turtle.right(120)


color1=str(get_color_choice())
color2=str(get_color_choice())                                          #get two colors
numhex=int(get_num_hexagons())                                          #get number of hexagons
import turtle
import math
side_len=(500/numhex/2)/(math.cos(math.pi/6))                           #size of hexagon side length
turtle.right(30)                                                        #rotate so hexagons are drawn straight along bottom

count2=0                                                                #initialize a count
for _ in range(numhex):                                                 #goes through numhex amount of times
    if count2%2==0:                                                     #every odd numbered row (1st, 3rd, 5th etc.)
        x=-500 
        y=-300 + count2*(side_len+(side_len*math.sin(math.pi/6)))
    elif count2%2==1:                                                   #every even numbered row (2nd, 4th, 6th etc.)
        x= -500 + ((500/numhex)/2)
        y=-300 + count2*(side_len+(side_len*math.sin(math.pi/6)))
    count=0                                                             #initialize count for drawing tessellation while loop
    turtle.penup()
    turtle.setposition(x,y)
    turtle.pendown()
    if (count2+1)%4==1 or (count2+1)%4==2:                              #first set of rows
        while count<numhex:                                             #when the count is less than the number of hexagons needed
            if count%2==0:                                              #draw in color1
                draw_hexagon(turtle.xcor(),turtle.ycor(),side_len,turtle,color1)
                count+=1
            elif count%2==1:                                            #draw in color2
                draw_hexagon(turtle.xcor(),turtle.ycor(),side_len,turtle,color2)
                count+=1
        count2+=1
    elif (count2+1)%4==3 or (count2+1)%4==0:                            #second set of rows
        while count<numhex:                                             #when the count is less than num of hexagons needed
            if count%2==0:
                draw_hexagon(turtle.xcor(),turtle.ycor(),side_len,turtle,color2) #color2
                count+=1
            elif count%2==1:
                draw_hexagon(turtle.xcor(),turtle.ycor(),side_len,turtle,color1) #color1
                count+=1
        count2+=1                                                       #add to count

