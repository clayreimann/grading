#Project 6
#Feb 25 2013

#function to repeatedly ask for a file to open 
#PUNCH's lecture code for asking user for input file
import string

def get_input_descriptor():
    opened_file_bool = False
    while (not opened_file_bool):
        try:
            file_name_str = input("What file would you like to open?")
            file_obj = open(file_name_str, "r")
            opened_file_bool = True   # only executed after file opens
        except IOError:
            print("Bad file name, please try again!")      #bad file name
            continue #reprompt
    else:
        return file_obj         #returns file descriptor

def get_data_list(file_obj,column_number): #passes file_obj through
    file_obj = file_obj.read()
    file_obj = file_obj.split("\n")        #splits at endings
    file_obj = file_obj[1:]
    date_list = []
    value_list = []
    for row in file_obj:
        row = row.split(",")                #splitting at commas
        date_index = row[0]
        val_index = row[column_number]
        value_list.append(val_index)        #adds val_index to value_list
        date_list.append(date_index)        #adds date_index to date_list
    tuple_list = []
    count = 0
    for tuple_index in date_list:
        date = date_list[count]
        value = value_list[count]
        date_val_tup = date, value
        tuple_list.append(date_val_tup)     #add date_val_tup to tuple_list
        count += 1
    return tuple_list                       #returns tuple_list

def average_data(tuple_list):               #passes tuple_list through
    count = 0
    day_count=0
    total = 0
    value_date_list = []
    for tup_char in tuple_list:             #goes through each tuple in list
        if count < len(tuple_list)-1:       #if this
            count_tup = tuple_list[count]   #compare this tuple
            count_tup2 = tuple_list[count+1]#with next tuple in list
            date_tup = count_tup[0]
            date_tup2= count_tup2[0]
            date_list = date_tup.split("-") #split up date
            date_list2 = date_tup2.split("-")#split up date
            month = int(date_list[1])
            month2 = int(date_list2[1])
            if month == month2:             #if months are same
                total += float(count_tup[1])#add to total count
                day_count+=1
                count +=1
            else:                           #once months aren't same
                average = round((total+float(count_tup[1]))/(day_count+1),2) #calculate average
                mo = date_list[1]
                yr = date_list[0]
                date_tbj = mo , yr          #creating month, year tuple
                join_date = ":".join(date_tbj)
                tup_avg = average, join_date
                value_date_list.append(tup_avg) #adding month, year, average tup to list
                total = 0
                day_count=0
                count +=1
        else:                               #considers last date_val_tup in tuple_list
            count_tup = tuple_list[count]
            date_tup = count_tup[0]
            date_list = date_tup.split("-")
            average = round((total+float(count_tup[1]))/(day_count+1),2) #same process as above, calculate avg
            mo = date_list[1]
            yr = date_list[0]
            date_tbj = mo , yr
            join_date = ":".join(date_tbj)
            tup_avg = average, join_date
            value_date_list.append(tup_avg)
            total = 0
            day_count=0
            count +=1
    return value_date_list                  #returns list of month:year, average tuples
    
def main():
    file_obj=get_input_descriptor()
    done = False
    while not done:             #prompts for column_number
        column_number = int(input("What column do you want?"))
        if column_number == 0:  #can't average dates, so invalid input
            print ("This is a column of dates with no average value. Try again.")
        elif column_number>=1 and column_number<=6: #valid responses
            done=True
        else: #any other invalid inputs
            print("Invalid column.")
    tuple_list=get_data_list(file_obj, column_number) #calls for get_data_list
    value_date_list=average_data(tuple_list)          #calls for average_data
    sorted_list= sorted(value_date_list)              #sorts average_data list low to high
    highest_six=sorted_list[-1:-7:-1]                 #takes last six in sorted list
    lowest_six=sorted_list[0:6]                       #takes first six values in sorted list
    highest_six_new= []
    lowest_six_new= []
    for item in highest_six:                          #goes through each of high six
        date= str(item[1])
        date= date.split(":")
        join_date = "-".join(date)                    #change date format
        tup_new = item[0], join_date
        highest_six_new.append(tup_new)               #add to list
    for item2 in lowest_six:                          #same process with each of low six
        date2= str(item2[1])
        date2= date2.split(":")
        join_date2 = "-".join(date2)
        tup_new2 = item2[0], join_date2
        lowest_six_new.append(tup_new2)        
    print("Lowest 6 for column", column_number)       #prints lowest 6
    for tup2 in lowest_six_new:
        date_tab = tup2[1]
        val_tab = "{0:.2f}".format(tup2[0])           #2 decimal points
        print("Date:", date_tab, "Value:", val_tab)
    print("    ")
    print("Highest 6 for column", column_number)      #same process high 6
    for tup in highest_six_new:
        date_tab2 = tup[1]
        val_tab2 = "{0:.2f}".format(tup[0])
        print("Date:", date_tab2, "Value:", val_tab2)
    
    
main()                                                #runs main function
