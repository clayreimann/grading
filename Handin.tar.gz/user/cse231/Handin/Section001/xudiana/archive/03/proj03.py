################
#Project 3     #
#Change Machine#
#Jan 23 2013   #
################

print ("Welcome to the vending machine change maker program.")
print ("Change maker initialized.")

#Counters for stock
nick_num = 25
dime_num = 25
qtr_num = 25
ones_num = 0
fiv_num = 0


while True:      #Stock
    print ("      ")
    print ("Stock Contains:")
    print (nick_num, "nickels")
    print (dime_num, "dimes")
    print (qtr_num, "quarters")
    print (ones_num, "ones")
    print (fiv_num, "fives")

    print ("      ")
    num_str = input ("Enter the purchase price(xx.xx) or 'q' to end:")     #User Input Prompt
    if num_str == 'q':
        total = 100*(nick_num*.05+dime_num*.1+qtr_num*.25 +ones_num + fiv_num*5) #Gives total in stock after user quits
        dollars = round(int(total//100))
        cents = round(int(total%100))
        print ("Total:", dollars, "dollars and", cents, "cents.")
        break
    elif float(num_str) > 0 and (float(num_str)*10)%.5 == 0:   #If the payment is valid
        num_pay=float(num_str)
        while True:                                            #Menu for deposits
            print("Menu for deposits:", end="")
            print("     ")
            print("'n'-deposit a nickel",end="")
            print("     ")
            print("'d'-deposit a dime",end="")
            print("     ")
            print("'q'-deposit a quarter",end="")
            print("     ")
            print("'o'-deposit a one dollar bill",end="")
            print("     ")
            print("'f'-deposit a five dollar bill",end="")
            print("     ")
            print("'c'-cancel the purchase",end="")
            print("     ")
            print("      ")
            num_pay2 = num_pay*100                            #Initialize num_pay2 outside of the while loop
            done = False                                      #initialize done
            while not done:                                   #While This is True (variable "done")    
                if int(round((num_pay2//100)))==0 and int(round(num_pay2%100))==0:
                    break
                else:
                    print ("Payment due:", int(round((num_pay2//100))), "dollars and", int(round(num_pay2%100)), "cents")
                    money_paid=input ("Indicate your deposit:")
                    if money_paid =='n':                      #If user enters a nickel as payment
                        num_pay2 = num_pay2-5                 #Subtract 5 from the price 
                        nick_num = nick_num+1                 #Add one to the nickel count in stock
                        if int((num_pay2)//100)==0 and int((num_pay2)%100)==0:                      #When price is zero
                            print ("No Change due. Thank you for your business! Please come again!")
                            break
                        elif int((num_pay2)//100)<0 or int((num_pay2)%100)<0:                       #Once the dollars or cents is negative
                            num_pay2 = round(0-num_pay2)
                            print ("      ")
                            print ("Please take your change")                                       #Giving change
                            if num_pay2>0 and num_pay2//25 < qtr_num:                               #Starting with quarters
                                if num_pay2<25 or qtr_num==0:
                                    print(end="")
                                else:                                                                               
                                    print (int(num_pay2//25) ,"quarters")
                                    qtr_num=qtr_num-(num_pay2//25)                                  #Subtract change from stock
                                    num_pay2 = (num_pay2 - 25*(num_pay2//25))                       #Subtract change from price
                            elif num_pay2>=25:
                                if qtr_num==0:
                                    print (end="")
                                else:                                                               #Give all the quarters the stock has
                                    print (int(qtr_num),"quarters")
                                    num_pay2=(num_pay2-25*qtr_num)
                                    qtr_num=0                                                       #Update qtr_num to 0
                            if num_pay2>0 and num_pay2//10 < dime_num:                              #Dimes
                                if num_pay2<10 or dime_num==0:                                      #Price less than 10 or no dimes left
                                    print(end="")
                                else:                                                               #Give dimes
                                    print (int(num_pay2//10) ,"dimes")
                                    dime_num=dime_num-(num_pay2//10)
                                    num_pay2 = (num_pay2 - 10*(num_pay2//10))
                            elif num_pay2>=10:                                                                      
                                if dime_num==0:
                                    print (end="")
                                else:                                                               #Give all dimes the stock has
                                    print (int(dime_num),"dimes")
                                    num_pay2=(num_pay2-10*dime_num)
                                    dime_num=0
                            if num_pay2>0 and num_pay2//5 < nick_num:                               #same process as above for nickels
                                if num_pay2<5 or nick_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//5) ,"nickels")
                                    nick_num=nick_num-(num_pay2//5)
                                    num_pay2 = (num_pay2 - 5*(num_pay2//5))
                            elif num_pay2>=5:
                                if nick_num==0:
                                    print (end="")
                                else:
                                    print (int(nick_num),"nickels")
                                    num_pay2=(num_pay2-(5*nick_num))
                                    nick_num=0
                                    done = True                 #Redefine done variable to stop from prompting for payment due
                        continue                                #PROGRAM AFTER THIS POINT IS REPETITION OF ABOVE, only diff is money_paid options
                    elif money_paid =='d':                                                              #User pays with dime
                        num_pay2 =num_pay2-10
                        dime_num = dime_num+1
                        if int((num_pay2)//100)==0 and int((num_pay2)%100)==0:                          #No Payment left
                            print ("No Change due. Thank you for your business! Please come again!")
                            break
                        elif int((num_pay2)//100)<0 or int((num_pay2)%100)<0:                           #If machine needs to give change
                            num_pay2 = round(0-num_pay2)
                            print ("     ")
                            print ("Please take your change")
                            if num_pay2>0 and num_pay2//25 < qtr_num:
                                if num_pay2<25 or qtr_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//25) ,"quarters")
                                    qtr_num=qtr_num-(num_pay2//25)
                                    num_pay2 = (num_pay2 - 25*(num_pay2//25))
                            elif num_pay2>=25:
                                if qtr_num==0:
                                    print (end="")
                                else:                                                                   #Give all quarters
                                    print (int(qtr_num),"quarters")
                                    num_pay2=(num_pay2-25*qtr_num)
                                    qtr_num=0
                            if num_pay2>0 and num_pay2//10 < dime_num:
                                if num_pay2<10 or dime_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//10) ,"dimes")
                                    dime_num=dime_num-(num_pay2//10)
                                    num_pay2 = (num_pay2 - 10*(num_pay2//10))
                            elif num_pay2>=10:
                                if dime_num==0:
                                    print (end="")
                                else:
                                    print (int(dime_num),"dimes")                                       #Give all dimes
                                    num_pay2=(num_pay2-10*dime_num)
                                    dime_num=0
                            if num_pay2>0 and num_pay2//5 < nick_num:
                                if num_pay2<5 or nick_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//5) ,"nickels")
                                    nick_num=nick_num-(num_pay2//5)
                                    num_pay2 = (num_pay2 - 5*(num_pay2//5))
                            elif num_pay2>=5:
                                if nick_num==0:
                                    print (end="")
                                else:
                                    print (int(nick_num),"nickels")                                     #Give all nickels
                                    num_pay2=(num_pay2-(5*nick_num))
                                    nick_num=0
                                if num_pay2>0 and nick_num==0:                                          #There are not even enough nickels
                                    print ("     ")
                                    print ("Not enough change. Please see manager for refund.")
                                    print ("Amount due:", int(round((num_pay2//100))), "dollars and", int(round(num_pay2%100)), "cents")
                                    done = True
                        continue
                    elif money_paid =='q':                                                              #User pays with quarter
                        num_pay2 = num_pay2-25
                        qtr_num = qtr_num+1
                        if int((num_pay2)//100)==0 and int((num_pay2)%100)==0:
                            print ("No Change due. Thank you for your business! Please come again!")
                            break
                        elif int((num_pay2)//100)<0 or int((num_pay2)%100)<0:                           #If change is needed
                            num_pay2 = round(0-num_pay2)
                            print ("     ")
                            print ("Please take your change")
                            if num_pay2>0 and num_pay2//25 < qtr_num:
                                if num_pay2<25 or qtr_num==0:                                           #start with quarters
                                    print(end="")
                                else:
                                    print (int(num_pay2//25) ,"quarters")                               #give as many quarters as needed
                                    qtr_num=qtr_num-(num_pay2//25)
                                    num_pay2 = (num_pay2 - 25*(num_pay2//25))
                            elif num_pay2>=25:                                                          #if stock has no quarters
                                if qtr_num==0:
                                    print (end="")
                                else:
                                    print (int(qtr_num),"quarters")                                     #give all quarters
                                    num_pay2=(num_pay2-(25*qtr_num))
                                    qtr_num=0
                            if num_pay2>0 and num_pay2//10 < dime_num:
                                if num_pay2<10 or dime_num==0:
                                    print(end="")
                                else:                                                                   #give as many dimes as needed
                                    print (int(num_pay2//10) ,"dimes")
                                    dime_num=dime_num-(num_pay2//10)
                                    num_pay2 = (num_pay2 - 10*(num_pay2//10))
                            elif num_pay2>=10:
                                if dime_num ==0:                                                        #no dimes left
                                    print(end="")
                                else:                                                                   #otherwise, give all dimes as possible
                                    print (int(dime_num),"dimes")
                                    num_pay2 = (num_pay2 - 10*(dime_num))
                                    dime_num=0
                            if num_pay2>0 and num_pay2//5 < nick_num:
                                if num_pay2<5 or nick_num==0:                                           #no nickels in stock or price less than 5
                                    print(end="")
                                else:
                                    print (int(num_pay2//5) ,"nickels")
                                    nick_num=nick_num-(num_pay2//5)
                                    num_pay2 = (num_pay2 - 5*(num_pay2//5))
                            elif num_pay2>=5:
                                if nick_num ==0:                                                        #if no more nickels
                                    print(end="")
                                else:
                                    print (int(nick_num),"nickels")                                     #give all nickels left in stock
                                    num_pay2 = (num_pay2 - 5*(nick_num))
                                    nick_num=0
                                if num_pay2>0 and nick_num==0 and dime_num==0:                          #not enough dimes and nickels, give change
                                    print ("      ")
                                    print ("Not enough change. Please see manager for refund.")
                                    print ("Amount due:", int(round((num_pay2//100))), "dollars and", int(round(num_pay2%100)), "cents")
                                    done = True
                        continue
                    elif money_paid == 'o':                                                             #user enters a one
                        num_pay2 = num_pay2-100
                        ones_num = ones_num+1
                        if int((num_pay2)//100)==0 and int((num_pay2)%100)==0:                          #no change due
                            print ("No Change due. Thank you for your business! Please come again!")
                            break
                        elif int((num_pay2)//100)<0 or int((num_pay2)%100)<0:                           #change due
                            num_pay2 = round(0-num_pay2)
                            print ("      ")
                            print ("Please take your change")
                            if num_pay2>0 and num_pay2//25 < qtr_num:                                   #start with quarters
                                if num_pay2<25 or qtr_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//25) ,"quarters")                               #give as many qtrs as needed
                                    qtr_num=qtr_num-(num_pay2//25)
                                    num_pay2 = (num_pay2 - 25*(num_pay2//25))
                            elif num_pay2>=25:
                                if qtr_num==0:                                                          #no quarters in stock
                                    print (end="")
                                else:
                                    print (int(qtr_num),"quarters")                                     #give all quarters of stock
                                    num_pay2=(num_pay2-25*qtr_num)
                                    qtr_num=0
                            if num_pay2>0 and num_pay2//10 < dime_num:                                  #same process with dimes
                                if num_pay2<10 or dime_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//10) ,"dimes")
                                    dime_num=dime_num-(num_pay2//10)
                                    num_pay2 = (num_pay2 - 10*(num_pay2//10))
                            elif num_pay2>=10:
                                if dime_num ==0:
                                    print(end="")
                                else:
                                    print (int(dime_num),"dimes")
                                    num_pay2 = (num_pay2 - 10*(dime_num))
                                    dime_num=0
                            if num_pay2>0 and num_pay2//5 < nick_num:                                   #same process with nickels
                                if num_pay2<5 or nick_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//5) ,"nickels")
                                    nick_num=nick_num-(num_pay2//5)
                                    num_pay2 = (num_pay2 - 5*(num_pay2//5))
                            elif num_pay2>=5:
                                if nick_num ==0:
                                    print(end="")
                                else:
                                    print (int(nick_num),"nickels")
                                    num_pay2 = (num_pay2 - 5*(nick_num))
                                    nick_num=0
                                if num_pay2>0 and nick_num==0 and dime_num==0 and qtr_num==0:           #if cannot make change with any coins
                                    print ("       ")
                                    print ("Not enough change. Please see manager for refund.")
                                    print ("Amount due:", int(round((num_pay2//100))), "dollars and", int(round(num_pay2%100)), "cents")
                                    done = True
                        continue
                    elif money_paid == 'f':                                                             #user pays with five dollar bill
                        num_pay2 = num_pay2-500
                        fiv_num = fiv_num+1
                        if int((num_pay2)//100)==0 and int((num_pay2)%100)==0:                          #user paid exact price
                            print ("No Change due. Thank you for your business! Please come again!")
                            break
                        elif int((num_pay2)//100)<0 or int((num_pay2)%100)<0:                           #change is needed                       
                            num_pay2 = round(0-num_pay2)
                            print ("     ")
                            print ("Please take your change")
                            if num_pay2>0 and num_pay2//25 < qtr_num:                                   #start with quarters
                                if num_pay2<25 or qtr_num==0:                                           #not enough quarters or price is less than 25
                                    print(end="")
                                else:                                                                   #give as many qtrs as needed
                                    print (int(num_pay2//25) ,"quarters")
                                    qtr_num=qtr_num-(num_pay2//25)
                                    num_pay2 = (num_pay2 - 25*(num_pay2//25))
                            elif num_pay2 >=25:
                                if qtr_num ==0:                                                         #no quarters in stock
                                    print(end="")
                                else:                                                                   #give all qtrs in stock
                                    print (int(qtr_num),"quarters")
                                    num_pay2 = (num_pay2 - 25*(qtr_num))
                                    qtr_num=0
                            if num_pay2>0 and num_pay2//10 < dime_num:                                  #same process with dimes
                                if num_pay2<10 or dime_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//10) ,"dimes")
                                    dime_num=dime_num-(num_pay2//10)
                                    num_pay2 = (num_pay2 - 10*(num_pay2//10))
                            elif num_pay2>=10:
                                if dime_num ==0:
                                    print(end="")
                                else:
                                    print (int(dime_num),"dimes")
                                    num_pay2 = (num_pay2 - 10*(dime_num))
                                    dime_num=0
                            if num_pay2>0 and num_pay2//5 < nick_num:                                   #same proocess with nickels
                                if num_pay2<5 or nick_num==0:
                                    print(end="")
                                else:
                                    print (int(num_pay2//5) ,"nickels")
                                    nick_num=nick_num-(num_pay2//5)
                                    num_pay2 = (num_pay2 - 5*(num_pay2//5))
                            elif num_pay2>=5:
                                if nick_num ==0:
                                    print(end="")
                                else:
                                    print (int(nick_num),"nickels")
                                    num_pay2 = (num_pay2 - 5*(nick_num))
                                    nick_num=0
                                if num_pay2>0 and nick_num ==0 and dime_num == 0 and qtr_num==0:        #no change left to give change
                                    print ("     ")
                                    print ("Not enough change. Please see manager for refund.")
                                    print ("Amount due:", int(round((num_pay2//100))), "dollars and", int(round(num_pay2%100)), "cents")
                                    done = True
                        continue
                    elif money_paid == 'c':                                         #when user cancels purchase, give back money they put in  
                        change_due = round((num_pay - num_pay2/100)*100)            #change due is whatever they paid into the machine
                        print ("      ")
                        print ("Please take change below.")
                        if change_due == 0:                                         #user did not put any money in
                            print ("No change due.")
                        if change_due>0 and change_due//25 < qtr_num:               #change due and begin with giving quarters
                            if change_due<25 or qtr_num==0:
                                print(end="")
                            else:
                                print (int(change_due//25) ,"quarters")             #give as many quarters as needed
                                qtr_num=qtr_num-(change_due//25)
                                change_due = (change_due - 25*(change_due//25))
                        elif change_due>=25:                                        
                            if qtr_num==0:                                          #no qtrs in stock
                                print (end="")
                            else:
                                print (int(qtr_num) ,"quarters")                    #give all qtrs from stock
                                change_due = (change_due - 25*(qtr_num))
                                qtr_num=0
                        if change_due>0 and change_due//10 < dime_num:              #same process with dimes
                            if change_due<10 or dime_num==0:
                                print(end="")
                            else:
                                print (int(change_due//10) ,"dimes")
                                dime_num=dime_num-(change_due//10)
                                change_due = (change_due - 10*(change_due//10))
                        elif change_due>=10:
                            if dime_num==0:
                                print (end="")
                            else:
                                print (int(dime_num) ,"dimes")
                                change_due = (change_due - 10*(dime_num))
                                dime_num=0
                        if change_due>0 and change_due//5 < nick_num:               #same process with nickels
                            if change_due<5 or nick_num==0:
                                print(end="")
                            else:
                                print (int(change_due//5) ,"nickels")
                                nick_num=nick_num-(change_due//5)
                                change_due = (change_due - 5*(change_due//5))
                        elif change_due>=5:
                                print (int(nick_num) ,"nickels")
                                change_due = (change_due - 5*(nick_num))
                                nick_num=0
                        if change_due>0 and nick_num ==0 and dime_num == 0 and qtr_num==0:      #no change left to give change
                                print ("     ")
                                print ("Not enough change. Please see manager for refund.")
                                print ("Amount due:", int(round((change_due//100))), "dollars and", int(round(change_due%100)), "cents")
                    else:
                        print ("Illegal selection:", money_paid)                #user entered something not from menu for payment option
                        continue
                break
            break
    else:
        print ("Illegal price: must be non-negative multiples of 5 cents")      #user entered illegal value for price

