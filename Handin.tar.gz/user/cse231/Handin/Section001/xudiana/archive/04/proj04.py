#Project 4
#January 31
#Strings and DNA



str_one = input("String 1:")                 #asks for input
str_two = input("String 2:")

done = False                                 #initialize a while loop var
while not done:                              #while not false
    print ("         ")

    print ("What do you want to do?")        #menu
    print ("         a (add indel)   ")
    print ("         d (delete indel)")
    print ("         s (score)       ")
    menu_opt = input ("         q (quit):")
    length1 = len(str_one)                  #length of str 1 and 2
    length2 = len(str_two)

    indel = '-'
    if menu_opt == 'q':                     #q
        print (end="")                      #quit and get out of while loop
            done=True
        elif menu_opt == 'a':               #adding indel
            str_inpa= input ("Work on which string? (1 or 2):")
        if str_inpa == '1':                 #work on 1
            index_a = int(input ("Before what index:"))
            if index_a >= length1:
                print ("Illegal selection.")
            else:                           #inserting an indel
                position = index_a - length1
                left_str = str_one [0:position]
                right_str = str_one [index_a:length1]
                str_one = left_str + '-' + right_str
        elif str_inpa == '2':               #work on string 2
            index_a = int(input ("Before what index:"))
            if index_a >= length2:          #same process as above
                print ("Illegal selection.")
            else:                           #inserting an indel
                position2 = index_a - length2
                left_str2 = str_two [0:position2]
                right_str2 = str_two [index_a:length2]
                str_two = left_str2 + '-' + right_str2  
        else:
            print ("Illegal selection.")
    elif menu_opt == 'd':                   #delete an indel
        str_inpd=input("Work on which string? (1 or 2):")
        count = int(0)                      #initialize a count
        str_count = str(count)
        if str_inpd == '1':
            index_d = int(input("Before what index:"))
            if str_one[index_d]!='-':
                print ("Error to delete character that is not an indel.")
            else:
                for str_count in str_one:   #for loop to compare char in strings
                    if count<index_d:
                        char_str = str_one[0:index_d]
                        count +=1           #add to count
                    elif count == index_d:
                        count += 1          #add to count
                    elif count>index_d:
                        char_str2 = str_one[index_d+1:length1+1]
                        count += 1          #add to count
                str_one = char_str + char_str2
        elif str_inpd == '2':               #work on string 2
            index_d = int(input("Before what index:"))
            if str_two[index_d] != '-':     #if the space is not indel
                print ("Error to delete character that is not an indel.")
            else:
                for str_count in str_two:   #for loop to compare char in strings
                    if count<index_d:
                        char_str = str_two[0:index_d]
                        count +=1           #same process as other for loop
                    elif count == index_d:
                        count += 1
                    elif count>index_d:
                        char_str2 = str_two[index_d+1:length2+1]
                        count += 1
                str_two = char_str + char_str2
        else:                               #not choosing to work on str1/2
            print ("Illegal input.")
    elif menu_opt == 's':                   #scoring
        str_s = str_one                     #initialize variable for strings
        str_s2 = str_two
        if length1<length2:                 #compare lengths
            add_ind= length2-length1
            str_s = str_s + ('-'*(add_ind)) #add indel to str_s
        elif length2<length1:
            add_ind2 = length1-length2
            str_s2 = str_s2+('-'*(add_ind2))#add indel to str_s2
        count2 = 0                          #initialize count, for loop
        match = 0                           #initialize matchcount
        mismatch = 0                        #intiialize mismatch
        str_count2= str(count2)
        str1 = ""                           #blank str1
        str2 = ""                           #blank str2
        for str_count2 in str_s and str_s2:
            if str_s[count2] == '-' or str_s2[count2] == '-':   #if indels
                str_up1 = str_s[count2].upper()
                str_up2 = str_s2[count2].upper()
                str1 = str1+str_up1
                str2 = str2 +str_up2
                count2 += 1
                mismatch +=1                #indels are mismatches
            elif str_s[count2].lower() == str_s2[count2].lower():
                str_low1 = str_s[count2].lower()
                str_low2 = str_s2[count2].lower()
                str1 = str1 + str_low1
                str2 = str2 + str_low2
                count2 += 1
                match += 1                  #add one to match count
            else:
                str_up1 = str_s[count2].upper()
                str_up2 = str_s2[count2].upper()
                str1 = str1+str_up1
                str2 = str2 +str_up2
                count2 += 1
                mismatch +=1                #add ont to mismatch count
                
        print ("Matches:", match, "Mismatches:", mismatch)
        print (str1)
        print (str2) #print the strings and numbers
    else:
        print ("Illegal selection. Try again.")
