import numpy as np
import matplotlib.pyplot as plt

#Open temperature.txt file and read it
file_obj=open("temperature.txt","r")
file_obj=file_obj.read()
file_obj.strip()
line_list=file_obj.split("\n")      #create list of each line
line_list=line_list[2:]
day_temps={}
month_temps={}
months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
for line in line_list:
    my_list=line.split(' ')
    new_list=[]
    for element in my_list:
        e_list=list(element)
        v=0
        for i in e_list:        #only add elements of the loist that contain numbers
            if i.isdigit():
                v=1
        if v==1:
            new_list.append(element)
    m=int(new_list[0])-1
    key=months[m]+new_list[1]
    #creates dictionary for days and all the temperatues per day
    if key in day_temps.keys():
        value=day_temps[key]
        value.add(new_list[4])
        day_temps[key]=value
    else:
        value={new_list[4]}
        day_temps[key]=value
for k in day_temps.keys():
    tup=min(day_temps[k]),max(day_temps[k])     #create tuple with igh and low per day
    value={tup}
    day_temps[k]=value      #tuple is new value for dictionary
for m in months:
    key=m
    high=float(0)
    low=float(0)
    num=float(0)
    for k in day_temps.keys():
        s=str(k)
        if s[:3]==m:
            tup=list(day_temps[k])[0]
            high+=float(tup[1])
            low+=float(tup[0])
            num+=float(1)
    high_avg=high/num           #average high and low temperatues per month
    low_avg=low/num
    t=low_avg,high_avg
    value=t
    month_temps[key]=value      #create dictionary with month and tuple of hihg.low temperature
top=[]
bottom=[]
#all below add low temps to bottom list and high temps to top list
for k in month_temps.keys():
    if k=='Jan':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Feb':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Mar':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Apr':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='May':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Jun':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Jul':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Aug':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Sep':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Oct':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Nov':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
for k in month_temps.keys():
    if k=='Dec':
        tup=month_temps[k]
        top.append(float(tup[1])-float(tup[0]))
        bottom.append(tup[0])
#create plot as described in program specifications
x=[1,2,3,4,5,6,7,8,9,10,11,12]
plt.bar(x,top,bottom=bottom)
locs, labels=plt.xticks(x,('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'))
plt.setp(labels, 'rotation', 'vertical')
plt.title('Charleston,MO - 2012')
plt.ylabel('Average Temp')
plt.savefig('Temp.png')


#open and read solar radiation text file
file_obj2=open("solar_radiation.txt","r")
file_obj2=file_obj2.read()
file_obj2.strip()
line_list2=file_obj2.split("\n")
line_list2=line_list2[4:]
temp_dict={}
solar_dict={}
#both loops below create dicts, hour as key and temp/radiation as value
for line in line_list:
    my_list=line.split(' ')
    new_list=[]
    for element in my_list:
        e_list=list(element)
        v=0
        for i in e_list:
            if i.isdigit():
                v=1
        if v==1:
            new_list.append(element)
    if int(new_list[0])==6:
        key=new_list[3]
        if key in temp_dict.keys():
            value=temp_dict[key]
            value.add(new_list[4])
        else:
            value={float(new_list[4])}
        temp_dict[key]=value
for line in line_list2:
    my_list=line.split(' ')
    new_list=[]
    for element in my_list:
        e_list=list(element)
        v=0
        for i in e_list:
            if i.isdigit():
                v=1
        if v==1:
            new_list.append(element)
    if int(new_list[0])==6:
        key=new_list[3]
        if key in solar_dict.keys():
            value=solar_dict[key]
            value.add(float(new_list[4]))
        else:
            value={float(new_list[4])}
        solar_dict[key]=value
for k in temp_dict.keys(): #averages all values of each key
    v_list=list(temp_dict[k])
    tot=float(0)
    for x in v_list:
        tot+=float(x)
    avg=tot/float(len(v_list))
    value=avg
    temp_dict[k]=value
for k in solar_dict.keys(): #averages all values of each key
    v_list=list(solar_dict[k])
    tot=float(0)
    for x in v_list:
        tot+=x
    avg=tot/float(len(v_list))
    value=avg
    solar_dict[k]=value
temp=[]
solar=[]
for k in temp_dict.keys(): #all code under this create lists of temps and radiation
    if k=='100':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='200':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='300':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='400':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='500':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='600':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='700':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='800':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='900':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1000':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1100':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1200':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1300':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1400':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1500':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1600':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1700':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1800':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='1900':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='2000':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='2100':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='2200':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='2300':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
for k in temp_dict.keys():
    if k=='2400':
        temp.append(temp_dict[k])
        solar.append(solar_dict[k])
        
fig = plt.figure() #plots the second figure as described in program specs
ax1 = fig.add_subplot(111)
hours=[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
ax1.plot(hours, temp, 'b.-') #left hand axis
ax1.set_xlabel('Hour')
# Make the y-axis label and tick labels match the line color.
ax1.set_ylabel('Average Temp', color='b')
for tl in ax1.get_yticklabels():
    tl.set_color('b')

ax2 = ax1.twinx()
ax2.plot(hours,solar, 'r.-')#right hand axis
ax2.set_ylabel('Average Solar Radiation', color='r')
for tl in ax2.get_yticklabels():
    tl.set_color('r')
plt.title('Charleston,MO- June 2012')
plt.savefig('SolarTemp.png')
