#Project 8
#March 18 2013

import string

#NOTE TO TA: This program takes a long time (1-2 mins on my computer) to give a prompt
#asking for the prefix but after that it works!***

def fill_completions(c_dict, file_object):              #function to fill completion dictionary
    for line in file_object:
        line = line.strip()
        word_list = line.split()                        #list of words in each line
        for word in word_list:
            word = word.lower()                         #make all words lower case
            char_list=list(word)                        #list of characters in the word
            letter_list=[]
            index=0
            for char in char_list:
                if char in string.punctuation:          #if a character is a punctuation mark, don't include
                    print(end="")
                elif char in string.ascii_letters:      #if character is a letter, add it to letter list
                    letter_list.append(char)
                elif char in string.digits:             #if character is a number, change index value
                    index=1
                else:
                    print(end="")
            word="".join(letter_list)                   #rejoin word without punctuation
            if len(word)==1:                            #don't add one letter word to dictionary
                print(end="")
            elif index==1:                              #if the word was  a number, don't add to dictionary
                print(end="")
            else:                                       #will add word to dictionary
                key_list= list(enumerate(word))         #creates a list of tuples as keys
                for key in key_list:
                    if key in c_dict.keys():            #if a key already has a value in dictionary
                        my_list=[word]
                        my_set=set(my_list)             #make a set with new word to be added under a key
                        c_dict[key]=set(c_dict[key])|my_set     #union set of existing words and new word
                    else:                               #if key doesn't have a value in dictionary
                        c_dict[key]={}
                        my_list=[word]
                        my_set=set(my_list)
                        c_dict[key]=set(c_dict[key])|my_set     #union an empty set with the new word
                    
def find_completions(prefix, c_dict):
    find_key_list=list(enumerate(prefix))               #list of keys for the entered prefix
    intersect_set= c_dict[find_key_list[0]]             #initialize set of possible words by the first key
    find_key_list=find_key_list[1:]
    for find_key in find_key_list:                      
        intersect_set=set(c_dict[find_key]) & intersect_set     #finds common words between the sets for each prefix key
    return intersect_set                                #returns set of possible word completions

def main():
    file_object=open("ap_docs.txt", "r")                #open ap_docs file
    c_dict={}                                           #initialize empty dictionary
    fill_completions(c_dict, file_object)               #call function to fill dictionary
    print("Enter a prefix of a word you wish to find or '#' to quit.")
    print("  ")
    done=False                    
    while not done:
        prefix=str(input("What is the prefix of the word you wish to find?"))
        if prefix== '#':
            done=True
        else:
            final_word_set=find_completions(prefix, c_dict)     #calls functions to find list of possible word completions
            if final_word_set==set():
                print('Sorry, there are no words with that as a prefix.')   #error if no words satisfy the prefix
            else:
                print(final_word_set)
main()
