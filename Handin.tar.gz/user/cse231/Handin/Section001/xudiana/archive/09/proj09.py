#Project 9
#Mar 25 2013

import cardsBasic
import string

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    foundation = [[],[],[],[]]
    cell = [[],[],[],[]]
    my_deck = cardsBasic.Deck()   #gets deck
    my_deck.shuffle()             #shuffles deck
    tableau = [[],[],[],[],[],[],[],[],[],[]]
    column = 0
    while not my_deck.is_empty():   #shuffles deck into tableau
        tableau[column].append(my_deck.deal())
        column += 1
        if column % 10 == 0:
            column = 0
    
    return foundation,tableau,cell


def move_tab_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''
    found_col = foundation[f_col-1]   #the foundation that user wants
    tab_col = tableau[t_col-1]        #the tableau that user wants
    if tab_col == []:                 #can't move if empty
        return False
    elif found_col==[]:               #if the foundation is empty, only aces
        if int(tab_col[-1].get_rank())==1:
            found_col.append(tab_col[-1])
            foundation[f_col-1] = found_col
            tab_col.pop(-1)
            tableau[t_col-1] = tab_col
            return True
        else:
            return False
    else:                           #if found not empty, only same suit cards
        if not found_col[-1].equal_suit(tab_col[-1]):
            return False
        else:                       #and the rank of card in found has to be 1 less
            if int(found_col[-1].get_rank())==int(tab_col[-1].get_rank()) - 1:
                found_col.append(tab_col[-1])
                foundation[f_col-1] = found_col
                tab_col.pop(-1)
                tableau[t_col-1] = tab_col
                return True
            else:
                return False

def move_cell_foundation(cell,foundation,c_col,f_col):
    found_col = foundation[f_col-1]         #the foundation column user wants
    cell_col=cell[c_col-1]                  #the cell col user wants
    if cell_col == []:                      #can't do if cell_col is empty
        return False
    elif found_col==[]:                     #if the foundation is empty, only aces
        if int(cell_col[-1].get_rank())==1:
            found_col.append(cell_col[-1])
            foundation[f_col-1] = found_col
            cell_col.pop(-1)
            cell[c_col-1] = cell_col
            return True
        else:
            return False
    else:                                   #must be same suit
        if not found_col[-1].equal_suit(cell_col[-1]):
            return False
        else:                               #and card in found is one less in rank
            if int(found_col[-1].get_rank())==int((cell_col[-1].get_rank())) - 1:
                found_col.append(cell_col[-1])
                foundation[f_col-1] = found_col
                cell_col.pop(-1)
                cell[c_col-1] = cell_col
                return True
            else:
                return False
    

def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    tab_col = tableau[t_col-1]          #tableau user wants
    cell_col = cell[c_col-1]            #cell user wants
    if tab_col ==[]:                    #can't grab card from empty column
        return False
    elif cell_col == []:                #adding cards to the cell
        cell_col.append(tab_col[-1])
        cell[c_col-1] = cell_col
        tab_col.pop(-1)
        tableau[t_col-1] = tab_col
        return True
    else:
        return False


def move_to_tableau(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    
    tab_col = tableau[t_col-1]      #tableau column that user wants
    cell_col = cell[c_col-1]        #cell column that user wants
    
    if cell_col == []:              #can't do if cell is empty
        return False
    elif tab_col == []:             #can only move kings when tab is empty
        if int(cell_col[-1].get_rank()) == 13:
            tab_col.append(cell_col[-1])
            tableau[t_col-1] = tab_col
            cell_col.pop(-1)
            cell[c_col-1] = cell_col
            return True
        else:
            return False
    else:
        if cell_col[-1].equal_suit(tab_col[-1]):  #must be same suit
            if int(cell_col[-1].get_rank()) == (int(tab_col[-1].get_rank())-1):
                tab_col.append(cell_col[-1])  #and one less in rank
                tableau[t_col-1] = tab_col
                cell_col.pop(-1)
                cell[c_col-1] = cell_col
                return True
            else:
                return False
        else:
            return False


def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    found_col0 = foundation[0] #the four foundations
    found_col1 = foundation[1]
    found_col2 = foundation[2]
    found_col3 = foundation[3]
    
    if found_col0 ==[] or found_col1 ==[] or found_col2==[] or found_col3==[]: #if any are empty, user has not won
        return False
    elif int(found_col0[-1].get_rank())==13 and int(found_col1[-1].get_rank())==13 and int(found_col2[-1].get_rank())==13 and int(found_col3[-1].get_rank())==13:
        return True                                                            #user wins when all founds have kings
    else:
        return False


def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    tab_col_source = tableau[t_col_source-1]                #first tableau user wants
    tab_col_dest = tableau[t_col_dest-1]                    #second tab user wants
    if tab_col_source ==[]:                                 #if the first tab is empty, can't do it
        return False
    elif tab_col_dest ==[]:                                 #only kings can be moved to empty tabs
        if int(tab_col_source[-1].get_rank())==13:
            tab_col_dest.append(tab_col_source[-1])
            tableau[t_col_dest-1] = tab_col_dest
            tab_col_source.pop(-1)
            tableau[t_col_source-1]=tab_col_source
            return True
        else:
            return False
    elif tab_col_source[-1].equal_suit(tab_col_dest[-1]):       #if not empty tab_dest, rank of tab_source card must be one less
        if int(tab_col_source[-1].get_rank()) == ((int(tab_col_dest[-1].get_rank())-1)):
            tab_col_dest.append(tab_col_source[-1])
            tableau[t_col_dest-1] = tab_col_dest
            tab_col_source.pop(-1)
            tableau[t_col_source-1]=tab_col_source
            return True
        else:
            return False
    else:
        return False

        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    win_bool = False                    #when the user has not won, run the while loop
    while win_bool is False:
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        if len(response_list) > 0:
            r = response_list[0]
            if r == 't2f':
                t_col = int(response_list[1])
                f_col = int(response_list[-1])
                val_t2f = move_tab_foundation(tableau,foundation,t_col,f_col)   #call move_tab_foundation function
                win_bool = is_winner(foundation)  #checks to see if user won
                if val_t2f is False:
                    print ("Invalid response. Try again.")
                    continue
                else:
                    continue
            elif r == 't2t':
                t_col_source = int(response_list[1])
                t_col_dest = int(response_list[-1])
                val_t2t = move_in_tableau(tableau,t_col_source,t_col_dest)      #call move_in_tableau function
                if val_t2t is False:
                   print ("Invalid response. Try again.")
                   continue
                else:
                   continue
            elif r == 't2c':
                t_col = int(response_list[1])
                c_col = int(response_list[-1])
                val_t2c = move_to_cell(tableau,cell,t_col,c_col)                #call move_to_cell function
                if val_t2c is False:
                    print ("Invalid response. Try again.")
                    continue
                else:
                    continue
            elif r == 'c2t':
                c_col = int(response_list[1])
                t_col = int(response_list[-1])
                val_c2t = move_to_tableau(tableau,cell,t_col,c_col)             #call move_to_tableau function
                if val_c2t is False:
                    print ("Invalid response. Try again.")
                    continue
                else:
                    continue
            elif r == 'c2f':
                c_col = int(response_list[1])
                f_col = int(response_list[-1])
                val_c2f = move_cell_foundation(cell,foundation,c_col,f_col)
                win_bool = is_winner(foundation)     #checks to see if user won
                if val_c2f is False:
                    print ("Invalid response. Try again.")
                    continue
                else:
                    continue
            elif r == 'q':
                break
            elif r == 'h':
                show_help()
            else:
                print('Unknown command:',r)
        else:
            print("Unknown Command:",response)
    print('Thanks for playing!')

play()


