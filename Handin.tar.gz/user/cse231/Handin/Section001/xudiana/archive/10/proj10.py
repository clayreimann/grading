import string
import turtle
import math
import time

class Rectangle(object):
    def __init__(self,x,y,width,height,color=''):
        self.x_cen=x        #defining the params for instances
        self.y_cen=y
        self.width=width
        self.height=height
        self.color=str(color)
        self.line='black'
    def __str__(self):
        return "%s%s %s%s %s%s %s%s %s%s" %("Rectangle x:",self.x_cen, "y:", self.y_cen, "width:",self.width, "height:",slef.height, "color:",self.color)
    def drawr(self, pen):
        pen.fillcolor(self.color)  #color of fill
        pen.up()
        pen.goto(self.x_cen-(self.width/2),self.y_cen+(self.height/2)) #moves turtle to top left corner
        pen.down()
        pen.begin_fill()
        for i in range(2):         #draws a rectangle
            pen.forward(self.width)
            pen.right(90)
            pen.forward(self.height)
            pen.right(90)
        pen.end_fill()
        pen.up()

class Star(object):
    def __init__(self,x,y,arm_length,color):
        self.x_star=x   #defining params for instances
        self.y_star=y
        self.length=arm_length
        self.color=str(color)
    def __str__(self):
        return "%s%s %s%s %s%s %s%s" %("Star x:",self.x_star, "y:", self.y_star, "arm:",self.length,"color:",self.color)   #returns string
    def draws(self,pen):
        pen.fillcolor(self.color)   #color of fill
        pen.up()
        pen.goto(self.x_star+(self.length/3.2361),self.y_star+(self.length/2.3511))     #moves turtle to bottom right corner of top point
        pen.down()
        pen.begin_fill()
        for i in range(5):   #draws star
            pen.forward(self.length)
            pen.right(144)      #turns 144 degrees
            pen.forward(self.length)
            pen.left(72)        #turns 72 degrees
        pen.end_fill()
        pen.up()

class Flag(object):
    def __init__(self,file_object):
        self.file_object = file_object    #gets file_object to get paramaters for flag shapes
        self.r_x_cor_list=[]              #list of rect x coordinates
        self.r_y_cor_list=[]              # "          " y coordinates
        self.r_width_list=[]              #rectangle widths, heights, colors
        self.r_height_list=[]
        self.r_color_list=[]
        self.s_x_cor_list=[]              #same idea for stars
        self.s_y_cor_list=[]
        self.s_arm_list=[]
        self.s_color_list=[]        
        count=0
        for line in self.file_object:     #strip each line, split into words
            line=line.strip()
            word_list=line.split(",")
            if len(word_list) == 1:       #if only one word in line, becomes numbers of either rects/stars
                num=int(word_list[0])
                count+=1
            else:
                if count==1:
                    self.r_x_cor_list.append(int(word_list[0]))     #goes through each line, adds rect params to lists
                    self.r_y_cor_list.append(int(word_list[1]))
                    self.r_width_list.append(int(word_list[2]))
                    self.r_height_list.append(int(word_list[3]))
                    self.r_color_list.append(str(word_list[4])[1:])
                    self.r_num=num
                else:
                    self.s_x_cor_list.append(int(word_list[0]))    #same for stars
                    self.s_y_cor_list.append(int(word_list[1]))
                    self.s_arm_list.append(int(word_list[2]))
                    self.s_color_list.append(str(word_list[3])[1:])
                    self.s_num=num
    def drawf(self,pen):
        count2=0
        for i in range(self.r_num):  #draws r_num of rectangles
            rect=Rectangle(self.r_x_cor_list[count2],self.r_y_cor_list[count2],self.r_width_list[count2],self.r_height_list[count2],self.r_color_list[count2])
            count2+=1
            rect.drawr(pen)
        count3=0
        for i in range(self.s_num):  #draws s_num of rectangles
            star=Star(self.s_x_cor_list[count3],self.s_y_cor_list[count3],self.s_arm_list[count3],self.s_color_list[count3])
            count3+=1
            star.draws(pen)
    def __str__(self):
        flag_str="%s \n" %("Rectangles")
        count3=0
        for i in range(self.r_num):  #prints the params for rectangles
            flag_str=flag_str+ "%s%s, %s%s, %s%s, %s%s, %s%s \n" %("x:",self.r_x_cor_list[count3],"y:",self.r_y_cor_list[count3],"w:",self.r_width_list[count3],"h:",self.r_height_list[count3],"c:",self.r_color_list[count3])
            count3+=1
        flag_str=flag_str+"%s \n" %("Stars")
        count4=0
        for i in range(self.s_num):  #prints the params for stars
            flag_str=flag_str+"%s%s, %s%s, %s%s, %s%s \n" %("x:",self.s_x_cor_list[count4],"y:",self.s_y_cor_list[count4],"a:",self.s_arm_list[count4],"c:",self.s_color_list[count4])
            count4+=1
        return flag_str 
            
        

def main():
    turtle.clearscreen()    #clears screen for flag
    pen = turtle.Turtle()   #defines pen as turtle
    pen.speed('fastest')
    senegal_file = open('senegal.txt')  #senegal flag
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.drawf(pen)
    senegal_file.close()

    time.sleep(4)           #delays the time to view senegal flag
    turtle.clearscreen()
    panama_file = open('panama.txt')  #panama flag
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.drawf(pen)
    panama_file.close()

    time.sleep(4)           #delays the time to view panama flag
    turtle.clearscreen()
    magdalena_file=open('myFlag.txt')   #Magdelena Flag
    magdalena_flag=Flag(magdalena_file)
    print(magdalena_flag)
    magdalena_flag.drawf(pen)
    magdalena_file.close()

main()                      #runs main function

