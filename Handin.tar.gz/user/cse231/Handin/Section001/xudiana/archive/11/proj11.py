import urllib.request
import string
class Tour(object):                                         #Initiate class
    def __init__(self,*cities):
        self.tour=cities                                    #tuple of all the cities
        self.city_list=list(cities)                         #list of all the cities
        self.city_num=len(cities)                           #number of cities
    def distance(self,mode='driving'):                      #distance method
        tot_dist=0
        if str(mode)!='driving':                            #error if the mode of tansport isn't one of the three allowed
            if str(mode)!='bicycling':
                if str(mode)!='walking':
                    print("Invalid mode")
        count=0
        for i in range(self.city_num-1):
            url='http://maps.googleapis.com/maps/api/distancematrix/json?origins='      #beginning of url
            o=self.city_list[count]
            o=o.split(",")
            d=self.city_list[count+1]
            d=d.split(",")
            o_city=o[0]                             #origin city
            o_city=o_city.split()
            o_state=o[1]                            #origin state
            url=url+str(o_city[0])                  #add to url string
            count3=1
            if len(o_city)!=1:
                for i in range(len(o_city)-1):
                    url=url+'+'+str(o_city[count3])     #add on necessary info to url string
                    count3+=1
            url=url+'+'+str(o_state[1:])+'&destinations='       #add to url string                        
            d_city=d[0]                             #destination city
            d_city=d_city.split()
            d_state=d[1]                            #destination state
            url=url+str(d_city[0])                  #add to url
            count2=1
            if len(d_city)!=1:
                for i in range(len(d_city)-1):
                    url=url+'+'+str(d_city[count2])     #add to url
                    count2+=1
            url=url+'+'+str(d_state[1:])+'&mode='+str(mode)+'&sensor=false'     #add to url
            web_obj=urllib.request.urlopen(str(url))            #open url as web object
            results_str=str(web_obj.read())                     #read web object
            web_obj.close()                                     #close web object
            results_str.strip()
            results=results_str.split('"')
            if results[15]== 'ZERO_RESULTS' or results[15]=='NOT_FOUND':        #one of the cities was not recgonized
                raise ValueError
            else:
                dist=results[20]            
                dist2=''
                for char in dist:
                    if char.isdigit()==True:
                        dist2+=char
                tot_dist+=int(dist2)            #distance value in meters
        return tot_dist
    def __str__(self):
        tour_list=list(self.tour)
        tour_str=str(tour_list[0])
        if self.city_num==1:
            count=1
        else:
            count=1
            for i in range(self.city_num-1):    #add on city to str for every city in tour
                tour_str+="%s %s" %(';',str(self.city_list[count]))     
                count+=1
        return tour_str
    def __repr__(self):
        tour_str=str(self.city_list[0])
        if self.city_num==1:
            count=1
        else:
            count=1
            for i in range(self.city_num-1):    #add on city to str for every city in tour
                tour_str+="%s %s" %(';',str(self.city_list[count]))     
                count+=1
        print(tour_str)
    def __add__(self,my_tour):
        add_tour_list=list(my_tour.tour)
        city_list=list(self.tour)
        count=0
        for i in range(len(my_tour.tour)):
            city_list.append(add_tour_list[count])      #add new tour cities to end of tour
            count+=1
        new_tour=tuple(city_list)       #format city list as a tuple for tour
        return new_tour
    def __mul__(self,integer):
        if type(integer)is not int: #is not an integer
            raise TypeError
        elif integer<0:
            raise ValueError
        tour_length=0
        for i in range(integer):            #multiplies tour ditance by integer
            tour_length+=self.distance('driving')
        return tour_length
    def __rmul__(self,integer):
        if type(integer)is not int: #is not an integer
            raise TypeError
        elif integer<0:
            raise ValueError
        tour_length=0
        for i in range(integer):
            tour_length+=self.distance('driving')
        return tour_length
    def __gt__(self,my_tour):
        if self.distance('driving')>my_tour.distance('driving'):
            b=True                  #boolean whether a tour is greater than another
        else:
            b=False
        return b
    def __lt__(self,my_tour):
        if self.distance('driving')<my_tour.distance('driving'):
            b=True                  #boolean whether a tour is less than another
        else:
            b=False
        return b
    def __eq__(self,my_tour):
        t1=str(Tour(self))
        t1=t1.split("; ")
        t2=list(my_tour)
        if len(t1)!=len(t2):
            b=False
        else:
            count=0
            for i in range(len(t1)):            #if each city is equivalent and in same order
                if str(t2[count])==str(t1[count]):
                    b=True
                    count+=1
                else:
                    b=False
                    break
        return b
                    


def main():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2: {}\nt3: {}".format(t1,t2,t3))            #test str format
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000), round(t1.distance('bicycling')/1000),round(t1.distance('walking')/1000)))        #test distance method
    print('t1+t2=',t1+t2)                                       #test addition method
    print('t3 driving distance=',t3.distance('driving'))        #display t3 distance
    print('3*t3=',3*t3)                                         #compare previous line for reference to multiplication method
    print('t3*3=',t3*3)                                         #test communitive property
    print('t2>t1?',t2>t1)                                       #test greater than method
    print('t2<t1?',t2<t1)                                       #test less than method
    t4=t1+t2
    print('t3=t1+t2?',t3==t4)                                   #test equal to method
main()
