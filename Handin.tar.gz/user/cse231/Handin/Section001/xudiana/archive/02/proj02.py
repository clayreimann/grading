##############
#Project 2   #
#CSE 231     #
#Jan 21, 2013#
##############


#Lets the user know the riddle
print ("Guess a six digit number SLAYER so that the following equation", \
"holds true where each letter stands for the digit in the position shown:")
print ("          ")
print ("SLAYER + SLAYER + SLAYER = LAYERS")


#Promps user for input
print ("        ")
num_str1 = input ("Enter your guess for SLAYER:")
num_int1 = int(num_str1)

#Sequential Execution
if num_int1 < 100000 or num_int1>=1000000:      #makes sure input is 6-digit num
    print ("Your guess is incorrect:")
    print ("SLAYER must be a six-digit number")
    print ("Thanks for playing.")
elif num_int1*3 != (num_int1%100000)*10+(num_int1//100000):  #when num is incorrect
    print ("Your guess is incorrect:")
    print ("SLAYER + SLAYER + SLAYER =", num_int1*3)
    print ("LAYERS =",(num_int1%100000)*10+(num_int1//100000))
    print ("Thanks for playing.")
else:
    print ("Your guess is correct:")   # when num is correct
    print ("SLAYER + SLAYER + SLAYER =", num_int1*3)
    print ("LAYERS =",(num_int1%100000)*10+(num_int1//100000))
    print ("You are awesome! Thanks for playing!")
    
