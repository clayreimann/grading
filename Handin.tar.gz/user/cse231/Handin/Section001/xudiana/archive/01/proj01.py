####################
#Diana Xu          #
#CSE 231 Project 1 #
#January 13 2013   #
####################


#Conversion from Richter to Energy in joules to tons of TNT

num_str1 = input("Please enter a Richter Scale measure:")
num_float = float(num_str1)
print('Richter measure:',num_float)

num_str2 =(10**((1.5*num_float)+4.8))
num_float2 = float(num_str2)
print('Equivalence in joules:',num_float2)

num_str3 = num_float2 / (4.184e9)
num_float3 = float(num_str3)
print ('Equivalence in tons of TNT:', num_float3)

#Table of Richter Values, Joules, and TNT
print ('                  ')

num1 = 1
num2 = 5
num3 = 9.1
num4 = 9.2
num_float5 = float(num4)
num5 = 9.5
num_float6 = float(num5)


num_float7 = float((10**((1.5*num1)+4.8)))
num_float8 = float((10**((1.5*num2)+4.8)))
num_float9 = float((10**((1.5*num3)+4.8)))
num_float10 = float((10**((1.5*num_float5)+4.8)))
num_float11 = float((10**((1.5*num_float6)+4.8)))

print('Richter', '           ','Joules', '                     ', 'TNT')
print(num1, '           ', num_float7, '       ',num_float7/(4.184e9))
print(num2, '           ', num_float8, '       ',num_float8/(4.184e9))
print(num3, '         ', num_float9, '    ',num_float9/(4.184e9))
print(num_float5, '         ', num_float10, '    ',num_float10/(4.184e9))
print(num_float6, '         ', num_float11, '   ',num_float11/(4.184e9))


