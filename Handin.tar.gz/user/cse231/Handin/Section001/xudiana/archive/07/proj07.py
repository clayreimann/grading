#March 11, 2013
#Project 7
#CSE231



import random
import string

def open_read_file(file_name_str): #used PUNCH's example file input prompt program
    opened_file_bool = False
    while (not opened_file_bool):
        try:
            file_obj = open(file_name_str, "r")
            opened_file_bool = True   # only executed after file opens
        except IOError:
            print("Bad file name, please try again!")      #bad file name
            file_name_str = input("What file would you like to open?")
            continue #reprompt
    else:
        return file_obj         #returns file descriptor

def scramble_word(word_str):                            #scrambles individual words
    char_list=list(word_str)                            #converts word to list of charcters
    count=0
    index=-1
    index_list=[]
    for char in char_list:
        if char in string.punctuation:                  #creates a list of the indices of each punctuation mark, if present in word
            index=count
            index_list.append(index)
            count+=1
        else:                                           #not punctuation
            count+=1
    
    if index==-1:                                       #no characters were punctuation marks
        middle=char_list[1:len(char_list)-1]            #take off first and last letter of word
        random.shuffle(middle)                          #scrambles middle
        scramble_word_str=''.join(middle)               #joins the scrambled middle into a string
        scramble_word_str=char_list[0]+scramble_word_str    #adds first letter back
        scrambled_word=scramble_word_str+char_list[-1]      #adds last letter back
    else:                                               #punctuation mark present
        new_char_list=char_list                         #assigns char_list to variable in order to manipulate while keeping original char_list
        reverse_index_list=index_list[-1:0:-1]+index_list[0:1]  #reverses puncutation indices
        for index in reverse_index_list:                        #goes through each punctuation index
            index=int(index)
            new_char_list=new_char_list[0:index]+new_char_list[index+1:] #removes punctuation mark
        middle=new_char_list[1:len(new_char_list)-1]                     #takes off first and last letter
        random.shuffle(middle)                                           #scrambles the middle
        scrambled_char=new_char_list[0:1]+middle+new_char_list[-1:]
        for index in index_list:                                         #puts punctuation back in
            index=int(index)
            if index==len(scrambled_char):                               #if punct mark is at the end
                scrambled_char=scrambled_char+char_list[index:index+1]
            else:                                                        #punct mark not at end
                scrambled_char= scrambled_char[0:index]+char_list[index:index+1]+scrambled_char[index:]     #concatenates letters before mark, mark, and after mark
        scrambled_word=''.join(scrambled_char)                           #puts word back together
    return scrambled_word

def scramble_line(line_str):                                            #scrambles entire line of text
    word_list=line_str.split(" ")                                       #makes a list of words
    scrambled_line=[]
    for word in word_list:                                              #goes through each word
        if len(word)<4:                                                 #don't scramble if 3 letters or less
            scrambled_line.append(word)
        else:
            scrambled_word=scramble_word(word)                          #calls scramble_word function to scramble word
            scrambled_line.append(scrambled_word)
    scrambled_line=' '.join(scrambled_line)                             #joins line back together
    return scrambled_line
                               
def main():
    file_out_name = input("What file would you like to write to?") #prompt for write file
    file_obj_out = open(file_out_name,"w")                         #opens write file
    file_name_str = input("What file would you like to open?")
    file_obj=open_read_file(file_name_str)
    file_obj = file_obj.read()                                     #reads the file wanted to be read
    line_list = file_obj.split("\n")                               #splits the above file into lines
    scrambled_line_list=[]
    for line in line_list:                                         #goes through each line of text
        scrambled_line=scramble_line(line)                          #calls scramble_line function
        scrambled_line_list.append(scrambled_line)
    scrambled_str=' '.join(scrambled_line_list)                     #joins the scrambled lines
    file_obj_out.write(scrambled_str)                               #writes these lines to the file wanted to be written by user

main()
        
