##################################################################
#  Section 1
#  Computer Project #7
#  villapan
##################################################################

#  Algorithm
#    1. Import functions
#    2. Define the functions
#    3. Write the function that will scramble a word (exlcude punctuation).
#       a. If length of word is less than or equal to 3, do not scramble word.
#       b. Determine if first character in word is a punctuation mark using for loop.
#       c. Determine if there is an apostrophe in the middle of word.
#       d. Determine if there is a punctuation mark at end of sentence.
#    4. Write the function that puts the words together to create a sentence or line.
#       a. Call scramble word function.
#    5. Define which index in the list is the date
#    6. Create main function.
#       a. Input for a file to write. Reprompt if bad file name.
#       b. Input for a file to read. Repromt if bad file name.
#       c. Call read file function.
#       d. Close file.
#    7. Call the main function

import random # Used to scramble lists
import string # Used to determine punctuation marks

# FUNCTIONS

def scramble_word(word):
    "Scrambles the word.  Determine character in string is punctuation. Disregards punctuation marks."
    
    if len(word) < 3:
        new_word = word # If length of string is less than 3, word will not be scrambled.

    else:
        scrambler_list = [] # Letters to add to list for scrambling.
        first_char = True # Determines if first char is punctuation or letter.
        first_char_index = 0 # Count used to determine first character's index.
        last_char_index = 0 # Count used to determine last character's index.
        new_word = '' # Will determine the new scrambled word

        for char in word: # Determine each character in word

            if char in string.punctuation and first_char == True: # First character is a punctuation mark.
                new_word += char
                first_char_index += 1
                last_char_index += 1
            elif first_char: # First character is not a punctuation mark
                first_char = False # Ensures that the first suite does not run again
                new_word += char
                first_char_index += 1
                last_char_index += 1
            elif char not in string.punctuation and word[-1] != word[first_char_index]: # Adds letters to scrambler list.
                scrambler_list.append(char)
                last_char_index += 1
            elif char not in string.punctuation and word[-1] == word[first_char_index]:
                scrambler_list.append(char)
            elif char in string.punctuation: # Deals with characters that are punctuation marks.
                scrambler_list.pop() # Gets rid of punctuation mark in list
                last_char_index -= 1 # The last character is the index before punctuation mark.
                random.shuffle(scrambler_list) # Shuffle the letters before last character.
                middle_letters = ''.join(scrambler_list) # Join middle letters
                new_word += middle_letters + word[last_char_index:] # Create new word
                break
                
        else: # Shuffles words if there is no punctuation in it.
            if len(scrambler_list):
                scrambler_list.pop()
            random.shuffle(scrambler_list)
            middle_letters = ''.join(scrambler_list)
            new_word = new_word + middle_letters + word[-1]

    return new_word

def scramble_line(line_str):
    "Puts scrambled words into a sentence."

    new_word_list = [] # Add the scrambled word into this list.

    for line in line_str: # Reads the lines of opened file
        line.strip() # Remove white space at the ends of line.
        word_list = line.split(' ') # Create new list out of the words in document.

        for word in word_list: # Iterate through each word of document in order to scramble
            word.strip() # Ensures there are no white spaces at the ends of word.
            if word == '':
                continue
            new_word = scramble_word(word) # Call scrambe word function
            new_word_list.append(new_word) # Add the new word to the list
        
    new_scrambled_line = ' '.join(new_word_list) # Join the list together with a space
    
    return new_scrambled_line

def open_read_file(file_name_str):
    "Opens a file to read. Reprompt user if not a good file name."

    opened_file_bool = False
    while (not opened_file_bool):
        file_str = input("What file would you like to open to read? ")
        try:
            file_object = open(file_str, 'r')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again.")
    return file_object

def main():
    "Asks the user what file they would like to write."

    opened_file_bool = False
    while (not opened_file_bool):
        file_str = input("What file would you like to open to write? ")
        try:
            file_write_obj = open(file_str, 'w')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again ")

    file = open_read_file(file_str)
    print(scramble_line(file))
    file.close()

main() # Call main function
    

    


