#######################################################
#  Section 1
#  Computer Project #12
#  Python 2.7
#  villapan
##################################################################

#  Algorithm
#    1. Define first function and iterate through temperature text
#    2. Create list out of each line, create tuple using month and day
#    3. Add month day tuple to dictionary as key
#    3. Add the temperature as value to that key
#    4. "Sort" the dictionary
#    5. Iterate through dictionary to calcuate average high and low of each month
#    6. Plot graph
#    7. Define second function, and iterate through temperature and solar text
#        *****NOTE: The method of finding both are similar.  Only commented on first part of function.
#    8. Split each line into a list
#    9. Add the lists that deal with the month June to a new list
#   10. For each respective list, organize them based on hour of day
#   11. Iterate through each list to find average of temperature and solar radiation in month of June
#   12. Plot graph

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from pylab import *

def plot_one(): # Highest/lowest temperature by month
    opened_f = open('temperature.txt', 'r') # Open file
    opened_f.readline() # Skip first two lines
    opened_f.readline()

    temp_dictionary = {} # Dictionary by (month, day) = temp val
    for line in opened_f:
        line_list = line.split() # Each line turned into list
        for element in line_list:
            month_day_tup = (int(line_list[0]), int(line_list[1])) # Create tuple (month, day) from lists
        if month_day_tup in temp_dictionary: # If key in list
            temp_list.append(float(line_list[4])) # Add value to that day
            temp_list.sort() # Sorts to get the highest and lowest values
            temp_dictionary[month_day_tup] = temp_list  
        else: # Tuple not in dictonary
            temp_list = [] # New list
            temp_list.append(float(line_list[4])) # Add value to list
            temp_dictionary[month_day_tup] = temp_list

    temp_sort = [(k,v) for k, v in temp_dictionary.items()] # Sort dictionary
    temp_sort.sort()

    temp = [] # Mutable list
    highs = [] # Average highs
    lows = [] # Average lows
    key_month = temp_sort[0][0][0] # First month
    cnt = 0 # Counts days

    for item in temp_sort:
        if item[0][0] > key_month: # If current month is greater than previous month
            total_high = 0 # Initialize
            total_low = 0
            for digits in temp: # Iterate through each high low of each day in month
                total_high += digits[1] # Add all highs together
                total_low += digits[0] # Add all lows together
            average_high = total_high/cnt # Average high
            average_low = total_low/cnt # Average low
            highs.append(round(average_high, 2)) # Append average high of month to list
            lows.append(round(average_low, 2)) # Append average low of month to list
            cnt=0
            temp = []
        elif item[0][0] == 12: # Month is Deciember
            hold = []
            hold.append(item[1][0])
            hold.append(item[1][-1])
            temp.append(hold)
            total_high = 0
            total_low = 0
        else: # Still on same month
            hold = [] # New list to append high and low temp of that day
            hold.append(item[1][0])
            hold.append(item[1][-1])
            temp.append(hold) # Append list to the temp list
            cnt += 1
        key_month = item[0][0]
        
    # Deals with December
    total_high = 0
    total_low = 0
    for digits in temp:
        total_high += digits[1]
        total_low += digits[0]
    average_high = total_high/31
    average_low = total_low/31
    highs.append(round(average_high, 2))
    lows.append(round(average_low, 2))

    # Adjusted high list for plotting
    new_high_list = [highs[0]-lows[0], highs[1]-lows[1], highs[2]-lows[2], highs[3]-lows[3], highs[4]-lows[4], highs[5]-lows[5], highs[6]-lows[6], highs[7]-lows[7], highs[8]-lows[8], highs[9]-lows[9], highs[10]-lows[10], highs[11]-lows[11]]

    month_list = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    fig1 = plt.figure()
    width = 0.35       # the width of the bars
    x_values = np.arange(len(month_list)) # How many values to plot
    plt.ylabel('Temperature') # Y label of Temperature
    plt.bar(x_values, new_high_list, bottom=lows) # Plot values
    plt.title('Charleston, MO 2012')
    plt.xticks(x_values+width/2.0, month_list, rotation=45) # X values
    fig1.savefig('month_temp.png') # Save graph
    plt.close() # Close graph

def plot_two(): # Second task, temp and solar radiation in June
    opened_fs = open('solar_radiation.txt', 'r') # Radiation file

    # Skip first 4 lines
    opened_fs.readline()
    opened_fs.readline()
    opened_fs.readline()
    opened_fs.readline()


    june_list = [] # Get June values
    for line in opened_fs:
        line_list = line.split() 
        if line_list[0] == '6': # June Values
            june_list.append(line_list) # Add whole list to June List


    for element in june_list: # Only keep hour of day and radiation of each list from June
        element.pop(0)
        element.pop(0)
        element.pop(0)
        element[0] = int(element[0]) # Turns hour of day to intergers to be sorted properly
    june_list.sort() # Sort by hour of day


    solar_average = [] # Solar averages for each hour of day in June
    temp1 = [] # List to be altered
    hour_key = june_list[0][0] # First hour of day
    cnt = 0 # Count for each hour of day

    for item in june_list:
        if item[0] > hour_key: # Current hour of day greater than previous
            total = 0 
            for digits in temp1: # List of temperature for each hour of each day in June
                total += int(digits) # Add them together
            average = total/cnt # Get average
            solar_average.append(average)
            cnt=0
            temp1=[]
        elif item[0] == 2400: # Deals with last hour of day
            temp1.append(item[1])
            cnt += 1
        else: # Still on same hour of day
            temp1.append(item[1]) # Append radiation to temp list
            cnt += 1
        hour_key = item[0] # Check to see if new hour of day
        
    # Deals with last hour of day
    total = 0
    for digits in temp1:
        total += int(digits)
    average = total/cnt
    solar_average.append(average)
            
    opened_s = open('temperature.txt', 'r') # Temperature file

    opened_s.readline()
    opened_s.readline()

    june_temps = [] # Get June temps
    for line in opened_s:
        line_list = line.split()
        if line_list[0] == '6':
            june_temps.append(line_list)

    for element in june_temps:
        element.pop(0)
        element.pop(0)
        element.pop(0)
        element[0] = int(element[0])
    june_temps.sort()

    temp_average = []
    temp1 = []
    hour_key = june_temps[0][0]
    cnt = 0

    for item in june_temps:
        if item[0] > hour_key: 
            total = 0
            for digits in temp1:
                total += float(digits)
            if total:
                average = round(total/float(cnt), 2)
                temp_average.append(average)
            else:
                average = 0
                temp_average.append(average)
            cnt = 0
            temp1=[]
        elif item[0] == 2400:
            temp1.append(item[1])
            cnt += 1
        else:
            temp1.append(item[1])
            cnt += 1
        hour_key = item[0]
        
    total = 0
    for digits in temp1:
        total += float(digits)
    if total:
        average = round(total/float(cnt), 2)
        temp_average.append(average)
    else:
        average = 0
        temp_average.append(average)



    fig = plt.figure() # Plot figure with both data sets
    plt.title('Charleston, MO 2012')
    ax1 = fig.add_subplot(111)
    t = np.arange(len(temp_average))
    s1 = np.exp(temp_average)
    ax1.plot(t, temp_average, 'b-')
    ax1.set_xlabel('Hour of Day')
    # Make the y-axis label and tick labels match the line color.
    ax1.set_ylabel('Average Temperature', color='b')
    for tl in ax1.get_yticklabels():
        tl.set_color('b')


    ax2 = ax1.twinx()
    s2 = np.exp(solar_average)
    ax2.plot(t, solar_average, 'r.')
    ax2.set_ylabel('Average Solar Radiation', color='r')
    for tl in ax2.get_yticklabels():
        tl.set_color('r')
    fig.savefig('average.png')
    plt.close()

plot_one()
plot_two()





