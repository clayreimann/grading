##################################################################
#  Section 1
#  Computer Project #5
#  villapan
##################################################################

#  Algorithm
#    1. Import math and turtle in order to draw hexagons
#    2. Define the get color function
#         a. The user can choose from three colors (r, g, b)
#    3. Define the get number of hexagons function
#         a. User must input a number between 4 and 20, else reprompted
#    4. Define get number of sides (s) function
#         a. s = 500/number of hexagons
#    5. Define drawing the hexagon
#    6. Define drawing the rows/tessellation
#         a. The amount of rows is determined by how many hexagons there are
#         b. If statesments for alternating colors every time hexagon is drawn
#         c. If statements for shifting every other row
#    7. Call functions


# import modules
import math
import turtle

# FUNCTIONS
def get_color():
    "Determines which colors to draw hexagons"

    #color options
    red = 'red'
    green = 'green'
    blue = 'blue'

    color1 = str(input("Please enter a color: ")) # first color
    
    while (not (color1 == 'red' or color1 == 'green' or color1 == 'blue')):

        color1 = str(input("Invalid color.  Please try again: ")) # user does not enter the color options

    color2 = str(input("Please enter a second color: ")) # second color

    while (not (color2 == 'red' or color2 == 'green' or color2 == 'blue')):

        color2 = str(input("Invalid color.  Please try again: "))

    else:
        return color1, color2 # return color values


def get_num_hex():
    "Asks user to input a number of hexagons to draw"

    num_hex = int(input("Enter amount of hexagons: ")) # number of hexagon value
    
    while num_hex < 4 or num_hex > 20:

        num_hex = int(input("Should be between 4 - 20. Please try again: ")) # value is not between 4 and 20
    
    else:
        return num_hex # return hexagon value

def get_s(num_hex):
    "Determines side length"

    s = 500/num_hex # side length is equal to 500 divided by number of hexagons
    return s
    

def draw_hexagon (x, y, s, pen, color):
    "Draws the hexagon"
    
    pen.fillcolor(color)
    pen.setheading(0)
    pen.up()
    pen.goto(x, y)
    pen.down()
    pen.begin_fill()
    count = 6
    pen.left(90) # orients pen in correct direction
    while count > 0:
        pen.forward(s)
        pen.right(60)
        count -= 1
    else:
        pen.right(60) # reorients pen at the end
    pen.end_fill()
    pen.speed(10)

def draw_rows(x, y, s, num_hex, pen, color1, color2):
    "Draws the entire tessellation"
    rows = num_hex # number of rows equals the number of hexagons
    
    while rows > 0: # draws the rows
        hexagons = num_hex # number of hexagons equals the user's input
        
        while hexagons > 0: # draws the individual hexagons to alternate color
            if hexagons % 2 == 0: # 'even' hexagons are drawns as color1
                draw_hexagon (x , y, s, pen, color1)
            elif hexagons % 2 == 1: # 'odd' hexagons are drawn as color2
                draw_hexagon (x , y, s, pen, color2)
            
            x += math.sqrt(3)*s # how far the pen needs to shift over to right to draw next hexagon
            hexagons -= 1 # count to draw hexagons

        # shifts the rows to draw tessellation
        if rows % 2 == 0: 
            x -= ((math.sqrt(3)*s)/2)*(2*num_hex+1)
            
        elif rows % 2 == 1:
            x -= ((math.sqrt(3)*s)/2)*(2*num_hex-1)
            
        y -= (3/2)*s # how far the next row needs to shift down
        rows -= 1 # count to draw rows
        
# menu of colors
print("Choices for colors to use are: ")
print(" red")
print(" blue")
print(" green")
print('')

# call functions
color1, color2 = get_color() 
num_hex = get_num_hex()
s = get_s(num_hex)
draw_rows(-350, 200, s, num_hex, turtle, color1, color2)

    

