##################################################################
#  Section 1
#  Computer Project #4
#  villapan
##################################################################

#  Algorithm
#    1. Ask user to input two biological strings
#    2. Print menu through a while loop
#    3. Create separate if statements for each menu selection
#    4. If user wants to add or delete indel:
#           a. Ask user which string he wants to alter
#           b. Ask user where he would like to insert or delete indel
#           c. Error check
#           d. Print new string, reprompt menu
#    5. If user wants to score the string:
#           a. Create match, mismatch, and index_position counters
#           b. Determine which string is shorter
#           c. Run through a while loop to count how many index positions in shorter string
#           d. Print matches/mismatches
#    6. If user enters q, breaks from the whole loop


# Biological string inputs
dna_str1 = str(input("Give me a biological string: "))
dna_str2 = str(input("Give me a second biological string: "))

# Prints biological string inputs
print("String 1: ", dna_str1)
print("String 2: ", dna_str2)


#initiate whole loop
while True:

    # prints the menu for the user
    print("")
    print("What do you want to do?")
    print("     a (add indel)")
    print("     d (delete indel)")
    print("     s (score)")
    print("     q (quit)")
    user_input = input("User input: ") # user's iinput
    print("")

    if user_input == 'q': # user wants to quit program
        break

    #user wants to add indel
    if user_input == 'a':
        str_change_input = input("Which string would you like to change (1 or 2): ") # Asks user which string he'd like to change
        if str_change_input == '1': # Alters first string
            index = int(input("Before what index: ")) # Determines where user wants to add indel
            index_count = 0 
            while index_count <= len(dna_str1): # Begins error checking
                index_count += 1
            if index > index_count: # Makes sure index is not bigger than string's index
                print("Error: Please try again") # Reprompts the menu
                continue
            dna_str1 = dna_str1[:index] + '-' + dna_str1[index:] # Adds indel
            print("New string: ", dna_str1) # Prints new string"
            print("")
        elif str_change_input == '2': # ALters second string
            index = int(input("Before what index: "))
            index_count = 0
            while index_count <= len(dna_str2):
                index_count += 1
            if index > index_count:
                print("Error: Please try again")
                continue
            dna_str2 = dna_str2[:index] + '-' + dna_str2[index:]
            print("New string: ", dna_str2)
            print("")
        else:
            print("Sorry that is not an option.") # User does not enter 1 or 2

    # user wants to delete indel
    if user_input == 'd':
        str_change_input = input("Which string would you like to change (1 or 2): ")
        if str_change_input == '1':
            index = int(input("Delete what index: ")) # Asks user which indel to delete
            if dna_str1[index] != '-': # Error checking: the deletion must be an indel
                print("Error: Please try again")
                continue
            dna_str1 = dna_str1[:index] + dna_str1[index + 1:] # Deletes the indel
            print(dna_str1)
        elif str_change_input == '2':
            index = int(input("Delete what index: "))
            if dna_str2[index] != '-':
                print("Error: Please try again")
                continue
            dna_str2 = dna_str2[:index] + dna_str2[index + 1:]
            print(dna_str2)
        else:
            print("Sorry that is not an option.")


    # user wants to compare/score strings
    if user_input == 's':

            index_position = 0 # initial index count
            match_count = 0 # initial match count
            mismatch_count = 0 # initial mismatch count
            dna_str2_new = '' # strings string 2 together
            dna_str1_new = '' # strings string 1 together

            if len(dna_str2) < len(dna_str1): # length of string 2 is shorter than 1
                
                while index_position <  len(dna_str2): # ensures that the index is not greater than the string's length
                
                    if dna_str2[index_position] == dna_str1[index_position]: # determines match
                        match_count += 1 # determines how many matches there are
                        dna_str2_new += dna_str2[index_position].lower() # lowercase all matches 
                        dna_str1_new += dna_str1[index_position].lower() 
                
                    if dna_str2[index_position] != dna_str1[index_position]: # determines mismatches
                        mismatch_count += 1 # determines how many mismatches there are
                        dna_str2_new += dna_str2[index_position].upper() # uppercase all mismatches
                        dna_str1_new += dna_str1[index_position].upper() 
                    index_position += 1


            if len(dna_str1) < len(dna_str2): # length of string 1 is shorter than 2
                
                while index_position <  len(dna_str1):
                
                    if dna_str2[index_position] == dna_str1[index_position]:
                        match_count += 1
                        dna_str2_new += dna_str2[index_position].lower()
                        dna_str1_new += dna_str1[index_position].lower() 
                
                    if dna_str2[index_position] != dna_str1[index_position]:
                        mismatch_count += 1
                        dna_str2_new += dna_str2[index_position].upper()
                        dna_str1_new += dna_str1[index_position].upper() 
                    index_position += 1
                    
            print("Matches: ", match_count, " Mismatches: ", mismatch_count) # prints match and mismatch count

            # visualizes the matches and mismatches
            print("Str1: ", dna_str1_new + dna_str1[index_position:]) # prints first dna string
            print("Str2: ", dna_str2_new + dna_str2[index_position:]) # prints second dna string
            continue


print("Thanks for playing") # user has quit the program
                    
                    
    
            
    
    
