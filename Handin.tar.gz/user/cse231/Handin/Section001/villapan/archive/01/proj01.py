num_str1 = input('Please give me a Richter scale measure:')
str1_float = float(num_str1)
energy = 10**((1.5*str1_float)+4.8)
tons = energy/(4.184*10**9)

num1_float = float(1)
energy1 = 10**((1.5*num1_float)+4.8)
tons1 = energy/(4.184*10**9)

num2_float = float(5)
energy2 = 10**((1.5*num2_float)+4.8)
tons2 = energy/(4.184*10**9)

num3_float = float(9.1)
energy3 = 10**((1.5*num3_float)+4.8)
tons3 = energy/(4.184*10**9)

num4_float = float(9.2)
energy4 = 10**((1.5*num4_float)+4.8)
tons4 = energy/(4.184*10**9)

num5_float = float(9.5)
energy5 = 10**((1.5*num5_float)+4.8)
tons5 = energy/(4.184*10**9)

print('Richter measure: ', str1_float)
print('Equivelance in joules: ', energy)
print('Equivelance in Tons of TNT: ', tons,end='\n\n')

print('Richter      Joules       Tons of TNT')
print('-'*40)
print(num1_float,       energy1,        tons1)
print(num2_float,       energy2,        tons2)
print(num3_float,       energy3,        tons3)
print(num4_float,       energy4,        tons4)
print(num5_float,       energy5,        tons5)  

