##################################################################
#  Section 1
#  Computer Project #6
#  villapan
##################################################################

#  Algorithm
#    1. Define the functions
#    2. Write function that prompts the user to open a file
#         a. Error check to see if the file is an approprite name
#    3. Read the file to obtain the data; skip the first line of data
#    4. Turn the lines of each file into a list
#    5. Define which index in the list is the date
#    6. Create if statements to determine which column to read
#    7. Return the date and column data in this function
#    8. New function to average the data
#    9. Rearrange the date in this function to read 'Month-Year'; get rid of day
#   10. Average the data for each month in a particular Month-Year
#   11. Return a new list of all the Month-Year averages
#   12. Write a main function to call all the previously defined functions
#   13. Within this function determine the 6 lowest and highest values that were averaged


#FUNCTIONS

def get_input_descriptor():
    "Prompts the user for a file name; error checks to make sure user inputs correct user name"
    
    opened_file_bool = False
    while (not opened_file_bool):
        file_str = input("What file would you like to open to read? ")
        try:
            file_object = open(file_str, 'r')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again.")
    return file_object
            
    
def get_data_list(file_object, column_number):
    "Reads the file table.csv and which column to read"

    first_line = file_object.readline() # Skips the first line of data
    tuple_list = [] # New list to create a list of tuples
    
    
    for line_str in file_object: # Reads every line in the file
        line_str.strip() # Remove white spaces at beginning and end of lines
        file_list = line_str.split(',') # Convert lines into lists
        
        date = file_list[0] # Index of the date in the lines
        
        # Determines which column to average
        if column_number == '1':
            column_data = file_list[1]
        elif column_number == '2':
            column_data = file_list[2]
        elif column_number == '3':
            column_data = file_list[3]
        elif column_number == '4':
            column_data = file_list[4]
        elif column_number == '5':
            column_data = file_list[5]
        else:
            column_data = file_list[6]

        file_tuple = date, float(column_data) # Create tuple for the date and value

        tuple_list.append(file_tuple) # Add this tuple to create list
        
    tuple_list.sort() # Sorts the list by date

    return tuple_list # Return the list so the column can be averaged
    

def average_data(list_of_tuples):
    "Averages the values in the specificed column by month and year"
    
    tuple_list = []
    
    for data in list_of_tuples: # Rearrange date to read Month-Year; get rid of day
        tuple_date = data[0] # Get the date from tuples
        date_list = tuple_date.split('-') # Convert the date into a list
        date_list.pop() # Get rid of last element 
        date_list.sort()# Rearrange list so the month is first
        month_date = '-'.join(date_list) # Convert the list back to string
        num_float = data[1] # Get the value of each tuple
        new_tuple = month_date, num_float # New tuple to rearrange elements

        tuple_list.append(new_tuple) # Add these tuples to a list

    new_list = []
    cnt = 0
    totals = 0
    get_tuple = tuple_list[0]
    get_date = get_tuple[0]
    
    for my_tuple in tuple_list: # Averages the values for the month-year
        
        if my_tuple[0] == get_date: # If the date equals the previous, add up the totals
            totals += float(my_tuple[1])
            cnt += 1
            date = my_tuple[0]
            
        else: # If the date does not equal previous date 
            average = round(totals/cnt, 2) # average the totals
            new_tuple = (average, date) # create new tuple
            new_list.append(new_tuple) # add this tuple to list
            cnt = 1 # reset count to one
            totals = float(my_tuple[1]) # Take the value that the iteration is currently in

        get_date = my_tuple[0] # Value to store previous date

    new_list.sort() # Sort the list by value
    
    return new_list

        
def main():
    "The main function that calls all the functions"

    file_object = get_input_descriptor() # Calls first function
    
    column_number = input("Which column would you like to average? ") # Determines which column to average
    tuple_list = get_data_list(file_object, column_number) # Call second function
    
    average_list = average_data(tuple_list) # Call thrid function
    
    # Algorithms used to determine lowest 6 values for averaged column
    low_1 = average_list[0]
    date_1 = low_1[1]
    value_1 = low_1[0]

    low_2 = average_list[1]
    date_2 = low_2[1]
    value_2 = low_2[0]

    low_3 = average_list[2]
    date_3 = low_3[1]
    value_3 = low_3[0]

    low_4 = average_list[3]
    date_4 = low_4[1]
    value_4 = low_4[0]

    low_5 = average_list[4]
    date_5 = low_5[1]
    value_5 = low_5[0]

    low_6 = average_list[5]
    date_6 = low_6[1]
    value_6 = low_6[0]

    
    # Algorithms used to determine highest 6 values for averaged column
    high_1 = average_list[(len(average_list))-1]
    date_7 = high_1[1]
    value_7 = high_1[0]

    high_2 = average_list[(len(average_list))-2]
    date_8 = high_2[1]
    value_8 = high_2[0]

    high_3 = average_list[(len(average_list))-3]
    date_9 = high_3[1]
    value_9 = high_3[0]

    high_4 = average_list[(len(average_list))-4]
    date_10 = high_4[1]
    value_10 = high_4[0]

    high_5 = average_list[(len(average_list))-5]
    date_11 = high_5[1]
    value_11 = high_5[0]

    high_6 = average_list[(len(average_list))-6]
    date_12 = high_6[1]
    value_12 = high_6[0]
    
    # Print values
    print("Lowest 6 for column ", column_number)
    print("Date: ", date_1, "Value: ", value_1)
    print("Date: ", date_2, "Value: ", value_2)
    print("Date: ", date_3, "Value: ", value_3)
    print("Date: ", date_4, "Value: ", value_4)
    print("Date: ", date_5, "Value: ", value_5)
    print("Date: ", date_6, "Value: ", value_6)
    print('')
    print("Highest 6 for column ", column_number)
    print("Date: ", date_7, "Value: ", value_7)
    print("Date: ", date_8, "Value: ", value_8)
    print("Date: ", date_9, "Value: ", value_9)
    print("Date: ", date_10, "Value: ", value_10)
    print("Date: ", date_11, "Value: ", value_11)
    print("Date: ", date_12, "Value: ", value_12)
    
    file_object.close() # Close the file

main() # Call the main function
    
    
