  ##################################################################
  #  Section 1
  #  Computer Project #2
  #  villapan
  ##################################################################

  #  Algorithm
  #    1. Prompt for a 6 digit interger in accoradance to SLAYER
  #    2. Input a 6 digit number
  #    3. Input formula for SLAYER + SLAYER + SLAYER = LAYERS
  #    4. Extract digits form the interger
  #    5. Turn the digits into decimal notation to convert SLAYER into LAYERS
  #    6. Program runs through if and else statements
  #         a. Statements will determine whether or not the function
  #            SLAYER + SLAYER + SLAYER = LAYERS
  #         b. If true, output tells user he is correct
  #         c. Else, the user is incorrect

print("Guess a six-digit number SLAYER so that \
following equation is true,",end="\n") # Gives user prompt

print("where each letter stands for the digit \
in the position shown:",end="\n\n") # Continuation of prompt

print("SLAYER + SLAYER + SLAYER = LAYERS") # Gives user puzzle

slayer_int = int(input("Enter your guess for SLAYER: ")) # User enters 6 digit int

slayer_result = slayer_int * 3 # Function for SLAYER + SLAYER + SLAYER = LAYERS

S_int = (slayer_int//100000) % 10 # the digit in the hundred-thousands-place
L_int = (slayer_int//10000) % 10 # the digit in the ten-thousands-place
A_int = (slayer_int//1000) % 10 # the digit in the thousands-place
Y_int = (slayer_int//100) % 10 # the digit in the hundreds-place
E_int = (slayer_int//10) % 10 # the digit in the tens-place
R_int = slayer_int % 10 # the digit in the ones-place

layers_result = 100000*L_int + 10000*A_int + 1000*Y_int \
                + 100*E_int + 10*R_int + S_int # Decimal notation of LAYERS

if slayer_int <= 99999 or slayer_int > 999999: # Ensures that the interger is NOT 6 digits
    print("Your guess is incorrect: ") # Returns that user is incorrect
    print("SLAYER must be a 6-digit number.")
    print("Thanks for playing.")
elif slayer_result == layers_result: # Statement if user's guess is correct
    print("Your guess is correct:") 
    print("SLAYER + SLAYER + SLAYER = ", slayer_result) # Prints original puzzle with results
    print("LAYERS = ", layers_result) # Shows user that SLAYER = LAYERS
    print("Thanks for playing.")
else: # Statement if user's guess is incorrect
    print("Your guess is incorrect:")
    print("SLAYER + SLAYER + SLAYER = ", slayer_result)
    print("LAYERS = ", layers_result) # Shows user that SLAYER != LAYERS
    print("Thanks for playing.")
                 
