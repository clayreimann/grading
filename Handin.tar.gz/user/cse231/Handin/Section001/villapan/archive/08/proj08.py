##################################################################
#  Section 1
#  Computer Project #8
#  villapan
##################################################################

#  Algorithm
#    1. Import the string function
#    2. Write function that creates the dictionary of possible words
#         a. Takes in c_dict and a file
#    3. Read the file to obtain words
#    4. Lowercase the word and strip it from all punctuation
#    5. Add words to a list and set-up an initial count to find index of letter in word
#    6. Iterate through each word and letter and create a new tuple out of index and its letter
#    7. If the tuple is not in the dictionary, initalize a set and add that tuple to the dictionary
#           a. Otherwise add the word to an existing dictionary
#    8. Define new function to return a list of possible words for a prefix
#           a. Take in argument prefix, prefix is then eunmerated into a list.
#    9. Initilize a set
#   10. Iterate through each tuple in the prefix
#           a. Iterate through the items in the dictionarys
#           b. If the prefix tuple is equal to a key in the dictionary add the values of the key to a set
#           c. Use sets to find commonalities in the set to distinguish possible words
#   11. Return a set
#   12. Write the main function which opens a document, calls fill_completions, and prompts user for a prefix
#           a. Within while loop, print the possible words

import string # Import string module

# FUNCTIONS    


def fill_completions(c_dict, file):
    "Create a dictionary of words based on the index of the letter in word"
    
    for line in file: # Iterate through each line in the file
        line = line.strip() # Remove white spaces at the ends of the line
        word_list = line.split() # Split line to add words to a list
        for word in word_list: # Iterate through each word in word list
            word = word.lower() # Lowercase the word
            word = word.strip(string.punctuation) # Remove punctuation at beginning and end
            if word: # If the word is not an empty string
                word_list = list(word) # Put each individual letter of the word in the list
                cnt = 0 # Create initial count
                for letter in word_list: # Iterate through each letter of word
                    key_tuple = cnt, letter # Create a tuple in the form (interger n, letter)
                    cnt += 1 # Add one to count for next index
                    if key_tuple in c_dict: 
                        c_dict[key_tuple].add(word) # Add the word to an existiting key in the form of a set
                    else: # If the key is not in dictionary
                        initial_set = set() # Initialize a set
                        initial_set.add(word) # Add the word to a new set
                        c_dict[key_tuple] = initial_set # Add the key and word to the dictionary



def find_completions(prefix, c_dict):
    "Take in a prefix to determine possible words for that completion"

    prefix_key = list(enumerate(prefix)) # Create a tuple out of prefix to determine a letter's position in a word
    my_set = set() # Initialize a set
    

    for p_key in prefix_key: # Iterate through tuples in the prefix
        for key, value in c_dict.items(): # Iterate through items in the dictionary
            if key == p_key: # The prefix tuple is equal to a key in the dictionary
                if my_set: # If the set is not empty
                    my_set = my_set & value # Find commonalities between previous set and value of the current key in dictionary
                else: # If the set is not in the dictonary
                    my_set = value # Add the value of current key to the set

    return my_set # Return the set
            
    
def main():
    "Main function opens document, and prompts user for prefix"

    file = open("ap_docs.txt", 'r') # Open file to be read
    dictionary = {} # Create empty dictionary
    fill_completions(dictionary, file) # Call function
    prefix = '' # Set an empty prefix
    while True:
        prefix = input("Give me a prefix or type '#' to quit: ") # Prompt user for a prefix
        if prefix == '#': # Quits the program if user enter '#'
            break
        elif prefix: # Prints possible words of prefix
            print(find_completions(prefix, dictionary))
    print("Thanks for playing.")

    file.close()

main() # Call main function
    
    
    
