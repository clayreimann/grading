##################################################################
#  Section 1
#  Computer Project #3
#  villapan
##################################################################

#  Algorithm
#    1. Display user stock machine and ask to input price amount through a loop
#    2. Determine if user input a valid variable:
#         a. If q: quits program and prints amount
#         b. If not a non-negative multiple of five, prompt user again
#    3. Print display menu prompting user to put change in machine through another loop
#    4. Create if statements to determine the amount of deposit
#         a. If user inputs invalid variable, repromot user
#    5. Reprompt user displaying the new price that he owes until:
#         a. amount of change deposited equals or exceeds 0, tell user to take change
#         b. the user cancels deposit, tell the user to take change deposited
#    6. Calculate the amount of change to give back through another loops
#    7. Use nested if statements to determine how much change to give back
#         a. Convert float prices to cents by multiplying by 100
#         b. Determine the greatest amount of quarters needed
#         c. If the price is not divisible by 25, determine amount of dimes
#         d. If the price is not divisible by 10, determine amount of nickels
#    8. Print new stock 


print("Welcome to the vending machine change maker program")
print("Change maker initializ

# displays the INITIAL amount of stock, used as counting variable
nickel_count = 25
dime_count = 25
quarter_count = 25
ones_count = 0
fives_count = 0

print("Welcome to the vending machine change maker program")
print("Change maker initialized.")
print("Stock contains:")
print(" ", nickel_count, " nickels")
print(" ", dime_count, " dimes")
print(" ", quarter_count, " quarters")
print(" ", ones_count, "  ones")
print(" ", fives_count, "  fives")
print(" ")

# initiate loop
while True:
# prompt user to input a number, xx.xx, or q    
    purchase_price_str = input("Enter purchase price (xx.xx) or 'q' to quit: ")
    if purchase_price_str == "q": # if user inputs q, kicks user out of loop
        break
# convert xx.xx to a float
# multiply by a 100 and round to get rid of float errors
    elif  round(float(purchase_price_str)*100) < 0 or round(float(purchase_price_str)*100) % 5 != 0:
        print("Illegal price: Must be a non-negative multiple of 5 cents.")
        continue # if user enters invalid number, reprompt
    else: # if user enters valid number, following menu is displayed
        print(" ")
        print("Menu for deposits:")
        print(" 'n' - deposit a nickel")
        print(" 'd' - deposit a dime")
        print(" 'q' - deposit a quarter")
        print(" 'o' - deposit a one dollar bill")
        print(" 'f' - deposit a five dollar bill")
        print(" 'c' - cancel the purchase")
        print(" ")

        float_price = float(purchase_price_str) # convert xx.xx to a float
        dollars = int(float_price) # determines amount of dollars in purchase
        cents = float_price - dollars # determines amount of cents in purchase
        sum_of_deposit = 0 # variable used to add how much user deposits
        deposit_amount = 0 # counting variable: value of each coin or bill

 
# nested loop, asks user for deposit         
        while float_price > 0: # kick user out of loop if payment falls below 0
            # prints amount of dollars and cents due
            # float price must be multiplied by 100 to determine cents
            print("Payment due: ", dollars, "dollars and ", round((cents)*100), "cents")
            deposit_str = input("Indicate your deposit: ") # how much user deposits
            if deposit_str == 'n': # nickel deposit
                float_price = float_price - .05 # initial price and subtracts "nickel"
                dollars = int(float_price) # determine NEW dollar amount
                cents = float_price - dollars # determine NEW cents amount
                deposit_amount =.05 # value of a nickel
                sum_of_deposit += deposit_amount # sum of the amount of change deposited
                nickel_count += 1 # "5 cents" is added every time user inputs n
            elif deposit_str == 'd':
                float_price = float_price - .1
                dollars = int(float_price)
                cents = float_price - dollars
                deposit_amount = .1 #value of dime
                sum_of_deposit += deposit_amount
                dime_count += 1 # "10 cents" is added every time user inputs d
            elif deposit_str == 'q':
                float_price = float_price - .25
                dollars = int(float_price)
                cents = float_price - dollars
                deposit_amount = .25 # value of quarter
                sum_of_deposit += deposit_amount
                quarter_count += 1 # "25 cents" is added every time user inputs q
            elif deposit_str == 'o':
                float_price = float_price - 1.00
                dollars = int(float_price)
                cents = float_price - dollars
                deposit_amount = 1.00 # value of a dollar
                sum_of_deposit += deposit_amount
                ones_count += 1 # "1 dollar" is added every time user inputs o
            elif deposit_str == 'f':
                float_price = float_price - 5.00
                dollars = int(float_price)
                cents = float_price - dollars
                deposit_amount = 5.00 # value of a five dollar bill
                sum_of_deposit += deposit_amount # "5 dollars" is added every time user inputs f
                fives_count += 1
            elif deposit_str == 'c': # cancel payment, kick user out of loop
                break
            else:
                print("Illegal selection: ", deposit_str) # user does not input menu value

# once user enters exact change or exceeds payment due
# calculate amount of change to give back

        print(" ")
        # counter variables to determine how many coins to give back
        quarter_return = 0
        nickel_return = 0
        dime_return = 0
        
        # user enters exact change
        if float_price == 0:
            print("Please take the change below.")
            print("  No change due.")

        # user needs change
        if float_price < 0:
            change_amount = -(round(100*(float_price)))
            print("Please take the change below.")
      
            # determines greatest amount of quarters needed          
            quarter_return = int(change_amount // 25)
            if 25 <= change_amount and quarter_count >= quarter_return:
                quarter_count -= quarter_return
                change_amount -= quarter_return*25
                print(quarter_return, "quarters")
            # determines quarters needed if there is not enough in stock
            elif 25 < change_amount and quarter_return > quarter_count:
                quarter_return = quarter_count
                quarter_count = 0
                change_amount -= quarter_count*25
                print(quarter_return, "quarters")
      
            # determines greatest amount of dimes needed       
            dime_return = int(change_amount // 10)
            if 10 <= change_amount and dime_count >= dime_return:
                dime_count -= dime_return
                change_amount -= dime_return*10
                print(dime_return, "dimes")
            # determines dimes needed if there is not enough in stock
            elif 10 < change_amount and dime_return > dime_count:
                dime_return = dime_count
                dime_count = 0
                change_amount -= dime_count*10
                print(dime_return, "dimes")

            # determines greatest amount of nickels needed 
            nickel_return = int(change_amount // 5)
            if 5 <= change_amount and nickel_count >= nickel_return:
                nickel_count -= nickel_return
                change_amount -= nickel_return*5
                print(nickel_return, "nickels")
            # determines amount of nickels needed  if there is not enough in stock
            elif 5 < change_amount and nickel_return > nickel_count:
                nickel_return = nickel_count
                nickel_count = 0
                change_amount -= nickel_count*5
                print(nickel_return, "nickels")
      
            # if there is not enough change in the machine, prompt user to see manager    
            if change_amount != 0:
                print("Please see manager.")
                print("Total amount due: ", change_amount, "cents")
                
        # user cancels their payment, returns their amount deposited
        if deposit_str == 'c':
            change_amount = round(100*(sum_of_deposit))
            print("Please take the change below.")

      
            quarter_return = int(change_amount // 25)
            if 25 <= change_amount and quarter_count >= quarter_return:
                quarter_count -= quarter_return
                change_amount -= quarter_return*25
                print(quarter_return, "quarters")
            elif 25 < change_amount and quarter_return > quarter_count:
                quarter_return = quarter_count
                quarter_count = 0
                change_amount -= quarter_count*25
                print(quarter_return, "quarters")
            dime_return = int(change_amount // 10)

      
            if 10 <= change_amount and dime_count >= dime_return:
                dime_count -= dime_return
                change_amount -= dime_return*10
                print(dime_return, "dimes")
            elif 10 < change_amount and dime_return > dime_count:
                dime_return = dime_count
                dime_count = 0
                change_amount -= dime_count*10
                print(dime_return, "dimes")

      
            nickel_return = int(change_amount // 5)
            if 5 <= change_amount and nickel_count >= nickel_return:
                nickel_count -= nickel_return
                change_amount -= nickel_return*5
                print(nickel_return, "nickels")
            elif 5 < change_amount and nickel_return > nickel_count:
                nickel_return = nickel_count
                nickel_count = 0
                change_amount -= nickel_count*5
                print(nickel_return, "nickels")
            if change_amount != 0:
                print("Please see manager.")
                print("Total amount due: ", (change_amount/100))
            
        # prints replenished stock
        print(" ")
        print("Stock contains:")
        print(" ", nickel_count, " nickels")
        print(" ", dime_count, " dimes")
        print(" ", quarter_count, " quarters")
        print(" ", ones_count, "  ones")
        print(" ", fives_count, "  fives")
        print(" ")
        
# if the user quits the machine, prompts the user the current amount in machine
            
sum_of_stock = float(nickel_count*.05 + dime_count*.1 + quarter_count*.25 + ones_count + fives_count*5)
dollars = int(sum_of_stock)
cents = sum_of_stock - dollars            
            
print("Total: ", dollars, "dollars and ", round(100*(cents)), "cents.")

