##################################################################
#  Section 1
#  Computer Project #10
#  villapan
##################################################################

#  Algorithm
#    1. Create three classes: Star, Rectangle, and Flag.
#    2. For star and rectangle function create draw method and string for printing dimensions.
#    3. Flag class takes in a file with dimensions of a specified flag.
#    4. Iterate through each line of file to determine number of rectangles and stars to be drawn.
#    5. Use readline function to read certain lines of file.
#    6. Split each line to get a list of each element by itself.
#    7. Convert the string digits to intergers.
#    8. Strip the color string so there is no white space.
#    9. Add that entire line of lists to a new list, and iterate for specificed amount of rectangles and stars.
#   10. Creates instances of Rectangle and Star classes.
#   11. Within Flag class init, loop through file to also create a string that will print specifications of flag.
#   12. Create draw class that loops through the list of instances for both Rectangles and Stars.
#   13. Create string class that returns string created in flag __init__.
#   14. Create and call main function that is provided.

import turtle
import string
import time

class Star(object): # Star class
    def __init__(self, x=0, y=0, arm_length=10, color = 'black'):
        ''' Star class that takes in parameters self,
            center coordinates (x, y), length of star, and color.'''
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color

    def draw(self, pen): # Draw star
        '''Draw star based on center point (x, y)'''
        
        first_point_x = self.x + self.arm_length/2.35 # First value of x where pen starts
        first_point_y = self.y + self.arm_length/3.236 # First value of y where pen starts
        pen.up()
        pen.goto(first_point_x, first_point_y)
        pen.fillcolor(self.color)
        pen.down()
        pen.begin_fill()        
        cnt = 0
        while cnt < 5: # Draws star
            pen.forward(self.arm_length)
            pen.right(144)
            pen.forward(self.arm_length)
            pen.left(72)
            cnt += 1
        pen.end_fill()

    def __str__(self):
        '''Returns string with dimensions of star'''
        myStr = "Star x:" + str(self.x) + ", y:" + str(self.y) + ", arm:" + str(self.arm_length) + ", color:" + self.color
        return myStr

class Rectangle(object):
    def __init__(self, x=0, y=0, width=50, height=50, color = 'blue'):
        ''' Rectangle class that takes in parameters self,
            center coordinates (x, y), length and width of rectangle, and color.'''
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        
    def draw(self, pen):
        '''Draw rectangle based on center point (x, y)'''
        pen.up()
        pen.goto(self.x - self.width/2, self.y + self.height/2) # Where turtle begins to draw
        pen.down()
        pen.fillcolor(self.color)
        pen.down()
        pen.begin_fill()
        cnt = 0
        while cnt < 2: # Draws rectangle
            pen.forward(self.width)
            pen.right(90)
            pen.forward(self.height)
            pen.right(90)
            cnt += 1
        pen.end_fill()

    def __str__(self):
        '''Returns string with dimensions of rectangle'''
        myStr = "Rectangle x:" + str(self.x) + ", y:" + str(self.y) + ", width:" + str(self.width) + ", height:" + str(self.height) + ", color:" + self.color
        return myStr

class Flag(object):
    def __init__(self, file_object):
        '''Takes in a file to be iterated through to determine how many rectangles and stars
           need to be drawn.  Create instances of each line.'''
        
        self.file_object = file_object
        self.rect_list = [] # Empty list that appends an instance for each Rectangle class
        self.star_list = [] # Empty list that appends an istance for each Star class

        rect_count = int(self.file_object.readline()) # Reads how many rectangles need to be drawn
        main_rect_list = [] # Appends a line of the file

        rect_str = "Rectangles\n" # Create string to return in string class
        for rect in range(rect_count): # Iterate through file based on Rectangle count
            rect = self.file_object.readline()
            rect_list = rect.split(',') # Create a list of the current line
            main_rect_list.append(rect_list) # Take the list and append it to main list
                                
            li =  rect_list # Read each object in list
            rect_str += "x: " + str(li[0]) # x coordinate
            rect_str += ", y: " + str(li[1]) # y coordinate
            rect_str += ", w: " + str(li[2]) # width
            rect_str += ", h: " + str(li[3]) # height
            rect_str += ", color: " + li[4] # color

            
            
        
        for lists in main_rect_list: # Iterate through the lists in main list
            cnt = 0 # Count to determine last object in current list
            new_list = [] # New list to append each object
            for obj in lists: # Iterate through each individual item in current list
                if cnt == len(lists)-1:
                    obj = obj.strip() # Ensures there are no whitespaces
                    new_list.append(obj)
                else:
                    obj = int(obj) # Transform string digits to intergers
                    new_list.append(obj)
                cnt += 1
            self.rect_list.append(Rectangle(new_list[0], new_list[1], new_list[2], new_list[3], new_list[4])) # Creates istance of Rectangle class

        star_count = int(self.file_object.readline()) # Reads how many stars there are
        main_star_list = [] # Appends a line of the file

        star_str = "\nStars:\n" # Star string
        for star in range(star_count): 
            star = self.file_object.readline() # Read each line for star specifications
            star_list = star.split(',') # Create list of line
            main_star_list.append(star_list) # Append list to main star list

            li = star_list # Used to get individual objects of star specs
            star_str += "x: " + str(li[0]) # x coord
            star_str += ", y: " + str(li[1]) # y coord
            star_str += ", a: " + str(li[2]) # arm length
            star_str += ", color: " +str(li[3]) # color

            

        for lists in main_star_list: # Method similar 
            cnt = 0
            new_list = []
            for obj in lists:
                if cnt == len(lists)-1:
                    obj = obj.strip()
                    new_list.append(obj)
                else:
                    obj = int(obj)
                    new_list.append(obj)
                cnt += 1
            self.star_list.append(Star(new_list[0], new_list[1], new_list[2], new_list[3])) # Create instance of Star class
                
        self.myStr = rect_str + star_str # Put the two string together

    def draw(self, pen):
        '''Use loops to draw rectangles and stars within flag.'''        
                             
        rect_count = 0 # count to iterate though rectangle instances                  
        for draw in range(len(self.rect_list)):
            instance = self.rect_list[rect_count]
            instance.draw(pen)  # draws all rectangles of flag                                    
            rect_count += 1 

        star_count = 0 # count to iterate through star instances
        for draw in range(len(self.star_list)):
            instance = self.star_list[star_count]
            instance.draw(pen) # draws stars
            star_count += 1

    def __str__(self):
        '''Returns string with the specifications of each rectangle and star in a flag.'''
        return self.myStr

def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt', 'r')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    myflag_file = open('myFlag.txt')
    myflag_flag = Flag(myflag_file)
    print(myflag_flag)
    myflag_flag.draw(pen)
    myflag_file.close()
    

main()

        
        
    
