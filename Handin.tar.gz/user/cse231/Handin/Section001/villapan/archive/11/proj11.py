##################################################################
#  Section 1
#  Computer Project #11
#  villapan
##################################################################

#  Algorithm
#    1. Import urllib function
#    2. Create a tour class
#    3. Create constructor, no limit on on arguments of cities
#    4. Add cities to a self.city_list
#    5. Create a distance method
#    6. create a list for cities and its state
#    7. Iterate through self.city_list to add the city and state to respective lists
#           a. Iterate through city list to ensure white space is replaced with '+'
#    8. Use if statements to specify various modes of transportation
#           a. Take in argument prefix, prefix is then eunmerated into a list.
#    9. Depending on how many cities the user inputs iterate through string concatecation of web object
#   10. If there is more than one city, store previous distance and next distance to next city
#   11. Create string, add, multiply, and comparison classes

import urllib.request

class Tour(object):
    def __init__(self, *city):
        '''Takes in as many city arguments the user inputs.  Adds the cities to a list.'''
        self.city = city
    
        if (type(self.city[0]) == list): # Deals with tour classes that are taken in as lists
            self.city_list = []
            for item in self.city:
                self.city_list.extend( item )
        else:
            self.city_list = []
            for city in self.city:
                self.city_list.append( city ) # Adds each city to a list

    def distance(self, mode='driving'):
        '''Gets total distance of the tour.  Create new lists for a city and
           state to be formatted into web address. Parse web address string.'''
    
        self.mode = mode
        city_list = [] # List for cities
        state_list = [] # List for states

        for item in self.city_list: # Iterate through self.city_list
            item_list = item.split(',') # Split each city into a list
            city_list.append(item_list[0]) # Append the city to respective list
            state_list.append(item_list[1][1:]) # Append the state to respective list"
            
        cnt = 0
        for item in city_list: # Iterates through city list to replace anyw hite space with '+'
            if ' ' in item:
                new_str = item.replace(' ', '+')
                city_list[cnt] = new_str
            cnt += 1
            
        total_distance = 0 # Total distance initial
        if self.mode == 'driving': # Mode is driving
            cnt = 0 # Count for range of self.city_list    
            while cnt < len(self.city_list)-1: # Use loop for tours with more than one city
                # Open url, format correctly with items from list
                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins={}+{}&destinations={}+{}&mode={}&sensor=false".format(city_list[cnt], state_list[cnt], city_list[cnt+1], state_list[cnt+1], 'driving'))
                results_str = str(web_obj.read())
                web_obj.close()
                # Parse web ojbect string
                indx_val = results_str.find('value')
                results_str = results_str[indx_val:]
                col_val = results_str.find(':')
                results_str = results_str[col_val+1:]
                distance_list = results_str.split(' ')
                distance = distance_list[1] # Get the distance value
                distance = int(distance[0:-2]) # Clean up distance value
                total_distance += distance # Add distances
                cnt+=1 # Count plus one if tour has more than one city

        elif self.mode == 'bicycling': # Mode is bicycling
            cnt = 0    
            while cnt < len(self.city_list)-1:
                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins={}+{}&destinations={}+{}&mode={}&sensor=false".format(city_list[cnt], state_list[cnt], city_list[cnt+1], state_list[cnt+1], 'bicycling'))
                results_str = str(web_obj.read())
                web_obj.close()
                indx_val = results_str.find('value')
                results_str = results_str[indx_val:]
                col_val = results_str.find(':')
                results_str = results_str[col_val+1:]
                distance_list = results_str.split(' ')
                distance = distance_list[1]
                distance = int(distance[0:-2])
                total_distance += distance
                cnt+=1

        elif self.mode == 'walking': # Mode is walking
            cnt = 0    
            while cnt < len(self.city_list)-1:
                web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins={}+{}&destinations={}+{}&mode={}&sensor=false".format(city_list[cnt], state_list[cnt], city_list[cnt+1], state_list[cnt+1], 'walking'))
                results_str = str(web_obj.read())
                web_obj.close()
                indx_val = results_str.find('value')
                results_str = results_str[indx_val:]
                col_val = results_str.find(':')
                results_str = results_str[col_val+1:]
                distance_list = results_str.split(' ')
                distance = distance_list[1]
                distance = int(distance[0:-2])
                total_distance += distance
                cnt+=1

        if total_distance:
            return total_distance
        else: # Total distance equals 0, user has not moved
            raise ValueError("Does not contain a distance value.")

    def __str__(self):
        '''Returns a string of the tour in the format City, State.'''
        
        myStr = ''
        for city in self.city_list:
            if city == self.city_list[-1]:
                myStr += city + " "
            else:
                myStr += city + "; "

        return myStr

    def __repr__(self):
        '''Returns string for shell representation.'''
        return self.__str__()

    def __add__(self, t2):
        '''Adds two tours together.'''
        t2_city_list = [] # New list for cities for other tour
        for city in t2.city:
            t2_city_list.append(city) # add cities to a new list
        t3 = [] # new list
        t3.extend(self.city_list) # add initial tour to list
        t3.extend(t2_city_list) # add second tour to list
        
        return Tour(t3)
            
        

    def __mul__(self, t2):
        '''Repeated concatenation of the tour, how many times to cycle through the cities.'''
        if type(t2) == int: # int value
            if t2 < 0: # value must be positive
                raise ValueError("Must be a positive interger.")
            else:
                t3 = [] # new list
                cnt = 0
                while cnt < t2: # how many times to add the tour to the list
                    t3.extend(self.city_list)
                    cnt += 1
                return Tour(t3)
        else:
            raise TypeError("Must be an interger")
        

    def __rmul__(self, t2):
        '''Reverse of multiplication.'''
        return self.__mul__(t2)

    def __gt__(self, t2):
        '''Checks to see if one tour is longer than another.'''
        if self.distance() > t2.distance():
            return True
        else:
            return False

    def __lt__(self, t2):
        '''Checks to see if one tour shorter than another.'''
        if self.distance() < t2.distance():
            return True
        else:
            return False

    def __eq__(self, t2):
        '''Checks to see if two tours are equivalent in distance.'''
        if self.distance() == t2.distance():
            return True
        else:
            return False
        
            
        
def main():

    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2: {}\nt3: {}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(
round(t1.distance()/1000), round(t1.distance('bicycling')/1000),
round(t1.distance('walking')/1000)))
    t4 = t1 + t2
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    t5 = 3*t3
    print("t5:", t5)
    print("t5 driving distance:", round(t5.distance()/1000),"km")
    print("Tour one is greather than tour two: ", t1 > t3)
    print("Tour one is less than tour two: ", t1 < t3)
    t6 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    print("Tour one is equal to tour two: ", t1 == t6)
    
main()
