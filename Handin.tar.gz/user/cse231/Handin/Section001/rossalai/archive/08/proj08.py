#proj08
#section1

import string

def fill_completions(c_dict,fd):
    word_list=[]
    for line in fd:
        line = line.strip()
        temp_list=line.split()
        for word in temp_list:
            word=word.lower()
            word=word.strip(string.punctuation)
            count=0
            if word.isalpha() and len(word)>1:
                #don't add 1 letter words, or words with embeded punctuation
                word_list.append(word)
                letter_index_list=list(enumerate(word))
                for element in letter_index_list:
                    if element in c_dict:
                        #if already in dictionary, add new word to set
                        c_dict[element].add(word)
                    else:
                        #make the dictionary value a set and add new word
                        c_dict[element]=set()
                        c_dict[element].add(word)
                    
def find_completions(prefix,c_dict): 
    letter_list=list(enumerate(prefix))
    old_set=set() 
    for element in letter_list: #intersect the sets
        if prefix.isalpha() is False:
            #for prefixes with punctuation or numbers
            new_set=set()
        elif len(prefix)==1:
            old_set=c_dict[element]
            new_set=old_set&c_dict[element]
        else:
            new_set=old_set&c_dict[element]
            old_set=c_dict[element]
    return new_set

def main():
    file_obj=open('ap_docs.txt')
    c_dict={}
    fill_completions(c_dict,file_obj)
    while True:
        pre=input("Enter a prefix or # to quit: ")
        print()
        if pre=='#':
            break
        else:
            comp_set=find_completions(pre,c_dict)
            if comp_set==set():
                #if weird prefix entered
                print('No Suggestions')
            else: #print suggested words
                print_list=[]
                for word in comp_set:
                    print_list.append(word)
                print('Suggested words: ',', '.join(print_list))
                print()
            
    
            
