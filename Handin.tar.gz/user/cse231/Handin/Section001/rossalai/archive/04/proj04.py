#proj04
#section1
string_one=input("String 1: ").lower() #makes input all lowercase
string_two=input("String 2: ").lower()
match=0
miss=0
while True:
    print(" ")
    print("Please enter a command")
    print("'a' to add an indel")
    print("'d' to delete an indel")
    print("'s' to score the alignment")
    print("'q' to quit")
    print(" ")
    command=input("What would you like to do? ")
    count=len(string_one)-1 #this will start the count at the last index
    if command=='a':
        input_str=input("Which string (1 or 2)? ")
        index_str=input("Before what index? ")
        index=int(index_str)
        if input_str=='1':
            if index>len(string_one)-1: #entered index is larger than the last index
                print("Error. Index out of range.")
            else: #takes string up until entered index, adds - then adds the rest of string
                string_one=string_one[:index]+'-'+string_one[index:len(string_one)]
                print("String one:",string_one)
                print("String two:",string_two)
        elif input_str=='2': #same process as for string one
            if index>len(string_two)-1:
                print("Error. Index out of range.")
            else:
                string_two=string_two[:index]+'-'+string_two[index:len(string_two)]
                print("String one:",string_one)
                print("String two:",string_two)
    elif command=='d':
        input_str=input("Which string (1 or 2)? ")
        index_str=input("Delete what index? ")
        index_int=int(index_str)
        if input_str=='1':
            if string_one[index_int]!='-': #if entered index isnt a -
                print("Error. Can only delete indels")
                print("String one:",string_one)
                print("String two:",string_two)
            else: #takes string until entered index and adds string after index
                string_one=string_one[:index_int]+string_one[index_int+1:]
                print("String one:",string_one)
                print("String two:",string_two)
        elif input_str=='2': #same procedure as above
            if string_two[index_int]!='-':
                print("Error. Can only delete indels")
                print("String one:",string_one)
                print("String two:",string_two)
            else:
                string_two=string_two[:index_int]+string_two[index_int+1:]
                print("String one:",string_one)
                print("String two:",string_two)
    elif command=='s':
        if len(string_one)>len(string_two):
            diff_one=len(string_one)-len(string_two)
            string_two=string_two+('-'*diff_one) #if string one is longer, add - to the end
            while count>=0:#start count at final index, count backwards to 0
                if string_one[count]=='-':
                    miss+=1 #indel automatically means a miss
                    letter_two=string_two[count].upper() #capitalize the coresponding letter of other string
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
                elif string_two[count]=='-':
                    miss+=1
                    letter_one=string_one[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    count-=1
                elif string_one[count]==string_two[count]:
                    match+=1
                    count-=1
                else:#if both strings have letters but they arent the same
                    miss+=1
                    letter_one=string_one[count].upper() #captialize both letters
                    letter_two=string_two[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
            else:
                print("Matches:",match,"Mismatches:",miss)
                print("String 1:",string_one)
                print("String 2:",string_two)
                string_one=string_one.lower()#make the strings all lowercase again
                string_two=string_two.lower()
                string_two=string_two[:len(string_two)-diff_one] #delete indels added to the end
                match=0 #reset the number of matches and misses
                miss=0
        elif len(string_two)>len(string_one): #same as above, only opposite string
            diff_two=len(string_two)-len(string_one)
            string_one=string_one+('-'*diff_two)
            while count>=0:
                if string_one[count]=='-':
                    miss+=1
                    letter_two=string_two[count].upper()
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
                elif string_two[count]=='-':
                    miss+=1
                    letter_one=string_one[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    count-=1
                elif string_one[count]==string_two[count]:
                    match+=1
                    count-=1
                else:
                    miss+=1
                    letter_one=string_one[count].upper()
                    letter_two=string_two[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
            else:
                print("Matches:",match,"Mismatches:",miss)
                print("String 1:",string_one)
                print("String 2:",string_two)
                string_one=string_one.lower()
                string_two=string_two.lower()
                string_one=string_one[:len(string_one)-diff_two]
                match=0
                miss=0
        elif len(string_one)==len(string_two): #if strings are same length, same procedure
            while count>=0:
                if string_one[count]=='-':
                    miss+=1
                    letter_two=string_two[count].upper()
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
                elif string_two[count]=='-':
                    miss+=1
                    letter_one=string_one[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    count-=1
                elif string_one[count]==string_two[count]:
                    match+=1
                    count-=1
                else:
                    miss+=1
                    letter_one=string_one[count].upper()
                    letter_two=string_two[count].upper()
                    string_one=string_one[:count]+letter_one+string_one[count+1:]
                    string_two=string_two[:count]+letter_two+string_two[count+1:]
                    count-=1
            else:
                print("Matches:",match,"Mismatches:",miss)
                print("String 1:",string_one)
                print("String 2:",string_two)
                string_one=string_one.lower()
                string_two=string_two.lower()
                match=0
                miss=0
    elif command=='q':
        break
    else: #if an invalid command is entered
        print("Error. Command not understood")
