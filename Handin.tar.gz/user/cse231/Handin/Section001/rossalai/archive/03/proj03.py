#proj03
#section1
nick_int=25
dime_int=25
quart_int=25
one_int=0
five_int=0

print("Welcome to the vending machine change maker program")
while True:
    deposit_int=0
    print(" ")
    print("Stock contains:")
    print(nick_int, "nickles")
    print(dime_int, "dimes")
    print(quart_int, "quarters")
    print(one_int, "ones")
    print(five_int, "fives")
    print(" ")
    input_str=input("Enter the purchase price or 'q' to quit: ")
    if input_str=='q':
        print("Stock contains:")
        print(nick_int, "nickles")
        print(dime_int, "dimes")
        print(quart_int, "quarters")
        print(one_int, "ones")
        print(five_int, "fives")
        print(" ")
        total_int=5*(nick_int)+10*(dime_int)+25*(quart_int)+100*(one_int)+500*(five_int)
        print("Total: ",int(total_int/100),"dollars and",total_int%100,"cents")
        print("Thanks, come again!")
        break
    else:
        price_int=int(100*float(input_str))
        if price_int%5!=0 or price_int<0:
            print("Error, price must be a positive multiple of 5 cents")
        else:
            print(" ")
            print("Deposit Menu:")
            print("'n' - deposit a nickel")
            print("'d' - deposit a dime")
            print("'q' - deposit a quarter")
            print("'o' - deposit a one dollar bill")
            print("'f' - deposit a five dollar bill")
            print("'c' - cancel the purchase")
            print(" ")
            print("Payment due: ",int(price_int/100),"dollars and ",price_int%100,"cents")
            due_int=price_int
            while due_int>0:
                deposit_str=input("What is your method of deposit? ")
                if deposit_str=='f':
                    due_int-=500
                    five_int+=1
                    deposit_int+=500
                    if due_int>0:
                        print("Payment due: ",int(due_int/100),"dollars and ",due_int%100,"cents")
                    elif due_int<0:
                        break
                elif deposit_str=='o':
                    due_int-=100
                    one_int+=1
                    deposit_int+=100
                    if due_int>0:
                        print("Payment due: ",int(due_int/100),"dollars and ",due_int%100,"cents")
                    elif due_int<0:
                        break
                elif deposit_str=='q':
                    due_int-=25
                    quart_int+=1
                    deposit_int+=25
                    if due_int>0:
                        print("Payment due: ",int(due_int/100),"dollars and ",due_int%100,"cents")
                    elif due_int<0:
                        break
                elif deposit_str=='d':
                    due_int-=10
                    dime_int+=1
                    deposit_int+=10
                    if due_int>0:
                        print("Payment due: ",int(due_int/100),"dollars and ",due_int%100,"cents")
                    elif due_int<0:
                        break
                elif deposit_str=='n':
                    due_int-=5
                    nick_int+=1
                    deposit_int+=5
                    if due_int>0:
                        print("Payment due: ",int(due_int/100),"dollars and",due_int%100,"cents")
                    elif due_int<0:
                        break
                elif deposit_str=='c':
                    if deposit_int==0:
                        print("Thanks, come again")
                    else:
                        change_int=deposit_int
                        print("Change due:",int(change_int/100),"dollars and",change_int%100,"cents")
                        print("Please take the change below:")
                        num_quart=(change_int//25)
                        num_dime=(change_int//10)
                        num_nick=(change_int//5)
                        if 0<num_quart<=quart_int: #if there are more quarters in stock than needed
                            print(num_quart," quarters")
                            quart_int=quart_int-num_quart #update quarter stock
                            change_int=change_int-((num_quart)*25) #update amount of change
                            num_dime=(change_int//10)  #update number of dimes needed
                            num_nick=(change_int//5)  #update number of nickles needed
                            if 0<num_dime<=dime_int: #if enough dimes
                                print(num_dime," dimes")
                                dime_int=dime_int-num_dime
                                change_int=change_int-((num_dime)*10)
                                num_nick=(change_int//5)
                                if 0<num_nick<=nick_int: #if enough nickles
                                    print(num_nick," nickels")
                                    nick_int=nick_int-num_nick
                                    change_int=change_int-((num_nick)*5)
                                    if quart_int==0 and dime_int==0 and nick_int==0: 
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                              ,change_int%100,"cents from the manager")
                                elif num_nick>nick_int: #if not enough nickles
                                    if nick_int!=0:
                                        print(nick_int," nickels")
                                    change_int=change_int-((nick_int)*5)
                                    nick_int=0
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                             ,change_int%100,"cents from the manager")
                            elif num_dime>dime_int: #if not enough dimes
                                if dime_int!=0:
                                    print(dime_int," dimes")
                                change_int=change_int-((dime_int)*10)
                                dime_int=0
                                num_nick=(change_int//5)
                                if 0<num_nick<=nick_int:
                                    print(num_nick," nickels")
                                    nick_int=nick_int-num_nick
                                    change_int=change_int-((num_nick)*5)
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                             ,change_int%100,"cents from the manager")
                                elif num_nick>nick_int:
                                    if nick_int!=0:
                                        print(nick_int," nickels")
                                    change_int=change_int-((nick_int)*5)
                                    nick_int=0
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                             ,change_int%100,"cents from the manager")
                            elif 0<num_nick<=nick_int:
                                print(num_nick," nickels")
                                nick_int=nick_int-num_nick
                                change_int=change_int-((num_nick)*5)
                                if quart_int==0 and dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                            elif num_nick>nick_int:
                                if nick_int!=0:
                                    print(nick_int," nickels")
                                change_int=change_int-((nick_int)*5)
                                nick_int=0
                                if quart_int==0 and dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                        elif num_quart>quart_int: #if not enough quarters
                            if quart_int!=0:
                                print(quart_int," quarters")
                            change_int=change_int-((quart_int)*25)
                            quart_int=0
                            num_dime=(change_int//10)
                            num_nick=(change_int//5)
                            if 0<num_dime<=dime_int:
                                print(num_dime," dimes")
                                dime_int=dime_int-num_dime
                                change_int=change_int-((num_dime)*10)
                                num_nick=(change_int//5)
                                if 0<num_nick<=nick_int:
                                    print(num_nick," nickels")
                                    nick_int=nick_int-num_nick
                                    change_int=change_int-((num_nick)*5)
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                              ,change_int%100,"cents from the manager")
                                elif num_nick>nick_int:
                                    if nicj_int!=0:
                                        print(nick_int," nickels")
                                    change_int=change_int-((nick_int)*5)
                                    nick_int=0
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                              ,change_int%100,"cents from the manager")
                            elif num_dime>dime_int:
                                if dime_int!=0:
                                    print(dime_int," dimes")
                                change_int=change_int-((dime_int)*10)
                                dime_int=0
                                num_nick=(change_int//5)
                                if 0<num_nick<=nick_int:
                                    print(num_nick," nickels")
                                    nick_int=nick_int-num_nick
                                    change_int=change_int-((num_nick)*5)
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                              ,change_int%100,"cents from the manager")
                                elif num_nick>nick_int:
                                    if nick_int!=0:
                                        print(nick_int," nickels")
                                    change_int=change_int-((nick_int)*5)
                                    nick_int=0
                                    if quart_int==0 and dime_int==0 and nick_int==0:
                                        print("Ran out of coins")
                                        print("Please pick up",int(change_int/100),"dollars and"\
                                              ,change_int%100,"cents from the manager")
                            elif 0<num_nick<=nick_int:
                                print(num_nick," nickels")
                                nick_int=nick_int-num_nick
                                change_int=change_int-((num_nick)*5)
                                if quart_int==0 and dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                            elif num_nick>nick_int:
                                if nick_int!=0:
                                    print(nick_int," nickels")
                                change_int=change_int-((nick_int)*5)
                                nick_int=0
                                if quart_int==0 and dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                        elif 0<num_dime<=dime_int: #if zero quarters start here with dimes
                            print(num_dime," dimes")
                            dime_int=dime_int-num_dime
                            change_int=change_int-((num_dime)*10)
                            num_nick=(change_int//5)
                            if 0<num_nick<=nick_int:
                                print(num_nick," nickels")
                                nick_int=nick_int-num_nick
                                change_int=change_int-((num_nick)*5)
                                if dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                            elif num_nick>nick_int:
                                if nick_int!=0:
                                    print(nick_int," nickels")
                                change_int=change_int-((nick_int)*5)
                                nick_int=0
                                if dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                        elif num_dime>dime_int: 
                            if dime_int!=0:
                                print(dime_int," dimes")
                            change_int=change_int-((dime_int)*10)
                            dime_int=0
                            num_nick=(change_int//5)
                            if 0<num_nick<=nick_int:
                                print(num_nick," nickels")
                                nick_int=nick_int-num_nick
                                change_int=change_int-((num_nick)*5)
                                if dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                            elif num_nick>nick_int:
                                if nick_int!=0:
                                    print(nick_int," nickels")
                                change_int=change_int-((nick_int)*5)
                                nick_int=0
                                if dime_int==0 and nick_int==0:
                                    print("Ran out of coins")
                                    print("Please pick up",int(change_int/100),"dollars and"\
                                          ,change_int%100,"cents from the manager")
                        elif 0<num_nick<=nick_int: #if zero quarters and dimes start here
                            print(num_nick," nickels")
                            nick_int=nick_int-num_nick
                            change_int=change_int-((num_nick)*5)
                            if nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                        elif num_nick>nick_int:
                            if nick_int!=0:
                                print(nick_int," nickels")
                            change_int=change_int-((nick_int)*5)
                            nick_int=0
                            if nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                    break
                else:
                    print("Illegal selection:",deposit_str) #if they enter something not on the menu
                    
            if due_int==0:
                print("No change due") #exact change
            if due_int<0: #exact same method as canceling purchase
                change_int=abs(due_int)
                print(" ")
                print("Change due:",int(change_int/100),"dollars and",change_int%100,"cents")
                print("Please take the change below:")
                num_quart=(change_int//25)
                num_dime=(change_int//10)
                num_nick=(change_int//5)
                if 0<num_quart<=quart_int:
                    print(num_quart," quarters")
                    quart_int=quart_int-num_quart
                    change_int=change_int-((num_quart)*25)
                    num_dime=(change_int//10)
                    num_nick=(change_int//5)
                    if 0<num_dime<=dime_int:
                        print(num_dime," dimes")
                        dime_int=dime_int-num_dime
                        change_int=change_int-((num_dime)*10)
                        num_nick=(change_int//5)
                        if 0<num_nick<=nick_int:
                            print(num_nick," nickels")
                            nick_int=nick_int-num_nick
                            change_int=change_int-((num_nick)*5)
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                        elif num_nick>nick_int:
                            if nick_int!=0:
                                print(nick_int," nickels")
                            change_int=change_int-((nick_int)*5)
                            nick_int=0
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                    elif num_dime>dime_int:
                        if dime_int!=0:
                            print(dime_int," dimes")
                        change_int=change_int-((dime_int)*10)
                        dime_int=0
                        num_nick=(change_int//5)
                        if 0<num_nick<=nick_int:
                            print(num_nick," nickels")
                            nick_int=nick_int-num_nick
                            change_int=change_int-((num_nick)*5)
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                        elif num_nick>nick_int:
                            if nick_int!=0:
                                print(nick_int," nickels")
                            change_int=change_int-((nick_int)*5)
                            nick_int=0
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                    elif 0<num_nick<=nick_int:
                        print(num_nick," nickels")
                        nick_int=nick_int-num_nick
                        change_int=change_int-((num_nick)*5)
                        if quart_int==0 and dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                    elif num_nick>nick_int:
                        if nick_int!=0:
                            print(nick_int," nickels")
                        change_int=change_int-((nick_int)*5)
                        nick_int=0
                        if quart_int==0 and dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                elif num_quart>quart_int:
                    if quart_int!=0:
                        print(quart_int," quarters")
                    change_int=change_int-((quart_int)*25)
                    quart_int=0
                    num_dime=(change_int//10)
                    num_nick=(change_int//5)
                    if 0<num_dime<=dime_int:
                        print(num_dime," dimes")
                        dime_int=dime_int-num_dime
                        change_int=change_int-((num_dime)*10)
                        num_nick=(change_int//5)
                        if 0<num_nick<=nick_int:
                            print(num_nick," nickels")
                            nick_int=nick_int-num_nick
                            change_int=change_int-((num_nick)*5)
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                        elif num_nick>nick_int:
                            if nick_int!=0:
                                print(nick_int," nickels")
                            change_int=change_int-((nick_int)*5)
                            nick_int=0
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                    elif num_dime>dime_int:
                        if dime_int!=0:
                            print(dime_int," dimes")
                        change_int=change_int-((dime_int)*10)
                        dime_int=0
                        num_nick=(change_int//5)
                        if 0<num_nick<=nick_int:
                            print(num_nick," nickels")
                            nick_int=nick_int-num_nick
                            change_int=change_int-((num_nick)*5)
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                        elif num_nick>nick_int:
                            if nick_int!=0:
                                print(nick_int," nickels")
                            change_int=change_int-((nick_int)*5)
                            nick_int=0
                            if quart_int==0 and dime_int==0 and nick_int==0:
                                print("Ran out of coins")
                                print("Please pick up",int(change_int/100),"dollars and"\
                                      ,change_int%100,"cents from the manager")
                    elif 0<num_nick<=nick_int:
                        print(num_nick," nickels")
                        nick_int=nick_int-num_nick
                        change_int=change_int-((num_nick)*5)
                        if quart_int==0 and dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                    elif num_nick>nick_int:
                        if nick_int!=0:
                            print(nick_int," nickels")
                        change_int=change_int-((nick_int)*5)
                        nick_int=0
                        if quart_int==0 and dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                elif 0<num_dime<=dime_int:
                    print(num_dime," dimes")
                    dime_int=dime_int-num_dime
                    change_int=change_int-((num_dime)*10)
                    num_nick=(change_int//5)
                    if 0<num_nick<=nick_int:
                        print(num_nick," nickels")
                        nick_int=nick_int-num_nick
                        change_int=change_int-((num_nick)*5)
                        if dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                    elif num_nick>nick_int:
                        if nick_int!=0:
                            print(nick_int," nickels")
                        change_int=change_int-((nick_int)*5)
                        nick_int=0
                        if dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                elif num_dime>dime_int:
                    if dime_int!=0:
                        print(dime_int," dimes")
                    change_int=change_int-((dime_int)*10)
                    dime_int=0
                    num_nick=(change_int//5)
                    if 0<num_nick<=nick_int:
                        print(num_nick," nickels")
                        nick_int=nick_int-num_nick
                        change_int=change_int-((num_nick)*5)
                        if dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                    elif num_nick>nick_int:
                        if nick_int!=0:
                            print(nick_int," nickels")
                        change_int=change_int-((nick_int)*5)
                        nick_int=0
                        if dime_int==0 and nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                elif 0<num_nick<=nick_int:
                    print(num_nick," nickels")
                    nick_int=nick_int-num_nick
                    change_int=change_int-((num_nick)*5)
                    if nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")
                elif num_nick>nick_int:
                    if nick_int!=0:
                        print(nick_int," nickels")
                    change_int=change_int-((nick_int)*5)
                    nick_int=0
                    if nick_int==0:
                            print("Ran out of coins")
                            print("Please pick up",int(change_int/100),"dollars and"\
                                  ,change_int%100,"cents from the manager")

            
                    
