#proj12
#section1
import numpy as np
import matplotlib.pyplot as plt
from pylab import *

#########NOTE###########
#QP, i emailed you about my project
#the readline() was giving a weird error for the radiation file
#it works fine if you delete the exponent in the textfile
#or change it to normal characters(^2)
# also,, could not get matplotlib to work, so no graphs are generated
#the program will print the results instead


def get_data(f_obj,col,num):
    my_list=[]
    count=0
    while count<=num: #skip however many lines specified
        skipline=f_obj.readline()
        count+=1
    for line in f_obj:
        line=line.strip()
        if line=='':
            print('')
        else:
            line_list=line.split()
            for element in line_list:
                element=element.strip()
            tupple=(line_list[0],line_list[col],line_list[4])
            #turn lines into tupples
            my_list.append(tupple) #add each tupple to a list
    return my_list

def get_highest(tup_list):
    new_list=[]
    count=0
    highest=0
    lowest=160
    while count<=len(tup_list)-1:
        if count==len(tup_list)-1:
            if float(tup_list[count][2])>highest:
                highest=float(tup_list[count][2])
            if float(tup_list[count][2])<lowest:
                lowest=float(tup_list[count][2])
            new_list.append((tup_list[count][0],tup_list[count][1],highest,lowest))
            count+=1
        elif tup_list[count][1]==tup_list[count+1][1]:
            if float(tup_list[count][2])>highest:
                highest=float(tup_list[count][2])
            if float(tup_list[count][2])<lowest:
                lowest=float(tup_list[count][2])
            count+=1
        elif tup_list[count][1]!=tup_list[count+1][1]:
            if float(tup_list[count][2])>highest:
                highest=float(tup_list[count][2])
            if float(tup_list[count][2])<lowest:
                lowest=float(tup_list[count][2])
            new_list.append((tup_list[count][0],tup_list[count][1],highest,lowest))
            highest=0
            lowest=160
            count+=1
    return new_list
            
            

def average_temps(tup_list):
    '''averages by month'''
    new_list=[]
    count=0
    high_sum=0
    low_sum=0
    total=0
    while count<=len(tup_list)-1:
        if count==len(tup_list)-1: #for the last element in the list
            total+=1
            high_sum+=float(tup_list[count][2]) #add up high temps
            low_sum+=float(tup_list[count][3])#add up low temps
            new_list.append((tup_list[count][0],high_sum/total,low_sum/total))
            #append average high and low
            count+=1
        elif tup_list[count][0]==tup_list[count+1][0]:
            #if the next element is in the same month
            total+=1
            high_sum+=float(tup_list[count][2])
            low_sum+=float(tup_list[count][3])
            count+=1
        elif tup_list[count][0]!=tup_list[count+1][0]:
            #if the next element is a different month
            total+=1
            high_sum+=float(tup_list[count][2])
            low_sum+=float(tup_list[count][3])
            new_list.append((tup_list[count][0],high_sum/total,low_sum/total))
            count+=1
    return new_list

def average_rad(tup_list):
    '''calculates hourly averages'''
    count=0
    my_list=[]
    while count<=len(tup_list)-1:
        if tup_list[count][0]=='7': #only do july
            my_list.append((int(tup_list[count][1]),float(tup_list[count][2])))
        count+=1
    my_dict={}
    time=100
    while time<=2400:
        my_dict[time]=0
        time+=100       
    for tupple in my_list:
        my_dict[tupple[0]]+=tupple[1]
    count=100
    while count<=2400:
        my_dict[count]/=31
        count+=100
    new_list=[]
    for k,v in my_dict.items():
        new_list.append((k//100,v))
        new_list.sort()
    return new_list

temp_file=open('temperature.txt','r')              
temp_list=get_data(temp_file,1,2)
other_list=get_highest(temp_list)
print(average_temps(other_list))
#prints the list of tupples in the format (month, avg hi, avg lo)
print('')
rad_file=open('solar_radition.txt','r')
rad_list=get_data(rad_file,3,4)
temp_file.close()
temp_file=open('temperature.txt','r')
other_list=get_data(temp_file,3,2)
print(average_rad(rad_list))
#prints list of tupples in the form (hour, avg rad)
print('')
print(average_rad(other_list))
#print list of tupples in the form (hour, avg temp)
            
