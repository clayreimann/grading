rs_str = input("What is the Richter Scale measure?")
try:
  rs_float = float(rs_str)
  if rs_float < 0:
    print('Oops! Input values should be positive, did you mean',\
          abs(rs_float),'?')
  nrg_float = 10**((1.5*rs_float)+4.8)
  tnt_float = nrg_float / 4.184E9
  print("Richter Scale measure:", abs(rs_float))  
  print("Energy in Joules:", nrg_float)
  print("Energy in Tons of TNT:", tnt_float)
  print(" ")
  print("Richter","         ","Joules","                   ","TNT")
  print("1","         ",10**(1.5+4.8),"      ",(10**(1.5+4.8))/4.184E9)
  print("5","         ",10**((1.5*5)+4.8),"      ",(10**((1.5*5)+4.8)/4.184E9))
  print("9.1","       ",10**((1.5*9.1)+4.8),"   ",(10**((1.5*9.1)+4.8)/4.184E9))
  print("9.2","       ",10**((1.5*9.2)+4.8),"   ",(10**((1.5*9.2)+4.8)/4.184E9))
  print("9.5","       ",10**((1.5*9.5)+4.8),"  ",(10**((1.5*9.5)+4.8)/4.184E9))
except (ValueError):
      print('Oops! Input should be a float or an integer')
