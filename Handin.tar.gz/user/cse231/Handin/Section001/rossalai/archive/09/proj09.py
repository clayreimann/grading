#proj09
#section1

import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    my_deck=cardsBasic.Deck()
    my_deck.shuffle()
    tableau = [[],[],[],[],[],[],[],[],[],[]]
    for i in range (6): #first two columns have 6 cards
        tableau[0].append(my_deck.deal())
        tableau[1].append(my_deck.deal())
    for i in range (5): #rest of columns have 5 cards
        tableau[2].append(my_deck.deal())
        tableau[3].append(my_deck.deal())
        tableau[4].append(my_deck.deal())
        tableau[5].append(my_deck.deal())
        tableau[6].append(my_deck.deal())
        tableau[7].append(my_deck.deal())
        tableau[8].append(my_deck.deal())
        tableau[9].append(my_deck.deal())
    foundation = [[],[],[],[]]
    cell = [[],[],[],[]]
    
    return foundation,tableau,cell


def move_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''
    try:
        if foundation[f_col-1]==[]: #if empty foundation
            if tableau[t_col-1][-1].get_rank()==1: #only allow aces
                move=True
                foundation[f_col-1]=[tableau[t_col-1][-1]] #move to foundation
                tableau[t_col-1].pop(-1)#remove from tableau
            else:
                print('Invalid move')
                move=False
        else: #if foundation has existing card
            if tableau[t_col-1][-1].get_rank()==1+foundation[f_col-1][0].get_rank():
                #only put card one less rank
                if tableau[t_col-1][-1].get_suit()==foundation[f_col-1][0].get_suit():
                    #only same suit
                    move=True
                    foundation[f_col-1]=[tableau[t_col-1][-1]]
                    tableau[t_col-1].pop(-1)
                else:
                    print('Invalid move')
                    move=False
            else:
                print('Invalid move')
                move=False
    except IndexError: #if the enter an invalid t_col or f_col
        print('Invalid move')
        move=False
    return move


def move_to_cell(tableau,cell,t_col,c_col): 
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    try:
        if cell[c_col-1]==[]: #only move to empty cell
            move=True
            cell[c_col-1]=[tableau[t_col-1][-1]]#move to cell
            tableau[t_col-1].pop(-1)#remove from tableau
        else:
            print('Invalid move')
            move=False
    except IndexError: #if invalid t_col or c_col value
        print('Invalid move')
        move=False
    return move

def move_to_tableau(tableau,cell,c_col,t_col): 
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    try:
        if cell[c_col-1]==[]: #cant move if there is no card
            move=False
        elif tableau[t_col-1][-1].get_suit()==cell[c_col-1][0].get_suit(): #must be same suit
            if tableau[t_col-1][-1].get_rank()==1+cell[c_col-1][0].get_rank(): #and one lower rank
                move=True
                tableau[t_col-1].append(cell[c_col-1][0]) #move to tableau
                cell[c_col-1]=[]#remove from cell
            else:
                print('Invalid move')
                move=False
        else:
            print('Invalid move')
            move=False
    except IndexError: #for invalid c_col or t_col value
        print('Invalid move')
        move=False

def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    if foundation[0]==[] or foundation[1]==[] or foundation[2]==[] or foundation[3]==[]:
        #if any foundation is empty, havent won yet
        win=False
    elif foundation[0][0].get_rank()==foundation[1][0].get_rank()==foundation[2][0].get_rank()==foundation[3][0].get_rank()==13:
        #if each foundation has a king, game is won
        win=True
    else:
        #if any other cards, havent won yet
        win=False
    return win

def move_in_tableau(tableau,t_col_source,t_col_dest): 
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    try:
        if tableau[t_col_dest-1]==[]:
            if tableau[t_col_source-1][-1].get_rank()==13:
                #can only move king to empty tableau
                move=True
                tableau[t_col_dest-1].append(tableau[t_col_source-1][-1])
                tableau[t_col_source-1].pop(-1)
            else:
                print('Invalid move')
                move=False
        elif tableau[t_col_source-1][-1].get_suit()==tableau[t_col_dest-1][-1].get_suit():
            #must move onto same suited card
            if tableau[t_col_source-1][-1].get_rank()+1==tableau[t_col_dest-1][-1].get_rank():
                #card must be ranked one lower than destination card
                move=True
                tableau[t_col_dest-1].append(tableau[t_col_source-1][-1])
                tableau[t_col_source-1].pop(-1)
            else:
                print('Invalid move')
                move=False
        else:
            print('Invalid move')
            move=False
    except IndexError: #if invalid t_col_source or t_col_dest val
        print('Invalid move')
        move=False
    return move
        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
         

    

    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    while True:
        print_game(foundation, tableau, cell)
        win=is_winner(foundation) #check before input for winning
        if win:
            print('Congratulations! you win!')
            break
        else:
            response = input("Command (type 'h' for help): ")
            response = response.strip()
            response_list = response.split()
            if len(response_list) > 0:
                r = response_list[0]
                if r == 't2f':
                    move_to_foundation(tableau,foundation,int(response_list[1]),int(response_list[2]))
                elif r == 't2t':
                    move_in_tableau(tableau,int(response_list[1]),int(response_list[2]))                         
                elif r == 't2c':
                    move_to_cell(tableau,cell,int(response_list[1]),int(response_list[2]))                         
                elif r == 'c2t':
                    move_to_tableau(tableau,cell,int(response_list[1]),int(response_list[2]))                         
                elif r == 'c2f':
                    move_to_foundation(cell,foundation,int(response_list[1]),int(response_list[2]))                        
                elif r == 'q':
                    break
                elif r == 'h':
                    show_help()
                else:
                    print('Unknown command:',r)
            else:
                print("Unknown Command:",response)
    print('Thanks for playing')

play()


        
    

