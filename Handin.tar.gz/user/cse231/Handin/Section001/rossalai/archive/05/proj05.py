#proj05
#section1
import turtle
import math
#function to prompt for the number of hexagons per row
def get_num_hexagons():
    while True:
        hex_num=int(input("How many hexagons per row would you like? "))
        if hex_num < 4 or hex_num > 20:
            print("Oops, the number of hexagons must be between 4 and 20")
        else:
            break
    return hex_num
#function to prompt for a color choice
def get_color_choice():
    while True:
        print("Legal color choices:")
        print("'purple'")
        print("'green'")
        print("'blue'")
        color_str=input("What color would you like? ")
        if color_str!='purple' and color_str!='green' and color_str!='blue':
            print("Illegal color coice")
        else:
            break
    return color_str
#function to draw one hexagon, starting from the vertex directly
#counterclockwise from the top
def draw_hexagon(x,y,side_len,pen,color):
    pen.speed(1000)
    pen.up()
    pen.goto(x,y)
    pen.down()
    pen.color('black')
    pen.begin_fill()
    pen.left(30)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.color(color)
    pen.end_fill()
    pen.up()
    pen.right(60)
    pen.forward(side_len)
    pen.right(60)
    pen.forward(side_len)
    pen.left(30)
    
x_pos=-250 #initial x position
y_pos=250 #initial y position
num=get_num_hexagons()
column=0
row=0
width=500/num
color_one=get_color_choice()
color_two=get_color_choice()
side=500/(2*num*math.sin(math.pi/3)) #formula for side length
while row<=num:
    #first draw one row
    while column<=num: #start with color one
        draw_hexagon(x_pos,y_pos,side,turtle,color_one)
        column+=1
        if column>=num:
            break
        else: #then color two
            draw_hexagon(x_pos+width,y_pos,side,turtle,color_two)
            x_pos+=2*width
            column+=1
            if column>=num:
                break
        #repeat until end of row
    #now, draw second row indented out
    column=0
    row+=1
    x_pos=-250-width/2 #new x starting position
    y_pos=y_pos-side-math.sqrt(side**2-(width/2)**2) #new y startins pos
    if row==num:
        break
    while column<=num: 
        draw_hexagon(x_pos,y_pos,side,turtle,color_one)
        column+=1
        if column>=num:
            break
        else:
            draw_hexagon(x_pos+width,y_pos,side,turtle,color_two)
            x_pos+=2*width
            column+=1
            if column>=num:
                break
    #prepare for next row to be at original indentation but new y pos
    column=0
    row+=1
    x_pos=-250
    y_pos=y_pos-side-math.sqrt(side**2-(width/2)**2)
    if row==num:
        break
    
    
    

        
