#proj11
#section1
import urllib.request

class Tour(object):
    def __init__(self,*dest):
        '''takes any number of cities and creates a trip in the order specified'''
        dest_list=[]
        for element in dest:
            dest_list.append(element)
        self.dest=dest_list
    def distance(self,mode='driving'):
        '''calculates the distance between each city and adds
           to find distance of trip, default mode is driving'''
        count=0
        num=1
        distance=0
        while num<len(self.dest):
            try:
                start_list=self.dest[count].split()#start with first city in list
                start_list[-2]=start_list[-2][:-1] #remove comma from location
                start_str='+'.join(start_list) #put + where spaces were
                end_list=self.dest[count+1].split() #do same with next city
                end_list[-2]=end_list[-2][:-1] 
                end_str='+'.join(end_list)
                #create URL to send to google
                out_str="http://maps.googleapis.com/maps/api/distancematrix/json?origins="
                out_str+=start_str+"&destinations="
                out_str+=end_str+"&mode="+mode+"&sensor=false"
                web_obj=urllib.request.urlopen(out_str) 
                data=web_obj.read()
                response=data.decode("UTF-8")
                web_obj.close()
                temp_list=response.split('\n') #get rid of carriage return strings
                temp_str=''.join(temp_list)
                temp_list=temp_str.split(':')
                dist_str=temp_list[7] #the index of the distance value
                dist_str=dist_str.split('}')[0] #gets rid of extras at end
                dist_str=dist_str.strip() #get rid of whitespace
                distance+=int(dist_str)
                count+=1
                num+=1
            except IndexError:
                raise ValueError ('No distance found')
        return distance

    def __str__(self):
        '''prints the trip in the form city,state; city,state etc'''
        print_str=''
        count=0
        while count<=len(self.dest)-1:
            print_str+=str(self.dest[count])
            print_str+='; '
            count+=1
        return print_str
    def __repr__(self):
        '''representation in shell same as str'''
        print_str=''
        count=0
        while count<=len(self.dest)-1:
            print_str+=str(self.dest[count])
            print_str+=';'
            count+=1
        return print_str
    def __add__(self,t2):
        '''adds cities of tour to the other tour'''
        t3=Tour()
        for element in self.dest:
            #add cities of first tour to new tour
            t3.dest.append(element)
        for element in t2.dest:
            #add citites of second tour to new tour
            t3.dest.append(element)
        return t3
    def __mul__(self,rhs):
        '''loops the trip however many times specified'''
        if type(rhs)==int:
            if rhs<0:
                raise ValueError ('can only multiply a Tour by a positive int')
            else:
                count=0
                t2=Tour()
                while count<rhs:
                    #repeated addition
                    t2=t2.__add__(self)
                    count+=1
                return t2
        else:
            raise TypeError ('can only multiply a Tour by a positive int')
    def __rmul__(self,rhs):
        '''same as mul'''
        return self.__mul__(rhs)
    def __gt__(self,t2):
        '''conpares distances of two Tours'''
        if self.distance()>t2.distance():
            result=True
        else:
            result=False
        return result
    def __lt__(self,t2):
        '''compares distances of two tours'''
        if self.distance()<t2.distance():
            result=True
        else:
            result=False
        return result
    def __eq__(self,t2):
        '''compares distances of two tours'''
        if self.dest==t2.dest:
            test=True
        else:
            test=False
        return test
        
def main():
    t1=Tour('New York, NY', 'Lansing, MI')
    t2=Tour('Los Angeles, CA', 'Oakland, CA')
    t3=Tour('Asdf, FT','Efgh, KP') #made up cities
    print('t1:',t1)
    print('t1 distance:',t1.distance())
    print('t2:',t2)
    print('t2 distance:',t2.distance())
    print('t1+t2:',t1+t2)
    print('t1+t2 distance:',(t1+t2).distance())
    print('t3:',t3)
    try:#tests raised ValueError in distance method
        print('t3 distance:',t3.distance())
    except ValueError:
        print('t3 distance: No distances found')
    print('3*t1:',3*t1)
    print('t2*2:',t2*2)
    try:#tests ValueError raised in __mul__
        print('-1*t1',-1*t1)
    except ValueError:
        print('-1*t1: not defined, can only multiply a Tour by a positive int')
    try:#tests TypeError raised in __rmul__
        print('t2*abcd:',t2*'abcd')
    except TypeError:
        print('t2*abcd not defined, can only multiply a Tour by a positive int')
    print('t1 > t2 ?',t1>t2)
    print('t1 < t2 ?',t1<t2)
    print('t1 = t2 ?',t1==t2)
    print('t1 = t1 ?',t1==t1)

main()
    
