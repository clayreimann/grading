#proj10
#section1
import turtle
import time

class Star(object):
    def __init__(self,x,y,arm_length,color):
        '''takes x and y coordinate of the center, the length of an arm,
        and the color of the star'''
        self.x=x
        self.y=y
        self.arm_length=arm_length
        self.color=str(color)
    def __str__(self):
        '''prints star in the form x:x center y:y center arm:arm length color:color'''
        print_str='Star x:'+str(self.x)+', y:'+str(self.y)+', arm:'+str(self.arm_length)+', color:'+self.color
        return print_str
    def draw(self,pen=turtle):
        '''draws a star using turtle as the default pen'''
        pen.up()
        pen.goto(self.x+self.arm_length/2.3511,self.y+self.arm_length/3.236)
        #go to the upper right inward vertex
        pen.seth(0) #make pen point right
        pen.down()
        pen.color(self.color)
        pen.fillcolor(self.color)
        pen.begin_fill()
        pen.forward(self.arm_length) #move forward an arm length
        pen.right(144) #turn around point of star
        pen.forward(self.arm_length) #move forward arm length
        pen.left(72)#turn around inward point of star
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.left(72)
        pen.forward(self.arm_length)
        pen.right(144)
        pen.forward(self.arm_length)
        pen.end_fill()
        pen.up()

        

class Rectangle(object):
    def __init__(self,x,y,width,height,color):
        '''takes x and y coordinate of the center,
        the height and width of the rectangle,
        and the color of the rectangle'''
        self.x=x
        self.y=y
        self.width=width
        self.height=height
        self.color=str(color)
    def __str__(self):
        '''prints rectangle in the form x:x center y:y center width:width height:height color:color'''
        print_str='Rectangle x:'+str(self.x)+', y:'+str(self.y)+', width:'+str(self.width)+', height:'+str(self.height)+', color:'+self.color
        return print_str
    def draw(self,pen=turtle):
        '''draws the specified rectangle using turtle as the default pen'''
        pen.up()
        pen.goto(self.x,self.y)
        pen.color(self.color)
        pen.fillcolor(self.color)
        pen.goto(self.x+self.width/2,self.y+self.height/2)
        #goto top right corner of rectangle
        pen.down()
        pen.begin_fill()
        #go to each other corner and then back
        pen.goto(self.x+self.width/2,self.y-self.height/2)
        pen.goto(self.x-self.width/2,self.y-self.height/2)
        pen.goto(self.x-self.width/2,self.y+self.height/2)
        pen.goto(self.x+self.width/2,self.y+self.height/2)
        pen.end_fill()
        pen.up()


class Flag(object):
    def __init__(self, f_obj):
        '''takes an open file object and gathers all the rectangles in a list and all the stars in another'''
        rect_num=int(f_obj.readline()) #number of rectangles in flag
        count=0
        rectangle_list=[]
        while count<rect_num:
            temp_list=f_obj.readline().strip().split(',')
            #make a temporary list of each value in the specified rectangle line
            rectangle_list.append(Rectangle(int(temp_list[0]),int(temp_list[1]),int(temp_list[2]),int(temp_list[3]),temp_list[4].strip()))
            #make a Rectangle of the temp list values and add the rectangle to a list
            count+=1
        star_num=int(f_obj.readline()) #same as rectangles only uses Star class
        count=0
        star_list=[]
        while count<star_num:
            temp_list=f_obj.readline().strip().split(',')
            star_list.append(Star(int(temp_list[0]),int(temp_list[1]),int(temp_list[2]),temp_list[3].strip()))
            count+=1
        self.rectangles=rectangle_list 
        self.stars=star_list
    def draw(self,pen=turtle):
        '''draws the rectangles and stars as specified in their classes using turtle as default'''
        for element in self.rectangles: #draw each rectangle
            element.draw()
        for element in self.stars: #draw each star
            element.draw()
    def __str__(self):
        '''returns one multiline string in the form
            Rectangles
            string information from each rectangle
            Stars
            string information from each star'''
        print_list=['Rectangles']
        for element in self.rectangles:
            element_list=str(element).split(' ')
            #turn each rectangle into a list of elements
            element_list.pop(0)
            #take off the 'Rectangle' at the begining of each rectangle string
            new_str=''
            for element in element_list: #make each rectangle a string again
                new_str+=element
            print_list.append('\n') #add a carriage return
            print_list.append(new_str)#add the string of rectangle info
        print_list.append('\n')
        print_list.append('Stars') 
        for element in self.stars: #repeat procedure with stars
            element_list=str(element).split(' ')
            element_list.pop(0)
            new_str=''
            for element in element_list:
                new_str+=element
            print_list.append('\n')
            print_list.append(new_str)
        print_str=''
        for element in print_list: #turn the print list into a string
            print_str+=element
        return print_str

def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print('Senegal Flag')
    print(senegal_flag)
    print(' ')
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print('Panama Flag')
    print(panama_flag)
    print('')
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)
    turtle.clearscreen()
    my_file=open('myFlag.txt')
    my_flag=Flag(my_file)
    print('Revolutionary War Flag')
    print(my_flag)
    my_flag.draw(pen)
    my_file.close()
    
    
