#proj07
#section01
import string
import random

def scramble_word(word_str):
    if len(word_str)<=3: #dont need to scramble if 3 letters
        new_word=word_str
    else:
        letter_list=[]
        for letter in word_str: #put the word into a list of its letters
            letter_list+=letter
        start_list=[]
        end_list=[]
        if letter_list[0] in string.ascii_letters: #if word start with letter
            start_list.append(letter_list[0])
            letter_list.pop(0)
        else: #if word starts with punctuation
            while letter_list[0] not in string.ascii_letters: 
                start_list.append(letter_list[0]) #add punctuation to new list
                letter_list.pop(0) #remove punctuation from old list
                if letter_list[0] in string.ascii_letters: #take first letter too
                    start_list.append(letter_list[0])
                    letter_list.pop(0)
                    break
        count=0
        while count<=len(letter_list)-1:
            if letter_list[count] not in string.ascii_letters:
                break #find the index of first punctuation
            else:
                count+=1
        if count==len(letter_list): #if there wasnt any punctuation
            end_list.append(letter_list[count-1]) #add last letter to new list
            letter_list.pop(count-1)#remove last letter from old list
        else: #if there was punctuation       
            count-=1  #include letter before
            while count<=len(letter_list)-1:
                end_list.append(letter_list[count]) #add last letter and punctuation to new list
                letter_list.pop(count) #remove from old list
        random.shuffle(letter_list) #scramble middle characters
        for element in letter_list: #add scrambled middle to start
            start_list.append(element)
        for thing in end_list:
            start_list.append(thing) #add end
        new_word=''.join(start_list) #make into a string
    return new_word

def scramble_line(line_str):
    line_list=line_str.split(' ') #make line into list of words
    new_list=[]
    for word in line_list:
        new_list.append(scramble_word(word)) #add scrambled word to new list
    new_line=' '.join(new_list) #make new line into string
    return new_line

def open_read_file(file_name_str):
    while True:
        try:
            in_obj=open(file_name_str, 'r') 
            break
        except (IOError, OSError): #checks for invalid file names
            print("Invalid file name")
            print('Open what file? ')
    return in_obj

def main():
    out_name=input('Open what file to write? ') 
    out_obj=open(out_name, 'w')
    in_name=input('Open what file to read? ')
    file_obj=open_read_file(in_name)
    for line in file_obj:
        out_obj.write(scramble_line(line)) #write scrambled line to new doc
    file_obj.close()
    out_obj.close()
                    
