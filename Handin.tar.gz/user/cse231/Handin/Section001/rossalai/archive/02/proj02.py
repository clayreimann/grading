#Proj02
#Section 1
#1/17/13

print("The object of this game is to enter a six digit number where the")
print("digits of the number represent the letters in'SLAYER'such that:")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print("Good luck!")

try:
    num = int(input("Please enter a guess for 'SLAYER': "))
    r_int = num%10 #this is the one's digit of 'SLAYER'
    e_int = (num//10)%10 
    y_int = (num//100)%10
    a_int = (num//1000)%10
    l_int = (num//10000)%10
    s_int = (num//100000)%10
    if num*3 == 100000*l_int + 10000*a_int + 1000*y_int + 100*e_int + 10*r_int + s_int :
        print("Your guess is correct!")
        print(num, "+", num, "+", num, "=", num*3)
        print("SLAYER + SLAYER + SLAYER = LAYERS")
    elif num < 100000: #checks for 6 digit number
        print("Please enter a 6 digit number")
    else:
        print("Sorry, your guess is incorrect")
        print(num, "+", num, "+", num, "=", num*3)
        print("LAYERS = ",100000*l_int + 10000*a_int + 1000*y_int + 100*e_int + 10*r_int + s_int)
except (ValueError): #if user enters something other than numbers
    print("Please enter an integer")
