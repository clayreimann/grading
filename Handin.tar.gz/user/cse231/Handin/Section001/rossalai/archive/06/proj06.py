#proj06
#section01
def get_input_descriptor():
    while True:
        try:
            in_name=input("Open what file to read: ")
            in_obj=open(in_name, 'r') #in_obj is the file object
            break
        except (IOError, OSError): #checks for invalid file names
            print("Invalid file name")
    return in_obj

def get_data_list(file_object, column_number):
    my_list=[]
    for line in file_object:
        line=line.strip()
        if line=='':
            print('') #ignoring any empty lines
        if line=='Date,Open,High,Low,Close,Volume,Adj Close':
            print('') #ignoring first line with titles
        else:
            line_list=line.split(',') #splits by commas
            my_tupple=(line_list[0],line_list[column_number]) #date and value tupple
            my_list.append(my_tupple) #add tupple to list
    return my_list

def average_data(list_of_tupples):
    new_list=[]
    count=0 #counts through each value in the list
    summation=0 #this will be the values added
    total=0 #total number of values each month
    while count<=len(list_of_tupples)-1:
        if count==len(list_of_tupples)-1: #for the last value
            total+=1
            summation+=float(list_of_tupples[count][1])
            count+=1
            avg=round(summation/total,2)
            year=list_of_tupples[count-1][0][:4]
            month=list_of_tupples[count-1][0][5:7]
            date=month+':'+year
            new_list.append((avg,date))
        elif list_of_tupples[count][0][:7]==list_of_tupples[count+1][0][:7]:
           #if the date is the same as the next date
           total+=1
           summation+=float(list_of_tupples[count][1])
           count+=1
           avg=summation/total
        elif list_of_tupples[count][0][:7]!=list_of_tupples[count+1][0][:7]:
            #for the last value of the month
            total+=1
            summation+=float(list_of_tupples[count][1])
            avg=round(summation/total,2)
            year=list_of_tupples[count][0][:4]
            month=list_of_tupples[count][0][5:7]
            date=month+'-'+year
            new_list.append((avg,date))
            total=0 #reset monthly total
            summation=0 #reset monthly sum
            count+=1
            continue
    return new_list

def find_highest(tupple_list): #finds largest value in the average list
    high_val=0
    for element in tupple_list:
        if element[0]>high_val:
            high_val=element[0]
            high_date=element[1]
    return (high_val,high_date)

def find_lowest(tupple_list): #finds lowest value in the average list
    low_val=float('inf')
    for element in tupple_list:
        if element[0]<low_val:
            low_val=element[0]
            low_date=element[1]
    return (low_val,low_date)

def main():
    filename=get_input_descriptor()
    while True:
        col_num=int(input("Average what column: "))
        if col_num <=6 and col_num >=1: #makes sure only cols 1-6
            break
        else:
            print('Invalid column')
    data_list=get_data_list(filename, col_num)
    avg_list=average_data(data_list)
    
    hi_tup_one=find_highest(avg_list)#finds highest avg
    avg_list.remove(hi_tup_one) #removes highest avg from list
    hi_tup_two=find_highest(avg_list) #finds next highest avg
    avg_list.remove(hi_tup_two)
    hi_tup_three=find_highest(avg_list)
    avg_list.remove(hi_tup_three)
    hi_tup_four=find_highest(avg_list)
    avg_list.remove(hi_tup_four)
    hi_tup_five=find_highest(avg_list)
    avg_list.remove(hi_tup_five)
    hi_tup_six=find_highest(avg_list)
    avg_list.remove(hi_tup_six)

    lo_tup_one=find_lowest(avg_list) #same as highest, only using low func
    avg_list.remove(lo_tup_one)
    lo_tup_two=find_lowest(avg_list)
    avg_list.remove(lo_tup_two)
    lo_tup_three=find_lowest(avg_list)
    avg_list.remove(lo_tup_three)
    lo_tup_four=find_lowest(avg_list)
    avg_list.remove(lo_tup_four)
    lo_tup_five=find_lowest(avg_list)
    avg_list.remove(lo_tup_five)
    lo_tup_six=find_lowest(avg_list)
    avg_list.remove(lo_tup_six)

    print('Lowest 6 for column '+str(col_num))#printing 6 lowest vals
    print('Date:{}, Value:{}'.format(lo_tup_one[1],lo_tup_one[0]))
    print('Date:{}, Value:{}'.format(lo_tup_two[1],lo_tup_two[0]))
    print('Date:{}, Value:{}'.format(lo_tup_three[1],lo_tup_three[0]))
    print('Date:{}, Value:{}'.format(lo_tup_four[1],lo_tup_four[0]))
    print('Date:{}, Value:{}'.format(lo_tup_five[1],lo_tup_five[0]))
    print('Date:{}, Value:{}'.format(lo_tup_six[1],lo_tup_six[0]))
    print(' ')
    print('Highest 6 for column '+str(col_num))#printing 6 highest vals
    print('Date:{}, Value:{}'.format(hi_tup_one[1],hi_tup_one[0]))
    print('Date:{}, Value:{}'.format(hi_tup_two[1],hi_tup_two[0]))
    print('Date:{}, Value:{}'.format(hi_tup_three[1],hi_tup_three[0]))
    print('Date:{}, Value:{}'.format(hi_tup_four[1],hi_tup_four[0]))
    print('Date:{}, Value:{}'.format(hi_tup_five[1],hi_tup_five[0]))
    print('Date:{}, Value:{}'.format(hi_tup_six[1],hi_tup_six[0]))
    
