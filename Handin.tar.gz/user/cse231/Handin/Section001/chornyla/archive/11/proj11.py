import urllib.request
import string

class Tour(object):
    '''Class to get the distance of a Tour'''
    def __init__(self, *dest):
        '''Initializes the destinations'''
        print('in init')
        
        ## initializes the destination into a list format
        self.dest = []
        if dest:
            if type(dest[0]) == list:
                for item in dest[0]:
                    self.dest.append(item)
            elif dest:
                for i in range(0,len(dest)):
                    self.dest.append(dest[i])
            self.tot_dist = 0
    def distance(self, mode = 'driving'):
        '''gets the distance of the trip'''
        print('in distance')

        ## formulates the distances between two cities of the trip at a time
        cnt1 = 0
        cnt2 = 1
        cnt = 0
        try:
            if len(self.dest) >= 2:
                while cnt2 < len(self.dest):
                    dest1 = self.dest[cnt1]
                    dest2 = self.dest[cnt2]
                    
                    dest1_list = dest1.split()
                    dest2_list = dest2.split()
                    
                    cnt = 0
                    for item in dest1_list:
                        dest1_list[cnt] = item.strip()
                        dest1_list[cnt] = item.strip(string.punctuation)
                        cnt += 1
                    cnt = 0
                    for item in dest2_list:
                        dest2_list[cnt] = item.strip()
                        dest2_list[cnt] = item.strip(string.punctuation)
                        cnt += 1

                    dest1 = '+'.join([i for i in dest1_list])
                    dest2 = '+'.join([i for i in dest2_list])
                    web_url_str = "http://maps.googleapis.com/maps/api/distancematrix/json?origins={:s}&destinations={:s}&mode={:s}&sensor=false".format(dest1,dest2,mode)
                    web_obj = urllib.request.urlopen(web_url_str)
                    web_url = str(web_obj.read())
                    web_obj.close()

                    web_url_list = web_url.split('"')
                    dist = web_url_list[20]
                    distance = ''
                    for i in dist:
                        if i.isdigit():
                            distance = distance + i
                    self.tot_dist += int(distance)
                    cnt1 += 1
                    cnt2 += 1
                return self.tot_dist
            else:
                ## an error is raised if a distance cannot be calculated
                raise ValueError('No possible distance.')
        except AttributeError:
            ## an error is raised if a distance cannot be calculated
            raise ValueError('No possible distance.')
    def __str__(self):
        '''displays the cities in the trip'''
        print('in str')
        ## returns the string of the destinations of the trip in order
        result_str = ''
        cnt = 0
        if self.dest:
            for item in self.dest:
                if cnt == 0:
                    result_str = item
                elif cnt != len(self.dest):
                    result_str = result_str + '; ' + item
                else:
                    result_str = result_str + item
                cnt += 1
        else:
            result_str = 'No cities listed.'
        return result_str
    def __repr__(self):
        '''displays the cities in the trip'''
        print('in repr')
        ## returns the string of the destinations of the trip in order
        result_str = ''
        cnt = 0
        try:
            for item in self.dest:
                if cnt == 0:
                    result_str = item
                elif cnt != len(self.dest):
                    result_str = result_str + '; ' + item
                else:
                    result_str = result_str + item
                cnt += 1
        except AttributeError:
            result_str = 'No cities listed'
        return result_str
    def __add__(self, new_trip):
        '''concatenates a tour onto the end of another'''
        print('in add')

        ## appends a new trip into the original tour
        dest_list = []
        for item in self.dest:
            dest_list.append(item)
        for item in new_trip.dest:
            dest_list.append(item)
        return Tour(dest_list)
    def __mul__(self,num):
        '''multiplies the tour by an integer'''
        print('in mul')

        ## multiplies the tour by an integer
        cnt = 0
        if type(num) == int and num > 0:
            dest_list = []
            while cnt < num:
                for item in self.dest:
                    dest_list.append(item)
                cnt += 1
        elif type(num) != int:
            raise TypeError('Cannot multiply by a non-integer')
        elif int(num) < 0:
            raise ValueError('Cannot multiply trip by a negative integer')
        print(dest_list)
        return Tour(dest_list)
    def __rmul__(self, num):
        ## self-checks to multiply the destinations by an integer
        '''makes sure the tour is multiplied by integer'''
        print('in rmul')
        return self.__mul__(num)
    def __gt__(self, new_tour):
        '''returns whether this tour is longer than another'''
        print('in gt')

        ## checks if this tour is longer than another
        if type(new_tour) == Tour:
            if self.distance() > new_tour.distance():
                return True
            elif self.distance() == new_tour.distance():
                return False
            else:
                return False
    def __lt__(self, new_tour):
        '''returns whether this tour is shorter than another'''
        print('in lt')

        ## checks if this tour is shorter than another
        if type(new_tour) == Tour:
            if self.distance() < new_tour.distance():
                return True
            elif self.distance() == new_tour.distance():
                return False
            else:
                return False
    def __eq__(self, new_tour):
        '''returns whether this tour is equal to another'''
        print('in eq')

        ## checks if this tour is equal to another
        cnt = 0
        if len(self.dest) == len(new_tour.dest):
            if self.dest == new_tour.dest:
                return True
            else:
                return False
        else:
            return False
        

def main():
    '''main function tests out each property of the class'''

    ## defines the tours
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")

    ## tests the modes
    print("t1: {}\nt2:{}\nt3:{}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000), round(t1.distance('bicycling')/1000), round(t1.distance('walking')/1000)))

    ## tests the classes
    print("Using driving distances from here on.")
    t4 = t1 + t2
    t5 = t1 + t2
    t6 = t4 > t5
    t7 = t1 > t3
    t8 = t1 < t3
    print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t4 == t1 + t2:", t4 == t1 + t2)
    print("t6 = t4 > t5:", t6)
    print("t7 = t1 > t3:", t7)
    print("t8 = t1 < t3:", t8)
    print("t3 * 3:", t3 * 3)
    print("3 * t3:", 3 * t3)

    t9 = Tour()
    t10 = -3 * t1

    ''' comment out all lines but one at a time to test the errors '''
    #print('t2 distance:', t2.distance())  ## no distance given, one argument included
    #print('t9 distance:', t9.distance())  ## no distance given, no argument included
    #print('t9:', t9)  ## no cities listed, no argument included
    #print('t1 * t2:', t1 * t2)  ## cannot multiply tour by a non-integer
    #print(t10)  ## cannot multiply tour by a negative integer

main()
