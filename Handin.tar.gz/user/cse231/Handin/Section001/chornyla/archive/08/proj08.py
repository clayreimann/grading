# Project 8
# Lauren Chorny
# Section 1
# March 14, 2013

# imports the string function
import string

# defines function to fill the completions dictionary
def fill_completions(c_dict, fd):
    my_set = set()
    # goes through each line of the file
    for line in fd:
        # strips line of whitespace and punctuaton
        line = line.strip()
        line = line.strip(string.punctuation)
        # splits line into list of words
        word_list = line.split()

        # iterates through the words in the line
        for word in word_list:
            # strips words of punctuation
            word = word.strip(string.punctuation)
            # makes words lowercase
            word = word.lower()
            # strips words of digits
            word = word.strip(string.digits)
            # enumerates the word into a list of position and the letter
            dict_list = list(enumerate(word))

            # gets the length of the list
            index = len(dict_list) - 1

            # iterates through each letter
            cnt = 0
            while cnt < index:
                # checks if the value in that position is in the dictionary
                if dict_list[cnt] in c_dict:
                    # adds the word to the dictionary
                    value = c_dict[dict_list[cnt]]
                    value.add(word)
                    c_dict[dict_list[cnt]] = value
                else:
                    # adds the key and word to the dictionary
                    value = set()
                    value.add(word)
                    c_dict[dict_list[cnt]] = value
                cnt += 1

# defines function to find the completion for the prefix           
def find_completions(prefix, c_dict):
    # enumerates the prefix
    new_list = list(enumerate(prefix))
    
    new_set = set()

    main_set = set()

    # finds the length of the word
    index = len(new_list)

    # iterates through the range of the length of the word
    for k in range(0,index):
        if k == 0:
            # only iterates through if it is the first time
            # see if key is in c_dict
            if new_list[k] in c_dict:
                new_set1 = c_dict[new_list[k]]
            # see if key is in c_dict
            if new_list[k+1] in c_dict:
                new_set2 = c_dict[new_list[k+1]]
            # compares the first two sets from c_dict
            new_set = new_set1 & new_set2
        else:
            # if it's already been compared once, do this
            # see if key is in c_dict
            if new_list[k] in c_dict:
                new_set1 = c_dict[new_list[k]]
            # compares the new set from c_dict to the set created from last comparison
            new_set = new_set & new_set1

    # returns the value of the new compared set
    return new_set

# defines the main function
def main():
    # opens the file to get the words for the dictionary
    fd = open('ap_docs.txt', 'r')
    c_dict = {}

    # calls the fill_completions file
    fill_completions(c_dict, fd)

    # while the user wants to input a prefix, the loop will run
    while True:
        # inputs user for prefix
        prefix = input("Please input a prefix, # to stop: ")
        if prefix == '#':
            break
        else:
            # calls the find_completions function if the user entered a prefix
            new_set = find_completions(prefix, c_dict)

        # if there are no completions, outputs to the user
        if new_set == set():
            print("That prefix has no completions.")
        else:
            # prints the words completed
            print("Words that complete the prefix:")
            print(new_set)

    # closes the file
    fd.close()
    
# calls the main function
main()
