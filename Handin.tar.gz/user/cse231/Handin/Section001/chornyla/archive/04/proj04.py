# Project 4

str1 = input("Input a string of DNA (consists of 'A', 'T', 'C', or 'G'): ") 
str2 = input("Input a string of DNA (consists of 'A', 'T', 'C', or 'G'): ")

prompt_str = ' '

print("\n")
print("Species 1: ", str1)
print("Species 2: ", str2)

while prompt_str != 'q':
    print("\na (add indel)\nd (delete indel)\ns (score)\nq (quit)\n")
    prompt_str = input("What do you want to do: ")

    if prompt_str == 'a':
        work_str = input("Work on which species (1 or 2): ")

        index_str = input("Before what index: ")
        index = int(index_str)

        if work_str == '1':
            if index < len(str1):
                str1 = str1[:index] + '-' + str1[index:]
            else:
                print("\nERROR: NO SUCH INDEX")
        elif work_str == '2':
            if index < len(str2):
                str2 = str2[:index] + '-' + str2[index:]
            else:
                print("\nERROR: NO SUCH INDEX")
        else:
            print("\nERROR: NO SUCH SPECIES")
    elif prompt_str == 'd':
        work_str = input("Work on which species (1 or 2): ")

        index_str = input("Before what index: ")
        index = int(index_str)

        if work_str == '1':
            if index < len(str1) and str1[index] == '-':
                temp_index = index + 1
                str1 = str1[:index] + str1[temp_index:]
            else:
                ("\nERROR: NO SUCH INDEX OR NO INDEL")
        elif work_str == '2':
            if index < len(str2) and str2[index] == '-':
                temp_index = index + 1
                str2 = str2[:index] + str2[temp_index:]
            else:
                print("\nERROR: NO SUCH INDEX OR NO INDEL")
        else:
            print("\nERROR: NO SUCH SPECIES")

    elif prompt_str == 's':
        index = 0
        matches = 0
        mismatches = 0
        str_cpy1 = ''
        str_cpy2 = ''
        str1 = str1.upper()
        str2 = str2.upper()
        
        if len(str1) < len(str2):
            while len(str1) < len(str2):
                str1 = str1 + '-'
        elif len(str1) >len(str2):
            while len(str1) > len(str2):
                str2 = str2 + '-'
            
        for char in str1:
            if char == str2[index]:
                str_cpy1 = str_cpy1 + char.lower()
                str_cpy2 = str_cpy2 + char.lower()
                matches += 1
            else:
                cap_index = index + 1
                str_cpy1 = str_cpy1 + char.upper()
                str_cpy2 = str_cpy2 + str2[index].upper()
                mismatches += 1
            index += 1
            
        str1 = str_cpy1
        str2 = str_cpy2

        print("\nMatches: ", matches, "   Mismatches: ", mismatches)
        print("\nSpecies 1: ", str1)
        print("Species 2: ", str2)
    else:
        print("\nERROR: FUNCTION UNKNOWN")
    
        
        
