###################################################################################
# CSE 231 Section 1
# Project 2
#
# Algorithm
#  1. Prompt for a six-digit integer
#  2. Input a six-digit integer
#  3. If it is not a six-digit integer, end the game.
#  4. If it is, find if SLAYER + SLAYER + SLAYER = LAYERS
#     a. If this is true, tell them they're correct, display the values
#     b. If it is false, tell them they're incorrect, display the values
###################################################################################

value_str = input("Guess a six-digit number SLAYER so that the following"
                  " equation is true,          where each letter stands for the"
                  " digit in the position shown:          SLAYER + SLAYER + SLAYER ="
                  " LAYERS       ")             # Prompt user for integer, input the value

value_int = int(value_str)                      

if value_int < 100000 or value_int > 999999:    # End the game if not a six-digit integer
    print("SLAYER must be a six-digit integer. Thanks for playing.")
else:
    s_ones_int = int(value_int // 100000)       # Isolate the S in SLAYER
    s_int = s_ones_int * 100000                 # Give the proper place value
    
    layer_int = (value_int - s_int) * 10        # Shift LAYER to LAYER0

    layers_int = layer_int + s_ones_int         # Make LAYERS

    slayer_int = 3 * value_int                  # SLAYER + SLAYER + SLAYER

    if slayer_int == layers_int:                # If they're equal, display correct
        print("Your guess is correct:")
        print("SLAYERS + SLAYERS + SLAYERS = ",slayer_int)
        print("LAYERS = ",layers_int)
        print("Thanks for playing.")
    else:                                       # If they're not equal, display incorrect
        print("Your guess is incorrect:")
        print("SLAYERS + SLAYERS + SLAYERS = ", slayer_int)
        print("LAYERS = ", layers_int)
        print("Thanks for playing.")
    
    


