# proj01.py - Richter Scale
# input a number, convert to joules, convert to tons of TNT
# Lauren Chorny, 1/9/13

richter_str = input("Input a Richter scale value (1-10): ")
richter_float = float(richter_str)

energy_float = 10 ** (1.5*richter_float + 4.8)

tnt_float = energy_float/4.184e9

print("Richter scale value: ", richter_float)
print("Value in joules: ", energy_float)
print("Value in Tons of TNT", tnt_float)

e_float1 = 10 ** (1.5 + 4.8)
e_float5 = 10 ** (1.5*5 + 4.8)
e_float91 = 10 ** (1.5*9.1 + 4.8)
e_float92 = 10 ** (1.5*9.2 + 4.8)
e_float95 = 10 ** (1.5*9.5 + 4.8)

print("Richter      Joules                  TNT            ")
print("1       ", e_float1,"     ", e_float1/4.184e9)
print("5       ", e_float5,"     ", e_float5/4.184e9)
print("9.1     ", e_float91,"  ", e_float91/4.184e9)
print("9.2     ", e_float92,"  ", e_float92/4.184e9)
print("9.5     ", e_float95," ", e_float95/4.184e9)
