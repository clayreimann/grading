# Project 7

# import functions
import random
import string

# define the function to open a file to read
def open_read_file(file_name_str):
    opened_file_bool = False

    # while the file does not exist, prompts user for file name
    while not opened_file_bool:

        # see if the file creates an error
        try:
            # no error, skips except
            file_obj = open(file_name_str, 'r')
            opened_file_bool = True

        # if error, reprompts user for file name
        except IOError:
            file_name_str = input("Bad file name, try again. ")

    # returns the file to the main function 
    return file_obj

# defines the function to get the line to scramble
def scramble_line(line_str):
    new_line_list = []

    # removes the whitespace from the beginning and end of line
    line_str = line_str.strip()

    # splits line into words
    word_str = line_str.split()

    # goes through the words in the line and calls the scramble function
    for word in word_str:

        # calls the scramble function, returns the new word
        new_word_str = scramble_word(word)

        # appends the new word to the new list of words
        new_line_list.append(new_word_str)

    
    # converts the list into a string
    new_line_str = ' '.join(new_line_list)

    # returns the new line as a string to the main function 
    return new_line_str
                
# defines the function to scramble the word
def scramble_word(word_str):
    # converts the word into a list of letters
    letters_list = list(word_str)
    # gets the length of the word
    str_len = len(word_str)
    # gets the index of the letters
    index = str_len - 1

    # checks if the word is longer than one letter
    if index != 0:

        # checks if the first character is punctuation 
        if letters_list[0] in string.punctuation:
            # removes punctuation, saved to add later
            first_punct = letters_list[0]
            letters_list.pop(0)
            index -= 1

        # checks of the last character is punctuation
        if letters_list[index] in string.punctuation:
            # removes punctuation, saved to add later
            last_punct = letters_list[index]
            letters_list.pop()
            index -= 1

        # goes through the letters to remove an apostrophe from contraction
        cnt = 0
        for letter in letters_list:
            # checks if letter is an apostrophe
            if letter is "'":
                # finds the index of the apostrophe to add later
                # removes the apostrophe
                index1 = cnt
                letters_list.pop(index1)
                index -= 1
            cnt += 1

        # checks if the first and last letters exist
        try:
            # finds the first and last letters, save to add later
            first_letter = letters_list[0]
            last_letter = letters_list[index]

            # removes the first and last letter
            letters_list.pop()
            letters_list.pop(0)

            # shuffle the letters that remain
            random.shuffle(letters_list)

            # adds the first and last letters back into the list
            letters_list.insert(0,first_letter)
            letters_list.append(last_letter)
        # if there is an index error, there is no scrambling
        except IndexError:
            'do nothing'

        # checks if there is a value stored as a punctuation at the beginning
        try:
            # if there is a value, the punctuation is reinserted at beginning
            letters_list.insert(0,first_punct)
        # if there is nothing stored, nothing is done
        except UnboundLocalError:
            'do nothing'

        # checks if there is a value stored as a punctuation at the end
        try:
            # if there is a value, the punctuation is appended
            letters_list.append(last_punct)
        # if there is nothing stored, nothing is done
        except UnboundLocalError:
            'do nothing'

        # checks if there is an apostrophe stored at specific index
        try:
            # if there is an apostrophe, it is reinserted in the same place
            letters_list.insert(index1, "'")
        # if there is no apostrophe, nothing is done
        except UnboundLocalError:
            'do nothing'

    # converts from list to string          
    new_word_str = ''.join(letters_list)

    # returns the new scrambled word to the scramble_line function
    return new_word_str
    

# defines the main function
def main():
    # prompts user for a file to read
    file_read_str = input("What file would you like to open to read? ")

    # checks for a file to write, error check 
    opened_file_bool = False
    while not opened_file_bool:
        file_write_str = input("What file would you like to open to write? ")
        try:
            file_write_obj = open(file_write_str, 'w')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again.")

    # calls the open_read_file function to open the file_read_str
    file_read_obj = open_read_file(file_read_str)

    # retrieves the lines from the file object
    for line_str in file_read_obj:
        # calls the scramble_line function, returns the new line
        new_line_str = scramble_line(line_str)
        # writes the new line into the file to write
        file_write_obj.write(new_line_str)

    # closes the files
    file_write_obj.close()
    file_read_obj.close()

# calls the main function to run the program       
main()
