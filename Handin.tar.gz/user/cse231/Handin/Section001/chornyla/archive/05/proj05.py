# Project 5

# import the turtle functions to draw
import turtle

# a function to find the color choice
def get_color_choice():
    print("Choices for color use are:\n   red\n   blue\n   green\n   yellow\n",
      "  orange\n   purple\n   pink\n")         # shows the color choices
    color_str = input("Please enter your choice: ")     # prompt for choice
    while True:  # goes through until a choice is valid
        if color_str == 'red' or color_str == 'blue' or color_str == 'green' or color_str == 'yellow' or color_str == 'orange' or color_str == 'purple' or color_str == 'pink':
            return color_str        # returns the choice
            break
        else:
            print("'", color_str, "' is not a legal choice.", end='')
            color_str = input(" Please try again: ")    # checks for the right input

# a function to find the number of hexagons per row/column
def get_num_hexagons():
    hex_str = input("Please enter a number of hexagons per row: ")  # prompt
    while True:
        if hex_str.isdigit():   # if the string is a digit, follows through commands
            hex_int = int(hex_str)
            if hex_int < 4 or hex_int > 20:     # checks if it is between 4 and 20
                hex_str = input("It should be between 4 and 20. Please try again: ")
            else:
                return hex_int    # returns the number of hexagons as an integer
                break
        else:       # if the string is not an integer, it re-asks
            hex_str = input("That is not a digit. Please try again: ")
            
# a function to draw the hexagon
def draw_hexagon(x, y, side_len, pen, color):
    pen.fillcolor(color)    # sets the fill color for what is drawn
    pen.begin_fill()        # begins where the fill begins
    pen.up()                # pen is up
    pen.goto(x,y)           # takes the turtle to a specific place
    pen.down()              # pen is down
    pen.seth(30)            # sets the direction of the turtle
    for i in range(6):          # goes through six sides to draw the hexagon
        pen.forward(side_len)
        pen.right(60)
    pen.end_fill()          # fills what was just drawn
    pen.up()

import math
color_str1 = get_color_choice()     # gets the first color
color_str2 = get_color_choice()     # gets the second color

hex_int = get_num_hexagons()        # gets the number of hexagons
hex_row = hex_int

x = 0    # sets the x value
y = 0    # sets the y value

# draws the hexagons
while hex_row > 0:
    hex_col = hex_int
    
    if hex_row % 2 == 0:    # if it's an even row, goes to a spot more indented
        x = 30*math.cos(math.pi/6)
        y += 30*math.sin(math.pi/6) + 30
    else:                   # goes to the other spot more left
        x = 0
        y += 30*math.sin(math.pi/6) + 30
        
    while hex_col > 0:      # draws the number of rows 
        draw_hexagon(x,y,30,turtle,color_str1)
        turtle.seth(0)
        x += 60*math.cos(math.pi/6)
        hex_col -= 1
        if hex_col > 0:
            draw_hexagon(x,y,30,turtle,color_str2)
            x += 60*math.cos(math.pi/6)
            hex_col -= 1
        else:
            break
        
    hex_row -= 1
                



