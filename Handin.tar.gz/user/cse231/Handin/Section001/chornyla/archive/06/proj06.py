# function to get the file
def get_input_descriptor():

    # while the file is non-existent, keeps prompting the user
    opened_file_bool = False
    while (not opened_file_bool):
        file_str = input("What file would you like to open to read? ")
        try:
            file_read_obj = open(file_str, 'r')
            opened_file_bool = True
        except IOError:
            print("Bad file name, try again.")

    # return the file object
    return file_read_obj

# function to get the data from the column
def get_data_list(file_obj, column_num):

    # for each line in the string, get out the element from the column
    cnt = 1
    average_list = []
    for line_str in file_obj:
        if cnt > 1:
            line_str = line_str.strip()
            element_list = line_str.split(',')
            element_tuple = element_list[0], element_list[column_num]
            average_list.append(element_tuple)
        cnt += 1

    average_list.sort()

    # return the list of the columns to average
    return average_list

# function to average the data of each month 
def average_data(list_of_tuples):
    average_list = []
    cnt = 1
    total = 0
    cnt2 = 0
    for element in list_of_tuples:
        date = str(element[0])
        
        date = date.split('-')
        month1 = date[1]
        year1 = date[0]


        # if the program has gone through once, then this statement is completed
        if cnt != 1:
            # if the months are the same and the years are the same, the
            # data is compiled together to find the average
            if month1 == month2 and year1 == year2:
                cnt2 += 1
                data = float(element[1])
                total += data
            # if the dates are no longer the same, average the data
            else:
                cnt2 += 1
                date_str = str(month2) + ':' + str(year2)
                average = round(float(total/cnt2),2)
                average_tuple = date_str, average
                average_list.append(average_tuple)
                cnt2 = 0
                total = 0
                cnt = 1
        
        cnt += 1
        month2 = date[1]
        year2 = date[0]

    # add the data for the last element of the list to the average
    cnt2 += 1
    total += float(element[1])
    date_str = str(month2) + ':' + str(year2)
    average = round(float(total/cnt2),2)
    average_tuple = date_str, average
    average_list.append(average_tuple)
        
    return average_list

# definition of the main function that calls the other functions
def main():

    # call the function to get the file object
    file_read_obj = get_input_descriptor()
 
    # input the user for the column number they'd like to average
    while True:
        column_number = input("Which column would you like to average(1 to 6)? ")
        if column_number < '1' or column_number > '6':
            print("Unable to output that column number.")
        else:
            column_number = int(column_number)
            break

    # call the function to get the data from the correct column
    element_list = get_data_list(file_read_obj, column_number)

    # call the function to average the data from the column
    average_list = average_data(element_list)

    # get only the data without the date
    data_list = []
    for element in average_list:
        data = element[1]
        data_list.append(data)

    # find the lowest 6 and highest 6
    cnt = 0
    max_list = []
    min_list = []
    while cnt < 6:
        max_num = max(data_list)
        index = data_list.index(max_num)
        data = average_list[index]
        data_list.pop(index)
        average_list.pop(index)
        max_list.append(data)

        min_num = min(data_list)
        index = data_list.index(min_num)
        data = average_list[index]
        data_list.pop(index)
        average_list.pop(index)
        min_list.append(data)
        
        cnt += 1

    # print the lowest 6 and highest 6
    print("\n")
    print("Lowest 6 for Column", column_number, ":")
    for element in min_list:
        date = element[0]
        data = element[1]
        print("Date: ", date, " Value: ", data)


    print("\n")
    print("Highest 6 for Column ", column_number, ":")
    for element in max_list:
        date = element[0]
        data = element[1]
        print("Date: ", date, " Value: ", data)

    # close the file
    file_read_obj.close()

# call the main function 
main()  
