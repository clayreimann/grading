## Project 10
## April 7, 2013
## Section 001

## import modes
import turtle
import string
import time

## reads the lines of the files
def readline(f_obj):
'''reads each line of the file object to create the lists of
    rectangles and stars '''
    
    cnt = 0
    index = 0
    rectlist = []
    starlist = []
    for line in f_obj:
        if line:
            line = line.strip()
            w_list = line.split(',')
            length = len(w_list)
            if w_list:
                if cnt == 0:
                    number = int(w_list[0])
                if cnt > 0:
                    if cnt <= number:
                        rectlist.append(w_list)
                    elif cnt > (number + 1):
                        starlist.append(w_list)
            cnt += 1
    return rectlist,starlist

## class that gets the stars and rectangles from the rect and star classes
class Flag(object):
    '''Flag class: gets the stars and rectangles from the file,
       draws the flag, and displays each rectangle and star's information'''

##  initializes the Flag
    def __init__(self, f_obj):
        self.f_obj = f_obj
        self.rectlist,self.starlist = readline(f_obj)
##  draws the Flag
    def draw(self, pen):
        for item in self.rectlist:
            if item:
                item[0] = int(item[0])
                item[1] = int(item[1])
                item[2] = int(item[2])
                item[3] = int(item[3])
                item[4] = str(item[4])
                item[4] = item[4].strip()
                rect = Rectangle(item[0],item[1],item[2],item[3],item[4])
            rect.draw(pen)
        for item in self.starlist:
            if item:
                item[0] = int(item[0])
                item[1] = int(item[1])
                item[2] = int(item[2])
                item[3] = str(item[3])
                item[3] = item[3].strip()
                star = Star(item[0],item[1],item[2],item[3])
                star.draw(pen)
##  returns the string of the information about each rectangle and star drawn
    def __str__(self):
        length_rect = len(self.rectlist)
        length_star = len(self.starlist)
        disp_str = 'Rectangles\n'
        for item in self.rectlist:
            if item:
                rect = Rectangle(item[0],item[1],item[2],item[3],item[4])
                disp_str = disp_str + rect.__str__() + '\n'
        disp_str = disp_str + '\nStars\n'
        for item in self.starlist:
            if item:
                star = Star(item[0],item[1],item[2],item[3])
                disp_str = disp_str + star.__str__() + '\n'
        return disp_str

## class that makes the rectangles
class Rectangle(object):
'''initializes the rectangle, displays the rectangles information,
   draws the rectangle'''

##  initializes the rectangle  
    def __init__(self,x,y,width,height,color):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
##  draws the rectangle
    def draw(self, pen):
        pen.up()
        pen.color(self.color)
        pen.goto(self.x-self.width/2,self.y-self.height/2)
        pen.begin_fill()
        pen.seth(90)
        pen.down()
        for i in range(0,2):
            pen.forward(self.height)
            pen.right(90)
            pen.forward(self.width)
            pen.right(90)
        pen.end_fill()
        pen.up()
##  returns the string of the information about the rectangle
    def __str__(self):
        return 'x:{}, y:{}, w:{}, h:{}, c:{}'.format(self.x,self.y,self.width,self.height,self.color)

## class that makes the stars
class Star(object):
'''initializes the star, displays the stars information, draws the star'''

##  initializes the star
    def __init__(self,x,y,arm_length,color):
        self.x = x
        self.y = y
        self.arm_length = arm_length
        self.color = color
##  draws the star
    def draw(self, pen):
        pen.up()
        pen.color(self.color)
        pen.goto(self.x+self.arm_length/3.2361,self.y+self.arm_length/2.3511)
        pen.begin_fill()
        pen.seth(0)
        for i in range(0,5):
            pen.forward(self.arm_length)
            pen.right(144)
            pen.forward(self.arm_length)
            pen.left(72)
        pen.end_fill()
## returns the string of the information about the star
    def __str__(self):
        return 'x:{}, y:{}, a:{}, c:{}'.format(self.x,self.y,self.arm_length,self.color)

## calls all the other classes, draws the flags
def main():
'''main function, calls the classes and prints the flags'''
##  clears the screen, initializes the turtle
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
##  opens the file, calls the Flag class, prints the Flag information
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

## opens the file, calls the Flag class, prings the Flag information
    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()
    
##  opens the file, calls the Flag class, prings the Flag information
    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    my_file = open('myFlag.txt')
    my_flag = Flag(my_file)
    print(my_flag)
    my_flag.draw(pen)
    my_file.close()

main()

