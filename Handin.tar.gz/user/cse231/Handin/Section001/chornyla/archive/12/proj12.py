## Project 12
## Section 1

## import all the necessary methods

import matplotlib as py
import matplotlib.pyplot as plt
import numpy as np
import string
import calendar

## find the high and low temperatures of each month
def hi_lo_temp(f_obj):
    hi_list = []
    lo_list = []
    average_list = []
    temp_list = []
    cnt = 1
    for line in f_obj:
        line.strip()
        ## goes through each line of code, from month to month, and appends
        ## the highest and lowest temperatures into appropriate lists
        if cnt >= 3 and cnt <= 746:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 746:
                highest1 = max(temp_list)
                lowest1 = min(temp_list)
                average1 = (highest1 + lowest1)/2
                average_list.append(average1)
                hi_list.append(highest1-lowest1)
                lo_list.append(lowest1)
                temp_list = []
        elif cnt >= 747 and cnt <= 1442:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 1442:
                highest2 = max(temp_list)
                lowest2 = min(temp_list)
                average2 = (highest2 + lowest2)/2
                average_list.append(average2)
                hi_list.append(highest2-lowest2)
                lo_list.append(lowest2)
                temp_list = []
        elif cnt >= 1443 and cnt <= 2186:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 2186:
                highest3 = max(temp_list)
                lowest3 = min(temp_list)
                average3 = (highest3 + lowest3)/2
                average_list.append(average3)
                hi_list.append(highest3-lowest3)
                lo_list.append(lowest3)
                temp_list = []
        elif cnt >= 2187 and cnt <= 2906:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 2906:
                highest4 = max(temp_list)
                lowest4 = min(temp_list)
                average4 = (highest4 + lowest4)/2
                average_list.append(average4)
                hi_list.append(highest4-lowest4)
                lo_list.append(lowest4)
                temp_list = []
        elif cnt >= 2907 and cnt <= 3650:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 3650:
                highest5 = max(temp_list)
                lowest5 = min(temp_list)
                average5 = (highest5 + lowest5)/2
                average_list.append(average5)
                hi_list.append(highest5-lowest5)
                lo_list.append(lowest5)
                temp_list = []
        elif cnt >= 3651 and cnt <= 4370:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 4370:
                highest6 = max(temp_list)
                lowest6 = min(temp_list)
                average6 = (highest6 + lowest6)/2
                average_list.append(average6)
                hi_list.append(highest6-lowest6)
                lo_list.append(lowest6)
                temp_list = []
        elif cnt >= 4371 and cnt <= 5114:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 5114:
                highest7 = max(temp_list)
                lowest7 = min(temp_list)
                average7 = (highest7 + lowest7)/2
                average_list.append(average7)
                hi_list.append(highest7-lowest7)
                lo_list.append(lowest7)
                temp_list = []
        elif cnt >= 5115 and cnt <= 5858:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 5858:
                highest8 = max(temp_list)
                lowest8 = min(temp_list)
                average8 = (highest8 + lowest8)/2
                average_list.append(average8)
                hi_list.append(highest8-lowest8)
                lo_list.append(lowest8)
                temp_list = []
        elif cnt >= 5859 and cnt <= 6578:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 6578:
                highest9 = max(temp_list)
                lowest9 = min(temp_list)
                average9 = (highest9 + lowest9)/2
                average_list.append(average9)
                hi_list.append(highest9-lowest9)
                lo_list.append(lowest9)
                temp_list = []
        elif cnt >= 6579 and cnt <= 7322:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 7322:
                highest10 = max(temp_list)
                lowest10 = min(temp_list)
                average10 = (highest10 + lowest10)/2
                average_list.append(average10)
                hi_list.append(highest10-lowest10)
                lo_list.append(lowest10)
                temp_list = []
        elif cnt >= 7323 and cnt <= 8042:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 8042:
                highest11 = max(temp_list)
                lowest11 = min(temp_list)
                average11 = (highest11 + lowest11)/2
                average_list.append(average11)
                hi_list.append(highest11-lowest11)
                lo_list.append(lowest11)
                temp_list = []
        elif cnt >= 8043 and cnt <= 8786:
            w_list = line.split()
            temp_list.append(float(w_list[4]))
            if cnt == 8786:
                highest12 = max(temp_list)
                lowest12 = min(temp_list)
                average12 = (highest12 + lowest12)/2
                average_list.append(average12)
                hi_list.append(highest12-lowest12)
                lo_list.append(lowest12)
                temp_list = []
        cnt += 1


    ## the x-coordinates
    x2 = [0.25,1.25,2.25,3.25,4.25,5.25,6.25,7.25,8.25,9.25,10.25,11.25]

    ## creates the graph
    ## set axis
    plt.axis([0,12,0,120])
    ## set ylabel
    plt.ylabel('Average Temp')
    ## set title
    plt.title('Charleston,MO - 2012')
    ## set x ticks
    plt.xticks(x2,calendar.month_name[1:13], rotation=45)
    ## make the bar graph
    plt.bar(x2,hi_list,.5,bottom = lo_list)
    ## save the figure
    plt.savefig('average_temp.png')

## finds the avg radiation of the hour vs. avg temp of the hour
def rad_vs_temp(f_obj1,f_obj2):
    hr_list1 = []
    hr_list2 = []
    hr_list3 = []
    hr_list4 = []
    hr_list5 = []
    hr_list6 = []
    hr_list7 = []
    hr_list8 = []
    hr_list9 = []
    hr_list10 = []
    hr_list11 = []
    hr_list12 = []
    hr_list13 = []
    hr_list14 = []
    hr_list15 = []
    hr_list16 = []
    hr_list17 = []
    hr_list18 = []
    hr_list19 = []
    hr_list20 = []
    hr_list21 = []
    hr_list22 = []
    hr_list23 = []
    hr_list24 = []
    avg_rad_list = []
    cnt = 1
    cnt2 = 0
    for line in f_obj1:
        ## goes through each line and appends data onto appropriate
        ## houred list
        line.strip()
        w_list = line.split()
        w_list[0] = w_list[0].strip()
        if cnt > 5:
            w_list[0] = int(w_list[0])
        if w_list[0] == 6:
            cnt2 += 1
            if cnt2 == 1:
                w_list[4] = w_list[4].strip()
                hr_list1.append(int(w_list[4]))
            elif cnt2 == 2:
                w_list[4] = w_list[4].strip()
                hr_list2.append(int(w_list[4]))
            elif cnt2 == 3:
                w_list[4] = w_list[4].strip()
                hr_list3.append(int(w_list[4]))
            elif cnt2 == 4:
                w_list[4] = w_list[4].strip()
                hr_list4.append(int(w_list[4]))
            elif cnt2 == 5:
                w_list[4] = w_list[4].strip()
                hr_list5.append(int(w_list[4]))
            elif cnt2 == 6:
                w_list[4] = w_list[4].strip()
                hr_list6.append(int(w_list[4]))
            elif cnt2 == 7:
                w_list[4] = w_list[4].strip()
                hr_list7.append(int(w_list[4]))
            elif cnt2 == 8:
                w_list[4] = w_list[4].strip()
                hr_list8.append(int(w_list[4]))
            elif cnt2 == 9:
                w_list[4] = w_list[4].strip()
                hr_list9.append(int(w_list[4]))
            elif cnt2 == 10:
                w_list[4] = w_list[4].strip()
                hr_list10.append(int(w_list[4]))
            elif cnt2 == 11:
                w_list[4] = w_list[4].strip()
                hr_list11.append(int(w_list[4]))
            elif cnt2 == 12:
                w_list[4] = w_list[4].strip()
                hr_list12.append(int(w_list[4]))
            elif cnt2 == 13:
                w_list[4] = w_list[4].strip()
                hr_list13.append(int(w_list[4]))
            elif cnt2 == 14:
                w_list[4] = w_list[4].strip()
                hr_list14.append(int(w_list[4]))
            elif cnt2 == 15:
                w_list[4] = w_list[4].strip()
                hr_list15.append(int(w_list[4]))
            elif cnt2 == 16:
                w_list[4] = w_list[4].strip()
                hr_list16.append(int(w_list[4]))
            elif cnt2 == 17:
                w_list[4] = w_list[4].strip()
                hr_list17.append(int(w_list[4]))
            elif cnt2 == 18:
                w_list[4] = w_list[4].strip()
                hr_list18.append(int(w_list[4]))
            elif cnt2 == 19:
                w_list[4] = w_list[4].strip()
                hr_list19.append(int(w_list[4]))
            elif cnt2 == 20:
                w_list[4] = w_list[4].strip()
                hr_list20.append(int(w_list[4]))
            elif cnt2 == 21:
                w_list[4] = w_list[4].strip()
                hr_list21.append(int(w_list[4]))
            elif cnt2 == 22:
                w_list[4] = w_list[4].strip()
                hr_list22.append(int(w_list[4]))
            elif cnt2 == 23:
                w_list[4] = w_list[4].strip()
                hr_list23.append(int(w_list[4]))
            elif cnt2 == 24:
                w_list[4] = w_list[4].strip()
                hr_list24.append(int(w_list[4]))
                cnt2 = 0
        cnt += 1
    
    ## calculates the average of each hour
    avg_rad_list.append(sum(hr_list1)/len(hr_list1))
    avg_rad_list.append(sum(hr_list2)/len(hr_list2))
    avg_rad_list.append(sum(hr_list3)/len(hr_list3))
    avg_rad_list.append(sum(hr_list4)/len(hr_list4))
    avg_rad_list.append(sum(hr_list5)/len(hr_list5))
    avg_rad_list.append(sum(hr_list6)/len(hr_list6))
    avg_rad_list.append(sum(hr_list7)/len(hr_list7))
    avg_rad_list.append(sum(hr_list8)/len(hr_list8))
    avg_rad_list.append(sum(hr_list9)/len(hr_list9))
    avg_rad_list.append(sum(hr_list10)/len(hr_list10))
    avg_rad_list.append(sum(hr_list11)/len(hr_list11))
    avg_rad_list.append(sum(hr_list12)/len(hr_list12))
    avg_rad_list.append(sum(hr_list13)/len(hr_list13))
    avg_rad_list.append(sum(hr_list14)/len(hr_list14))
    avg_rad_list.append(sum(hr_list15)/len(hr_list15))
    avg_rad_list.append(sum(hr_list16)/len(hr_list16))
    avg_rad_list.append(sum(hr_list17)/len(hr_list17))
    avg_rad_list.append(sum(hr_list18)/len(hr_list18))
    avg_rad_list.append(sum(hr_list19)/len(hr_list19))
    avg_rad_list.append(sum(hr_list20)/len(hr_list20))
    avg_rad_list.append(sum(hr_list21)/len(hr_list21))
    avg_rad_list.append(sum(hr_list22)/len(hr_list22))
    avg_rad_list.append(sum(hr_list23)/len(hr_list23))
    avg_rad_list.append(sum(hr_list24)/len(hr_list24))

    hr_list1 = []
    hr_list2 = []
    hr_list3 = []
    hr_list4 = []
    hr_list5 = []
    hr_list6 = []
    hr_list7 = []
    hr_list8 = []
    hr_list9 = []
    hr_list10 = []
    hr_list11 = []
    hr_list12 = []
    hr_list13 = []
    hr_list14 = []
    hr_list15 = []
    hr_list16 = []
    hr_list17 = []
    hr_list18 = []
    hr_list19 = []
    hr_list20 = []
    hr_list21 = []
    hr_list22 = []
    hr_list23 = []
    hr_list24 = []
    temp_list = []

    cnt = 1
    cnt2 = 0
    for line in f_obj2:
        line.strip()
        ## goes through each line and appends the correct data
        ## to the end of the correctly houred list
        w_list = line.split()
        w_list[0] = w_list[0].strip()
        if cnt > 2:
            w_list[0] = int(w_list[0])
        if w_list[0] == 6:
            cnt2 += 1
            if cnt2 == 1:
                w_list[4] = w_list[4].strip()
                hr_list1.append(float(w_list[4]))
            elif cnt2 == 2:
                w_list[4] = w_list[4].strip()
                hr_list2.append(float(w_list[4]))
            elif cnt2 == 3:
                w_list[4] = w_list[4].strip()
                hr_list3.append(float(w_list[4]))
            elif cnt2 == 4:
                w_list[4] = w_list[4].strip()
                hr_list4.append(float(w_list[4]))
            elif cnt2 == 5:
                w_list[4] = w_list[4].strip()
                hr_list5.append(float(w_list[4]))
            elif cnt2 == 6:
                w_list[4] = w_list[4].strip()
                hr_list6.append(float(w_list[4]))
            elif cnt2 == 7:
                w_list[4] = w_list[4].strip()
                hr_list7.append(float(w_list[4]))
            elif cnt2 == 8:
                w_list[4] = w_list[4].strip()
                hr_list8.append(float(w_list[4]))
            elif cnt2 == 9:
                w_list[4] = w_list[4].strip()
                hr_list9.append(float(w_list[4]))
            elif cnt2 == 10:
                w_list[4] = w_list[4].strip()
                hr_list10.append(float(w_list[4]))
            elif cnt2 == 11:
                w_list[4] = w_list[4].strip()
                hr_list11.append(float(w_list[4]))
            elif cnt2 == 12:
                w_list[4] = w_list[4].strip()
                hr_list12.append(float(w_list[4]))
            elif cnt2 == 13:
                w_list[4] = w_list[4].strip()
                hr_list13.append(float(w_list[4]))
            elif cnt2 == 14:
                w_list[4] = w_list[4].strip()
                hr_list14.append(float(w_list[4]))
            elif cnt2 == 15:
                w_list[4] = w_list[4].strip()
                hr_list15.append(float(w_list[4]))
            elif cnt2 == 16:
                w_list[4] = w_list[4].strip()
                hr_list16.append(float(w_list[4]))
            elif cnt2 == 17:
                w_list[4] = w_list[4].strip()
                hr_list17.append(float(w_list[4]))
            elif cnt2 == 18:
                w_list[4] = w_list[4].strip()
                hr_list18.append(float(w_list[4]))
            elif cnt2 == 19:
                w_list[4] = w_list[4].strip()
                hr_list19.append(float(w_list[4]))
            elif cnt2 == 20:
                w_list[4] = w_list[4].strip()
                hr_list20.append(float(w_list[4]))
            elif cnt2 == 21:
                w_list[4] = w_list[4].strip()
                hr_list21.append(float(w_list[4]))
            elif cnt2 == 22:
                w_list[4] = w_list[4].strip()
                hr_list22.append(float(w_list[4]))
            elif cnt2 == 23:
                w_list[4] = w_list[4].strip()
                hr_list23.append(float(w_list[4]))
            elif cnt2 == 24:
                w_list[4] = w_list[4].strip()
                hr_list24.append(float(w_list[4]))
                cnt2 = 0
        cnt += 1
        
    ## calculates the average temperature for each month
    temp_list.append(sum(hr_list1)/30)
    temp_list.append(sum(hr_list2)/30)
    temp_list.append(sum(hr_list3)/30)
    temp_list.append(sum(hr_list4)/30)
    temp_list.append(sum(hr_list5)/30)
    temp_list.append(sum(hr_list6)/30)
    temp_list.append(sum(hr_list7)/30)
    temp_list.append(sum(hr_list8)/30)
    temp_list.append(sum(hr_list9)/30)
    temp_list.append(sum(hr_list10)/30)
    temp_list.append(sum(hr_list11)/30)
    temp_list.append(sum(hr_list12)/30)
    temp_list.append(sum(hr_list13)/30)
    temp_list.append(sum(hr_list14)/30)
    temp_list.append(sum(hr_list15)/30)
    temp_list.append(sum(hr_list16)/30)
    temp_list.append(sum(hr_list17)/30)
    temp_list.append(sum(hr_list18)/30)
    temp_list.append(sum(hr_list19)/30)
    temp_list.append(sum(hr_list20)/30)
    temp_list.append(sum(hr_list21)/30)
    temp_list.append(sum(hr_list22)/30)
    temp_list.append(sum(hr_list23)/30)
    temp_list.append(sum(hr_list24)/30)

    # plots the average temperature axis on one side
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    t = [i for i in range(1,25)]
    ax1.plot(t,temp_list,'b.-')
    ax1.set_xlabel('Hour')
    ax1.set_ylabel('Average Temperature', color = 'b')
    for t1 in ax1.get_yticklabels():
        t1.set_color('b')

    # plots the average solar radiation axis on the other side
    ax2 = ax1.twinx()
    ax2.plot(t,avg_rad_list,'r.-')
    ax2.set_ylabel('Average Solar Radiation', color = 'r')
    for t1 in ax2.get_yticklabels():
        t1.set_color('r')

    plt.title('Charleston, MO - June 2012')
    plt.savefig('temp_vs_rad.png')
        
def main():
    # opens the temperature file
    file_str = 'temperature.txt'
    f_obj = open(file_str,'r')

    # calls the function
    hi_lo_temp(f_obj)
    # closes the file
    f_obj.close()

    # reopens the file
    f_obj = open(file_str, 'r')
    # opens solar radiation file
    file_str2 = 'solar_radition.txt'
    f_obj2 = open(file_str2, 'r')
    # calls the function
    rad_vs_temp(f_obj2,f_obj)
    # closes the files
    f_obj.close()
    f_obj2.close()

# calls the main function
main()

