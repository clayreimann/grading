# Lauren Chorny
# Project 9
# March 20, 2013
# Section 1


# import the cardsBasic class
import cardsBasic


# defines setup, which shuffles and deals the cards
def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    
    my_deck = cardsBasic.Deck()
    my_deck.shuffle()
    
    foundation = []
    cell = []
    tableau = []
    column = 0
    
    # creates a list of lists for foundations, tableaus, and cells
    for i in range(0,4):
        foundation.append(list())
        cell.append(list())
    for i in range(0,10):
        tableau.append(list())

    # deals the cards to the tableau
    while not my_deck.is_empty():
        tableau[column].append(my_deck.deal())
        column += 1
        if column % 10 == 0:
            column = 0
    
    return foundation,tableau,cell

# defines the function that moves from tableau to the foundation
def move_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''
    if t_col > 9 or f_col > 3:
        return False
    else:

        if tableau[t_col] == []:
            return False
        else:
            # gets the last card from the column
            card1 = tableau[t_col].pop()
            card1_rank = card1.get_rank()

            # checks if the foundation is empty
            if foundation[f_col] == []:
                # only adds if it is an ace
                if card1_rank == 1:
                    tableau[t_col].append(card1)
                    return True
                else:
                    tableau[t_col].append(card1)
                    return False
            else:
                card2 = foundation[f_col].pop()
                card2_rank = card2.get_rank()

                # only adds if it is the next in line number in the same suit
                if card2_rank < card1_rank:
                    if (card1_rank-card2_rank) == 1 and card1.equal_suit(card2):
                        foundation[f_col].append(card2)
                        tableau[t_col].append(card1)
                        return True
                    else:
                        foundation[f_col].append(card2)
                        tableau[t_col].append(card1)
                        return False
                else:
                    foundation[f_col].append(card2)
                    tableau[t_col].append(card1)
                    return False

    ## this function returns True(okay to move) or False(invalid move)
            

# defines the function to move to a cell
def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    # if the cell is empty, the card will be moved
    if c_col > 3 or t_col > 9:
        return False
    else:
        if cell[c_col] == []:
            return True
        else:
            return False

    ## this function returns True(okay to move) or False(invalid move)
        

# defines the function to move to the tableau
def move_to_tableau(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''

    # if the cell is empty, it will not move from cell to tableau
    # error checking
    if f_col > 3 or t_col > 9:
        return False
    else:
        if foundation[f_col] == []:
            return False
        else:
            card2 = foundation[f_col].pop()
            card2_rank = card2.get_rank()
            if tableau[t_col] != []:
                card1 = tableau[t_col].pop()
                card1_rank = card1.get_rank()

                # if the card is the next number in the series of the same suit
                if card2_rank < card1_rank:
                    if (card1_rank-card2_rank) == 1 and card1.equal_suit(card2):
                        foundation[f_col].append(card2)
                        tableau[t_col].append(card1)
                        return True
                    else:
                        foundation[f_col].append(card2)
                        tableau[t_col].append(card1)
                        return False
                else:
                    foundation[f_col].append(card2)
                    tableau[t_col].append(card1)
                    return False
            else:
                foundation[f_col].append(card2)
                return True

    ## this function returns True(okay to move) or False(invalid move)
        
# defines the function if you won
def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    # if the foundation is empty, you win
    if foundation == [[],[],[],[],[],[],[],[],[],[]]:
        return True
    else:
        return False

    # this function returns True(win) or False(continue playing)

# defines the function to move within the tableau
def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''


    # if the tableau isn't empty, checks if same suit and right number
    if t_col_source > 9 or t_col_dest > 9:
        return False
    else:
        card1 = tableau[t_col_source].pop()
        card1_rank = card1.get_rank()
        
        if tableau[t_col_dest] != []:
            card2 = tableau[t_col_dest].pop()
            card2_rank = card2.get_rank()
            
            if card1.equal_suit(card2):
                if card1_rank < card2_rank:
                    if (card2_rank - card1_rank) == 1:
                        tableau[t_col_dest].append(card2)
                        tableau[t_col_source].append(card1)
                        return True
                    else:
                        tableau[t_col_source].append(card1)
                        tableau[t_col_dest].append(card2)
                        return False
                else:
                    tableau[t_col_source].append(card1)
                    tableau[t_col_dest].append(card2)
                    return False
            else:
                tableau[t_col_source].append(card1)
                tableau[t_col_dest].append(card2)
                return False
        else:
            tableau[t_col_source].append(card1)
            return True

    ## this function returns True(okay to move) or False(invalid move)
    
# this function prints the game
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

# this function prints the rules
def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

# this function prints the response possibilities
def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
         

# this function calls all the functions together to play the game
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    # runs while the user chooses to play
    while True:
        # Uncomment this next line. It is commented out because setup doesn't do anything so printing doesn't work.
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        if len(response_list) > 0 and len(response_list) < 4:
            r = response_list[0]
            if r == 't2f':

                try:
                    try:
                        t_col = int(response_list[1]) - 1
                        f_col = int(response_list[2]) - 1


                        if response_list[1] == [] or t_col > 9 or f_col > 3 or response_list[2] == []:
                            print("\nInvalid move.")
                            continue

                        param = move_to_foundation(tableau,foundation,t_col,f_col)
                        if param == False:
                            print("\nInvalid move.")
                        else:
                            card = tableau[t_col].pop()
                            foundation[f_col].append(card)
                    except IndexError:
                        print('\nInvalid move.')
                               
                except ValueError:
                    print('\nInvalid move.')
        
            elif r == 't2t':
                # finds column value

                try:
                    try:
                        t1_col = int(response_list[1]) - 1
                        t2_col = int(response_list[2]) - 1

                        if response_list[1] == [] or t1_col > 10 or t2_col > 10 or response_list[2] == []:
                            print("\nInvalid move.")
                            continue
                
                        # moves card or says invalid move
                        param = move_in_tableau(tableau,t1_col,t2_col)

                        if param == False:
                            print("\nInvalid move.")
                        else:
                            card = tableau[t1_col].pop()
                            tableau[t2_col].append(card)
                    except IndexError:
                        print('\nInvalid move.')

                except ValueError:
                    print('\nInvalid move')
            elif r == 't2c':

                try:
                    try:
                        # finds column value
                        t_col = int(response_list[1]) - 1
                        c_col = int(response_list[2]) - 1

                        if response_list[1] == [] or t_col > 9 or c_col > 4 or response_list[2] == []:
                            print("\nInvalid move.")
                            continue

                        # moves card or says invalid move
                        param = move_to_cell(tableau,cell,t_col,c_col)

                        if param == False:
                            print("\nInvalid move.")
                        else:
                            card = tableau[t_col].pop()
                            cell[c_col].append(card)
                    except IndexError:
                        print('\nInvalid move.')

                except ValueError:
                    print("\nInvalid move.")
            elif r == 'c2t':


                try:
                    try:
                        # finds column value
                        c_col = int(response_list[1]) - 1
                        t_col = int(response_list[2]) - 1

                        if response_list[1] == [] or t_col > 9 or c_col > 3 or response_list[2] == []:
                            print("\nInvalid move.")
                            continue

                        # moves card or says invalid move
                        param = move_to_tableau(tableau, cell, t_col, c_col)

                        if param == False:
                            print("\nInvalid move.")
                        else:
                            card = cell[c_col].pop()
                            tableau[t_col].append(card)
                    except IndexError:
                        print('\nInvalid move.')
                            
                except ValueError:
                          print('\nInvalid move.')
                    
            elif r == 'c2f':


                try:
                    try:
                        # finds column value
                        c_col = int(response_list[1]) - 1
                        f_col = int(response_list[2]) - 1

                        if response_list[1] == [] or c_col > 4 or f_col > 3 or response_list[2] == []:
                            print("\nInvalid move.")
                            continue

                        # moves card or says invalid move
                        param = move_to_foundation(cell,foundation,c_col,f_col)

                        if param == False:
                            print("\nInvalid move.")
                        else:
                            card = cell[c_col].pop()
                            foundation[f_col].append(card)
                    except IndexError:
                        print('\nInvalid move.')

                except ValueError:
                    print("\nInvalid move.")
                
            elif r == 'q':
                # quits
                break
            elif r == 'h':
                # prints the response possibilities
                show_help()
            else:
                print('Unknown command:',r)                             
        else:
            # error checking the response
            print("Unknown Command:",response)

        # checks if winner
        param = is_winner(tableau)
        if param == True:
            print("You win!")
            break
    # final print before the program terminates
    print('Thanks for playing')

play()


        
    

