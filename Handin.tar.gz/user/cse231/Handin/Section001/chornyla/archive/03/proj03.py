print("Welcome to the vending machine change maker program.")
print("Change maker initialized.")
print("")
print("Stock contains:")
print("  25 nickels")
print("  25 dimes")
print("  25 quarters")
print("  0 ones")
print("  0 fives\n")
print("")

price_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")
print("")


nickels = 25
dimes = 25
quarters = 25
ones = 0
fives = 0

total_dol = 0
total_cent = 0



while price_str != 'q':
    price_float = float(price_str)
    price_int = int(round(price_float * 100))
    price_dol = int(price_float/1)
    price_cent = round(price_int - price_dol * 100)

    change_q = 0
    change_d = 0
    change_n = 0

    if price_int < 0 or price_int % 5 != 0:
        print("Illegal price: Must be a non-negative multiple of 5 cents.")
        print(" ")
        price_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")
        continue
    else:
        print("Menu for deposits:")
        print("  'n' - deposit a nickel")
        print("  'd' - deposit a dime")
        print("  'q' - deposit a quarter")
        print("  'o' - deposit a one dollar bill")
        print("  'f' - deposit a five dollar bill")
        print("  'c' - cancel the purchase")
        print("")

        if price_dol == 0:
            print("Payment due: ", price_cent, "cents")
        else:
            print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
        

        deposit_int = 0

        print("")
        
        while deposit_int < price_int:
            
            deposit_str = input("Indicate your deposit: ")
            
            if deposit_str == 'n':
                deposit_int += 5
                if price_cent == 0 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 95
                    nickels += 1
                else:
                    price_cent -= 5
                    
                nickels += 1

                print("")
                if price_dol == 0:
                    print("Payment due: ", price_cent, " cents")
                else:
                    print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
                print("")
                                  
            elif deposit_str == 'd':
                deposit_int += 10
                if price_cent == 0 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 90
                elif price_cent == 5 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 95
                else:
                    price_cent -= 10
                    
                dimes += 1

                print("")
                if price_dol == 0:
                    print("Payment due: ", price_cent, " cents")
                else:
                    print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
                print("")
                                  
            elif deposit_str == 'q':
                deposit_int += 25
                if price_cent == 0 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 75
                elif price_cent == 5 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 80
                elif price_cent == 10 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 85
                elif price_cent == 15 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 90
                elif price_cent == 20 and price_dol > 0:
                    price_dol -= 1
                    price_cent = 95
                else:
                    price_cent -= 25
                    
                quarters += 1
                
                print("")
                if price_dol == 0:
                    print("Payment due: ", price_cent, " cents")
                else:
                    print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
                print("")
                                  
            elif deposit_str == 'o':
                deposit_int += 100
                if price_dol == 0:
                    break
                else:
                    price_dol -= 1
                    print("")
                    print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
                    print("")
                    
                ones += 1
                                  
            elif deposit_str == 'f':
                deposit_int += 500
                if price_dol < 5:
                    break
                else:
                    price_dol -= 5
                    print("")
                    print("Payment due: ", price_dol, "dollars and ", price_cent, " cents")
                    print("")
                    
                fives += 1
                                  
            elif deposit_str == 'c':
                print("")
                print("Please take the change below:")
                
                while deposit_int >= 25 and quarters > 0:
                    deposit_int -= 25
                    quarters -= 1
                    change_q += 1
                    
                while deposit_int >= 10 and dimes > 0:
                    deposit_int -= 10
                    dimes -= 1
                    change_d += 1
                    
                while deposit_int >= 5 and nickels > 0:
                    deposit_int -= 5
                    nickels -= 1
                    change_n += 1

                if change_q > 0:
                    print(change_q, " quarters")
                if change_d > 0:
                    print(change_d, "dimes")
                if change_n > 0:
                    print(change_n, "nickels")

                if quarters == 0 and dimes == 0 and nickels == 0:
                    print("")
                    print("Machine is out of change.")
                    print("See store manager for remaining refund.")
                    change = change_q * 25 + change_d * 10 + change_n * 5
                    change_dol = int(change / 100)
                    change_cent = change - change_dol * 100
                    print("Amount due is: ", change_dol, "dollars and ", change_cent, " cents")
                break
                
            else:
                print("\nIllegal selection: ", deposit_str, "\n")

            
                
        if deposit_int != price_int and deposit_str != 'c':
            change_int = deposit_int - price_int
            print("")
            print("Please take the change below:","\n")
            change_q = 0
            change_d = 0
            change_n = 0
            
            while change_int >= 25 and quarters > 0:
                change_int -= 25
                quarters -= 1
                change_q += 1

            while change_int >= 10 and dimes > 0:
                change_int -= 10
                dimes -= 1
                change_d += 1

            while change_int >= 5 and nickels > 0:
                change_int -= 10
                nickels -= 1
                change_n += 1
                
            if change_q > 0:
                print(change_q, " quarters")
            if change_d > 0:
                print(change_d, "dimes")
            if change_n > 0:
                print(change_n, "nickels")
                    
            if quarters == 0 and dimes == 0 and nickels == 0:
                print("")
                print("Machine is out of change.")
                print("See store manager for remaining refund.")
                change_dol = int(change_int / 100)
                change_cent = change_int - change_dol * 100
                print("Amount due is: ", change_dol, "dollars and ", change_cent, " cents")


        print("")
        print("Stock contains:")
        print(nickels, " nickels")
        print(dimes, " dimes")
        print(quarters, " quarters")
        print(ones, " ones")
        print(fives, " fives")
        print("")
        price_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")
        print("")
        

else:
    total = nickels * 5 + dimes * 10 + quarters * 25 + ones * 100 + fives * 500
    total_dol = round(int(total/100))
    total_cent = round(total - total_dol * 100)
    
    print("Total: ", total_dol, " dollars and ", total_cent, " cents")

        
