##################################################################
#  Section 001H
#  Computer Project #4
#  Percentage contribution:
#  kineyd2              100%
##################################################################

# VARIABLES
outputString = ''
userInput1 = input("Enter first string: ")
userInput2 = input("Enter second string: ")
string1 = userInput1.lower()
string2 = userInput2.lower()

while True:
    # KEEPS GOING UNTIL USER QUITS.
    print ("Choose one of the following commands: ")
    print ("      a - (add)")
    print ("      d - (delete)")
    print ("      s - (score)")
    print ("      q - (quit)")
    command_str = input ("Enter command: ")
    if command_str == 'a':
        # INDEL ADD LOGIC
        whichStr_str = input("Work on which string? (1 or 2): ")
        index_int = int(input("At which index?: "))
        if whichStr_str == '1':
            if index_int > len(string1):
                    print ('Index is out of range. Please retry.')
                    continue
            string1 = string1[:index_int] + '-' + string1[index_int:]
        else:
            if index_int > len(string1):
                    print ('Index is out of range. Please retry.')
                    continue
            string2 = string2[:index_int] + '-' + string2[index_int:]
        print (string1)
        print (string2)
    if command_str == 'd':
        # INDEL DELETE LOGIC
        while True:
            whichStr_str = input("Work on which string (1 or 2): ")
            index_int = int(input("At which index?: "))
            # ONLY ALLOWS '-' TO BE DELETED
            deleter  = ''
            if whichStr_str == '1':
                deleter = string1
            else:
                deleter == string2
            if deleter[index_int] != '-':
                print ('You can only delete indels.')
                break
            if whichStr_str == '1':
                if index_int > len(string1):
                    print ('Index is out of range. Please retry.')
                    continue
                string1 = string1[:index_int] + string1[index_int+1:]
            else:
                if index_int > len(string2):
                    print ('Index is out of range. Please retry.')
                    continue
                string2 = string2[:index_int] + string2[index_int+1:]
            print (string1)
            print (string2)
            break
    if command_str == 's':
        # SCORING LOGIC
        while len(string1) < len(string2):
            string1 += '-'
        while len(string2) < len(string1):
            string2 += '-'
        while len(string1) == len(string2) and string1[(len(string1)) - 1] == '-' and string2[(len(string2)) - 1]:
            string1 = string1[:(len(string1) - 1)]
            string2 = string2[:(len(string2) - 1)]
        newString1 = ''
        newString2 = ''
        counter = 0
        matches = 0
        mismatches = 0
        while counter < len(string1):
            if string1[counter] == '-' or string2[counter] == '-':
                newString1 += string1[counter].upper()
                newString2 += string2[counter].upper()
                counter += 1
                mismatches += 1
                continue
            if string1[counter] == string2[counter]:
                newString1 += string1[counter].lower()
                newString2 += string2[counter].lower()
                matches += 1
            else:
                newString1 += string1[counter].upper()
                newString2 += string2[counter].upper()
                mismatches += 1
            counter += 1
        string1 = newString1
        string2 = newString2
        print (' ')
        print ('String 1 = ', newString1)
        print ('String 2 = ', newString2)
        print ('There are ', matches, 'matches.')
        print ('There are ', mismatches, 'mismatches.')
        print (' ')
    if command_str == 'q':
        print ('bye')
        break
        # DEAD
