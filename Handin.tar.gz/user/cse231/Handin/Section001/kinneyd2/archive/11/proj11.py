#################################################
#  Section 001H
#  Computer Project #11
#  Percentage contribution:
#  kinneyd2              100%
##################################################################
import urllib.request


class Tour(object):
    def __init__(self, *cities):
        self.city_list = []
        for city in cities:
            city = city.strip()
            city = city.replace(", ", "+")
            city = city.replace(" ", "+")
            self.city_list.append(city)
            
    def distance(self, travel_mode='driving'):
        distance_str = ""
        total_distance_int = 0
        city_count = len(self.city_list)
        counter = 0
        while counter < len(self.city_list)-1:
            url_str = "http://maps.googleapis.com/maps/api/distancematrix/json?"
            origins_str = "origins="
            dest_str = "&destinations="
            origins_str += str(self.city_list[counter])
            dest_str += str(self.city_list[counter+1])
            entire_url_str = url_str+origins_str+dest_str+"&mode="+travel_mode+"&sensor=false"
            #print (entire_url_str)
            web_obj = urllib.request.urlopen(entire_url_str)
            distance_data = web_obj.read()
            single_distance = str(distance_data.decode("UTF-8"))
            dist_int = single_distance.find("distance")
            single_distance = single_distance[dist_int:]
            val_int = single_distance.find("value")
            single_distance = single_distance[val_int+10:]
            nex_int = single_distance.find("}")
            single_distance_int = int(single_distance[:nex_int].strip())
            #print(single_distance_int)
            total_distance_int += single_distance_int
            counter += 1
        return total_distance_int

    def __str__(self):
        ret_str = ""
        for city in self.city_list:
            ret_str += city.replace("+", " ")
        return ret_str

    def __add__(self, other):
        new_tour = Tour("{}".format(self.city_list[0]), "{}".format(self.city_list[1]), "{}".format(other.city_list[0]), "{}".format(other.city_list[1]))
        return new_tour
    
    def __mul__(self, other):
        if type(other) != int:
            raise TypeError("Must multiply by an integer.")
        if other < 0:
            raise ValueError("Must be a non-negative integer.")
        self.distance() * other
            
    def __rmul__(self, other):
        self.__mul__(other)
    
    def __gt__(self, other):
        if self.distance() > other.distance():
            return True
        else:
            return False
        
    def __lt__(self, other):
        if self.distance() < other.distance():
            return True
        else:
            return False
        
    def __eq__(self, other):
        if self.distance() == other.distance():
            return True
        else:
            return False
    
def main():
    tour1 = Tour("Indianapolis, IN", "Kansas City, KA")
    tour2 = Tour("Kansas City, KA", "Santa Fe, NM", "Las Vegas, NV")
    tour3 = Tour("Las Vegas, NV", "Los Angelas, CA")
    print("tour1: {}\ntour2: {}\ntour3: {}".format(tour1, tour2, tour3))
    print("tour1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(tour1.distance()/1000), round(tour1.distance('bycicling')/1000), tour1.distance('walking')/1000))
    tour4 = tour1 + tour3
    print("tour4: ", tour4)
    print("tour4 * 3: ", tour4 * 3)
    print("tour4 * -6: ", tour4 * -6)
    print("tour4 * 6.4", tour4 * 6.4)
    print("tour4 == tour1 + tour3: ", tour4 == tour1 + tour3)
    print("tour4 > tour1 + tour3: ", tour4 > tour1 + tour3)
    print("tour1 < tour2 + tour3: ", tour1 < tour3 + tour4)

main()
