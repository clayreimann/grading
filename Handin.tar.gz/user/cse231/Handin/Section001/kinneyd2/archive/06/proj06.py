##################################################################
#  Section 001H
#  Computer Project #6
#  Percentage contribution:
#  kineyd2              100%
##################################################################

# To-Do:
#           file input unhard-code (only when finished with entire program)
#           MAKE IT FUCKING WORK, DAMNIT.

# averaged_tuple_value = (sum_of_tuple_values / number _of_tuples)
# tuple = [(MM-YYYY), (averaged_tuples_tuple)]

# returns opened file
def get_input_descriptor():
    file_name_str = 'table.csv' #input('Enter File Name: ')
    # Punch's while loop
    opened_file_bool = False
    while (not opened_file_bool):
        try:
            file_obj = open(file_name_str, 'r')
            opened_file_bool = True   # only executed after file opens
        except IOError:
            print("Bad file name, try again ")
            file_name_str = input("What file???") # reprompt, bad file
    else:
        return(file_obj)

# takes file object and column number, returning list of tuples
# tuples = (YYYY-MM-DD, tuple_value) 
def get_data_list(file_object, column_number):
    """Requires:
        -- file object and column number
        Returns:
        --returning list of tuples """
    data_list = []
    for line_str in file_object:
        line_str = line_str.strip()
        tuple_list = line_str.split(',')
        if tuple_list[0] == 'Date':
            continue
        tuple_obj = tuple_list[0] + ',' + tuple_list[column_number]
        data_list.append(tuple_obj) # add tuple
    file_object.close()
    return data_list

# takes list of tuples and returns list of dates only, in correct format
# does not group months together (multiple instances of each month)
def reformat_date (list_of_all_tuples):
    """Requires:
        -- list of all the tuples
        Returns:
        -- list of all tuples with dates in correct format"""
    count = 0
    while count < (len(list_of_all_tuples) - 1):
        tuple_obj = list_of_all_tuples[count].split(',')
        incorrect_date_list = tuple_obj[0].split('-')
        correct_date_str = incorrect_date_list[1] + '-' + incorrect_date_list[0] # (YYYY-MM-DD) to (MM-YYYY)
        list_of_all_tuples[count] = ((correct_date_str), (tuple_obj[1]))
        count += 1
    return list_of_all_tuples

# takes list of tuples for one month and averages the data.             
def average_data(list_of_tuples):
    """Requires:
        -- list of tuples (correct dates, unaverageed data)
        Returns:
        -- same list with tuples = (correct date, averaged data)"""
    final_list = []
    final_list_index = 0
    count = 0
    compare = 0
    num_of_tuples = 0
    averaged_tuple_values = 00.00
    all_tuple_values = 00.00
    while count < (len(list_of_tuples) ):
        first_date_str = list_of_tuples[count][0]
        compare_date_str = list_of_tuples[compare][0]
        tuple_value = float(list_of_tuples[compare][1])
        all_tuple_values += tuple_value
        num_of_tuples += 1
        averaged_tuple_values = all_tuple_values/num_of_tuples
        if first_date_str == compare_date_str:
            correct_tuple = ((first_date_str),(averaged_tuple_values))
            if len(final_list) == 0:
                final_list.append(correct_tuple)
                compare += 1
                continue
            try:
                final_list[final_list_index] = (correct_tuple)
            except IndexError:
                final_list.append(correct_tuple)
                final_list_index += 1
            compare += 1
        else:
            correct_tuple = ((compare_date_str), (tuple_value))
            final_list.append(correct_tuple)
            final_list_index += 1
            count = compare
            num_of_tuples = 1
            all_tuple_values = tuple_value
        if compare == len(list_of_tuples):
            break
    return final_list

def main():
    file_obj = get_input_descriptor()
    while True:
        print (" 1 - Open \n 2 - High \n 3 - Low \n 4 - Close \n 5 - Volume \n 6 - Adj Close")
        column_int = int(input('Which column number? (1-6): '))
        if column_int > 6 or column_int < 1:
            continue
        else:
            break
    data_list = get_data_list(file_obj, column_int)
    data_list = reformat_date(data_list)
    averaged_data_list = average_data(data_list)
    #print (averaged_data_list)
    counter = 0
    while counter < len(averaged_data_list):
        tuple_list = averaged_data_list[counter]
        tuple_date = tuple_list[0]
        tuple_value = tuple_list[1]
        averaged_data_list[counter] = (tuple_value, tuple_date)
        counter += 1
    averaged_data_list.sort()
    averaged_data_list = averaged_data_list[1:]
    #print (averaged_data_list)
    bottom_six_list = averaged_data_list[:6]
    averaged_data_list.reverse()
    top_six_list = averaged_data_list[:6]
    count = 0
    print ('Top six months:')
    while count < len(top_six_list):
        Tmonth = str(top_six_list[count][1])
        Tvalue = str(top_six_list[count][0])
        print('month:' + Tmonth)
        print ('value:' + Tvalue)
        count += 1
    else:
        count = 0
        print (' ')
    print ('Bottom six months:')
    while count < len(bottom_six_list):
        Bmonth = str(bottom_six_list[count][1])
        Bvalue = str(bottom_six_list[count][0])
        print ('month:' + Bmonth)
        print ('value:' + Bvalue)
        count += 1
##################
main()
