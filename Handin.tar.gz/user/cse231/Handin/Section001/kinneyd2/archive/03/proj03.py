##################################################################
#  Section 001H
#  Computer Project #3
#  Percentage contribution:
#  kineyd2              100%
##################################################################s
# variables
quarterStock_int = 25
nickelStock_int = 25
dimeStock_int = 25
output_str = ''
payAmount_float = 0
user_payment = 0
quarterChangeAmt_int = 0
dimeChangeAmt_int = 0
nickelChangeAmt_int = 0
oneStock_int = 0
fiveStock_int = 0
quarterReturnValue = 00.00
dimeReturnValue = 00.00
nickelReturnValue = 00.00
print ('Welcome to the vending machine change maker program')
print ('Change maker initialized.')
while True :
    # displays amount of change in machine and prompts user for price.
    print ('Stock contains:')
    print ('   ', nickelStock_int, 'nickels')
    print ('   ', dimeStock_int, 'dimes')
    print ('   ', quarterStock_int, 'quarters')
    print ('   ', oneStock_int, 'ones')
    print ('   ', fiveStock_int, 'fives')
    entry_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")
    # quits if user enters 'q', or else runs program
    if entry_str == 'q':
        output_str = 'Thanks for participating'
        print(output_str)
        break
    else:
        amount_float = float(entry_str)
        amount_int = round(amount_float*100)
        # verifies user-entered price is payable in nickels
        if amount_int % 5 != 0:
            output_str = 'Illegal price: Must be a non-negative multiple of 5 cents.'
            print (output_str)
            continue
        else:
            amount_owed = amount_int
            # prints how much user has entered and how much they still owe until
            # amount is payed
            while user_payment < amount_int:
                print ('Menu for deposits:')
                print ("   'n' - deposits a nickel")
                print ("   'd' - deposits a dime")
                print ("   'q' - deposits a quarter")
                print ("   'f' - deposits a five dollar bill")
                print ("   'o' - deposits a one dollar bill")
                print ("   'c' - cancels purchase")
                print ('You have entered: $', user_payment / 100)
                print ('You owe: $',amount_owed / 100)
                payAmount_str = input("Enter an amount of money or 'c' to cancel: ")
                # "money back" logic:
                if payAmount_str == 'c':
                    change_float = user_payment
                    amount_int = 0
                if payAmount_str == 'n':
                    nickelStock_int += 1
                    user_payment += 5
                    amount_owed -= 5
                if payAmount_str == 'd':
                    dimeStock_int += 1
                    user_payment += 10
                    amount_owed -= 10
                if payAmount_str == 'q':
                    quarterStock_int += 1
                    user_payment += 25
                    amount_owed -= 25
                if payAmount_str == 'f':
                    user_payment += 500
                    amount_owed -= 500
                    fiveStock_int += 1
                if payAmount_str == 'o':
                    user_payment += 100
                    amount_owed -= 100
                    oneStock_int += 1
                print ('Please enter a valid letter.')
            # shows user how much they have entered and the
            # change that they will be receiving
            if user_payment >= amount_int:
                quarterReturnAmt = 0
                dimeReturnAmt = 0
                nickelReturnAmt = 0
                changeAmt_int = user_payment - amount_int
                print ("You're change is: $", changeAmt_int/100)
                # greedy algorithm
                while changeAmt_int > 0:
                    while (changeAmt_int - 25) >= 0 and quarterStock_int > 0:
                        quarterReturnAmt += 1
                        quarterStock_int -= 1
                        changeAmt_int -= 25
                    while (changeAmt_int - 10) >= 0 and dimeStock_int > 0:
                        dimeReturnAmt += 1
                        dimeStock_int -= 1
                        changeAmt_int -= 10
                    while (changeAmt_int - 5) >= 0 and nickelStock_int > 0:
                        nickelReturnAmt += 1
                        nickelStock_int -= 1
                        changeAmt_int -= 5
                    quarterReturnValue_float = (quarterReturnAmt * 25) / 100
                    dimeReturnValue_float = (dimeReturnAmt * 10) / 100
                    nickelReturnValue_float = (nickelReturnAmt * 5) / 100
                    askManagerAmt_float = changeAmt_int / 100
                    changeAmt_int = 0
            print ("You received  ", quarterReturnAmt, "quarters ($", quarterReturnValue_float, ")")
            print ("You received  ", dimeReturnAmt, "dimes ($", dimeReturnValue_float, ")")
            print ("You received  ", nickelReturnAmt, "nickels ($", nickelReturnValue_float, ")")
            print ("You need to ask the manager for: $", askManagerAmt_float)
