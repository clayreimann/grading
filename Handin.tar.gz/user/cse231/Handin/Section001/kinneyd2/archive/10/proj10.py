##################################################################
#  Section 001H
#  Computer Project #10
#  Percentage contribution:
#  kinneyd2              100%
##################################################################
import turtle
import time

# Star Class
class Star(object):
    def __init__(self, x = 0, y = 0, arm_length = 0, color = ''):
        self.x = int(x)
        self.y = int(y)
        self.arm_length = int(arm_length)
        self.color = color.strip()

    def draw(self, turtle):
        turtle.up()
        num_sides = 0
        turtle.goto((self.x + self.arm_length/2.35), (self.y + self.arm_length/3.236))
        turtle.down()
        turtle.color(self.color)
        turtle.begin_fill()
        while num_sides < 5:
            turtle.forward(self.arm_length)
            turtle.right(144)
            turtle.forward(self.arm_length)
            turtle.left(72)
            num_sides += 1
        turtle.end_fill()
        turtle.up()
            
    def __str__(self):
        return_str = 'Star x:{} y:{} arm:{} color:{} \n'.format(self.x, self.y, self.arm_length, self.color)
        return return_str

# Triangle class
class Triangle(object):
    def __init__(self, x1 = 0,y1 = 0,x2 = 50,y2 = 0,x3 = 0,y3 = 50, color = ''):
        """
        Sets three points for a triangle
        params: three pairs of x-y coordinates
        """
        self.x1 = int(x1)
        self.x2 = int(x2)
        self.x3 = int(x3)
        self.y1 = int(y1)
        self.y2 = int(y2)
        self.y3 = int(y3)
        self.color = color.strip()

    def draw(self, turtle):
        turtle.showturtle()
        turtle.up()
        turtle.setheading(0)
        turtle.fillcolor(self.color)
        turtle.goto(self.x1,self.y1)
        turtle.down()
        turtle.begin_fill()
        turtle.goto(self.x2,self.y2)
        turtle.goto(self.x3,self.y3)
        turtle.goto(self.x1,self.y1)
        turtle.end_fill()

    def __str__(self):
        triangle_str = str("Triangle: ({},{}), ({},{}), ({},{}), {} \n".format(self.x1, self.y1, self.x2, self.y2, self.x3, self.y3, self.color))
        return triangle_str

# Rectangle Class
class Rectangle(object):
    def __init__(self, x= 0, y = 0, width = 0, height = 0, color = ''):
        """
        Only draws ractangles that have sides parallel to x=0 and y=0
        params: center point, width and height of rectangle, color of rectangle
        """
        self.x = int(x)
        self.y = int(y)
        self.width = int(width)
        self.height = int(height)
        self.color = color.strip()
    
    def draw(self, turtle):
        turtle.up()
        turtle.goto(self.x-self.width/2, self.y-self.height/2)
        turtle.down()
        turtle.fillcolor(self.color)
        turtle.begin_fill()
        for i in range(2):
            turtle.forward(self.width)
            turtle.left(90)
            turtle.forward(self.height)
            turtle.left(90)
        turtle.end_fill()
    
    def __str__(self):
        return_str = 'Rectangle x:{} y:{} arm:{} color:{} \n'.format(self.x, self.y, self.width, self.height, self.color)
        return return_str

# Pirate Rectangle class
class PirateRectangle(object):
    """
    draws a 4-sided polygon
    params: 4 x-y coordinate pairs and a color str
    """
    def __init__(self, bl_x = 0, bl_y = 0, br_x = 10, br_y = 0, tr_x = 10, tr_y = 10, tl_x = 0, tl_y = 10, color = ''):
        self.bl_x = int(bl_x)
        self.bl_y = int(bl_y)
        self.br_x = int(br_x)
        self.br_y = int(br_y)
        self.tr_x = int(tr_x)
        self.tr_y = int(tr_y)
        self.tl_x = int(tl_x)
        self.tl_y = int(tl_y)
        self.color = color.strip()

    def draw(self, turtle):
        turtle.showturtle()
        turtle.up()
        turtle.goto(self.bl_x, self.bl_y)
        turtle.down()
        turtle.fillcolor(self.color)
        turtle.begin_fill()
        turtle.goto(self.br_x, self.br_y)
        turtle.goto(self.tr_x, self.tr_y)
        turtle.goto(self.tl_x, self.tl_y)
        turtle.goto(self.bl_x, self.bl_y)
        turtle.end_fill()

    def __str__(self):
        return 'Rectangle: bottom left: ({},{}) bottom right: ({},{}) top right: ({},{}) top left: ({},{}) color: {} \n'.format(self.bl_x, self.bl_y, self.br_x, self.br_y, self.tr_x, self.tr_y, self.tl_x, self.tl_y, self.color)

# Circle Class
class Circle(object):
    def __init__(self, x = 0, y = 0, radius = 0, color = ''):
        self.x = int(x)
        self.y = int(y)
        self.radius = int(radius)
        self.color = color.strip()

    def draw(self, turtle):
        turtle.showturtle()
        turtle.up()
        turtle.setheading(0)
        turtle.color(self.color)
        turtle.goto(self.x, self.y)
        turtle.down()
        turtle.begin_fill()
        turtle.circle(self.radius)
        turtle.end_fill()
        turtle.up()
        turtle.hideturtle()

    def __str__(self):
        return ("Circle:  x: {}, y: {}, radius: {}, color: {} \n".format(self.x, self.y, self.radius, self.color))
# Flag class
class Flag(object):
    def __init__(self, file_obj):
        self.file_obj = file_obj
        self.rect_list = []
        self.star_list = []
        rect_count = int(self.file_obj.readline())
        while rect_count > 0:
            line_str = self.file_obj.readline()
            line_str = line_str.strip()
            line_list = line_str.split(',')
            rect = Rectangle(line_list[0], line_list[1], line_list[2], line_list[3], line_list[4])
            self.rect_list.append(rect)
            rect_count -= 1
        star_count = int(self.file_obj.readline())
        while star_count > 0:
            line_str = self.file_obj.readline()
            line_str = line_str.strip()
            line_list = line_str.split(',')
            star = Star(line_list[0], line_list[1], line_list[2], line_list[3])
            self.star_list.append(star)
            star_count -= 1
    
    def draw(self, turtle):
            for rect in self.rect_list:
                rect.draw(turtle)
            for star in self.star_list:
                star.draw(turtle)
    
    def __str__(self):
        ret_str = ''
        for rect in self.rect_list:
            ret_str += rect.__str__()
        for star in self.star_list:
            ret_str += star.__str__()
        return ret_str

# Pirate Fag class
class PirateFlag(object):
    def __init__(self, file_obj):
        self.file_obj = file_obj
        self.p_rect_list = []
        self.circle_list = []
        self.triangle_list = []
        p_rect_count = int(self.file_obj.readline())
        # stores all rectangles into a list
        while p_rect_count > 0:
            line_str = self.file_obj.readline()
            line_str = line_str.strip()
            line_list = line_str.split(',')
            p_rect = PirateRectangle(line_list[0], line_list[1], line_list[2], line_list[3], line_list[4], line_list[5], line_list[6], line_list[7], line_list[8])
            self.p_rect_list.append(p_rect)
            p_rect_count -= 1
        # stores all circles into a list
        circle_count = int(self.file_obj.readline())
        while circle_count > 0:
            line_str = self.file_obj.readline()
            line_str = line_str.strip()
            line_list = line_str.split(',')
            circle = Circle(line_list[0], line_list[1], line_list[2], line_list[3])
            self.circle_list.append(circle)
            circle_count -= 1
        triangle_count = int(self.file_obj.readline())
        # stores triangles into a list
        while triangle_count > 0:
            line_str = self.file_obj.readline()
            line_str = line_str.strip()
            line_list = line_str.split(',')
            triangle = Triangle(line_list[0], line_list[1], line_list[2], line_list[3], line_list[4], line_list[5], line_list[6])
            self.triangle_list.append(triangle)
            triangle_count -= 1
    
    def draw(self, turtle):
            for p_rect in self.p_rect_list:
                p_rect.draw(turtle)
            for circle in self.circle_list:
                circle.draw(turtle)
            for triangle in self.triangle_list:
                triangle.draw(turtle)
    
    def __str__(self):
        ret_str = ''
        for p_rect in self.p_rect_list:
            ret_str += p_rect.__str__()
        for circle in self.circle_list:
            ret_str += circle.__str__()
        for triangle in self.triangle_list:
            ret_str += triangle.__str__()
        return ret_str

def main():    
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    pirate_file = open('myFlag.txt')
    pirate_flag = PirateFlag(pirate_file)
    print(pirate_flag)
    pirate_flag.draw(pen)
    pirate_file.close()
    
main()
