print("Guess a six-digit number SLAYER so that the following equation is true:")
print("SLAYER + SLAYER +SLAYER = LAYERS")
print("Each letter stands for the digit shown.")
print()
SLAYER_int = int(input("Enter your guess for SLAYER: "))

# math to split SLAYER up and then place it back together in the correct order.
S_int = (SLAYER_int//100000)%10
L_int = (SLAYER_int//10000)%10
A_int = (SLAYER_int//1000)%10
Y_int = (SLAYER_int//100)%10
E_int = (SLAYER_int//10)%10
R_int = (SLAYER_int)%10
triple_SLAYER_int = (SLAYER_int + SLAYER_int + SLAYER_int)
LAYERS_int = (L_int*100000)+(A_int*10000)+(Y_int*1000)+(E_int*100)+(R_int*10)+(S_int)

# if block that determines whether the answer is right or wrong.
if (triple_SLAYER_int == LAYERS_int) :
   return_value = "CORRECT!"
else:
    return_value = "YOU'RE WRONG"

# display both values and whether or not user is correct.
print ("LAYERS = ", LAYERS_int)
print ("SLAYER + SLAYER + SLAYER = ", triple_SLAYER_int)
print (return_value)
