##################################################################
#  Section 001H
#  Computer Project #8
#  Percentage contribution:
#  kinneyd2              100%
##################################################################
import string

def fill_completions(c_dict, file_obj):
        for line in file_obj:
                line = line.strip()
                word_list = line.split()
                for word in word_list:
                        word = word.lower()
                        word = word.strip(string.punctuation)
                        if word:
                                count = 0
                                while count < len(word):
                                        if (count, word[count]) in c_dict:
                                                c_dict[count, word[count]].add(word)
                                        else:
                                                c_dict[count, word[count]] = {word}
                                        count += 1
                        
def find_completions(prefix, c_dict):
        prefix_list = list(prefix)
        return_set = c_dict[0, prefix_list[0]]
        count1 = 1
        while count1 < len(prefix_list):
                return_set = return_set & c_dict[count1, prefix_list[count1]]
                count1+=1
        return return_set

##def get_input_descriptor():
##    file_name_str = 'ap_docs.txt' #input('Enter File Name: ')
##    opened_file_bool = False
##    while (not opened_file_bool):
##        try:
##            file_obj = open(file_name_str, 'r')
##            opened_file_bool = True   # only executed after file opens
##        except IOError:
##            print("Bad file name, try again ")
##            file_name_str = input("What file???") # reprompt, bad file
##    else:
##        return(file_obj)

def main():
        c_dict = {}
        prefix_str = ''
        print_set = {}
        opened_file = open('ap_docs.txt', 'r')
        fill_completions(c_dict, opened_file)
        while True:
                prefix_str = input("Enter a prefix or '#' to quit: ")
                if prefix_str == '#':
                        break
                else:
                        print_set = find_completions(prefix_str, c_dict)
                        print (print_set)
                        break
        print('~~Done~~')
                        
main()
