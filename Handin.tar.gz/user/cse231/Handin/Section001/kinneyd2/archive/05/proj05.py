##################################################################
#  Section 001H
#  Computer Project #5
#  Percentage contribution:
#  kineyd2              100%
##################################################################
import math
import turtle
import time
# FUNCTIONS

# PROMPTS USER FOR COLOR
def get_color_choice():
    while True:
        print ("1 - Red")
        print ("2 - Orange")
        print ("3 - Yellow")
        print ("4 - Green")
        print ("5 - Blue")
        print ("6 - Cyan")
        print ('7 - Violet')
        print ('8 - White')
        print ('9 - Black')
        print ('10 - Brown')
        print ('11 - Gray')
        print ('12 - Pink')
        color_input_str = input("Enter your selection for color: ")
        if color_input_str == '1' or color_input_str == 'red':
            color_choice = 'red'
        elif color_input_str == '2' or color_input_str == 'orange':
            color_choice = 'orange'
        elif color_input_str == '3' or color_input_str == 'yellow':
            color_choice = 'yellow'
        elif color_input_str == '4' or color_input_str == 'green':
            color_choice = 'green'
        elif color_input_str == '5' or color_input_str == 'blue':
            color_choice = 'blue'
        elif color_input_str == '6' or color_input_str == 'cyan':
            color_choice = 'cyan'
        elif color_input_str == '7' or color_input_str == 'violet':
            color_choice = 'violet'
        elif color_input_str == '8' or color_input_str == 'white':
            color_choice = 'white'
        elif color_input_str == '9' or color_input_str == 'black':
            color_choice = 'black'
        elif color_input_str == '10' or color_input_str == 'brown':
            color_choice = 'brown'
        elif color_input_str == '11' or color_input_str == 'gray':
            color_choice = 'gray'
        elif color_input_str == '12' or color_input_str == 'pink':
            color_choice = 'HotPink'
        else:
            print (color_input_str, 'is not a valid entry. Please try again.')
            continue
        return color_choice

# PROMPTS USER FOR AMOUNT OF HEXAGONS    
def get_num_hexagons():
    while True:
        amt_input_str = input('How many hexagons do you want in each row (4 - 20): ')
        if amt_input_str.isdigit() == False:
            print ('Please enter an integer.')
            continue
        else:
            amt_input_int = int(amt_input_str)
        if amt_input_int < 4 or amt_input_int > 20:
            print ('Invalid entry, please try again.')
            continue
        else:
            return amt_input_int
            break

# FINDS SIDE LENGTH BASED ON AMOUNT OF HEXAGONS SPECIFIED
def get_hex_side_length():
    hex_full_length = (500/hex_amt_int)
    hex_side_len = (hex_full_length/2)/(math.cos(math.pi/6))
    return hex_side_len

# HEXAGON DRAWING LOGIC
def draw_hexagon(x, y, side_len, pen, color):
    pen.speed(10)
    pen.up()
    pen.goto(x,y)
    pen.down()
    pen.left(30)
    sideNum = 0
    pen.begin_fill()
    while sideNum < 6:
        pen.fillcolor(color)
        pen.forward(side_len)
        pen.left(60)
        sideNum += 1
    else:
        pen.right(30)
    pen.end_fill()
    
# NOT FUNCTIONS
hexagon_number = 0
num_of_lines = 0
num_of_hexes = 0
x_coordinate = -200
y_coordinate = 200
color1_choice = get_color_choice()
color2_choice = get_color_choice()
proper_color = ''
hex_amt_int = get_num_hexagons()
hex_side_length = get_hex_side_length()
# CONTINUES UNTIL NUMBER OF LINES IS CORRECT
while num_of_lines < hex_amt_int:
    # CONTINUES UNTIL NUMBER OF HEXAGONS IN LINE IS CORRECT
    while num_of_hexes < hex_amt_int:
        if num_of_hexes % 2 > 0:
            proper_color = color2_choice
        else:
            proper_color = color1_choice
        drawing = draw_hexagon(x_coordinate,y_coordinate,hex_side_length,turtle,proper_color)
        num_of_hexes += 1
        x_coordinate += (500/hex_amt_int)
    # CHANGES x_coordinate AND y_coordinate DEPENDING ON END OF LINE OR NOT
    if num_of_lines % 2 > 0:
        x_coordinate -= (500) + ((500/hex_amt_int)/2)
        y_coordinate -= (hex_side_length) + (math.sqrt(((hex_side_length)**2)-(((500/hex_amt_int)/2)**2)))
    else:
        x_coordinate -= (500) - ((500/hex_amt_int)/2)
        y_coordinate -= (hex_side_length) + (math.sqrt(((hex_side_length)**2)-(((500/hex_amt_int)/2)**2)))
    num_of_lines += 1
    num_of_hexes = 0
# SLAUGHTERS THE TURTLE AFTER 10 SECONDS
time.sleep(10)
turtle.bye()
