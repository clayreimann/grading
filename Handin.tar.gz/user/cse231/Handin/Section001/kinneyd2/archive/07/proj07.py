 ##################################################################
#  Section 001H
#  Computer Project #7
#  Percentage contribution:
#  kinneyd2              100%
##################################################################
import random
import string

def open_read_file(file_name_str): # supposed to take file name and re
        opened_bool = False
        while not(opened_bool):
                try:
                        file_obj = open(file_name_str, 'r') # opens the file
                        opened_bool = True
                except IOError:
                        file_name_str = input("Re-enter file name: ")
        return(file_obj)

def scramble_word(single_word_str):
        scrambled_list = []
        scrambled_word_str = ''
        first_index = 0
        last_index = -1
        first_punct = False
        last_punct = False
        middle_punct = False
        placer = 0
        count = 0
        middle_count = 0
        if len(single_word_str) < 4: # skips scrambling process if the word is less than four characters
                scrambled_word_str = single_word_str
        else:
                single_word_list = list(single_word_str)
                if single_word_list[first_index] in string.punctuation: # checks for punctuation at the beginning
                        first_punct_char = single_word_list[first_index]
                        first_punct = True
                        first_index += 1
                first_char = single_word_list[first_index]
                if single_word_list[last_index] in string.punctuation: # checks for punctuation at the end
                        last_punct_char = single_word_list[last_index]
                        last_punct = True
                        last_index -= 1
                last_char = single_word_list[last_index]
                list_to_shuffle = single_word_list[first_index+1:last_index]
                while middle_count < len(list_to_shuffle):
                        if list_to_shuffle[middle_count] in string.punctuation:
                                middle_punct_char = list_to_shuffle[middle_count]
                                list_to_shuffle = list_to_shuffle[:middle_count] + list_to_shuffle[middle_count+1:]
                                middle_punct = True
                                break
                        else:
                                middle_count += 1
                random.shuffle(list_to_shuffle) # shuffles middles characters of the word
                scrambled_list.append(first_char)
                for char in list_to_shuffle:
                        scrambled_list.append(char)
                scrambled_list.append(last_char) # word is now put back together after being scrambled
                while placer < len(scrambled_list):
                        if scrambled_list[placer] in string.punctuation:
                                middle_punct_char = scrambled_list[placer]
                                break
                        else:
                                placer += 1
                for letter in scrambled_list: # turns scrambled word from list to string
                        scrambled_word_str += letter
                while count < len(scrambled_word_str): # loop to add punctuation tp the middle of the word
                        if scrambled_word_str[count] in string.punctuation:
                                scrambled_word_str = scrambled_word_str[:count] + scrambled_word_str[count+1:]
                                scrambled_word_str = scrambled_word_str[:placer] + middle_punct_char + scrambled_word_str[placer:]
                                break
                        else:
                                count += 1
                if first_punct == True: # adds punctuation onto the beginning
                        scrambled_word_str = first_punct_char + scrambled_word_str
                if last_punct == True: # adds punctuation onto the end
                        scrambled_word_str = scrambled_word_str + last_punct_char
                if middle_punct == True:
                        scrambled_word_str = scrambled_word_str[:middle_count+1] + middle_punct_char + scrambled_word_str[middle_count+1:]
        return scrambled_word_str

def scramble_line(line_list):
        scrambled_line_list = []
        for word in line_list:
                scrambled_str = scramble_word(word)
                scrambled_line_list.append(scrambled_str)
        return scrambled_line_list

def main():
        final_str = ''
        file_name_str = input('Enter file name: ')
        opened_bool = False
        read_file_obj = open_read_file(file_name_str)
        write_file_obj = open("proj07_writeFile", 'w')
        for line in read_file_obj:
                line_list = line.split() # makes a list of words in the line
                scrambled_line = scramble_line(line_list)
                for word in scrambled_line:
                        final_str += word + ' '
                write_file_obj.write(final_str)
        read_file_obj.close()
        write_file_obj.close()

main()
