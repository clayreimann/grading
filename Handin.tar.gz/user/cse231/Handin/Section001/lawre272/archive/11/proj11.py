################################################################################
#Project 11
#Section: 001H
#Date:
#lawre272
#
#Program Overview:
#
#1. Make a class called Tour that will use Google API to return distances for a
#tour instance that is made in the class.
#
#2. Make a method that can add two tours together.
#
#3. Make a method that can multiply a tour with a scalar.
#
#4. Make methods that can see if a tour is greater than, less than or equal to
#another tour.
#
#5. Make a method that can print out the tour in a certain format.
################################################################################
import urllib.request  #Need this to use the google API.

class Tour(object):
    #Makes the tour instances.
    def __init__(self, startcity, *destinationcity):
        #This will be used for the print function.
        self.prstartcity = startcity
        
        #This will be used to put into the API.
        startcity = startcity.replace(",", "")
        startcity = startcity.replace(" ", "+")
        self.startcity = startcity
        
        #This will make a list of destinations used for the print function.
        prdes_city_list = []
        for obj in destinationcity:
            prdes_city_list.append(obj)
        self.prdes_city_list = prdes_city_list
        
        #This will make a list of destinations used for the distance method.
        des_city_list = []
        for obj in destinationcity:
            des_city_list.append(obj) #Going from tuple to a list
        
            
        #This will put the objects in the list to the right format to be used in
        #the API.
        count = 0
        for obj in des_city_list:
            obj = str(obj)
            obj = obj.replace(",", "")
            obj = obj.replace(" ", "+")
            des_city_list[count] = obj
            count +=1
        self.des_city_list = des_city_list
        #print(self.des_city_list)

    #Calculates the distance from the tour.
    def distance(self, mode = 'driving'):
        try:
            #Setting mode to default of driving unless said otherwise.
            self.mode = mode
            start = self.startcity
            #Running the API and making the query string to send to the API.
            #Also goes into the response from the API and grabs the distance
            #in the meters.
            total_distance = 0
            #print(self.des_city_list)
            for obj in self.des_city_list:
                #print(obj)
                query_string = 'http://maps.googleapis.com/maps/api/distancematrix/'+ \
                               'json?origins='+ start + '&destinations='+ \
                               obj+ '&mode='+ self.mode +'&sensor=false'
                web_obj = urllib.request.urlopen(query_string)
                data = web_obj.read()
                response = data.decode("UTF-8")
                response = response.strip()
                response_list = response.split(":")
                response_list = response_list[7].split(" ")
                distance_str = response_list[1]
                distance_str =  distance_str.strip()
                distance = int(distance_str)
                total_distance = total_distance + distance
                web_obj.close()
                start = obj
            #Returns the distance in meters.
            #print(total_distance)
            return (total_distance)
        except ValueError:
            print("There was no destination indicated. Please try again.")

    #This method returns a string of the citys toured in the Tour.
    def __str__(self):
        returnstr = self.prstartcity
        #print(returnstr)
        for obj in self.prdes_city_list:
            #print(obj)
            if type(obj) == list:
                for i in obj:
                    returnstr = returnstr + "; " + i
            else:
                returnstr = returnstr + "; " + obj
            #print(returnstr)
        return returnstr

    #This method returns a string of the citys toured in the Tour.
    def __repr__(self):
        """returnstr = self.prstartcity
        for obj in self.prdes_city_list:
            returnstr = returnstr + "; " +obj"""
        return self.__str__

    #This method takes two tours and adds the tours together.
    #NOTE: I'M HAVING TROUBLE WITH THIS!!!!!!!!!!
    def __add__(self, tour2):
        
        #Assign self to a new variable so you aren't changing self.
        new_tour = Tour(self.prstartcity, self.prdes_city_list)
        #print(new_tour.prdes_city_list)
        
        #Grabbing the data from the initialze method.
        des2_start = tour2.prstartcity
        des2_list = tour2.prdes_city_list
        
        #Adds the start city and destinations to the print lists to be used in
        #the string method.
        new_tour.prdes_city_list.append(des2_start)
        if len(des2_list) >=1:
            for obj in des2_list:
                new_tour.prdes_city_list.append(obj)
                
        #print(new_tour.prdes_city_list)
        #Taking the start city and reformatting it so it can go into the
        #distance method.
        des2_start = des2_start.replace(",", "")
        des2_start = des2_start.replace(" ", "+")
        new_tour.des_city_list.append(des2_start)
        
        #Taking the destination lsit and reformatting it so it can go into the 
        #distance method.
        if len(des2_list) >=1:
            for obj in des2_list:
                obj = str(obj)
                obj = obj.replace(",", "")
                obj = obj.replace(" ", "+")
                new_tour.des_city_list.append(obj)
        
        """des1_start = self.prstartcity
        des1_list = self.prdes_city_list
        #print(des1_start, des1_list)
        des2_start = tour2.prstartcity
        des2_list = tour2.prdes_city_list
        #print(des2_start, des2_list)

        #print(des1_list)
        #print(des2_start)

        des1_list.append(des2_start)
        #print(des1_list)
        if len(des2_list) >=1:
            for obj in des2_list:
                des1_list.append(obj)

        #print(des1_list)

        new_tour = Tour(des1_start, des1_list)
        #print(new_tour)
        #Adds the start city and destinations to the print lists to be used in
        #the string method.
        new_tour.prdes_city_list.append(des2_start)
        if len(des2_list) >=1:
            for obj in des2_list:
                new_tour.prdes_city_list.append(obj)
        #print(new_tour.prdes_city_list) 
        #Taking the start city and reformatting it so it can go into the
        #distance method.
        print(new_tour.des_city_list)
        des2_start = des2_start.replace(",", "")
        des2_start = des2_start.replace(" ", "+")
        #print(new_tour.des_city_list)
        new_tour.des_city_list.append(des2_start)
        #print(new_tour.des_city_list)
        #Taking the destination lsit and reformatting it so it can go into the
        #distance method.
        if len(des2_list) >=1:
            for obj in des2_list:
                obj = str(obj)
                obj = obj.replace(",", "")
                obj = obj.replace(" ", "+")
                new_tour.des_city_list.append(obj)"""
        return new_tour
    
    #Method that takes a tour and multiplys it by a scalar number.
    #NOTE: I'M HAVING TROUBLE WITH THIS!!!!!!!!!! (Same reason as __add__)
    def __mul__(self, num):
        try:
            try:
                #print(type(num))
                if type(num) == int:
                    new_tour = Tour(self.prstartcity, self.prdes_city_list)
                    des_start = self.prstartcity
                    des_list = self.prdes_city_list
                    for i in range(num):
                        new_tour.prdes_city_list.append(des_start)
                        if len(des_list) >=1:
                            for obj in des_list:
                                new_tour.prdes_city_list.append(obj)

                    for i in range(num):
                        des_start = des_start.replace(",", "")
                        des_start = des_start.replace(" ", "+")
                        new_tour.des_city_list.append(des_start)

                        if len(des_list) >=1:
                            for obj in des_list:
                                obj = str(obj)
                                obj = obj.replace(",", "")
                                obj = obj.replace(" ", "+")
                                new_tour.des_city_list.append(obj)
                    return new_tour
                
            except TypeError:
                print("Please enter integer.")
        except ValueError:
            print("Please enter positive integer.")
            
    #Method that takes a tour and multiplys it by a scalar number.
    def __rmul__(self, num):
        return self.__mul__(num)
    
    #Method that checks if tour1 is greater than tour 2. If so, return True.
    def __gt__(self,tour2):
        dis1 = self.distance()
        dis2 = tour2.distance()
        if dis1 > dis2:
            return True
        if dis1 < dis2:
            return False

    #Method that checks if tour1 is less than tour 2. If so, return True.
    def __lt__(self,tour2):
        dis1 = self.distance()
        dis2 = tour2.distance()
        if dis1 > dis2:
            return False
        if dis1 < dis2:
            return True

    #Method that checks to see if tour1 and tour2 stop at the same places on
    #their tour in the exact same order.
    def __eq__(self,tour2):
        if self.prstartcity == tour2.prstartcity:
            if self.prdes_city_list == tour2.prdes_city_list:
                return True
            else:
                return False
        else:
            return False
        
#Main function that needs to test all methods in class.
def main():
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Oakland, CA")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2:{}\nt3:{}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(
    round((t1.distance())/1000), round((t1.distance('bicycling'))/1000),
    round((t1.distance('walking'))/1000)))
    print("Using driving distances from here on.")
    print(" ")
    #SKIPS LANSING!
    print("Checks Add Method.")
    t4 = t1 + t2
    #print("t4:", t4)
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print(" ")
    print("Checks Equal To Method.")
    print("t4 == t1 + t2:", t4 == t1 + t2)
    print("t4 == t1 + t3:", t4 == t1 + t3)
    print(" ")
    print("Checks Greater than Method.")
    print("t1 > t3", t1 > t3)
    print("t3 > t1", t3 > t1)
    print(" ")
    print("Checks Less than Method.")
    print("t3 < t1", t3 < t1)
    print("t1 < t3", t1 < t3)
    #Note to TA: I've tried and outlined the __mul__ function but I can't quite
    #seem to get it to work. I know that ... see below......
    print(" ")
    print("Checking Multiplication Method.")
    print("2 * t3", t3.__mul__(2))

"""Note to TA: The two main methods that are not working in my program are add
and mul where I have to create a new instances instead of just adding or
multiplying the distances together. For some reason, I can't create an instance
correctly where it will read through my init correctly. I've tried add several
differnt ways, (why all the comments and stuff, but its not working). When I use
a list for the destination list, it skips over Lansing and goes straight into
Sacremento. The multiply thing isn't working because when I multiply it by 2 it
creates it 3 times. Which is werid. Everything else to my knowledge works just
fine independently, its just the add and mul methods where you need to make a
new instance, that is messing up.
"""
main()
