#################################################################################
#Project 4
#Date: 2/4/13
#lawre272
#
#1. Prompt for two strings.
#2. Display a menu of options.
#3. Add an indel in string if user enters A.
#4. Delete an indel in string if user enters a D, but only delete the indels.
#5. Score the strings if user enters S. Put in indels if the string is shorter than
# the others, and capalize letters that don't match. Count matches and mismatches.
#6. Quit if user enters Q.
################################################################################
str1 = input("String 1: ")
str2 = input("String 2: ")



while True:
    str1 = str1.lower() #Makes both strings lowercase.
    str2 = str2.lower()
    print(" ")
    print("What do you want to do:") #Menu of options.
    print("              a (add)")
    print("              d (delete)")
    print("              s (score)")
    option_str = input("              q (quit): ")

    if option_str == "q": #User enters q, quit program.
        break
    if option_str == "a": #User enters a, add indel.
        #Specify string and postion for inserting indel.
        which_str = int(input("Work on which string ( 1 or 2): "))
        pos = int(input("Before what index: "))

        if which_str == 1:
            
            if pos > (len(str1)-1): #Error checking that it's in range.
                print("Your input is out of range. Please try again.")
                print(" ")
            else:
                str1 = str1[:pos] + '-' + str1[pos:] #Insert indel.

        elif which_str == 2:
            if pos > (len(str1)-1):
                print("Your input is out of range. Please try again.")
                print(" ")
            else:
                str2 = str2[0:pos] + '-' + str2[pos:]

    elif option_str == "d": #User enters d, delete indel.
        #Specify string and postion to delete indel.
        which_str = int(input("Work on which string ( 1 or 2): "))
        pos = int(input("Before what index: "))

        if which_str == 1:
            if pos > (len(str1)-1): #Error checking that it's in range.
                print("Your input is out of range. Please try again.")
                print(" ")
            else:
                if str1[pos] == '-': #Deleting indel.
                    left = pos
                    right = pos + 1
                    str1 = str1[:left] + str1[right:]
                else:
                    #Error checking that deleted item is an indel.
                    print("Error! That is not an indel!")
                    print(" ")

        elif which_str == 2:
            if pos > (len(str1)-1):
                print("Your input is out of range. Please try again.")
                print(" ")
            else:
                if str2[pos] == '-':
                    left = pos
                    right = pos + 1
                    str2 = str2[:left] + str2[right:]
                else:
                    print("Error! That is not an indel!")
                    print(" ")
    

    elif option_str == "s": #User enters s, scoring the strings.
        mismatches = 0 #Mismatch counter.
        matches = 0 #Match counter.
        str1 = str1.lower() #Making strings lowercase.
        str2 = str2.lower()
 
        while len(str1) > len(str2): #Making each string the same length.
            str2 = str2 + '-'
        while len(str1) < len(str2):
            str1 = str1 + '-'
        while str1[-1] == '-' and str2[-1] == '-':
            #Preventing indels on the each of both strings.
            str1 = str1[0:-1]
            str2 = str2[0:-1]

        place = 0
        while place < len(str2):
            if str2[place] != str1[place]:
                #If there in an indel in the string, other string letter gets
                #capatalize and mismatch is added to count.
                if str1[place] == '-' and str2[place] != '-':
                    str2place = str2[place]
                    str2 = str2[:place] + str2place.upper() + str2[place+1:]
                    mismatches +=1
                    place += 1
                    continue
                #If there in an indel in the string, other string letter gets
                #capatalize and mismatch is added to count.
                if str1[place] != '-' and str2[place] == '-':
                    str1place = str1[place]
                    str1 = str1[:place] + str1place.upper() + str1[place+1:]
                    mismatches += 1
                    place += 1
                #If letter in one string does not match letter in other string
                #capatalize letters in both strings and mismatch is added to count.
                else:
                    str2place = str2[place]
                    str2 = str2[:place] + str2place.upper() + str2[place+1:]
                    str1place = str1[place]
                    str1 = str1[:place] + str1place.upper() + str1[place+1:]
                    mismatches += 1
                    place += 1
            #If letters match from both strings, leave lowercase and match
            #count is added.
            else:
                matches += 1
                place += 1
        #Print the matches and mismatches count along with each string. 
        print("Matches: ", matches, "Mismatches: ", mismatches)
        print(str1)
        print(str2)
