#project 1
#Section 001H
#1/10/13

#Asking for the Richter scale measure
richt_num = input("Please give me a Richter scale measure: ")
user_num = float(richt_num)

#Converting the Richter scale measure to energy and TNT tons
print("Richter measure:", richt_num)
print("Equivalence in joules:", 10**((1.5*user_num)+4.8))
print("Equivalence in Tons of TNT:", (10**((1.5*user_num)+4.8))/(4.184e9) )

a=1
b=5
c=9.1
d=9.2
e=9.5

#Table of other Richter scale measures
print(" ")
print("Richter", "     ", "Joules", "                      ", "TNT",)
print(a, "     ", 10**((1.5*a)+4.8), "              ", (10**((1.5*a)+4.8))/(4.184e9))
print(b, "     ", 10**((1.5*b)+4.8), "            ", (10**((1.5*b)+4.8))/(4.184e9))
print(c, "   ", 10**((1.5*c)+4.8), "   ", (10**((1.5*c)+4.8))/(4.184e9))
print(d, "   ", 10**((1.5*d)+4.8), "   ", (10**((1.5*d)+4.8))/(4.184e9))
print(e, "   ", 10**((1.5*e)+4.8), " ", (10**((1.5*e)+4.8))/(4.184e9))
