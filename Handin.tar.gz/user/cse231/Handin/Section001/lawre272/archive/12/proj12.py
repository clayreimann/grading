################################################################################
#Project 12
#Section 001H
#lawre272
#Date:
#
#Program Overview
#
#1. Open temperature.txt and get the highest and lowest temperature for each day
#in each month. Then calculate the average high and low temperature for each
#month.
#
#2. Open solar_radition.txt and calculate the average temperature of each hour
#for each day in the entire month of June. Also calculate the average solar
#radition of each hour for each day in the entire month of june.
#
#3. Once all three data sets have been aquired, draw two figures using
#matplotlib and numpy to display your data.
################################################################################
#Import matplotlib and numpy into my program.
import matplotlib.pyplot as plt
import numpy as np

#This is the average temperature function.
#This function is supposed to take the days of the month and the data from the
#file object and return an average high temperature and low temperature for the
#month that is run through the function.
def average_temp(skip, days, file_obj):
    
    #skip the first two lines in the file since they don't hold any data.
    file_obj.readline()
    file_obj.readline()
    
    #To get to a certain month, you have to skip the rest of the months lines
    #to get to the desired month's lines. This will skip to that month.
    for s in range(skip):
        file_obj.readline()
        
    #This will hold all the low temperatures for the month.
    low_temp = []
    
    #This will hold all the high temperatures for the month.
    high_temp = []
    
    #This for loop deals with what will happen in each day.
    for d in range(days):
        
        #This will hold all the data for one day. (Ideally, should be 24 lines)
        day_list = []
        
        #This for loop will run for each hour in the day.
        for i in range(24):

            #Formatting needed to get one list of the hour's data.
            line = file_obj.readline()
            line = line.strip()
            line = line.strip(' ')
            for char in line:
                if char == " ":
                    char = ''
            line_list = line.split(" ")
            hour_list = []
            for obj in line_list:
                if obj != '':
                    #This hour list is now one line of data.
                    #Example [1.0,1.0,2012.0,100.0,56.2]
                    hour_list.append(float(obj))
                    
            #This will hold all of those hour lines into one day list.
            #Should only hold 24 entries (24 hours in one day)
            day_list.append(hour_list)

        #This will hold the temperatures for the entire day.   
        day_temp_list = []

        #This for loop is supposed to take all 24 temperatures for the day and
        #put it in the day_temp_list.
        for obj in day_list:
            day_temp_list.append(obj[-1])

        #After we got the entire day's worth of temperatures in the list, we
        #want to sort the list so [0] will be the lowest temperature and [1]
        #will be the highest temperature.
        day_temp_list.sort()

        #Now for each day we want to append the highest temperature and the
        #lowest temperature into the high_temp list and the low_temp list.
        high_temp.append(day_temp_list[-1])
        low_temp.append(day_temp_list[0])

    #This is to set the average high to 0.
    aver_high = 0

    #Since the aver_high is set to 0 it will add all the temperatures in the
    #high_temp list together to get the total high temp.
    for obj in high_temp:
        aver_high = aver_high + obj

    #Taking the toal high temp, we divide it by the days to get the average for
    #the month.
    aver_high = aver_high/days

    #Round it so it looks nicer.
    aver_high = round(aver_high,2)

    #Same process for the low temp as we did for the high temp.
    aver_low = 0
    for obj in low_temp:
        aver_low = aver_low + obj
    aver_low = aver_low/days
    aver_low = round(aver_low,2)

    #Return a tuple of the high and low temp.
    return (aver_low, aver_high)

#This is the average_solar_radiation function.
#This function is supposed to put all the radition data in a list for each hour
#in the day. Then it will add up all the radition for each hour of all 30 days
#and divide it by 30 to find the average solar radition for the day.
def average_solar_radiation(skip, days, file_obj):

    #Skips the first four lines since they don't hold any data.
    file_obj.readline()
    file_obj.readline()
    file_obj.readline()
    file_obj.readline()

    #To get to a certain month, you have to skip the rest of the months lines
    #to get to the desired month's lines. This will skip to that month.
    for s in range(skip):
        file_obj.readline()

    #Each list is for each hour in the day. This will hold all the solar
    #radition values for that hour in the 30 days.
    #Example: h1 holds all the solar radition at 1am for each day in the month
    #of June.
    h1 = []
    h2 = []
    h3 = []
    h4 = []
    h5 = []
    h6 = []
    h7 = []
    h8 = []
    h9 = []
    h10 = []
    h11 = []
    h12 = []
    h13 = []
    h14 = []
    h15 = []
    h16 = []
    h17 = []
    h18 = []
    h19 = []
    h20 = []
    h21 = []
    h22 = []
    h23 = []
    h24 = []

    #This for loop deals with what will happen in each day.
    for d in range(days):
        
        #This will hold all the data for one day. (Ideally, should be 24 lines)
        day_list = []
        
        #This for loop will run for each hour in the day.
        for i in range(24):

            #Formating needed to make each line into a list we can pull from.
            line = file_obj.readline()
            line = line.strip()
            line = line.strip(' ')
            for char in line:
                if char == " ":
                    char = ''
            line_list = line.split(" ")
            hour_list = []
            for obj in line_list:
                if obj != '':

                    #This hour list is now one line of data.
                    #Example [1.0,1.0,2012.0,100.0,56.2]
                    hour_list.append(float(obj))

            #This will hold all of those hour lines into one day list.
            #Should only hold 24 entries (24 hours in one day)
            day_list.append(hour_list)

        #This will append all the solar radition into the respective hour list
        #for each day in June.
        h1.append(day_list[0][4])
        h2.append(day_list[1][4])
        h3.append(day_list[2][4])
        h4.append(day_list[3][4])
        h5.append(day_list[4][4])
        h6.append(day_list[5][4])
        h7.append(day_list[6][4])
        h8.append(day_list[7][4])
        h9.append(day_list[8][4])
        h10.append(day_list[9][4])
        h11.append(day_list[10][4])
        h12.append(day_list[11][4])
        h13.append(day_list[12][4])
        h14.append(day_list[13][4])
        h15.append(day_list[14][4])
        h16.append(day_list[15][4])
        h17.append(day_list[16][4])
        h18.append(day_list[17][4])
        h19.append(day_list[18][4])
        h20.append(day_list[19][4])
        h21.append(day_list[20][4])
        h22.append(day_list[21][4])
        h23.append(day_list[22][4])
        h24.append(day_list[23][4])

    #Repeat process:
    #The Average num list will hold each hours average value of solar radition
    #In their respective order.
    average_num_list = []

    #Preset num.
    num = 0

    #For each obj in h1, add it together to num to get the total radition for
    #1am.
    for obj in h1:
        num = num + obj

    #Take the total radition for that hour and divide by 30 for the 30 days in
    #June to find the average.
    avg_num1 = round((num/30),2)
    average_num_list.append(avg_num1)
    
    num = 0
    for obj in h2:
        num = num + obj
    avg_num2 = round((num/30),2)
    average_num_list.append(avg_num2)
    
    num = 0
    for obj in h3:
        num = num + obj
    avg_num3 = round((num/30),2)
    average_num_list.append(avg_num3)
    
    num = 0
    for obj in h4:
        num = num + obj
    avg_num4 = round((num/30),2)
    average_num_list.append(avg_num4)
    
    num = 0
    for obj in h5:
        num = num + obj
    avg_num5 = round((num/30),2)
    average_num_list.append(avg_num5)
    
    num = 0
    for obj in h6:
        num = num + obj
    avg_num6 = round((num/30),2)
    average_num_list.append(avg_num6)
    
    num = 0
    for obj in h7:
        num = num + obj
    avg_num7 = round((num/30),2)
    average_num_list.append(avg_num7)
    
    num = 0
    for obj in h8:
        num = num + obj
    avg_num8 = round((num/30),2)
    average_num_list.append(avg_num8)
    
    num = 0
    for obj in h9:
        num = num + obj
    avg_num9 = round((num/30),2)
    average_num_list.append(avg_num9)
    
    num = 0
    for obj in h10:
        num = num + obj
    avg_num10 = round((num/30),2)
    average_num_list.append(avg_num10)
    
    num = 0
    for obj in h11:
        num = num + obj
    avg_num11 = round((num/30),2)
    average_num_list.append(avg_num11)
    
    num = 0
    for obj in h12:
        num = num + obj
    avg_num12 = round((num/30),2)
    average_num_list.append(avg_num12)
    
    num = 0
    for obj in h13:
        num = num + obj
    avg_num13 = round((num/30),2)
    average_num_list.append(avg_num13)
    
    num = 0
    for obj in h14:
        num = num + obj
    avg_num14 = round((num/30),2)
    average_num_list.append(avg_num14)
    
    num = 0
    for obj in h15:
        num = num + obj
    avg_num15 = round((num/30),2)
    average_num_list.append(avg_num15)
    
    num = 0
    for obj in h16:
        num = num + obj
    avg_num16 = round((num/30),2)
    average_num_list.append(avg_num16)
    
    num = 0
    for obj in h17:
        num = num + obj
    avg_num17 = round((num/30),2)
    average_num_list.append(avg_num17)
    
    num = 0
    for obj in h18:
        num = num + obj
    avg_num18 = round((num/30),2)
    average_num_list.append(avg_num18)
    
    num = 0
    for obj in h19:
        num = num + obj
    avg_num19 = round((num/30),2)
    average_num_list.append(avg_num19)
    
    num = 0
    for obj in h20:
        num = num + obj
    avg_num20 = round((num/30),2)
    average_num_list.append(avg_num20)
    
    num = 0
    for obj in h21:
        num = num + obj
    avg_num21 = round((num/30),2)
    average_num_list.append(avg_num21)
    
    num = 0
    for obj in h22:
        num = num + obj
    avg_num22 = round((num/30),2)
    average_num_list.append(avg_num22)
    
    num = 0
    for obj in h23:
        num = num + obj
    avg_num23 = round((num/30),2)
    average_num_list.append(avg_num23)
    
    num = 0
    for obj in h24:
        num = num + obj
    avg_num24 = round((num/30),2)
    average_num_list.append(avg_num24)

    #Return the list of the averages of solar radition of each hour for the 30
    #days in june. Ideally only 24 entries in this list.
    return average_num_list

#This average_hour_temp function is very similar to the average_solar_radition
#function only instead of looking at solar_radition.txt it looks back at
#temperature.txt. Basically a repeat process.
def average_hour_temp(skip, days, file_obj):
    file_obj.readline()
    file_obj.readline()
    
    for s in range(skip):
        file_obj.readline()
        
    h1 = []
    h2 = []
    h3 = []
    h4 = []
    h5 = []
    h6 = []
    h7 = []
    h8 = []
    h9 = []
    h10 = []
    h11 = []
    h12 = []
    h13 = []
    h14 = []
    h15 = []
    h16 = []
    h17 = []
    h18 = []
    h19 = []
    h20 = []
    h21 = []
    h22 = []
    h23 = []
    h24 = []
    
    for d in range(days):
        day_list = []
        for i in range(24):
            line = file_obj.readline()
            line = line.strip()
            line = line.strip(' ')
            for char in line:
                if char == " ":
                    char = ''
            line_list = line.split(" ")
            hour_list = []
            for obj in line_list:
                if obj != '':
                    hour_list.append(float(obj))
            day_list.append(hour_list)
            
        h1.append(day_list[0][4])
        h2.append(day_list[1][4])
        h3.append(day_list[2][4])
        h4.append(day_list[3][4])
        h5.append(day_list[4][4])
        h6.append(day_list[5][4])
        h7.append(day_list[6][4])
        h8.append(day_list[7][4])
        h9.append(day_list[8][4])
        h10.append(day_list[9][4])
        h11.append(day_list[10][4])
        h12.append(day_list[11][4])
        h13.append(day_list[12][4])
        h14.append(day_list[13][4])
        h15.append(day_list[14][4])
        h16.append(day_list[15][4])
        h17.append(day_list[16][4])
        h18.append(day_list[17][4])
        h19.append(day_list[18][4])
        h20.append(day_list[19][4])
        h21.append(day_list[20][4])
        h22.append(day_list[21][4])
        h23.append(day_list[22][4])
        h24.append(day_list[23][4])
        
    average_num_list = []
    
    num = 0
    for obj in h1:
        num = num + obj
    avg_num1 = round((num/30),2)
    average_num_list.append(avg_num1)
    
    num = 0
    for obj in h2:
        num = num + obj
    avg_num2 = round((num/30),2)
    average_num_list.append(avg_num2)
    
    num = 0
    for obj in h3:
        num = num + obj
    avg_num3 = round((num/30),2)
    average_num_list.append(avg_num3)
    
    num = 0
    for obj in h4:
        num = num + obj
    avg_num4 = round((num/30),2)
    average_num_list.append(avg_num4)
    
    num = 0
    for obj in h5:
        num = num + obj
    avg_num5 = round((num/30),2)
    average_num_list.append(avg_num5)
    
    num = 0
    for obj in h6:
        num = num + obj
    avg_num6 = round((num/30),2)
    average_num_list.append(avg_num6)
    
    num = 0
    for obj in h7:
        num = num + obj
    avg_num7 = round((num/30),2)
    average_num_list.append(avg_num7)
    
    num = 0
    for obj in h8:
        num = num + obj
    avg_num8 = round((num/30),2)
    average_num_list.append(avg_num8)
    
    num = 0
    for obj in h9:
        num = num + obj
    avg_num9 = round((num/30),2)
    average_num_list.append(avg_num9)
    
    num = 0
    for obj in h10:
        num = num + obj
    avg_num10 = round((num/30),2)
    average_num_list.append(avg_num10)
    
    num = 0
    for obj in h11:
        num = num + obj
    avg_num11 = round((num/30),2)
    average_num_list.append(avg_num11)
    
    num = 0
    for obj in h12:
        num = num + obj
    avg_num12 = round((num/30),2)
    average_num_list.append(avg_num12)
    
    num = 0
    for obj in h13:
        num = num + obj
    avg_num13 = round((num/30),2)
    average_num_list.append(avg_num13)
    
    num = 0
    for obj in h14:
        num = num + obj
    avg_num14 = round((num/30),2)
    average_num_list.append(avg_num14)
    
    num = 0
    for obj in h15:
        num = num + obj
    avg_num15 = round((num/30),2)
    average_num_list.append(avg_num15)
    
    num = 0
    for obj in h16:
        num = num + obj
    avg_num16 = round((num/30),2)
    average_num_list.append(avg_num16)
    
    num = 0
    for obj in h17:
        num = num + obj
    avg_num17 = round((num/30),2)
    average_num_list.append(avg_num17)
    
    num = 0
    for obj in h18:
        num = num + obj
    avg_num18 = round((num/30),2)
    average_num_list.append(avg_num18)
    
    num = 0
    for obj in h19:
        num = num + obj
    avg_num19 = round((num/30),2)
    average_num_list.append(avg_num19)
    
    num = 0
    for obj in h20:
        num = num + obj
    avg_num20 = round((num/30),2)
    average_num_list.append(avg_num20)
    
    num = 0
    for obj in h21:
        num = num + obj
    avg_num21 = round((num/30),2)
    average_num_list.append(avg_num21)
    
    num = 0
    for obj in h22:
        num = num + obj
    avg_num22 = round((num/30),2)
    average_num_list.append(avg_num22)
    
    num = 0
    for obj in h23:
        num = num + obj
    avg_num23 = round((num/30),2)
    average_num_list.append(avg_num23)
    
    num = 0
    for obj in h24:
        num = num + obj
    avg_num24 = round((num/30),2)
    average_num_list.append(avg_num24)

    #Return the list of the averages of temperature of each hour for the 30
    #days in june. Ideally only 24 entries in this list.
    return average_num_list

#This is the main function.
def main():

    #This opens up the file temperature.txt which holds the temperature data
    #for the entire year of 2012.
    file_obj = open('temperature.txt', 'r')

    #These variables will hold the number of days of each month.
    jan_days = 31
    feb_days = 29
    mar_days = 31
    apr_days = 30
    may_days = 31
    jun_days = 30
    jul_days = 31
    aug_days = 31
    sep_days = 30
    oct_days = 31
    nov_days = 30
    dec_days = 31

    #This is calling the function to run through the months data and get the
    #average high and low back and assign that into the variable.
    jan_var = average_temp(0, jan_days, file_obj)
    feb_var = average_temp(744, feb_days, file_obj)
    mar_var = average_temp(1440, mar_days, file_obj)
    apr_var = average_temp(2184, apr_days, file_obj)
    
    #For whatever reason, when I send may through the average_temp function it
    #comes back with a Index error. I don't understand how it can work for the
    #first four months but not continue working.

    #Also, when I was testing just the month of may through the average_temp
    #function, it would run just fine with no error. I tried to find where
    #the index error was coming through but I can't seem to find it.
    
    #print("something?")
    may_var = average_temp(2904, may_days, file_obj)
    jun_var = average_temp(3648, jun_days, file_obj)
    jul_var = average_temp(4368, jul_days, file_obj)
    aug_var = average_temp(5112, aug_days, file_obj)
    sep_var = average_temp(5856, sep_days, file_obj)
    oct_var = average_temp(6576, oct_days, file_obj)
    nov_var = average_temp(7320, nov_days, file_obj)
    dec_var = average_temp(8040, dec_days, file_obj)

    #This closes the file object so we can open up a new file.
    file_obj.close()

    #This opens up the solar_radition.txt so we can read in the data and grab
    #June's solar radition data.
    file_obj = open('solar_radition.txt', 'r')

    #This gets the avg solar radition list when run through the average solar
    #radition function.
    radiation_list = average_solar_radiation(3648, jun_days, file_obj)

    #This closes the file object so we can open up a new file.
    file_obj.close()

    #This opens the temperature.txt file back up so we can get the average temp
    #data of each hour for each day in the month of June.
    file_obj = open('temperature.txt', 'r')

    #This gets the avg temp data lies when run through the average hour temp
    #function.
    june_hour_temp = average_hour_temp(3648, jun_days, file_obj)

    #This closes the file object.
    file_obj.close()

    #This lets python know we have one figure we are creating.
    plt.figure(1)

    #The vertical axis label.
    plt.ylabel("Average Temperature")

    #The horizontal axis label.
    plt.xlabel("Months")

    #The figure's title.
    plt.title('Charleston, MO - 2012')
    
    #X is used for the xticks so we can change the horizontal axis markers.
    x = np.array([0,1,2,3,4,5,6,7,8,9,10,11,12])

    #This is the list of the markers for the x axis.
    my_xaxis = ['', 'January', 'Febuary', 'March', 'April', 'May', 'June',\
                'July', 'August', 'September', 'October','November' \
                'December']

    #Resets the ticks on the x axis to the months and the months are rotated
    #45 degress so we can read them.
    plt.xticks( x, my_xaxis, rotation=45)


    #This would be the bottom of the bars, or the avg low temp for each month.
    b = np.array([jan_var[0],feb_var[0],mar_var[0],apr_var[0],may_var[0],\
                  jun_var[0],jul_var[0],aug_var[0],sep_var[0],oct_var[0],\
                  nov_var[0],dec_var[0]])

    #This would be the top of the bars, or the avg high temp for each month.
    y = np.array([jan_var[1],feb_var[1],mar_var[1],apr_var[1],may_var[1], \
                  jun_var[1],jul_var[1],aug_var[1],sep_var[1],oct_var[1], \
                  nov_var[1],dec_var[1]])

    #NOTE: Somewhere in here it is giving me a syntax error. I can not find
    #the error and since the error jumps around I think it is a spacing issue
    #but I can't seem to locate it.

    #Creating the actual bars of the bar graph.
    plt.bar(x,y, width = .5, bottom=b, align = 'center')

    #Showing the graph.
    plt.show()

    #Once we close out of the first figure, python knows we want to make
    #and show the second figure.
    fig_var = plt.figure(2)

    #Adds a sub plt and makes it possible for the second plot line to appear
    #on the graph.
    axis1 = fig_var.add_subplot(111)

    #Says that there are two y axes that share a x axis.
    axis2 = axis1.twinx()


    #The horizontal axis label.
    plt.xlabel("Hour")

    #The figure's title.
    plt.title('Charleston, MO - June 2012')

    #X is used for the xticks so we can change the horizontal axis markers.
    x = np.array([1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20\
                              ,21,22,23,24])

    #These are the points for the radition line of the graph.
    y = np.array([radiation_list[0],radiation_list[1],radiation_list[2],\
              radiation_list[3],radiation_list[4],radiation_list[5],\
              radiation_list[6],radiation_list[7],radiation_list[8],\
              radiation_list[9],radiation_list[10],radiation_list[11],\
              radiation_list[12],radiation_list[13],radiation_list[14],\
              radiation_list[15],radiation_list[16],radiation_list[17],\
              radiation_list[18],radiation_list[19],radiation_list[20],\
              radiation_list[21],radiation_list[22],radiation_list[23]])

    #This sets the ticks for the secondary y axis.
    axis2.axis([0,25,0,800])
    
    #Ploting the radition data in a red solid line with circle dots.
    axis2.plot(x,y, 'ro-')

    #This sets the secondary axis ticks to red along with the axis label.
    axis2.set_ylabel('Average Solar Radiation', color='r')
    for obj in axis2.get_yticklabels():
        obj.set_color('r')
        
    #These are the points for the temperature line of the graph.
    t = np.array([june_hour_temp[0],june_hour_temp[1],june_hour_temp[2],\
              june_hour_temp[3],june_hour_temp[4],june_hour_temp[5],\
              june_hour_temp[6],june_hour_temp[7],june_hour_temp[8],\
              june_hour_temp[9],june_hour_temp[10],june_hour_temp[11],\
              june_hour_temp[12],june_hour_temp[13],june_hour_temp[14],\
              june_hour_temp[15],june_hour_temp[16],june_hour_temp[17],\
              june_hour_temp[18],june_hour_temp[19],june_hour_temp[20],\
              june_hour_temp[21],june_hour_temp[22],june_hour_temp[23]])

    #The sets the ticks for the primary y axis.
    axis1.axis([0,25,0,90])
    
    #Ploting the temperature data in a blue solid line with circle dots.
    axis1.plot(x,t, 'bo-')
    

    #This sets the primary axis ticks to blue along with the axis label.
    axis1.set_ylabel('Average Temp', color='b')
    for obj in axis1.get_yticklabels():
        obj.set_color('b')
    

    #Show the second figure.
    plt.show()

#Run the main function.
main()


#Note to QP: So... I have the formatting for the graphs all done (I tested it
#on a smaller program and it looks like the formatting of the graphs in the pdf)
#but the data collection is giving me issues. When I first was writing the
#program it was working just fine. Now opening it up today it doesn't want to 
#work. Giving me some syntax error and an index error that doesn't make sense.
#Both are referenced eariler in the program. I tried my best. Like I said,
#the formatting of the graphs is correct but the data is collecting right now.
