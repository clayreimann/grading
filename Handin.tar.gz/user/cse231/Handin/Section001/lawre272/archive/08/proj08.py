################################################################################
#Project 8
#Section 001H
#Date: 3/18/2013
#lawre272
#
#Program Overview
#1. Opening the file "ap_docs.txt", grab all the words in the file and strip
#them of numbers and punctuation.
#
#2. Take each word and break them up by their letters to creat your different
#keys for your dictionary. Then for each corresponding key, add that word into
#their set of values.
#
#3. Prompt the user for a prefix that they would just start typing in. When they
#hit enter, print out the set of words in the dictonary that could be possible
#results for the prefix they entered.
#
#4. Repeat until the '#' symbol is used.
################################################################################
import string

#Function that fills in the dictionary of keys and words.
def fill_completions(c_dict, fd):
    #For each line in the file...
    for line in fd:
        line = line.strip()
        line_list = line.split(" ")
        #If the line is empty, ignore it and continue on.
        if line_list == ['']:
            continue
        #For each word in the line
        for word in line_list:
            #If they word starts or ends with these conditions ignore the word.
            #This is to ignore the <NEW DOCUMENT> lines and other lines with
            #file formating.
            if word[0] == '<' or word[-1] == '>' or \
               word[0] == '<' and word[-1] == '>':
                continue
            #The first attempt to strip away the punctuation.
            my_list = list(string.punctuation)
            count = 0
            while count < len(my_list):
                word = word.strip(my_list[count])
                count += 1
            #For words with '-' in them, they would combined together instead
            #of separting so I'm ignoring those words so it doesn't return
            #words that are weird. Ex. "abarrel"
            charcheck = ''
            for char in word:
                if char == '-':
                    charcheck = 1
                if char == '`':
                    charcheck = 1
            if charcheck == 1:
                continue
            #Yet another attempt to strip out the numbers and punctuation. 
            #Still gives me some words with select punctuatation.
            for char in string.digits + string.punctuation:
                word = word.replace(char, '')

            if len(word) > 1:
                #The last sweep of stripping away those odd punctuation marks.
                count1 = 0
                for char in word:
                    if char == "'":
                        word = word[:count1] + word[count1 + 1:]
                        continue
                    if char == ".":
                        word = word[:count1] + word[count1 + 1:]
                        continue
                    if char == ",":
                        word = word[:count1] + word[count1 + 1:]
                        continue
                    count1 += 1
                #Changes the word to lower case and then enumerates it and adds
                #the keys and words into the dictionary.
                word = word.lower()
                for tup in enumerate(word):
                    #If key exists...
                    if tup in c_dict:
                        c_dict[tup].add(word)
                    #If key doesn't exist...
                    else:
                        c_dict[tup] = set()
                        c_dict[tup].add(word)

#A function that takes the prefix given and returns a list of words that could
#be possible words that the user is trying to type.
def find_completions(prefix, c_dict):
    #Sets a baseline set then enumerates the prefix and keeps adding to the set
    #by using the intersection menthod. Then returns the set of strings.
    first_set = c_dict[0, prefix[0]]
    for tup in enumerate(prefix):
        new_set = c_dict[tup]
        first_set = new_set & first_set

    return(first_set)
        
#Main function.
def main():
    #Opens up file "ap_docs.txt" and reads into it and fills up the dictionary.
    file_obj = open("ap_docs.txt", "r")
    comp_dict = {}
    fill_completions(comp_dict, file_obj)
    prefix = ''
    #Main while loop
    while True:
        try:
            #Prompts user for prefix. If prefix is '#' break the loop which
            #ends the program.
            prefix = input("Please type in a prefix or type '#' when done: ")
            if prefix == '#':
                print("Thank you!")
                break

            #If its not the "#', then it will print out the set of strings.
            #If the set of strings is empty then it will say the prefix has no
            #completions and continue on.
            else:
                set_str = find_completions(prefix, comp_dict)
                if set_str == set():
                    print("This prefix has no completions.")

                else:
                    print(set_str)
                    
        except KeyError:
            #If the error KeyError pops up it will say the prfix has no
            #completions and continue on.
            print("This prefix has no completions.")

main()
