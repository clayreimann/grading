##############################################################################
#Project 5
#Date: 2/7/2013
#lawre272
#
#Project Overview
#1. Print a menu of legal colors and ask for two colors. (define function)
#2. Prompt for the number of hexagons per row. (define function)
#3. Import math and calculate the side length of each hexagon based on number
# of hexagons. (used for the pixels wide)
#4. Define a function that can draw a hexagon in turtle.
#5. Figure out placement of the hexagons to make the diagonal pattern.
##############################################################################

#Import turtle so we can draw the hexagons.
import turtle

#Import math so we can do some of the math needed to figure out
# side length.
import math

#The function  that will continue to prompt for colors until a legal color
#value is entered.
def get_color_choice():
    print(" ")
    color_choice = input("Please enter your choice: ")
    while True:
        if color_choice != "red"\
           and color_choice != "blue"\
           and color_choice != "green"\
           and color_choice != "yellow"\
           and color_choice != "orange"\
           and color_choice != "purple"\
           and color_choice != "pink":

            print(color_choice, "is not a legal choice.")
            color_choice = input("Please try again: ")
            continue
        else:
            return(color_choice)
            break

#The function that will continue to prompt for a number of hexagons until
#a value is entered between 4 and 20.
def get_num_hexagons():
    print(" ")
    hexnum = int(input("Please enter a number of hexagons per row: "))
    while True:
        if 4 <= hexnum <= 20:
            return(hexnum)
            break
        else:
            print("It should be between 4 and 20.")
            hexnum = int(input("Please try again: "))
            continue

#The function that will actually draw the hexagons and fill them with color.
def draw_hexagon(x, y, side_len, pen, color):
    pen.up()
    pen.goto(x,y)
    pen.down()
    pen.speed(100)
    pen.begin_fill()
    pen.left(30)
    pen.forward(side_len)
    pen.left(60)
    pen.forward(side_len)
    pen.left(60)
    pen.forward(side_len)
    pen.left(60)
    pen.forward(side_len)
    pen.left(60)
    pen.forward(side_len)
    pen.left(60)
    pen.forward(side_len)
    pen.left(30)
    pen.fillcolor(color)
    pen.end_fill()

#Print out the menu of colors for the user to choose from.
print("Choices for colors to use are:")
print("  red")
print("  blue")
print("  green")
print("  yellow")
print("  orange")
print("  purple")
print("  pink")

#Prompt the user for two colors and a number of hexagons between 4 and 20
#using the functions defined above.
color1 = get_color_choice()
color2 = get_color_choice()
hexnum_choice = get_num_hexagons()

#Figuring out the width of the hexagon, the side lengths, the height and
#the y offset for each row.
hexwidth = round(500/hexnum_choice)
side_len = (hexwidth/2)/(math.cos((math.pi)/6))
hexheight = side_len*2
triheight = hexheight - (side_len * math.sin((math.pi)/6))

#Start at the top left corner of the python screen.
yposition = 150
xposition = -250
hexnum_row_counter = 1

#Main while loop for drawing the hexagons.
while hexnum_row_counter <= hexnum_choice:
    
#For the two rows starting with the first color.
    if hexnum_row_counter == 1\
                            or hexnum_row_counter == 2\
                            or hexnum_row_counter == 5\
                            or hexnum_row_counter == 6\
                            or hexnum_row_counter == 9\
                            or hexnum_row_counter == 10\
                            or hexnum_row_counter == 13\
                            or hexnum_row_counter == 14\
                            or hexnum_row_counter == 17\
                            or hexnum_row_counter == 18:

#The second row of the first color has to be offset just a bit before it can
#start to repeat colors.
        if hexnum_row_counter % 2 == 0:
            hexnum_counter = 0
            xposition = -250 - hexwidth/2

#The first initial hexagon in the row.
            draw_hexagon( xposition, yposition, side_len, turtle, color1)

#The while loop that actually draws the hexagons to the number specified
#by the user.
            while hexnum_counter < hexnum_choice -1:
                if hexnum_counter % 2 == 0:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color2)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1
                else:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color1)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1

            hexnum_row_counter += 1
            yposition = yposition - triheight

#The first row of the first color can stay in the starting xposition so it
#fits with the second row.
        else:
            hexnum_counter = 0
            xposition = -250
            draw_hexagon( xposition, yposition, side_len, turtle, color1)
    
            while hexnum_counter < hexnum_choice -1:
                if hexnum_counter % 2 == 0:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color2)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1
                else:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color1)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1

            hexnum_row_counter += 1
            yposition = yposition - triheight

#Same process as above but with the second color.
    else:
        if hexnum_row_counter % 2 == 0:
            xposition = -250 - hexwidth/2
            hexnum_counter = 0
            draw_hexagon( xposition, yposition, side_len, turtle, color2)
    
            while hexnum_counter < hexnum_choice -1:
                if hexnum_counter % 2 == 0:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color1)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1
                else:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color2)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1
                    
            hexnum_row_counter += 1
            yposition = yposition - triheight
            
        else:
            xposition = -250
            hexnum_counter = 0
            draw_hexagon( xposition, yposition, side_len, turtle, color2)
    
            while hexnum_counter < hexnum_choice -1:
                if hexnum_counter % 2 == 0:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color1)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1
                else:
                    draw_hexagon( xposition + hexwidth, yposition,\
                                  side_len, turtle, color2)
                    xposition = xposition + hexwidth
                    hexnum_counter += 1

            hexnum_row_counter += 1
            yposition = yposition - triheight




