################################################################################
#Section 001H
#Project 10
#Date: 4/6/2013
#lawre272
#
#Program Overview:
#Creat three classes, a star class, a rectangle class and a flag class to draw
#a flag using turtle.
#
#Note: My code is going to simply run the myFlag.txt in the program.
################################################################################
import turtle
import time

#The class to make the star shapes.
class Star():
    #This makes each instance of the star class.
    def __init__(self, x = 0, y = 0, arm_length = 0, color = ""):
        self.x = int(x)
        self.y = int(y)
        self.arm_length = int(arm_length)
        self.color = color
    #This draws the stars using Turtle.
    def draw(self, turtle):
        turtle.pencolor("black")
        turtle.up()
        turtle.goto(self.x, self.y)
        turtle.left(90)
        turtle.forward(self.arm_length/2.35)
        turtle.right(90)
        turtle.forward(self.arm_length/3.236)
        turtle.down()
        turtle.begin_fill()
        turtle.fillcolor(self.color)
        turtle.forward(self.arm_length)
        turtle.right(144)
        turtle.forward(self.arm_length)
        turtle.left(72)
        turtle.forward(self.arm_length)
        turtle.right(144)
        turtle.forward(self.arm_length)
        turtle.left(72)
        turtle.forward(self.arm_length)
        turtle.right(144)
        turtle.forward(self.arm_length)
        turtle.left(72)
        turtle.forward(self.arm_length)
        turtle.right(144)
        turtle.forward(self.arm_length)
        turtle.left(72)
        turtle.forward(self.arm_length)
        turtle.right(144)
        turtle.forward(self.arm_length)
        turtle.left(72)
        turtle.end_fill()
    #This returns a string with the position of the star, arm length and the
    #color.
    def __str__(self):
        return "Star x:{}, y:{}, arm:{}, color:{}".format \
               (self.x, self.y, self.arm_length, self.color)

#This is the rectangle class to make the rectangle shapes.
class Rectangle():
    #This makes the instances of the rectangle class.
    def __init__(self, x = 0, y = 0, width = 0, height = 0, color = ""):
        self.x = int(x)
        self.y = int(y)
        self.width = int(width)
        self.height = int(height)
        self.color = color
    #This actually draws the rectangle in Turtle.
    def draw(self, turtle):
        turtle.pencolor("black")
        turtle.up()
        turtle.goto(self.x, self.y)
        turtle.forward(self.width/2)
        turtle.left(90)
        turtle.forward(self.height/2)
        turtle.left(90)
        turtle.down()
        turtle.begin_fill()
        turtle.fillcolor(self.color)
        turtle.forward(self.width)
        turtle.left(90)
        turtle.forward(self.height)
        turtle.left(90)
        turtle.forward(self.width)
        turtle.left(90)
        turtle.forward(self.height)
        turtle.right(90)
        turtle.end_fill()
    #This returns a string with the position of the rectangle, width, height
    #and the color.
    def __str__(self):
        return "Rectangle x:{}, y:{}, width:{}, height:{}, color:{}".format \
                         (self.x, self.y, self.width, self.height, self.color)

#This class actually calls the rectangle and star class to make the flags using
#the file object.
class Flag():
    #This makes the instances of the flag.
    def __init__(self, file_object):
        #Reads the first line to get the number of rectangles.
        num_of_rec = int(file_object.readline())
        count = 0
        rec_spec = []
        #Going through the next few lines of rectangle specs I make a list of
        #rectangle specs.
        while count < num_of_rec:
            rectangle = file_object.readline()
            rectangle = rectangle.strip()
            rectangle = rectangle.split(",")
            for num in range(len(rectangle)):
                rectangle[num] = rectangle[num].strip(" ")
            rec_spec.append(rectangle)
            count += 1
        #print(rec_inst)
        
        #Reads the next line to get the number of stars.
        num_of_star = int(file_object.readline())
        count = 0
        star_spec = []
        #Going through the remaining lines of star specs, I make a list of star
        #specs.
        while count < num_of_star:
            star = file_object.readline()
            star = star.strip()
            star = star.split(",")
            for num in range(len(star)):
                star[num] = star[num].strip(" ")
            star_spec.append(star)
            count += 1
        #print(star_inst)
            
        self.star_spec = star_spec #Makes the list of star specs.
        self.rec_spec = rec_spec   #Makes the list of rectangle specs.

        #Making the list of rectangle instances.
        rec_inst = []
        for num in self.rec_spec:
            #print(num)
            inst_rec = Rectangle(num[0], num[1], num[2], num[3], num[4])
            rec_inst.append(inst_rec)

        #Making the list of star instances.
        star_inst = []
        for num in self.star_spec:
            inst_star = Star(num[0], num[1], num[2], num[3])
            star_inst.append(inst_star)

        self.star_inst = star_inst
        self.rec_inst = rec_inst
        
    def draw(self, turtle):
        #print(self.rec_inst)

        #Using the list of rectangle instances, it draws the rectangles.
        for obj in self.rec_inst:
            obj.draw(turtle)
        #Using the list of star instances, it draws the star.
        for obj in self.star_inst:
            obj.draw(turtle)

    #Returns a string of all the rectangle information and the star information.
    def __str__(self):
        rect = "Rectangle \n"
        num = len(self.rec_spec)
        count = 0
        reclist = []
        #Does the formatting and makes a list of strings.
        while count < num:
            reci = "x:{}, y:{}, width:{}, height:{}, color:{}\n".format \
                         (self.rec_spec[count][0], self.rec_spec[count][1], \
                          self.rec_spec[count][2],self.rec_spec[count][3], \
                          self.rec_spec[count][4])
            reclist.append(reci)
            count += 1
        #Takes the list of strings and contatonates it into a string.
        count = 0
        recistr = ''
        recidone = reclist[0]
        while count < num - 1:
            recidone = recidone + reclist[count + 1]
            count += 1

        star = "Star \n"
        num = len(self.star_spec)
        count = 0
        starlist = []
        #Does the formatting and makes a list of strings.
        while count < num:
            stari = "x:{}, y:{}, a:{}, c:{}\n".format(self.star_spec[count][0], \
                                                      self.star_spec[count][1], \
                                                      self.star_spec[count][2], \
                                                      self.star_spec[count][3])
            starlist.append(stari)
            count += 1
        #Takes the list of strings and contatonates it into a string.
        count = 0
        staristr = ''
        staridone = starlist[0]
        while count < num - 1:
            staridone = staridone + starlist[count + 1]
            count += 1
        #Takes all the parts and contatonates it into one big string.
        strreturn = rect + recidone + star + staridone
        return strreturn
                

def main():
    #Chunk of code draws the Senegal Flag.
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    #Chunk of code draws the Panama Flag.
    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    #Chunk oc code draws the American Flag.
    time.sleep(4)   # delay so you can see your flag"""
    turtle.clearscreen()
    panama_file = open('myFlag.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

#Runs the main funtion.
main()
