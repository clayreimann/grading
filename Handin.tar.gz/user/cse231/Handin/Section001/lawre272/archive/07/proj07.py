################################################################################
#Section: 001H
#Date: 3/2/2013
#Project 7
#lawre272
#
#Project Overview:
#
#1. Prompt for a file of English text to read and another file to be able to
#write to.
#
#2. Read each line of the file and scramble each word on the line but keeping
#the first and last letter of the word the same.
#
#3. Output the lines to the file by writing to it.
################################################################################
import random

def scramble_word(word_str):       #Function to scramble a single word.
    unscram_word_str = word_str
    if len(unscram_word_str) <= 3: #Ignore words that have a length of 3 or less
        return(unscram_word_str)
    #if len(unscram_word_str) == 4: #Makes sure words of length 4 are scrambled.
      #  end_letters = unscram_word_str[0] + unscram_word_str[-1]
       # scram_word = unscram_word_str[0] + unscram_word_str[2] + \
        #                 unscram_word_str[1] + unscram_word_str[-1]
       # return(scram_word)

    else:
        #Each if statement sets a condition for the word to meet but the process
        #is realitivly the same.
        
        #If there is a " at the beginning and end of the word.
        if unscram_word_str[0] == '"' and unscram_word_str[-1] == '"':
            #Making a copy of the string
            unscram_word_list = unscram_word_str
            #Getting the end letters of the word.
            end_letters = unscram_word_list[0:2] + unscram_word_list[-2:]
            #Finding the middle letters of the word, (letters that will be
            #shuffled), listing them so they can be shuffled and then putting
            #the shuffled letters back into a string.
            middle_word = unscram_word_list[2:-2]
            middle_word_list = list(middle_word)
            random.shuffle(middle_word_list)
            middle_word_str = ''.join(middle_word_list)
            #Reassemebling the now scrambled word.
            scram_word = unscram_word_list[0:2] + middle_word_str \
                         + unscram_word_list[-2:]
            return(scram_word)

        if unscram_word_str[0] == '"' and unscram_word_str[-2:] == '")':
            unscram_word_list = unscram_word_str
            end_letters = unscram_word_list[0:2] + unscram_word_list[-3:]
            middle_word = unscram_word_list[2:-3]
            middle_word_list = list(middle_word)
            random.shuffle(middle_word_list)
            middle_word_str = ''.join(middle_word_list)
            scram_word = unscram_word_list[0:2] + middle_word_str \
                         + unscram_word_list[-3:]
            return(scram_word)

        if unscram_word_str[0] == '"' or unscram_word_str[0] == "'" or \
            unscram_word_str[0] == "(":
            unscram_word_list = unscram_word_str
            end_letters = unscram_word_list[:2] + unscram_word_list[-1]
            middle_word = unscram_word_list[2:-1]
            middle_word_list = list(middle_word)
            random.shuffle(middle_word_list)
            middle_word_str = ''.join(middle_word_list)
            scram_word = unscram_word_list[:2] + middle_word_str \
                          + unscram_word_list[-1]
            return(scram_word)
        
        if unscram_word_str[-1] == '.' or unscram_word_str[-1] == '?' or \
           unscram_word_str[-1] == '!' or unscram_word_str[-1] == ',' or \
           unscram_word_str[-1] == '"' or unscram_word_str[-1] == "'" or \
           unscram_word_str[-2] == "'" or unscram_word_str[-1] == ")":
            unscram_word_list = unscram_word_str
            end_letters = unscram_word_list[0] + unscram_word_list[-2:]
            middle_word = unscram_word_list[1:-2]
            middle_word_list = list(middle_word)
            random.shuffle(middle_word_list)
            middle_word_str = ''.join(middle_word_list)
            scram_word = unscram_word_list[0] + middle_word_str \
                         + unscram_word_list[-2:]
            return(scram_word)
            
        else:
            unscram_word_list = unscram_word_str
            end_letters = unscram_word_list[0] + unscram_word_list[-1]
            middle_word = unscram_word_list[1:-1]
            middle_word_list = list(middle_word)
            random.shuffle(middle_word_list)
            middle_word_str = ''.join(middle_word_list)
            scram_word = unscram_word_list[0] + middle_word_str \
                         + unscram_word_list[-1]
            return(scram_word)

def scramble_line(line_str):       #Fucntion that will scramble entire lines.
    line_list = line_str.split()   #Spliting the string and making a list of
    count = 0                      #words from the text line.
    scram_line = []
    for char in line_list:         #For loop to go through each word and run it
        scram_line.append(scramble_word(char))  #the scramble_word function.
        scram_line_list = list(scram_line)
        count +=1
    scram_line_str = ' '.join(scram_line_list) #Remake the list of scrambled
                                    #words into a line of text (strngs).
    return(scram_line_str)
                 
def open_read_file(file_name_str):
    #Saying that it wants to read the file
    mode_str = 'r'
    file_bool = False
    while (not file_bool):
        try:
            #Tries to open the file. If it's a legal file, set boolean to true.
            file_name_obj = open(file_name_str, mode_str)
            file_bool = True
        #If an IOError pops up, do this:
        except IOError:
            #Tell the user its a bad file and prompt again.
            print("Bad file name, try again ")
            file_name_str = input("Open what file: ")
    else:
        #Return the file discriptor.
        return(file_name_obj)

def main():
    #Prompting for a file to open
    filename_str = input("Open what file: ")
    file_obj = open_read_file(filename_str) #Opens the file and returns the file
                                            #object.
                                #For loop that will run each line in the file
                                #through the scramble_line function.
    for line in file_obj:
        scram_line = scramble_line(line)
    file_obj.close()
                                #Open a file to write to and then write the
                                #scrambled text.
    #Just a fair note. I'm not quite sure if this is what was meant by a second
    #file_obj. So I hope this is right.
    filename_out = input("What file to write to: ")
    file_obj_w = open(filename_out, 'w')
    file_obj_w.write(scram_line)
    file_obj_w.close()

main()
