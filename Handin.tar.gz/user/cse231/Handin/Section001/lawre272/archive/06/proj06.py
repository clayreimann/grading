##############################################################################
#Section: 001H
#Date: 2/24/2013
#lawre272
#
#Program Overview:
#
#1. Define four functions that you will use to execute this program. They will
# be broken down so that you can test them so that each part works before the
# the main.
#
#2. The get_input_desciptor() function will repeatedly prompt for the name of
# the file until the user enters a correct file that can be opened. It will
# return the file discriptor attached to the opened file.
#
#3. The get_data_list function will read the data in the file. The data can be
# read from any column and it will return a list that consists tuples in the
# form (date,column_data).
#
#4. The average_data function will take the return of the get_data_list function
# and average the data for each month and create another list of tuples. This
# form will be in (data_avg, date). The date does not contain a day any more.
#
#5. The main file will call the get_input to get a file descriptor and promt for
# a colum to average. Call the get_data functionoa and the average_data function
# and run both functions and then finally print the top 6 entries and the bottom
# 6 entries.
#
##############################################################################

def get_input_descriptor():
    #Prompting for a file to open
    filename_str = input("Open what file: ")
    #Saying that it wants to read the file
    mode_str = 'r'
    file_bool = False
    while (not file_bool):
        try:
            #Tries to open the file. If it's a legal file, set boolean to true.
            file_obj = open(filename_str, mode_str)
            file_bool = True
        #If an IOError pops up, do this:
        except IOError:
            #Tell the user its a bad file and prompt again.
            print("Bad file name, try again ")
            filename_str = input("Open what file: ")
    else:
        #Return the file discriptor.
        return(file_obj)

def get_data_list(file_object, column_number):
    count = 0
    my_list = []

    #Read the first line of the file since it doesnt conatain numerical data.
    file_object.readline()

    #For loop to get the list of tuples for the specified data.
    for line_str in file_object:
        line_str = line_str.split(',') #Spliting the coloumn to make it\
                                       #easier to grab pieces.
        #print(line_str)
        column_data = line_str[column_number] #Specifying the column number\
                                       #to get the data out of the list.

        date = line_str[0]             #Getting the date for the tuple.
        my_tuple = date, column_data   #Making the tuple.
        my_list.append(my_tuple)

    count += 1
    sorted_list = sorted(my_list)      #Sort the list so that it makes the
    file_object.close()                #months in order.

    return(sorted_list)                #Returns the list of tuples.

def average_data(list_of_tuples):
    count = 0
    my_average_list = []

    while count < len(list_of_tuples): #Need to reset the date format.
        my_tuple = list_of_tuples[count]
        date = my_tuple[0]             #Grabbing the date from the list.
        data = float(my_tuple[1])      #Grabbing the data from the list.

        date_split = date.split('-')
        new_date = date_split[1] + '-' + date_split[0] #The new formated date.
        my_new_tuple = new_date, data  #The new tuple with the updated date.
                                    #The date now only has the month and year.
        my_average_list.append(my_new_tuple) #The new list of tuples.

        count += 1

    count1 = 0 #Counts the number of values in each month.
    count2 = 0 #counts the number times we run through this so that it will be
               #able to count till the end of the list.

    total_data = 0                     #Set up total_data.
    start_date = my_average_list[0]    #Sets up the beginning month in the list.

    average_data_list = []             #Sets up empty string that will be needed
                                       #at the end.

    for list_tuple in my_average_list:
        if list_tuple == start_date:   #Checks to see if current date equals
            date_old = list_tuple[0]   #start date.
            count1 = 0                 #Resets the month value counter.

        if list_tuple[0] == date_old:  #Main meat where the adding gets done.
            total_data = total_data + list_tuple[1]
            date_old = list_tuple[0]   #Resets the compairson date.
            count1 += 1
            count2 += 1

        if list_tuple[0] != date_old or count2 == len(my_average_list):
            #For the last value in the list.
            if count2 == len(my_average_list):
                total_data = total_data + list_tuple[1]
                count1 += 1
                average_data =  round(total_data/ count1, 2)
                average_tuple = average_data, list_tuple[0]
                #Adds last value in the list to complete the list of tuples.
                average_data_list.append(average_tuple)
                break

                                       #The main meat of the averaging.
            average_data =  round(total_data/ count1, 2)
            average_tuple = average_data, date_old
            average_data_list.append(average_tuple)

            start_date = list_tuple[0]
            date_old = list_tuple[0]
            total_data = list_tuple[1]
            
            count1 = 1
            count2 += 1     

    return(average_data_list)

def main(): #Main function.
    #Make sure
    file_object = get_input_descriptor()
    column_number = int(input("What column: "))

    check = False
    while(not check):
        #check that the coloum number doesnt excede the actual number of\
        #coloums.
        if 0 < column_number and column_number <7:
            #Get the tuple list of the data specified.
            data_list = get_data_list(file_object, column_number)
            #Get the tuple list of the average data and the dates.
            average_list = average_data(data_list)
            average_list = sorted(average_list)

            #Printing the 6 lowest values for the column data.
            print("Lowest 6 for column", column_number)
            print("Date:", average_list[0][1], " ", \
                  "Value: ", average_list[0][0])
            print("Date:", average_list[1][1], " ", \
                  "Value: ", average_list[1][0])
            print("Date:", average_list[2][1], " ", \
                  "Value: ", average_list[2][0])
            print("Date:", average_list[3][1], " ", \
                  "Value: ", average_list[3][0])
            print("Date:", average_list[4][1], " ", \
                  "Value: ", average_list[4][0])
            print("Date:", average_list[5][1], " ", \
                  "Value: ", average_list[5][0])

            print(" ")

            #Printing the 6 highest values for the column data.
            print("Highest 6 for column", column_number)
            print("Date:", average_list[-1][1], " ", \
                  "Value: ", average_list[-1][0])
            print("Date:", average_list[-2][1], " ", \
                  "Value: ", average_list[-2][0])
            print("Date:", average_list[-3][1], " ", \
                  "Value: ", average_list[-3][0])
            print("Date:", average_list[-4][1], " ", \
                  "Value: ", average_list[-4][0])
            print("Date:", average_list[-5][1], " ", \
                  "Value: ", average_list[-5][0])
            print("Date:", average_list[-6][1], " ", \
                  "Value: ", average_list[-6][0])

            #Once printed exit the loop.
            check = True
        else:
            #If the coloumn number is out of range reprompt.
            print("Not in file range.")
            column_number = int(input("What column: "))

main()
