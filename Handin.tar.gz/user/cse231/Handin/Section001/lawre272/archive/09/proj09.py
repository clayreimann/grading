################################################################################
#Project 9
#Section 001H
#Date: 3/25/2013
#lawre272
#
#Program Overview
#1. Recreate the seahaven card game and reenforce the rules of the game.
#
################################################################################
import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    my_deck = cardsBasic.Deck()
    my_deck.shuffle()
    
    foundation = [[], [], [], []]
    tableau =[[], [], [], [], [], [], [], [], [], []]
    cell = [[], [], [], []]

    #This is formatting the tableau lists to set up the game.
    for i in range(6):
        tableau[0].append(my_deck.deal())
        tableau[1].append(my_deck.deal())

    for i in range(5):
        tableau[2].append(my_deck.deal())
        tableau[3].append(my_deck.deal())
        tableau[4].append(my_deck.deal())
        tableau[5].append(my_deck.deal())
        tableau[6].append(my_deck.deal())
        tableau[7].append(my_deck.deal())
        tableau[8].append(my_deck.deal())
        tableau[9].append(my_deck.deal())

    return foundation,tableau,cell


def move_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    moves a card at the end of a column of tableau to a column of foundation
    '''
    a_card = tableau[t_col][-1]
    tableau[t_col].pop() #This gets rid of the card out of the tableau.
    foundation[f_col].append(a_card) #This adds it to the foundation.

def cell_to_foundation(cell,foundation,c_col,f_col):
    '''
    parameters: a cell, a foundation, column of cell, column of foundation
    moves a card at the end of a column of cell to a column of foundation
    '''
    a_card = cell[c_col][-1]
    cell[c_col].pop()
    foundation[f_col].append(a_card)



def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    moves a card at the end of a column of tableau to a cell
    '''
    a_card = tableau[t_col][-1]
    tableau[t_col].pop()
    cell[c_col].append(a_card)

def move_to_tableau(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    moves a card in the cell to a column of tableau
    '''
    a_card = cell[c_col][-1]
    tableau[t_col].append(a_card)
    cell[c_col].pop()
        

def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean True'''
    
    if foundation[0] == [] and foundation[1] == [] and foundation[2] == [] and \
       foundation[3] == []:
        pass
    else:
        try:
            f_card1 = foundation[0][-1]
            f_card2 = foundation[1][-1]
            f_card3 = foundation[2][-1]
            f_card4 = foundation[3][-1]
            if f_card1.get_rank() == 13 and f_card2.get_rank() == 13 \
               and f_card3.get_rank() == 13 and f_card4.get_rank() == 13:
                return(True)
        except IndexError:
            pass


def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    move card from one tableau column to another
    '''
    a_card = tableau[t_col_source][-1]
    tableau[t_col_source].pop()
    tableau[t_col_dest].append(a_card)
        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')

def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
         
#Actually the main function of the game and where most of the error checking
#takes place within the game.
def play():
    ''' 
    main program. Does error checking on the user input and moves. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    while True:
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()
        
        if len(response_list) > 0:
            #Incase the user mistypes something, this allows the game to
            #continue.
            try:
                if int(response_list[1]) > 10 or int(response_list[2]) > 10:
                    print("Invalid command. Parameters outside the range.",
                          "Please try again!")
                    continue
            except IndexError:
                pass
            r = response_list[0]
            #If you are trying to move a card from the tableau to the foundation
            if r == 't2f':
                t_col = (int(response_list[1])-1)
                f_col = (int(response_list[2])-1)
                try:
                    t_card = tableau[t_col][-1]
                    #If the foundatino is empty and the card is an Ace,
                    #move the card.
                    if foundation[f_col] == [] and t_card.get_rank() == 1:
                        move_to_foundation(tableau,foundation,t_col,f_col)
                        
                    #If the foundation isn't empty, check the suit and rank of
                    #the card to check to see if the move is valid.
                    elif foundation[f_col] != []:
                        f_card = foundation[f_col][-1]
                        if f_card.get_suit() == t_card.get_suit() and \
                           t_card.get_rank() == (f_card.get_rank() + 1):
                            move_to_foundation(tableau,foundation,t_col,f_col)
                        #Error statement.   
                        else:
                            print("Error: Invaild move.",
                                  "Card is either not the correct suit or the",
                                  "next card to be played in foundation.")
                    #Error statement.
                    else:
                        print("Error: Invaild move. Only Aces can be played",
                              "when their is no card in the foundation.")
                except IndexError:
                    print("IndexError in command. Please try again.")
                #Check to see if the user has won the game.
                check = is_winner(foundation)
                if check == True:
                    print("Winer! Game over!")
                    break
            #When trying to move a card within the tableau.
            elif r == 't2t':
                t_col_source = (int(response_list[1])-1)
                t_col_dest = (int(response_list[2])-1)
                #If the tableau is empty and the card you are trying to move is
                #a King, move the card.
                if tableau[t_col_dest] == []:
                    t_card_start = tableau[t_col_source][-1]
                    if t_card_start.get_rank() == 13:
                        move_in_tableau(tableau,t_col_source,t_col_dest)
                    #Error Statement.
                    else:
                        print("Error: Invaild move. Must be a King.")
                #If the tableau colloum isn't empty, check for the suit and rank
                #of the card to see if the move is vaild.
                elif tableau[t_col_dest] != []:
                    try:
                        t_card_start = tableau[t_col_source][-1]
                        t_card_finish = tableau[t_col_dest][-1]

                        if t_card_finish.get_suit() == t_card_start.get_suit() \
                           and t_card_start.get_rank() == \
                           (t_card_finish.get_rank() - 1):
                            move_in_tableau(tableau,t_col_source,t_col_dest)
                        #Error Statement. 
                        else:
                            print("Error: Invaild move.",
                                  "The card is either not of the correct suit",
                                  "or not the next card to be played.")
                    except IndexError:
                        print("Error in command. Please try again.")
                #Check to see if the user has won the game.
                check = is_winner(foundation)
                if check == True:
                    print("Winer! Game over!")
                    break
            #If the user is trying to move from the tableau to the cell.
            elif r == 't2c':
                t_col = (int(response_list[1])-1)
                c_col = (int(response_list[2])-1)
                try:
                    t_card = tableau[t_col][-1]
                    #If the cell is empty, move the card.
                    if cell[c_col] == []:
                        move_to_cell(tableau,cell,t_col,c_col)
                    #Error Statement.
                    else:
                        print("Error: Invaild move. Cell is full")
                except IndexError:
                    print("Error in command. Please try again.")
                #Check to see if the user has won the game.
                check = is_winner(foundation)
                if check == True:
                    print("Winer! Game over!")
                    break
            #Trying to move from the cell to the tableau.
            elif r == 'c2t':
                t_col = (int(response_list[2])-1)
                c_col = (int(response_list[1])-1)
                #If the tableau colloum was empty and the card in the cell was
                #a king, move the card.
                if tableau[t_col] == []:
                    c_card = cell[c_col][-1]
                    if c_card.get_rank() == 13:
                            move_to_tableau(tableau,cell,t_col,c_col)
                    #Error Statement.
                    else:
                        print("Error: Invaild move. Must be a King.")
                #If the tableau colloum wasn't empty, check the suit and rank of
                #the card to deteremine if the move is a valid move.
                elif tableau[t_col] != []:
                    try:
                        t_card = tableau[t_col][-1]
                        c_card = cell[c_col][-1]

                        if t_card.get_suit() == c_card.get_suit() and \
                           c_card.get_rank() == (t_card.get_rank() -1):
                            move_to_tableau(tableau,cell,t_col,c_col)
                        #Error statement.
                        else:
                            print("Error: Invaild move.",
                                  "Card is not of correct suit or not the",
                                  "next card to be played.")
                    except IndexError:
                        print("Error in command. Please try again.")
                    #Check to see if the user has won the game.
                    check = is_winner(foundation)
                    if check == True:
                        print("Winer! Game over!")
                        break
            #Trying to move from the cell to the foundation.
            elif r == 'c2f':
                c_col = (int(response_list[1])-1)
                f_col = (int(response_list[2])-1)
                try:
                    c_card = cell[c_col][-1]
                    #If the foundation is empty and the card in the cell is an
                    #Ace, move the card.
                    if foundation[f_col] == [] and c_card.get_rank() == 1:
                        cell_to_foundation(cell,foundation,c_col,f_col)
                    #If the foundation isn't empty, check the suit and rank of
                    #the card to see if the move was valid.
                    elif foundation[f_col] != []:
                        f_card = foundation[f_col][-1]
                        if f_card.get_suit() == c_card.get_suit() and \
                           c_card.get_rank() == (f_card.get_rank() + 1):
                            cell_to_foundation(cell,foundation,c_col,f_col)
                        #Error Statement.
                        else:
                            print("Error: Invaild move. Card is not of correct",
                                  "suit or the next card to be played in",
                                  "foundation.")
                    else:
                        print("Error: Invaild move. Only Aces cause be played",
                              "when the foundation is empty.")
                except IndexError:
                    print("Error in command. Please try again.")
                #Check to see if the user has won the game.
                check = is_winner(foundation)
                if check == True:
                    print("Winer! Game over!")
                    break
            #quits the game.
            elif r == 'q':
                break
            #Shows the help.
            elif r == 'h':
                show_help()
            else:
                print('Unknown command:',r)
        else:
            print("Unknown Command:",response)
    print('Thanks for playing')

play()
