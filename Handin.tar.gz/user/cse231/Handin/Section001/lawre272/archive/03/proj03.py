#############################################################################
#Section 001H
#Project 3
#Date 1/27/13
#lawre272
#
#1. prompt for an price or quit
#2. check to see the price is a positive multiple of .05
#3. print out a menu and prompt the user to select something
#4. print the remaining owed
#5. determine the change as an output with what is left in the stock
#6. print the coins dispensed and there amounts or print a message "No Change"
#7. if stock does not meet output need, print get remaining from manager
#8. print remaining stock and total amount.
#############################################################################


print("Welcome to the vending machine change maker program")
print("Change maker initialized.")

#set the counters for the stock to keep track of the stock
ncounter = 25 # the number of nickels
dcounter = 25 # the number of dimes
qcounter = 25 # the number of quaters
ocounter = 0 # the number of ones
fcounter = 0 # the number of fives

#print off the stock table
print("Stock contains:")
print("    ", ncounter, " nickels")
print("    ", dcounter, " dimes")
print("    ", qcounter, " quarters")
print("    ", ocounter, " ones")
print("    ", fcounter, " fives")
print(" ")

while True:


    #prompt for a price
    change_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")

    #if the user puts in "q", quit the change machine but first calculate the total
    #in the change machine.
    if change_str == "q":
        nickels = ncounter * 5
        dimes = dcounter * 10
        quaters = qcounter * 25
        dollars = ocounter * 100
        fives = fcounter * 500

        #the total amount of money in the machine
        total = ((nickels + dimes + quaters + dollars + fives)/100) 
        total_dollars = int(total//1)
        total_cents = round((total - total_dollars)*100)

        print("Total: ", total_dollars, "dollars and ", total_cents, "cents.")
        break #quit the loop

    else:
        #turn the price into something python can use to compute change
        change_float = float(change_str)
        change_int = round(change_float*100)

        #check to make sure that the price put in is a multiple of .05 cents
        if change_int%5 != 0 or change_int <= 0:
            print("Illegal price: Must be a non-negative multiple of 5 cents.")
            print(" ")
            continue

        else:
            #print the menu for the user to reference
            print(" ")
            print("Menu for deposits:")
            print("  ", "'n' - deposit a nickel")
            print("  ", "'d' - deposit a dime")
            print("  ", "'q' - deposit a quarter")
            print("  ", "'o' - deposit a one dollar bill")
            print("  ", "'f' - deposit a five dollar bill")
            print("  ", "'c' - cancel the purchase")

            #Seperate the price into the dollar amount and the cents amount
            int_dollars = int(change_float//1)
            float_cents = round((change_float - int_dollars)*100)

            #print the payment due for the user to reference how much is owed.
            if int_dollars > 0:
                print(" ")
                print("Payment due: ", int_dollars, "dollars and ", float_cents, "cents")
                option_str = input("Indicate your deposit: ")
            else:
                print(" ")
                print("Payment due:", float_cents, "cents")
                option_str = input("Indicate your deposit: ")

            #Outer limit counters. This is used if the user cancels the transaction.
            ncounter_old = ncounter
            dcounter_old = dcounter
            qcounter_old = qcounter
            ocounter_old = ocounter
            fcounter_old = fcounter

            while change_int !=0: #While the user owes an amount.

                #The notes in this section apply to the sections below it since it is the same\
                #for the different deposits. (Ex. 'n', 'd', etc.)
                if option_str != "n" and option_str != "d" and option_str != "q" and option_str != "o" and option_str != "f" and option_str != "c":
                     print("Illegal selection: ", option_str) #Checks for illegal imputs.
                     
                elif option_str == "n":                 #If the user deposits a nickel.
                    change_int = change_int - 5         #Calculates the new change owed.
                    ncounter += 1                       #Adds a nickel to stock.

                elif option_str == "d":                 #If the user deposits a dime.
                    change_int = change_int - 10     
                    dcounter += 1                   

                elif option_str == "q":                 #If the user deposits a quater.
                    change_int = change_int - 25     
                    qcounter += 1                   

                elif option_str == "o":                 #If the user deposits a one.
                    change_int = change_int - 100     
                    ocounter += 1                   

                elif option_str == "f":                 #If the user deposits a five.
                    change_int = change_int - 500     
                    fcounter += 1

                elif option_str == "c":
                    ncancel = ncounter - ncounter_old   #Math needed to figure out the change the user put in.
                    dcancel = dcounter - dcounter_old
                    qcancel = qcounter - qcounter_old
                    ocancel = ocounter - ocounter_old
                    fcancel = fcounter - fcounter_old

                    ncancel_amount = ncancel * 5
                    dcancel_amount = dcancel * 10
                    qcancel_amount = qcancel * 25
                    ocancel_amount = ocancel * 100
                    fcancel_amount = fcancel * 500

                                                        #Amount owed to user.
                    change_int = ((ncancel_amount + dcancel_amount + qcancel_amount + ocancel_amount + fcancel_amount) * -1)

                if change_int == 0:                     #If the user pays for the amount in full.
                    print(" ")
                    print("Please take the change below.")
                    print("  No change due.")
                    break
                elif change_int < 0:                    #If there is change owed to the user.
                    print(" ")
                    print("Please take the change below.")
                    due_back = (change_int*-1)
                        
                    qneeded_float = due_back/25
                    qcheck = qcounter - qneeded_float
                                                        #Math to figure out the change in quaters.
                    if due_back >= 25 and qcounter > 0 and qcheck >= 0:
                        qneeded_int = int(qneeded_float)                                
                        print(qneeded_int, "quaters")
                        qcounter = qcounter - qneeded_int
                        due_back = due_back - (qneeded_int * 25)

                    if due_back >= 25 and qcounter > 0 and qcheck < 0:
                        qgiven = qcounter
                        print(qgiven, "quaters")
                        qneeded = int(qneeded_float*100)
                        qcounter_math = qcounter*100
                        qleft = (qneeded - qcounter_math)
                        qcounter = qcounter - qgiven
                        due_back = int(((qleft * 25)/100))
                                  
                    dneeded_float = due_back/10
                    dcheck = dcounter - dneeded_float
                                                        #Math to figure out the change in dimes.
                    if due_back >= 10 and dcounter > 0 and dcheck >= 0:
                        dneeded_int = int(dneeded_float)
                        print(dneeded_int, "dimes")
                        dcounter = dcounter - dneeded_int
                        due_back = due_back - (dneeded_int * 10)

                    if due_back >= 10 and dcounter > 0 and dcheck < 0:
                        dgiven = dcounter
                        print(dgiven, "dimes")
                        dneeded = int(dneeded_float*100)
                        dcounter_math = dcounter*100
                        dleft = (dneeded - dcounter_math)/100
                        dcounter = dcounter - dgiven
                        due_back = int(dleft * 10)

                    nneeded_float = due_back/5
                    ncheck = ncounter - nneeded_float
                                                        #Math to figure out the change in nickels.
                    if due_back >= 5 and ncounter > 0 and ncheck >= 0:
                        nneeded_int = int(nneeded_float)
                        print(nneeded_int, "nickels")
                        ncounter = ncounter - nneeded_int
                        break

                    if due_back >= 5 and ncounter > 0 and ncheck < 0:
                        ngiven = ncounter
                        print(ngiven, "nickels")
                        nneeded = int(nneeded_float*100)
                        ncounter_math = ncounter*100
                        nleft = (nneeded - ncounter_math)/100
                        ncounter = ncounter - ngiven
                        due_back = int(nleft * 5)
                                                        #If the machine can't dispense the change needed.
                    if due_back >= 5:
                        print(" ")
                        print("Machine is out of change.")
                        print("See store manger for remaining refund.")
                                                        #Math to figure out how much is owed to user. 
                        due_back_float = due_back/100
                        int_dollars = int(due_back_float//1)
                        float_cents = round((due_back_float - int_dollars)*100)
                                                        #Prints the amount needed to get from manager.                            
                        if int_dollars > 0:
                            print("Amount due is: ", int_dollars, " dollars and ", float_cents, " cents.")
                        else:
                            print("Payment due: ", float_cents, "cents.")
                        break

                    if due_back == 0:
                        break
                          
                change_float = change_int/100
                int_dollars = int(change_float//1)
                float_cents = round((change_float - int_dollars)*100)

                if int_dollars > 0:                         #Prints amount still owed by user.
                    print("Payment due: ", int_dollars, "dollars and ", float_cents, "cents")
                    option_str = input("Indicate your deposit: ")
                else:
                    print("Payment due: ", float_cents, "cents")
                    option_str = input("Indicate your deposit: ")
                
            print(" ")
            print("Stock contains")
            print("    ", ncounter, " nickels")
            print("    ", dcounter, " dimes")
            print("    ", qcounter, " quarters")
            print("    ", ocounter, " ones")
            print("    ", fcounter, " fives")
            print(" ") 
