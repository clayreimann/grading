############################################################################
#Section 001H
#Computer Project #2
#Date: 1/17/13
#lawre272
#
#Program Overview
#1. Prompt for a 6-digit number
#2. Input a 6-digit number
#3. Check to see if they used a 6-digit number using an if statement. If not, say so and end program.
#4. Do math required to figure out if the left and right side of the equation equal each other.
#   a.Take 6-digit number and assign the corresponding integer to one of the letters in the word.
#   b.Multiply each integer by the place value it is in the word. (S = int*100000)(L = int*10000)
#   c.Add numbers together then multiply by three on the one side and only add them together once on the other side.
#5.Use another if statement to see if the left and right side equal each other.
#   a.If they equal each other, say correct and show both numbers.
#   b.If they do not equal each other, say incorrect and show both numbers.
#
############################################################################

#Ask for the 6 digit number for the equations to work.
print("Guess a six-digit number SLAYER so that following equation is true,",\
      "where each letter stands for the digit in the position shown:")
print(" ")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print(" ")

user_str = input("Enter your guess for SLAYER: ")
user_int = int(user_str)

#If they don't put in a 6 digit number but a number less than 6 digits, it will say
#'must be a 6-digit number.' and the program will end there.

if user_int <= 99999 or user_int >=1000000:
    print("Your guess is incorrect:")
    print("SLAYER must be a 6-digit number.")
    print("Thanks for playing.")

#If it is a 6-digit number, it will go through the math needed to solve the equations
# on the right and left side of the equation.
#Assign a digit from the number inputed and assign it to a letter in the word SLAYER
else:
    S = ((user_int//100000)%10)
    L = ((user_int//10000)%10)
    A = ((user_int//1000)%10)
    Y = ((user_int//100)%10)
    E = ((user_int//10)%10)
    R = ((user_int//1)%10)

    
    import math
    user_int = 3*((S*100000)+(L*10000)+(A*1000)+(Y*100)+(E*10)+(R*1))
    answer_int = ((S*1)+(L*100000)+(A*10000)+(Y*1000)+(E*100)+(R*10))

#If the guess is incorrect, the program will return, "Your guess is inncorrect" Also it
#will show the answer to the left and right side of the equations. Showing you why it
#is not correct.

    if user_int != answer_int:
        print("Your guess is incorrect:")
        print("SLAYER + SLAYER + SLAYER = ", user_int)
        print("LAYERS = ", answer_int)
        print("Thanks for playing.")

#If the answer is correct it will say so. The correct portion will also show the
#answers to the left and right side of the equation.

    else:
        print("Your guess is correct:")
        print("SLAYER + SLAYER + SLAYER = ", user_int)
        print("LAYERS = ", answer_int)
        print("Thanks for playing.")
