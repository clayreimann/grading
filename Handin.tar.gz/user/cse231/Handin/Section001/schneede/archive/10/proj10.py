#proj10
#sec001
#Due 4/8/13

####################################################################################

#Program OverviewStar class:

#Draws flags based on specifications from a text file

#Defines 3 classes as follows

#   1. Star class:
#       __init__ (self, x, y, arm_length, color)
#       draw(self, turtle) for drawing stars
#       __str__(self) for printing star descriptions

#   2. Rectangle class:
#       __init__ (self, x,y,width,height,color)
#       draw(self, turtle) for drawing rectangles
#       __str__(self) for printing rectangle descriptions

#   3. Flag class:
#       __init__(self, file_object)
#       draw(self, turtle) for drawing flags
#       __str__(self) for printing flag descriptions

#main() draws some flags using the classes defined above

#####################################################################################

import turtle
import time

class Star(object):

    def __init__(self, x, y, arm_length, color): #establishes attributes of the star class
        self.x = x #x position of center
        self.y = y #y position of center
        self.arm_length = arm_length #length of star arm
        self.color = color #color of star

    def draw(self, turtle):

        '''draws a star'''
        
        turtle.up()
        turtle.color(self.color) #sets turtle color
        turtle.goto(self.x + (self.arm_length/3.236), self.y + (self.arm_length/2.35)) #sets turtle initial drawing position
        turtle.down() #puts pen down
        turtle.begin_fill() #starts color fill
        
        for i in range(0,5): #repeats actions below 5 times
            turtle.forward(self.arm_length) #draws first part of point
            turtle.right(144) #turns
            turtle.forward(self.arm_length) #draws second part of point
            turtle.left(72) #turns to start new point
           
        turtle.end_fill() #ends color fill

    def __str__(self): #returns a string with star details when print() is called on a star instance
        return "Star x:{}, y:{}, arm:{}, color: {}".format(self.x, self.y, self.arm_length, self.color)

class Rectangle(object):

    def __init__(self, x, y, width, height, color): #establishes attributes of the rectangle class
        self.x = x #x position of center
        self.y = y #y position of center
        self.width = width # width of rectangle
        self.height = height #height of rectangle
        self.color = color #fill color

    def draw(self, turtle):

        '''draws a rectangle'''
        
        turtle.up()
        turtle.color(self.color) #sets pen color
        turtle.goto(self.x - (self.width/2), self.y + (self.height/2)) #sets turtle initial drawing position
        turtle.down() #puts pen down
        turtle.begin_fill() #starts fill

        for i in range(0,2): #repeats the following actions two times
            turtle.forward(self.width) #draws horizontal side
            turtle.right(90) #turns 
            turtle.forward(self.height) #draws vertical side
            turtle.right(90) #turns

        turtle.end_fill() #ends color fill

    def __str__(self): #returns a string with rectangle details when print() is called on a rectangle instance
        return "Rectangle x:{}, y:{}, width:{}, height: {}, color: {}".format(self.x, self.y, self.width, self.length, self.color)

class Flag(object):

    def __init__(self, file_object): #sets attributes of flag class
        self.file_object = file_object

        rect_int = int(self.file_object.readline()) #reads first line from spec file to determine number of rectangles to draw
        rect_list = [] #empty list to collect rectangles
        
        for i in range(0,rect_int): #repeats for how many rectangles are specified in the spec file
            line = self.file_object.readline() #reads specs for rectangle
            line = line.strip() 
            line_list = line.split(",") #turns line of specs into a list
            new_list = [] #empty list to collect rectangle parameters
            
            for item in line_list:
                item = item.strip() #strips white space from items
                new_list.append(item) #adds cleaned up items to new parameter list

            temp_rect = Rectangle(int(new_list[0]),int(new_list[1]),int(new_list[2]),int(new_list[3]),new_list[4]) #makes rectangle from specs
            rect_list.append(temp_rect) #adds newrectangle to list of rectangles

        star_int = int(self.file_object.readline()) #reads next line from spec file to determine number of stars to draw
        star_list = [] #empty list to collect stars

        for i in range(0,star_int): #repeats for how many stars are specified in the spec file
            line = self.file_object.readline() #reads specs for star
            line = line.strip()
            line_list = line.split(",") #turns line of specs into a list
            new_list = [] #empty list to collect star parameters
            
            for item in line_list:
                item = item.strip() #strips white space from items
                new_list.append(item) #adds cleaned up items to new parameter list

            temp_star = Star(int(new_list[0]),int(new_list[1]),int(new_list[2]),new_list[3]) #makes star from specs
            star_list.append(temp_star) #adds new star to list of stars

        self.rect_list = rect_list
        self.star_list = star_list

    def draw(self, turtle): 

        '''draws a flag'''
        
        for item in self.rect_list:
            item.draw(turtle)

        for item in self.star_list:
            item.draw(turtle)
            
    def __str__(self): #returns a string with flag description
        flag_str = "Rectangles: \n"

        for item in self.rect_list: #pulls descriptions for each rectangle and adds to flag string
            flag_str = flag_str + "x:{}, y:{}, w:{}, h:{}, c:{} \n".format(item.x,item.y,item.width,item.height,item.color)

        flag_str = flag_str + "Stars: \n"

        for item in self.star_list: #pulls descriptions for each star and adds to flag string
            flag_str = flag_str + "x:{}, y:{}, a:{}, c:{} \n".format(item.x,item.y,item.arm_length,item.color)
            
        return flag_str

def main():
    turtle.clearscreen()
    pen = turtle.Turtle() #sets pen to turtle
    pen.speed('fastest') #sets pen speed
    senegal_file = open('senegal.txt') #opens Senegal flag specs file
    senegal_flag = Flag(senegal_file) #makes a flag instance
    print(senegal_flag) #prints description
    senegal_flag.draw(pen) #draws flag
    senegal_file.close() #closes file
    time.sleep(4)   # delay so you can see your flag
    
    turtle.clearscreen()
    panama_file = open('panama.txt') #opens Panama flag specs file
    panama_flag = Flag(panama_file) #makes a flag instance
    print(panama_flag) #prints description
    panama_flag.draw(pen) #draws flag
    panama_file.close() #closes file
    time.sleep(4) # delay so you can see your flag

    turtle.clearscreen()
    guinea_file = open('myFlag.txt') #opens Panama flag specs file
    guinea_flag = Flag(guinea_file) #makes a flag instance
    print(guinea_flag) #prints description
    guinea_flag.draw(pen) #draws flag
    guinea_file.close() #closes file
    time.sleep(4) # delay so you can see your flag
    
    turtle.bye() #closes turtle window

main() #runs main program
