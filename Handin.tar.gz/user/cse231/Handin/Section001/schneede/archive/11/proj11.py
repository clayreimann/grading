#proj11
#sec 001
#Due 4/15/13

######################################################################################

#Program Overview

#Defines a Tour class with the following methods

#   1. __init__
#       takes an arbitrary number of city,state abbreviation pair strings as arguments

#   2. __str__, __repr__
#       generates a string representation of Tour objects
#       format is city, state ; city, state

#   3. __add__
#       takes tours as arguments, concatenates them

#   4. __mul__, __rmul__
#       takes a tour and positive integer as arguments
#       repeated concatenation of a tour
#       number of concatenations determined by integer argument

#   5. distance
#       calculates the distance travelled on a given tour using google map api

#   6. __gt__,__lt__,__eq___
#       methods for comparing the distances travelled on given tours
#       returns True if comparison is correct, False otherwise

#######################################################################################

import urllib.request
import re

class Tour(object):

    def __init__(self, *location):
        self.location = location
            
        
    def __str__(self):

        '''allows description of tour objects to be printed'''
        
        tour_str = '' #empty string to start
        for i in range(0,len(self.location)-1): #iterates through all but last location
            tour_str = tour_str + "{}; ".format(self.location[i]) #adds each location to print string followed by a semicolon to separate locations
        tour_str = tour_str + "{}".format(self.location[len(self.location)-1]) #adds last location to print string without semicolon

        return tour_str

    def __repr__(self):
        '''method for console display of tour objects'''
        return self.__str__()

    def __add__(self, other): 

        '''concatenates two tours'''

        new_tour = Tour() #creates empty tour
        new_tour.location = self.location + other.location #sets location parameters of empty tour to self locations + other locations

        return new_tour
    
    def __mul__(self,my_int):
        
        '''repeatedly concatenates the tour as many times as indicated by the my_int parameter'''
        
        if type(my_int) != int: #checks to make sure input is an integer
            raise TypeError("Input must be an integer")

        elif my_int < 0: #checks to make sure inputted integer is positive
            raise ValueError("Input must be positive")
        
        new_tour = Tour() #makes an empty tour
        for i in range(0,my_int): 
            new_tour = new_tour.__add__(self) #adds tour to the empty tour 'my_int' times
            
        return new_tour

    def __rmul__(self,my_int):
        '''reverses parameters if integer is entered first instead of tour'''
        return self.__mul__(my_int)

   
    def distance(self, mode = "driving"):
        '''        
        Calculates the distance travelled on a given tour
        Breaks tour into pairs of locations (i.e. 1st with 2nd, 2nd with 3rd, and so forth)
        Calculates total distance by summing over tour pieces
        '''

        total_dist = 0 #initial value for total distance, each tour piece distance will be added to this
        
        for i in range(0,len(self.location)):
            try:
                temp_list1 = self.location[i].split(",") #turns location tuple into a list
                city_temp1 = temp_list1.pop(0) #extracts city portion
                city_name_list1 = city_temp1.split( ) #if city is two words, makes a list entry for each word
                temp_list1 = city_name_list1 + temp_list1 #adds city back into the list
                origin_list = [] #empty list to be filled with city, state 

                for item in temp_list1: 
                    item = item.strip() #strips white space from each entry
                    origin_list.append(item) #appends each entry to a new list

                temp_list2 = self.location[i+1].split(",") #turns location tuple into a list
                city_temp2 = temp_list2.pop(0) #extracts city portion
                city_name_list2 = city_temp2.split( ) #if city is two words, makes a list entry for each word
                temp_list2 = city_name_list2 + temp_list2 #adds city back into the list
                dest_list = [] #empty list to be filled with city, state

                for item in temp_list2:
                    item = item.strip() #strips white space from each entry
                    dest_list.append(item) #appends each entry to a new list
                    
            except IndexError: #breaks loop once the end of the list has been reached
                break
                
            base = "http://maps.googleapis.com/maps/api/distancematrix/json?origins=" #first part of url call
            origin = '+'.join(origin_list) #origin of tour portion
            destination = '+'.join(dest_list) #destination of tour portino
            obj_name = base + origin + "&destinations=" + destination + "&mode=" + mode + "&sensor=false" #builds entire web object name from pieces above
            
            web_obj = urllib.request.urlopen(obj_name) #opens web object
            results_str = str(web_obj.read()) #reads web object as a string
            web_obj.close() #closes web object
            
            match = re.search(r'"value" : [\d]+', results_str) #searchs results_str for the given pattern
            
            if match:
                distance_str = match.group() #makes a string of the format "value" : distance
                distance_list = distance_str.split(":") #breaks string into a list
                popped = distance_list.pop(1) #extracts distance value from list
                popped = popped.strip() #strips white space from distance string
                distance_float = float(popped) #turns string into a float
                total_dist += distance_float #adds extracted distance to total distance

            else:
                raise ValueError("No distance found")

        return total_dist
    
    def __gt__(self, other):
        
        '''compares tour distances to see if first is greater than the second'''
        
        if self.distance() > other.distance(): #calls distance method on each tour to compare distances
            return True #returns True if first distance is greater than second
        else:
            return False #returns False otherwise


    def __lt__(self, other):
        
        '''compares tour distances to see if first is less than the second'''
        
        if self.distance() < other.distance(): #calls distance method on each tour to compare distances
            return True #returns True if first distance is less than second
        else:
            return False #returns False otherwise
        

    def __eq__(self, other):

        '''compares tour distances to see if first is equal to the second'''
        
        if self.distance() == other.distance(): #calls distance method on each tour to compare distances
            return True #returns True is first distance is equal to second
        else:
            return False #returns False otherwise

def main():
    #testing the tour constructor
    t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")
    t2 = Tour("Plano, TX")
    t3 = Tour("Sacramento, CA", "Oakland, CA")
    print("t1: {}\nt2: {}\nt3: {}".format(t1,t2,t3))
    print()

    #testing the distance method for each mode
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000),round(t1.distance('bicycling')/1000),round(t1.distance('walking')/1000)))
    print()

    #testing __add__, __mul__ and __rmul__ methods
    print("Using driving distances from here on.")
    t4 = t1 + t2 #testing __add__
    t5 = 2 * t3 #testing __mul__
    t6 = t3 * 2 #testing __rmul__

    print("t4:", t4)
    print("t5:", t5)
    print("t6:", t6)
    print()

    #testing distance method with instances constructed via __add__, __mul__ and __rmul__
    print("t4 driving distance:", round(t4.distance()/1000),"km")
    print("t5 driving distance:", round(t5.distance()/1000),"km")
    print("t6 driving distance:", round(t6.distance()/1000),"km")
    print()

    #testing __eq__, __gt__ and __lt__
    print("t4 == t1 + t2:", t4 == t1 + t2) #__eq__
    print("t5 == t6:", t5 == t6) #__eq__
    print("t4 > t1: ", t4 > t1) #__gt__
    print("t4 < t1: ", t4 < t2) #__lt__

    t7 = t3 * "string"
main()

