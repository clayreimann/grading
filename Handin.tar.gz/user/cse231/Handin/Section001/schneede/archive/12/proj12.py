#proj12
#sec001
#4/22/13

'''USING PYTHON 3.2.3'''

import pylab
import numpy as np
import matplotlib.pyplot as plt

def open_file(file_name):
    
    '''takes a file name as input, returns a file with specified name'''
    
    try:
        file_obj = open(file_name,"r") #opens file
    except IOError:
        print("Bad file name") #error message if file does not exist
        
    return file_obj

def get_data(file_obj):

    '''
    gets data from the file
    stores data in a dictionary
    key format is (month,day)
    value is high tempterature for that day
    '''
    for i in range(0,2):
        file_obj.readline() #skips first 2 lines that don't contain data
    
    data_dict = {} #empty dictionary to store data
    
    for line in file_obj:
        line = line.strip()
        line_list = line.split() #turns line into a list
        key = (int(line_list[0]),int(line_list[1])) #makes a key from first two list entries
        value1 = (float(line_list[4])) #high temp value
        value2 = (float(line_list[4])) #low temp value
        
        try:
            if value1 > data_dict[key][0]:
                data_dict[key] = (value1,data_dict[key][1]) #replaces current value if new value is higher
                
            if value2 < data_dict[key][1]:
                data_dict[key] = (data_dict[key][0],value2) #replaces current value if new value is lower
                
        except KeyError:
            data_dict[key] = (value1,value2) #adds key:value if key isn't already in dictionary

    file_obj.close()
    
    return data_dict

def get_monthly_average(data_dict):
    month = 1 #initial value for month
    high_sum = 0 #initial value for monthly total high temps
    low_sum = 0 #initial value for monthly total low temps
    count = 0 #initial value for number of days averaged over

    avg_dict = {} #empty dictionary to store averages
    
    key_list = sorted(data_dict) #ordered list of keys
    
    for key in key_list:
        
        if key[0] == month:
            high_sum += data_dict[key][0] #adds high temp to sum
            low_sum += data_dict[key][1] #adds low temp to sum
            count += 1
            
        else:
            high_avg = high_sum/count #calculates high temp average
            low_avg = low_sum/count #calculates low temp average
            avg_dict[month] = (high_avg,low_avg) #stores data formatted as month:(high,low) in dictionary

            month += 1 #moves to next month

            high_sum = data_dict[key][0] #captures first value for high sum for next month
            low_sum = data_dict[key][1] #captures first value for low sum for next month
            count = 1 #resets count
            
    else:
        high_avg = high_sum/count #calculates high temp average for last month
        low_avg = low_sum/count #calculates low temp average for last month
        avg_dict[month] = (high_avg,low_avg) #stores data formatted as month:(high,low) in dictionary

    return avg_dict
    
def plot_averages(avg_dict):

    '''plots average high and low temperature for each month'''
    
    key_list = sorted(avg_dict) #creates ordered list of keys
    
    high_list = [] #empty list to stores high temp averages
    low_list = [] #empty list to stores low temp averages
    month_list = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

    for key in key_list:
        high_list.append(avg_dict[key][0]-avg_dict[key][1]) #generates list of differences, high - low
        low_list.append(avg_dict[key][1]) #generates list of low temps

    bar_width = 0.5
    x_values = pylab.arange(len(key_list))
    pylab.xticks(x_values+bar_width/2.0,month_list,rotation=45) #formatting for x axis labels
    pylab.title("Charleston, MO 2012") #chart title
    pylab.xlabel("Month") #x axis title
    pylab.ylabel("Average Temp") #y axis title
    pylab.bar(x_values, high_list, bottom = low_list, width = bar_width, color = 'orange') #makes bar graph
    pylab.savefig("temp_averages.png") #saves file
    #pylab.show()
    pylab.close() #closes plot

def june_data(file_obj, skip_int):
    
    for i in range(0,skip_int):
        file_obj.readline() #skips first 'skip_int' lines that don't contain data
        
    data_dict = {} #empty dictionary to store data

    for line in file_obj:
        line = line.strip()
        line_list = line.split()
        
        if line_list[0] == "6": #only pulls data for June
            key = (int(line_list[3]),int(line_list[1])) #key format (hour,day)
            value = float(line_list[4]) #solar radiation value for each hour
            data_dict[key] = value #assigns value to given key

    file_obj.close() #closes the file
    
    return data_dict
        
def june_avg(data_dict):
    
    hour = 100 #initial value for hour
    solar_sum = 0 #initial value for total solar radiation for given hour
    count = 0 #initial value for number of entries averaged over

    avg_dict = {} #empty dictionary to store averages
    
    key_list = sorted(data_dict) #ordered list of keys
    
    for key in key_list:
        
        if key[0] == hour:
            solar_sum += data_dict[key] #adds solar radiation to sum
            count += 1
            
        else:
            solar_avg = solar_sum/count #calculates high temp average
            avg_dict[hour] = solar_avg #stores data formatted as hour:radiation in dictionary

            hour += 100 #moves to next hour 

            solar_sum = data_dict[key] #captures first value for high sum for next month
            count = 1 #resets count
            
    else:
        solar_avg = solar_sum/count #calculates solar radiation average for last hour
        avg_dict[hour] = solar_avg #stores data formatted as hour:radiation in dictionary

    return avg_dict

def plot_june_avg(temp_avg_dict,solar_avg_dict):

    '''
    takes two dictionaries as inputs
    plots temperature data and solar radiation data on same plot
    '''

    temp_key_list = sorted(temp_avg_dict) #sorted list of keys
    solar_key_list = sorted(solar_avg_dict) #sorted list of keys

    temp_value_list = [] #empty list to store temperature averages
    solar_value_list = [] #empty list to store solar radiation averages
    
    for key in temp_key_list:
        temp_value_list.append(temp_avg_dict[key]) #list of temperature values

    for key in solar_key_list:
        solar_value_list.append(solar_avg_dict[key]) #list of solar radiation values


    fig = plt.figure()
    plt.title("Charleston, MO 2012") #chart title
    ax1 = fig.add_subplot(111)
    x_values = pylab.arange(len(temp_key_list)) #set length of x axis
    ax1.plot(x_values, temp_value_list, 'b.-') #plots temperature values
    ax1.set_xlabel('Hour') #x axis title
    ax1.set_ylabel('Average Temp', color='b') #left y axis title
    for tl in ax1.get_yticklabels(): #changes tick colors to match data point color
        tl.set_color('b')

    ax2 = ax1.twinx() #for plotting second data list on same plot
    ax2.plot(x_values, solar_value_list, 'r.-') #plots solar radiation data
    ax2.set_ylabel('Average Solar Radiation', color='r') #right y axis title
    for tl in ax2.get_yticklabels(): #changes tick colors to match data point color
        tl.set_color('r')
        
    plt.savefig("temp_vs_solar.png") #saves figure
    plt.close()
    
def first_task():
    '''
    gets average high temp and average low temp for each month in 2012
    plots high and low temp for each month on a bar graph
    '''
    temp_data_obj = open_file("temperature.txt") #opens file
    my_data_dict = get_data(temp_data_obj) #reads in data
    my_avg_dict = get_monthly_average(my_data_dict) #calculates averages for high, low temps for each month
    plot_averages(my_avg_dict) #plots averages
    

def second_task():
    '''
    gets average temp and average solar radiation for each hour
    makes a scatter plot of both data sets on the same plot
    '''
    
    temp_data_obj = open_file("temperature.txt") #opens temperature file
    solar_data_obj = open_file("solar_radition.txt") #opens solar radiation file
    june_temp_dict = june_data(temp_data_obj,2) #gets temperature data for each hour in June
    june_solar_dict = june_data(solar_data_obj,4) #gets solar radiation data for each hour in June
    june_temp_avg = june_avg(june_temp_dict) #gets average temp for each hour in June
    june_solar_avg = june_avg(june_solar_dict) #gets average solar radiation for each hour in June
    plot_june_avg(june_temp_avg,june_solar_avg) #plots data
        
first_task()
second_task()
