#proj03
#Sec 001
#Due 1/28/13

#Initialize stock
nickels_int = 25 #number of nickels in machine
dimes_int = 25 #number of dimes
quarters_int = 25 #number of quarters
ones_int = 0 #number of one dollar bills in the machine
fives_int = 0 #number of five dollar bills in the machine

machinetotal_int = quarters_int*25 + dimes_int*10 + nickels_int*5

payments_int = 0 #total amount that customer has deposited in cents

print("Welcome to the vending machine change maker program! Hooray change!")
print(" ")
print("Stock contains:")
print("   ", nickels_int, "nickels")
print("   ", dimes_int, "dimes")
print("   ", quarters_int, "quarters")
print("   ", ones_int, "ones")
print("   ", fives_int, "fives")
print(" ")

price_str = input("Please enter the purchase price (xx.xx) or 'q' to quit: ")
print(" ")


while(price_str != "q"): #Loop breaks when user enters 'q' to quit the program

    #Turns input into integer that represents number of cents in price
    price_int = int(round(100*float(price_str))) 
    
    if price_int%5 != 0 or price_int < 0:
        print("That is not a valid price. Price must be a non negative multiple of 5 cents") #Error message for invalid price
        price_str = input("Please enter the purchase price (xx.xx) or 'q' to quit: ") #Prompts for another input
        continue
    
    else:
        dollarsdue_int = price_int//100 #number of dollars in user inputted price
        centsdue_int = price_int%100 #number of cents in user inputted price
        print("Amount due: ", end="")

        #prints the price inputted by the user
        if dollarsdue_int !=0: #omits value for dollars if dollars owed is 0
            print(dollarsdue_int, "dollars, ", end="")
        if centsdue_int !=0: #omits value for cents if cents owed is 0
            print(centsdue_int, "cents") 
        print(" ")

    print(" ")

    #Gives the user options for coins/bills to deposit or allows them to cancel the transaction
    print("Menu for deposits")
    print("   'n' - deposit a nickel")
    print("   'd' - deposit a dime")
    print("   'q' - deposit a quarter")
    print("   'o' - deposit a one dollar bill")
    print("   'f' - deposit a five dollar bill")
    print("   'c' - cancel purchase")
    print(" ")
    
    while payments_int < price_int: #Loop breaks when deposits exceed price inputted by user
        
        deposit_str = input("Please indicate your deposit: ")
        print(" ")

        if deposit_str == "n":
            print("You deposited a nickel")
            print(" ")
            nickels_int = nickels_int + 1
            payments_int = payments_int + 5
        
        elif deposit_str == "d":
            print("You deposited a dime")
            print(" ")
            dimes_int = dimes_int + 1
            payments_int = payments_int + 10
            
        
        elif deposit_str == "q":
            print("You deposited a quarter")
            print(" ")
            quarters_int = quarters_int + 1
            payments_int = payments_int + 25
        
        elif deposit_str == "o":
            print("You deposited a one dollar bill")
            print(" ")
            ones_int = ones_int + 1
            payments_int = payments_int + 100
        
        elif deposit_str == "f":
            print("You deposited a five dollar bill")
            print(" ")
            fives_int = fives_int + 1
            payments_int = payments_int + 500
        
        elif deposit_str == "c":
            print("You have cancelled your purchase")
            print(" ")

            #Return customer deposits in least amount of coins/bills possible
            if payments_int == 0:
                print("No change")
                break
            else:
                change_int = payments_int #calculates change owed
                changedollars_int = change_int//100 #dollars of change owed
                changecents_int = change_int%100 #cents of change owed
                print("Change due:", end="")

                #prints the change change due to the user
                #omits value for dollars or cents owed if 0
                if changedollars_int !=0:
                    print(changedollars_int, "dollars, ", end="")
                if changecents_int !=0:
                    print(changecents_int, "cents") 
            
                #Dispenses correct coins to user
                
                #Quarters
                quarters_change_int = change_int//25 #Calculates number of quarters to dispense

                while quarters_change_int > quarters_int: #Reduces number of quarters to dispense if quarters_change_int is more than the number in the machine.
                    quarters_change_int = quarters_change_int - 1

                change_int = change_int - (quarters_change_int*25) #Reduces change owed by the amount of quarters dispensed in cents
                quarters_int = quarters_int - quarters_change_int
                
                #Dimes
                dimes_change_int = change_int//10 #Calculates number of dimes to dispnse

                while dimes_change_int > dimes_int: #Reduces number of dimes to dispense if dimes_change_int is more than the number in the machine.
                    dimes_change_int = dimes_change_int - 1

                change_int = change_int - (dimes_change_int*10) #Reduces change owed by the amount of dimes dispensed in cents
                dimes_int = dimes_int - dimes_change_int
                
                #Nickels
                nickels_change_int = change_int//5 #Calculates number of nickels to dispnse

                while nickels_change_int > nickels_int: #Reduces numbers of nickels to dispense if nickels_change_int is more than the number in the machine
                    nickels_change_int = nickels_change_int -1
                    
                change_int = change_int - (nickels_change_int*5) #Reduces change owed by the amount of nickels dispensed in cents
                nickels_int = nickels_int - nickels_change_int

                #Prints the change dispensed by the machine

                #This blocks prints the change dispensed if there is enough change to cover change owed to the user
                if change_int == 0:
                    print("Change is:")
                    print(quarters_change_int, "quarters")
                    print(dimes_change_int, "dimes")
                    print(nickels_change_int, "nickels")

                #This block prints the change dispensed and the change still owed if the machine can't give the user all of their change
                else:
                    print("Change is:")
                    print(quarters_change_int, "quarters")
                    print(dimes_change_int, "dimes")
                    print(nickels_change_int, "nickels")
                    print(" ")
                    print("I'm sorry, the machine has run out of change.")
                    print("Please see the store manager to receive your change.")
                    print(" ")
                    print("Change owed:")
                    changedollars_int = -1*change_int//100 #remaining dollars of change owed to user
                    changecents_int = -1*change_int%100 #remaining cents of change owed to user

                    #prints the change change due to the user
                    #omits value for dollars or cents owed if 0
                    if changedollars_int !=0:
                        print(changedollars_int, "dollars, ", end="")
                    if changecents_int !=0:
                        print(changecents_int, "cents") 
                break
            
        
        else:
            print("Invalid deposit")
            print(" ")
            continue

        amountdue_int = price_int - payments_int #current amount due in cents
        dollarsdue_int = amountdue_int//100 #new number of dollars due
        centsdue_int = amountdue_int%100 #new number of cents due

        #prints amount due if user payments do not exceed price, exits loop if user has paid in full
        if payments_int >= price_int:
            print("You have paid in full")
        else:
            #prints the price inputted by the user
            #omits value for dollars or cents owed if 0
            print("Amount due is: ", end="")
            if dollarsdue_int !=0:
                print(dollarsdue_int, "dollars, ", end="")
            if centsdue_int !=0:
                print(centsdue_int, "cents", end="") 
            print(" ")
            print(" ")
            continue
        
    #This block starts the change giving part of the program
        if payments_int == price_int:
            print("No change")
        else:
            change_int = payments_int - price_int #calculates change owed
            changedollars_int = change_int//100 #dollars of change owed
            changecents_int = change_int%100 #cents of change owed
            print("Change due:", end="")

            #prints the change change due to the user
            #omits value for dollars or cents owed if 0
            if changedollars_int !=0:
                print(changedollars_int, "dollars, ", end="")
            if changecents_int !=0:
                print(changecents_int, "cents") 
            
            #Dispenses correct coins to user
            #Quarters
            quarters_change_int = change_int//25 #Calculates number of quarters to dispense

            while quarters_change_int > quarters_int: #Reduces number of quarters to dispense if quarters_change_int is more than the number in the machine.
                quarters_change_int = quarters_change_int - 1

            change_int = change_int - (quarters_change_int*25) #Reduces change owed by the amount of quarters dispensed in cents
            quarters_int = quarters_int - quarters_change_int
                
            #Dimes
            dimes_change_int = change_int//10 #Calculates number of dimes to dispnse

            while dimes_change_int > dimes_int: #Reduces number of dimes to dispense if dimes_change_int is more than the number in the machine.
                dimes_change_int = dimes_change_int - 1

            change_int = change_int - (dimes_change_int*10) #Reduces change owed by the amount of dimes dispensed in cents
            dimes_int = dimes_int - dimes_change_int
                
            #Nickels
            nickels_change_int = change_int//5 #Calculates number of nickels to dispnse

            while nickels_change_int > nickels_int: #Reduces numbers of nickels to dispense if nickels_change_int is more than the number in the machine
                    nickels_change_int = nickels_change_int -1

            change_int = change_int - (nickels_change_int*5) #Reduces change owed by the amount of nickels dispensed in cents
            nickels_int = nickels_int - nickels_change_int

            #Prints the change dispensed by the machine

            #This blocks prints the change dispensed if there is enough change to cover change owed to the user
            if change_int == 0:
                print("Change is:")
                print(quarters_change_int, "quarters")
                print(dimes_change_int, "dimes")
                print(nickels_change_int, "nickels")

            #This block prints the change dispensed and the change still owed if the machine can't give the user all of their change
            else:
                print("Change is:")
                print(quarters_change_int, "quarters")
                print(dimes_change_int, "dimes")
                print(nickels_change_int, "nickels")
                print(" ")
                print("I'm sorry, the machine has run out of change.")
                print("Please see the store manager to receive your change.")
                print(" ")
                print("Change owed:")
                changedollars_int = -1*change_int//100 #remaining dollars of change owed to user
                changecents_int = -1*change_int%100 #remaining cents of change owed to user

                #prints the change change due to the user
                #omits value for dollars or cents owed if 0
                if changedollars_int !=0:
                    print(changedollars_int, "dollars, ", end="")
                if changecents_int !=0:
                    print(changecents_int, "cents")              


    payments_int = 0 #resets payments to 0 for next purchase
    print(" ")
    
    print("Stock contains:")
    print("   ", nickels_int, "nickels")
    print("   ", dimes_int, "dimes")
    print("   ", quarters_int, "quarters")
    print("   ", ones_int, "ones")
    print("   ", fives_int, "fives")
    print(" ")
    price_str = input("Please enter the purchase price (xx.xx) or 'q' to quit: ") #Prompts for another input

print(" ")
print("Program ended. Thanks for playing!")
