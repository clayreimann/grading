#proj04
#Section 001
#Due 2/4/13

#Prompts the user for two strings consisting of alphabetical characters

sequence1_str = "" #Placeholder for first user sequence
sequence2_str = "" #Placeholder for second user sequence
    
while True: #Loop will break when user enters 'q' for quit
    print(" ")
    print("Please enter two strings of characters ('q' to quit):")

    sequence1_str = input("String 1: ") #Prompts user for first string

    if sequence1_str == "q":
        break #breaks loop once user enters 'q' to quit

    if sequence1_str.isalpha() == False: #Gives the user an error message if the user inputs not letter characters
        print("Invalid input for String 1. Letters only please!")
        continue
    
    sequence2_str = input("String 2: ") #Prompts user for second string if they have not already quit
    print(" ")
    
    if sequence2_str == "q":
        break #breaks loop once user enters 'q' to quit

    if sequence2_str.isalpha() == False: #Gives the user an error message if the user inputs not letter characters
        print("Invalid input for String 2. Letters only please!")
        continue

    sequence1_str = sequence1_str.lower() #makes the user inputted string all lower case
    sequence2_str = sequence2_str.lower() #makes the user inputted string all lower case

    #Presents a list of commands for the user to select from
    print("Commands:")
    print("a (add indel)") #User may make an insertion
    print("d (delete indel)") #User may delete a previously added insertion
    print("s (score)") #User may score their strings
    print("q (quit)") #User may quit and enter a new pair of strings
    print()

    while True: #Breaks when user quits or once user has scored their strings
        
        print()
        print("string 1 is {}".format(sequence1_str)) #displays what user entered for string 1 in all lowercase
        print("string 2 is {}".format(sequence2_str)) #displays what user entered for string 2 in all lowercase
        print()
        usercommand_str = input("What do you want to do?: ") #Prompts the user to input one of the above commands
        
        if usercommand_str == "a":
            print("You chose to add indel")
            select_int = int(input("Which string would you like to work on? (1 or 2): ")) #allows user to select one of their strings to make an addition

            if select_int == 1:
                print("You selected string 1")

                while True: #loop will break once the user enters a valid index for the addition
                    placement_int = int(input("Where would you like to make an addition? (Range is 0 to {}): ".format(len(sequence1_str)-1))) #Prompts the user for an index
                    if placement_int >= len(sequence1_str): #Gives an error message if selected index is out of range            
                        print("Index out of range")
                        continue
                    break
                
                firstchunk_str = sequence1_str[0:placement_int] #separates part of string before selected index
                secondchunk_str = sequence1_str[placement_int:] #separates part of string after selected index
                sequence1_str = firstchunk_str + "-" + secondchunk_str #creates a new string by adding the indel at the selected index
                continue
        
            else:
                print("You selected string 2")

                while True: #loop will break once the user enters a valid index for the addition
                    placement_int = int(input("Where would you like to make an addition? (Range is 0 to {}): ".format(len(sequence2_str)-1))) #Prompts the user for an index
                    if placement_int >= len(sequence2_str): #Gives an error message if selected index is out of range            
                        print("Index out of range")
                        continue
                    break
                
                firstchunk_str = sequence2_str[0:placement_int] #separates part of string before selected index
                secondchunk_str = sequence2_str[placement_int:] #separates part of string after selected index
                sequence2_str = firstchunk_str + "-" + secondchunk_str #creates a new string by adding the indel at the selected index
                continue

        elif usercommand_str == "d":
            print("You chose to delete indel")
            select_int = int(input("Which string would you like to work on? (1 or 2): ")) #allows user to select which string to delete from

            if select_int == 1:
                print("You selected string 1")
                if "-" not in sequence1_str:
                    print("Cannot delete from this string. No additions have been made.")
                    continue
                
                while True: #loop will break once the user enters a valid index for the deletion
                    placement_int = int(input("Where would you like to make a deletion? (Range is 0 to {}): ".format(len(sequence1_str)-1))) #Prompts the user for an index
                    if placement_int >= len(sequence1_str): #Gives an error message if selected index is out of range            
                        print("Index out of range")
                        continue

                    if sequence1_str[placement_int] != "-": #Gives error message if user tries to delete from original string
                        print("Invalid deletion. Can't delete from original string.")
                        continue

                    break

                firstchunk_str = sequence1_str[0:placement_int] #separates part of string before selected index
                secondchunk_str = sequence1_str[placement_int+1:] #separates part of string after selected index
                sequence1_str = firstchunk_str + secondchunk_str #creates a new string by removing the indel at the selected index

                continue #reprompts the user for a command
            
            else:
                print("You selected string 2")
                if "-" not in sequence2_str:
                    print("Cannot delete from this string. No additions have been made.")
                    continue

                while True: #loop will break once the user enters a valid index for the deletion
                    placement_int = int(input("Where would you like to make a deletion? (Range is 0 to {}): ".format(len(sequence2_str)-1))) #Prompts the user for an index
                    if placement_int >= len(sequence2_str): #Gives an error message if selected index is out of range            
                        print("Index out of range")
                        continue
                    if sequence2_str[placement_int] != "-": #Gives error message if user tries to delete from original string
                        print("Invalid deletion. Can't delete from original string.")
                        continue
                
                    break  

                firstchunk_str = sequence2_str[0:placement_int] #separates part of string before selected index
                secondchunk_str = sequence2_str[placement_int+1:] #separates part of string after selected index
                sequence2_str = firstchunk_str + secondchunk_str #creates a new string by removing the indel at the selected index                   

                continue #reprompts the user for a command

        elif usercommand_str == "s":

            dashes1_str = "" #Placeholder for string of dashes added to the end of the shorter string during comparison
            dashes2_str = "" #Placeholder for string of dashes added to the end of the shorter string during comparison

            print("You chose to score your strings")
            if len(sequence1_str) <= len(sequence2_str):
                maxlength_int = len(sequence2_str) #creates a variable equal to the length of the longer string
                difference_int = len(sequence2_str)-len(sequence1_str) #creates a variable for the difference in length between the two strings
                dashes1_str = difference_int * "-" #creates a string of dashes to add to the end of string 1 to make it the same length as string 2
               
            else:
                maxlength_int = len(sequence1_str) #creates a variable equal to the length of the longer string 
                difference_int = len(sequence1_str)-len(sequence2_str) #creates a variable for the difference in length between the two strings
                dashes2_str = difference_int * "-" #creates a string of dashes to add to the end of string 2 to make it the same length as string 1

            test1_str = sequence1_str + dashes1_str #creates a copy of string 1 for the comparison
            test2_str = sequence2_str + dashes2_str #creates a copy of string 2 for the comparison
            #the dash strings are added to the user inputted strings to create the test copies
            #the if/else block above creates a string of dashes for the shorter string only
            #the longer string has a dash string added as well, but this string doesn't contain any characters
            
            print()

            count_int = 0 #keeps track of index
            matches_int = 0 #keeps track of matches
            mismatches_int = 0 #keeps track of mismatches
            display1_str = "" #builds a string for comparison display
            display2_str = "" #builds a string for comparison display
                    
            while count_int < maxlength_int: #compares the character at each index until the end of the strings is reached
                if test1_str[count_int] == test2_str[count_int]: #when there is a match
                    matches_int = matches_int + 1 #adds 1 to the count of matches
                    display1_str = display1_str + test1_str[count_int] #constructs display string 1 character by character
                    display2_str = display2_str + test2_str[count_int] #constructs display string 2 character by character
                else: #when there is a mismatch
                    mismatches_int = mismatches_int + 1 #adds 1 to the count of mismatches
                    char1_str = test1_str[count_int].upper() #creates an uppercase version of the mismatched character from string 1
                    char2_str = test2_str[count_int].upper() #creates an uppercase version of the mismatched character from string 2
                    display1_str = display1_str + char1_str #adds character to display string 1
                    display2_str = display2_str + char2_str #adds character to display string 2
                count_int = count_int + 1
            
            print("Matches: {}  Mismatches: {}".format(matches_int,mismatches_int)) #Prints matches and mismatches

            #prints display versions of each string
            #mismatched characters are uppercase
            #matched characters are lowercase
            #dashes are printed at the end of the shorter string to make it the same length as the longer string
            print("string 1 {}".format(display1_str)) 
            print("string 2 {}".format(display2_str))
                
            continue #returns user to beginning of inner loop and reprompt for a valid command

        elif usercommand_str == "q":
            break #ends the loop, returns to beginning and reprompts the user for strings to test

        else:
            print("That is not a valid command")
            continue #returns user to beginning of inner loop and reprompt for a valid command
    
    

print("Thanks for playing!")



