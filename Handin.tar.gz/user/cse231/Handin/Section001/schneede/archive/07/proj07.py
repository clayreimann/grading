#proj07
#Sec 001
#Due 3/11/13

###########################################################################################################################################

#Program overview

#Five functions are defined

#   1. scramble_word takes takes a single word and returns a scrambled word according to the following rules
#       First and last letter are the same
#       Words of 3 characters or less are not scrambled
#       Punctuation marks retain their position also

#   2. scramble_line takes a line of text and returns a line of text with each word scrambled
#       uses scramble_word to scramble each word

#   3. open_read_file repeatedly prompts for a file name and returns a file object once a valid file name is entered

#   4. open_write_file prompts for a file name for writing.
#       If the specified file name does not include the .txt extension, this extension is added to ensure writing is done to a text file

#   5. main()
#       Uses open_read_file to prompt for a file to read
#       Uses open_write file to prompt for a file to write output to
#       Using the file object returned by open_read_file
#           Generates a scrambled line from each line of text from the opened file
#           Writes the scrambled line to the specified output file


###########################################################################################################################################

def scramble_word(word_str):
    '''
    Takes a single word (as a string) as an input, then scrambles the letters in that string
    First and last letters are not change
    Punctuation is not changed
    Returns the scrambled word
    '''
    
    import random #imports the random module
    
    if len(word_str) > 3:
        my_list = list(word_str) #turns inputted word into a string

        index_int = 0 #initial index value
        first_char = my_list[index_int] #pulls first character from list
        first_chunk_list = [first_char] #turns the first character into a list
        
        while first_char.isalpha() == False:
            
            index_int = index_int + 1 #changes index
            first_char = my_list[index_int] #pulls next character from the list
            first_chunk_list.append(first_char) #adds the next character to the list if the previous character wasn't a letter

        temp_list = my_list[index_int+1:] #creates a new list with first chunk removed
            
        index_int = -1 #resets index value to pull out end of list
        last_char = my_list[index_int] #pulls last character from list
        last_chunk_list = [last_char] #turns the last character into a list

        while last_char.isalpha() == False:
            
            index_int = index_int - 1 #changes index
            last_char = my_list[index_int] #pulls next character (moving backwards) from the list
            last_chunk_list = [last_char] + last_chunk_list #adds the next character (moving backwards) to the list if the previous character wasn't a letter
            
        temp_list = temp_list[:index_int] #removes last chunk from list

        popped_str = ""
        temp_index_int = 0
        
        #checks for punctuation inside words
        for item in temp_list:    
          
            if item.isalpha() == False:
                fix_index_int = temp_index_int
                popped_str = temp_list.pop(fix_index_int) #extracts punctuation from list
            temp_index_int = temp_index_int + 1
            
        random.shuffle(temp_list) #shuffles characters in the middle

        #if punctuation was removed from the middle of the word, it is readded in the appropriate location here
        if popped_str != "":
            temp_list = temp_list[:fix_index_int] + [popped_str] + temp_list[fix_index_int:]
            
        temp_list = first_chunk_list + temp_list + last_chunk_list #adds first and last chunk to temp_list
        scramble_str = ''.join(temp_list) #generates scrambled word

    else:
        scramble_str = word_str #returns original word if it is 3 characters or less in length

    return scramble_str #returns the newly created scrambled word
        
def scramble_line(line_str):
    '''
    Takes a line of text (as a string), separates the words in the line and stores the words as a list
    Uses the scramble_word function to scramble each word
    Puts the scrambled words into a list in the same order in which they originally
    Joins the scrambed words into a new line and returns this newly constructed line
    '''
    
    line_str = line_str.strip() #strips blank characters from ends of line
    line_list = line_str.split() #makes a list of words in the line
    scramble_list = [] #creates a null list
    
    for word in line_list: #for each word in the list created above, do the following
        new_word_str = scramble_word(word) #uses scramble_word to make a scrambled version of each word
        scramble_list = scramble_list + [new_word_str] #adds the scrambled word to the list created above, collect a list of scrambled words

    scramble_line_str = ' '.join(scramble_list) #joins new scrambled words into a new line
     
    return scramble_line_str #returns the new line of scrambled words

def open_read_file(file_name_str):
    '''
    Takes a file name (as a string) as input
    Tries to open a file of that name
    Repeatedly prompts for a valid file name if the first input is invalid
    Returns the opened file for reading
    '''
    
    while True:
        try:
            file_obj = open(file_name_str, "r")
            break #breaks loop once a file is successfully opened
    
        except IOError:
            print("Bad file name") #prints an error message
            file_name_str = input("Please enter a file name: ") #reprompts for a valid file name
            
    return file_obj #returns the opened file

def open_write_file():
    '''
    Prompts for a file name from the user
    If inputted name does not include .txt, this file extension will be added to the file name provided
    returns a text file object for writing
    '''

    write_file_str = input("Please enter a file name for writing: ") #prompts user for a file name for writing

    if ".txt" not in write_file_str:
        file_name_str = write_file_str + ".txt" #ensures that write file is a plain text file
    else:
        file_name_str = write_file_str #if the name already has the .txt extension, no changes are made to the file name

    file_obj = open(file_name_str, "w") #opens the specified file for writing

    return file_obj #returns the opened file object
    
    
def main():
    '''
    Uses open_write_file to prompt the user for a file to write, then opens that file for writing
    Prompts the user for a file to read and uses open_read_file to open it
    For each line in the opened file object being read, uses scramble line to create a new line of scrambled words
    Writes the new line of scrambled words to the specified write file
    '''
    
    user_write_obj = open_write_file()
    user_readfile_str = input("Please enter a file to read: ") #prompts the user for a text file to read
    user_read_obj = open_read_file(user_readfile_str) #uses open_read_file function to open a file for reading
    
    for doc_line in user_read_obj: #for each line in the opened file, do the following
        new_doc_line = scramble_line(doc_line) #uses scramble_line to create a new line of scrambled words from each line of the read file
        user_write_obj.write(new_doc_line) #writes the new line of scrambled words to the specified output file

    print("File writing complete")
    
    user_read_obj.close() #closes read file
    user_write_obj.close() #closes write file
    
main() #runs program
    
    
        
