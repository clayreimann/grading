#proj06
#Sec 001
#Due 2/25/13

###############################################################################################################

#Program overview

#Four functions are defined

#   1. get_input_descriptor prompts for a file name from the user and returns the file object with descriptor

#   2. get_data_list takes a file object and column number as arguments and returns a list of tuples
#       -each tuple consists of the date of the data entry and the value from the column selected

#   3. average_data takes a list of tuples as an argument and returns a list of tuples
#       -each tuple consists of a date (month:year) and a monthly average of the data element of the tuples

#   4. main incorporates the 3 functions above
#       a. uses get_input_descriptor to repeatedly prompt the user for a valid file name
#       b. repeatedly prompts the user for a column to analyze
#       c. uses the user inputs from the above 2 steps as arguments in the function get_data_list
#       d. takes the return from get_data_list as an argument in average_data to generate monthly averages
#       e. prints the highest 6 and lowest 6 monthly averages for the column of data selected

##############################################################################################################

def get_input_descriptor():

    '''
    Prompts the user for a file name and opens the file
    Returns the file object with descriptor
    '''
    
    while True:
        try: #watches this block for errors
            file_name_str = input("Please enter a file to read: ") #prompts the user for a file name
            file_obj = open(file_name_str, "r") #reads the file into the program
            break #exits loop if file open is successful
            
        except IOError: #executes if user enters a bad file name
            print("Bad file. Try again.") #prints error message
            continue #returns user to beginning of loop to reprompt for a file name
        
    return file_obj #returns a descriptor of the now opened file


def get_data_list(file_object, column_number):

    '''
    Takes a file object and an integer as arguments
    Extracts the date and corresponding data from the column corresponding to the integer argument
    Returns a list of tuples, each tuple containing the date and corresponding column data
    '''

    data_list = [] #empty list to start with
    
    for line in file_object:
        try:
            line = line.strip() #strips space characters from the ends of each line
            line_list = line.split(",") #separates comma delimited entries into a list for each line
            data_tuple = line_list[0], float(line_list[column_number]) #creates a tuple with date, column data for specified column
            temp_list = [data_tuple] #makes a list containing only the most recently extracted tuple
            data_list = data_list + temp_list #adds the most recently extracted tuple to the list of data
        except ValueError:
            continue

    return data_list #returns a list of tuples, each tuple containing (date, column_data)
            
def average_data(list_of_tuples):

    '''
    Takes a list of tuples as an argument, each tuple consisting of a date and corresponding data
    For each month, an average is calculated
    Returns a list of tuples, each containing a date (formatted (month:year) as a string) and the corresponding average as a float
    '''
    
    sorted_by_date_list = sorted(list_of_tuples) #sorts list to put earliest date first
    sum_float = 0 #initial value for sum variable used in average calculations
    count_int = 0 #initial value for number of elements being summed
    month_int = int(sorted_by_date_list[0][0][5:7]) #month of first data value
    average_list = [] #null list to add averages to later
    temp_float = 0 #initial value for variable that will catch skipped data entries

    #after first month, skips first data entry for each subsequent month when computing averages
    #this is corrected by setting the count equal to 1 in the else block and catching the skipped value to the sum
    
    for list_item in sorted_by_date_list: #iterates through list of tuples to compute monthly averages

        date_list = list_item[0].split("-") #turns the date item in each tuple into a list containing [year, month, date]
        
        if int(date_list[1]) == month_int: #checks to see if date is in same month
            sum_float = sum_float + list_item[1] #adds the value if the date is in the same month
            count_int = count_int + 1 #adds 1 to the count of values being summed
            new_date_str = date_list[1] + ":" + date_list[0] #builds a date string containing ('month:year')
            end_boolean = True #indicates that the end of the month has been reached

        else: #enters this block when the month switches
            temp_float = list_item[1] #catches data entry for current line so it can be added to the sum of the next month
            average_float = sum_float/count_int #calculates the monthly average
            average_float = round(average_float,2) #rounds the monthly average to 2 decimal places
            new_tuple = average_float, new_date_str #creates a tuple containing (monthly average, date) where date contains ('month:year')
            average_list = average_list + [new_tuple] #adds the tuple created above to the list of averages
            month_int = month_int + 1 #changes the month

            if month_int > 12: #checks to see if month_int is out of range
                month_int = 1 #resets month_int to 1 (January) if month_int is out of range
                
            count_int = 1 #resets the count to one to include first value of new month
            sum_float = temp_float #resets the sum to the skipped value to make sure it is included in the sum of the next month
            end_boolean = False #indicates that there are additional monthly averages to calculate

    if end_boolean == True: #computes last average in the column
        average_float = sum_float/count_int #calculates monthly average
        average_float = round(average_float,2) #rounds the monthly average to 2 decimal places
        new_tuple = average_float, new_date_str #creates a tuple containing (monthly average, date) where date contains ('month:year')
        average_list = average_list + [new_tuple] #adds the tuple created above to the list of averages
    
    return average_list    
    
def main():

    '''
    Uses the get_input_descriptor function embedded in a while loop to repeatedly prompt the user for a file name
    Repeatedly prompts the user for a column number
    Uses the function get_data_list to extract the date and the data from the column corresponding to the number entered by the user
       stores each date and corresponding data entry as a tuple
       tuples are stored in a list

    Uses the average_data function to calculate monthly averages from the list of tuples returned by get_data_list
    Prints the highest 6 and lowest 6 monthly averages with the corresponding dates from the list of tuples returned by average_data
    '''
    
    user_file_obj = get_input_descriptor() #prompts for a file to read

    while True: #loop breaks when user has entered a valid column number for analysis

        try: #this block checks for possible index and value errors
            user_column_number = int(input("Please enter a column to analyze: "))
            if user_column_number > 6 or user_column_number < 0: #checks to see if the input is in the specified range (0 to 6)
                print("Input out of range")
                continue
            user_data_list = get_data_list(user_file_obj, user_column_number) #retrieves data from file
            break

        except ValueError: #checks to see if user input is a number
            print("Invalid input") #error message for non-integer inputs
            continue #returns user to beginning of the loop to reprompt for a column number 

    user_monthly_list = average_data(user_data_list)
    
    sorted_list = sorted(user_monthly_list)
        
    #This block finds and prints the lowest 6 monthly averages in the selected column
    print("Lowest 6 monthly averages for column {} are:".format(user_column_number))
    for i in range(0,6):
        print(sorted_list[i]) #prints item at specified location in list

    #This block finds and prints the highest 6 monthly averages in the selected column
    print("Highest 6 monthly averages for column {} are:".format(user_column_number))
    for i in range(1,7): 
        i = -i #this is because list is printed in increasing order, therefore highest values are at the end of the list
        print(sorted_list[i]) #prints item at specified location in list
        
    user_file_obj.close() #closes file

main() #executes program   
    
