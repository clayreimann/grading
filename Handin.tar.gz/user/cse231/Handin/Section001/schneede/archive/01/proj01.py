#Section 001
#Project 1
#Due 1/14/13

#prompts the user to enter a Richter scale measure
richter_str = input("Please give me a Richter scale measure: ")
print(" ")

#converts the input from the prompt to a float
richter_float = float(richter_str)

#prints the inputted Richter scale measure
print("Richter measure: ", richter_float)

#Calculates the amount of energy in joules 
print("Equivalnce in joules: ", 10**(1.5*richter_float+4.8))

#calculates the amount of energy in tons of TNT exploded
print("Equivlance in tons of TNT: ", (10**(1.5*richter_float+4.8))/4.184e9)
print(" ")

#calculates the Joules and TNT equivalences of some selected Richter scale measures
print("Richter        Joules                           TNT")
print("1.0      ", 10**(1.5*1.0+4.8), "                ", (10**(1.5*1.0+4.8))/4.184e9)
print("5.0      ", 10**(1.5*5.0+4.8), "              ", (10**(1.5*5.0+4.8))/4.184e9)
print("9.1      ", 10**(1.5*9.1+4.8), "     ", (10**(1.5*9.1+4.8))/4.184e9)
print("9.2      ", 10**(1.5*9.2+4.8), "     ", (10**(1.5*9.2+4.8))/4.184e9)
print("9.5      ", 10**(1.5*9.5+4.8), "   ", (10**(1.5*9.5+4.8))/4.184e9)
