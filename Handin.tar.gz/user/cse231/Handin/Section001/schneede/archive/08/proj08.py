#proj08
#Sec 001
#Due 3/18/13

###########################################################################################################################################

#Program overview

#Three functions are defined

#   1. fill_completions(c_dict, fd) takes an empty dictionary and an opened text file as inputs and has no return
#       The dictionary is filled using words from the opened text file
#       The keys are tuples of the form (n, 1) where n is a non negative integer and 1 is a lower case letter
#       The values are the word that the letters came from

#   2. find_completions(prefix, c_dict)
#       Takes a prefix (str) and a completions dictionary as inputs
#       Generates a set of words that could complete that prefix

#   3. main()
#       Opens the file ap_docs.txt
#       prompts for a prefix from the user
#       Generates a completions dictionary from ap_docs.txt using fill_completions 
#       Uses the user prefix in find_completions to find a list of possible completions
#       Prints the list of possible completions

###########################################################################################################################################

def fill_completions(c_dict, fd):
    '''
    The dictionary is filled using words from the opened text file
    The keys are tuples of the form (n, 1) where n is a non negative integer and 1 is a lower case letter
    The values are the word that the letters came from
    '''
    
    import string
    for line in fd: #separates file into lines
        line = line.strip() #strips space characters from the ends of each line
        line_list = line.split(" ") #separates space delimited entries into a list for each line
        for word in line_list: #separates lines into words
            word = word.lower()
            word = word.strip(string.punctuation)
            if len(word) > 1: #checks to make sure word is more than 1 character
                key_list = list(enumerate(word)) #generates tuples of the form (index, character) from the word
                for key in key_list:
                    if key[1].isalpha(): #checks to make sure character is a letter
                        if key in c_dict: #checks to see if the key is already in the dictionary
                            c_dict[key] = c_dict[key] | {word} #adds word to set under that key if it is not a already there
                        else:
                            c_dict[key] = {word} #creates a new key if key does not already exist

def find_completions(prefix, c_dict):
    '''
    find_completions(prefix, c_dict)
    Takes a prefix (str) and a completions dictionary as inputs
    Generates a set of words that could complete that prefix
    '''
    
    result = c_dict[(0,prefix[0])] #sets result to dictionary value corresponding to the first letter of the prefix
    for index in range(1,len(prefix)): 
        result = result & c_dict[(index,prefix[index])] #gathers set of words including the given prefix
    return result

def main():
    '''
    Opens the file ap_docs.txt
    prompts for a prefix from the user
    Generates a completions dictionary from ap_docs.txt using fill_completions 
    Uses the user prefix in find_completions to find a list of possible completions
    Prints the list of possible completions
    '''
    
    read_file = open("ap_docs.txt","r")
    my_dict = {} #empty dictionary to be filled
    fill_completions(my_dict, read_file) #fills completion dictionary

    while True:
        user_prefix = input("Please enter a prefix (# to quit): ") #prompts user for a prefix
        if user_prefix == "#": 
            print("Program ended")
            break #exits loop, quits program
        elif user_prefix.isalpha(): #checks to see if user_prefix contains non-letter characters
            completions_set = find_completions(user_prefix, my_dict) #generates a set of possible completions based on user inputted prefix
            if completions_set == set(): #checks to see if the intersection is the empty set
                print("No words found")
            else:
                completions_set = sorted(completions_set) #alphabetizes set of completions
                print("Possible completions are:") #prints possible completions
                for word in completions_set:
                    print(word)
            continue
        else:
            print("Invalid prefix")
            continue
        
main()
