#proj05
#Sec 001
#Due 2/11/13

import turtle 
import time
import math

print("Available colors:")
print("red")
print("blue")
print("green") 
print("yellow")
print("orange")
print("purple")
print("pink")
print()

def get_color_choice():
    colors_list = ["red", "blue", "green", "yellow", "orange", "purple", "pink"] #creates a list of valid colors
    
    while True:
        color_choice_str = input("Please enter a color from the list above: ")
        if color_choice_str not in colors_list: #checks if user input is in list above
            print("That is not a valid selection") #returns an error message if user input is not in specified list
            continue #sends user to beginning of loop to reprompt for a valid color selection
        break

    return color_choice_str #function returns user color selection as a string

def get_num_hexagons():
    while True:
        rows_choice_str = input("Please enter a number of hexagons (range is 4 to 20): ")
        if rows_choice_str.isdigit() is False: #checks if user input is an integer
            print("Invalid input. Input must be an integer between 4 and 20") #returns an error message is user inputs a non-integer value
            continue #sends user to beginning of loop to reprompt for a new number of rows

        rows_choice_int = int(rows_choice_str) #converts user input into an integer

        if rows_choice_int not in range(4,21): #checks if user input is in specified range
            print("Input not in specified range.") #returns an error message if user input is not between 4 and 20
            continue #sends user to beginning of loop to reprompt for a new number of rows
        
        break

    return rows_choice_int #function returns user row selection as an integer

def draw_hexagon(x, y, side_len, pen, color):
    pen.speed(100) #makes it draw fast!
    pen.fillcolor(color) #sets pen color
    pen.setheading(0)
    pen.up()
    pen.goto(x, y) #start position of pen
    pen.down() #initializes drawing
    pen.begin_fill() #starts fill so hexagon is filled with specified color once drawn
    pen.left(30) #rotates pen to start drawing
    for side in range(6): #loop draws 6 sides
        pen.forward(side_len) #draws a side
        pen.right(60) #rotates pen to draw next side
    pen.end_fill() #ends fill so hexagon is filled with specified color once drawn

selection1_str = get_color_choice() #acquires first color choice
selection2_str = get_color_choice() #acquires second color choice
rows_int = get_num_hexagons() #acquires choice for number of rows

print("Color choices are {} and {}, number of rows selected is {}".format(selection1_str, selection2_str, rows_int)) #prints user color and row selections

#Calculate the side length of the hexagons
width_int = 500/rows_int
side_int = (width_int/2)/math.cos(math.pi/6)

#drawing hexagon function goes here eventually
x_pos = -250 #sets starting x coordinate of tessellation
y_pos = 250 #sets starting y coordinate of tessellation\
align_int = 0 #will be used to alternate left/right position of rows so the interlock perfectly
color_str = selection2_str

while y_pos >= -250 + width_int: #stops pen when bottom of canvas is reached

    while x_pos <= 250 - width_int: #moves to next row when pen hits edge of canvas

        #this if block alternates the hexagon color
        if color_str == selection1_str:
            color_str = selection2_str
        elif color_str == selection2_str:
            color_str = selection1_str
        
        draw_hexagon(x_pos, y_pos, side_int, turtle, color_str) #this draws the hexagon
        x_pos = x_pos + width_int #moves the starting x position for the next hexagon.
        #returns to beginning of loop to draw another hexagon until side edge of canvas is reached
        
    else:
        y_pos = y_pos - (side_int + side_int*math.sin(math.pi/6)) #moves the starting y position for the next row

        #this if block aligns each row left or right so the hexagons interlock
        if align_int == 0:
            x_pos = -250 - (width_int/2)
            align_int = 1
        elif align_int == 1:
            x_pos = -250
            align_int = 0
        continue #returns to beginning of loop until the specified number of hexagons are drawn
    
time.sleep(10) #time delay for viewing of the graphic
turtle.bye() #closes the turtle drawing window







    
    
        
        

    


    


    
