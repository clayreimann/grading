#Section 001
#Project 2
#Due 1/21/13

#This program prompts the user to guess a six digit number.
#The program then tests to see if the given number satisfies the equation
#described below

print("Guess a six-digit number SLAYER so that following equation is true,")
print("where each letter stands for the digit in the position shown:")
print("")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print("")     

#Prompts the user to guess a six digit number to satisfy the equation described
slayer_str = input("Input your guess for SLAYER: ")
slayer_int = int(slayer_str)
print("")

#Gives the user an error message if they type a number that is not six digits
if slayer_int < 100000 or slayer_int > 999999:
    print("That is not a six digit number. Please try again.")

#If the user enters a six digit number, the program continues with these
#calculations to test if their guess satisfies the equation
    
else:
    R_digit = slayer_int % 10 #Ones digit
    E_digit = (slayer_int//10)%10 #Tens digit
    Y_digit = (slayer_int//100)%10 #Hundreds digit
    A_digit = (slayer_int//1000)%10 #Thousands digit
    L_digit = (slayer_int//10000)%10 #Ten thousands digit
    S_digit = (slayer_int//100000)%10 #Hundred thousands digit

    #Computes the number LAYERS by combining the digits isolated above
    layers_int = S_digit + R_digit*10 + E_digit*100 + Y_digit*1000 + A_digit*10000 + L_digit*100000

    #Computes the sum SLAYER + SLAYER + SLAYER
    result_int = slayer_int + slayer_int + slayer_int

    #This checks to see if SLAYER + SLAYER + SLAYER = LAYERS
    #If the guess is correct, the program prints the message below
    if result_int == layers_int:
        print("Congratulations! Your guess is correct!")

    #If the guess is incorrect, the program prints the following
    else:
        print("Your guess is incorrect")
    
    print("")
    print("SLAYER + SLAYER + SLAYER = ", result_int)
    print("LAYERS = ", layers_int)
    print("")   
    print("Thanks for playing!")


