#CSE 231 
#Section 1 
#Project 10 
#4/08/13 

import turtle
import time
#####################################################################################  

class Star(object):
    def __init__(self,x,y,arm_length,color):
        self.x = x
        self.y = y
        self.a = arm_length
        self.color = color
    def draw(self,pen):
        pen.up()
        pen.left(90)
        pen.goto(self.x,self.y)
        pen.color(self.color)
        pen.forward(self.a/2.35)
        pen.right(90)
        pen.forward(self.a/3.236)
        pen.down()
        pen.begin_fill()
        for i in range(5):
            pen.forward(self.a)
            pen.right(144)
            pen.forward(self.a)
            pen.left(72)
        pen.end_fill()
        pen.hideturtle()
        pen.up()
        pen.home()
    def __str__(self):
        star_str = 'Star '
        star_str +='x:{}, '.format(self.x)
        star_str +='y:{}, '.format(self.y)
        star_str +='arm:{}, '.format(self.a)
        star_str +='color:{}'.format(self.color)
        return star_str
#####################################################################################        

class Rectangle(object):
    def __init__(self,x,y,width,height,color):
        self.x = x
        self.y = y
        self.w = width
        self.h = height
        self.color = color
    def draw(self,pen):
        pen.up()
        pen.goto(self.x-self.w/2,self.y+self.h/2)
        pen.color(self.color)
        pen.begin_fill()
        pen.forward(self.w)
        pen.right(90)
        pen.forward(self.h)
        pen.right(90)
        pen.forward(self.w)
        pen.right(90)
        pen.forward(self.h)
        pen.end_fill()
        pen.up()
        pen.home()
    def __str__(self):
        rect_str = 'Rectangle '
        rect_str +='x:{}, '.format(self.x)
        rect_str +='y:{}, '.format(self.y)
        rect_str +='width:{}, '.format(self.w)
        rect_str +='height:{}, '.format(self.h)
        rect_str +='color:{}'.format(self.color)
        return rect_str
#####################################################################################

class Flag(object):
    def __init__(self,f_obj):
        rect_num_str = f_obj.readline().strip()
        rect_num = int(rect_num_str)

        rect_list = []
        rect_list_list = []
        rect_class_list = []
        for i in range(rect_num):
            rect_list.append(f_obj.readline().strip())
            rect_list_list.append(rect_list[i].split(','))
            rect_class_list.append(Rectangle(int(rect_list_list[i][0].strip()),int(rect_list_list[i][1].strip()),int(rect_list_list[i][2].strip()),int(rect_list_list[i][3].strip()),rect_list_list[i][4].strip()))


        star_num_str = f_obj.readline().strip()
        star_num = int(star_num_str)

        star_list = []
        star_list_list = []
        star_class_list = []
        for j in range(star_num):
            star_list.append(f_obj.readline().strip())
            star_list_list.append(star_list[j].split(','))
            star_class_list.append(Star(int(star_list_list[j][0].strip()),int(star_list_list[j][1].strip()),float(star_list_list[j][2].strip()),star_list_list[j][3].strip()))



        self.rect_num = rect_num
        self.rect_classes = rect_class_list
        self.star_num = star_num
        self.star_classes = star_class_list

        
    def draw(self,pen):
        for i in range(self.rect_num):
            self.rect_classes[i].draw(pen)
        for j in range(self.star_num):
            self.star_classes[j].draw(pen)

    def __str__(self):
        flag_str = 'DummyRec:'+'\n'
        for i in range(self.rect_num):
            flag_str += self.rect_classes[i].__str__() + '\n'
        flag_str += 'DummySta:'+'\n'
        for j in range(self.star_num):
            flag_str += self.star_classes[j].__str__() + '\n'
            flag_str = flag_str.replace('Rectangle ','')
            flag_str = flag_str.replace('Star ','')
            flag_str = flag_str.replace('DummyRec','Rectangles')
            flag_str = flag_str.replace('DummySta','Stars')
        return flag_str
        
#####################################################################################    
            
def main():
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    print("Look for the Python Turtle Graphics window")
    print("Position it and the Python Shell window side by side.")
    input("Then press `Enter' to continue ...")
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print("Senegal Flag")
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print("Panama Flag")
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    myFlag_file = open('myFlag.txt')
    my_flag = Flag(myFlag_file)
    print("United States Flag")
    print(my_flag)
    my_flag.draw(pen)
    myFlag_file.close()
        
        



        
        
        
