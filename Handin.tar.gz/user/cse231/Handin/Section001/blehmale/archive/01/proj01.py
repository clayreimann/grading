#Project 1
#Alex Blehm
#CSE 231, Sect 1
#1-9-13


num_str = input('Please enter a Richter Scale Measure:')
str_float = float(num_str)

R = str_float

J = 10**(1.5*R+4.8)
T = J/4.184e9


J1 = 10**(1.5*1+4.8)
J5 = 10**(1.5*5+4.8)
J91 = 10**(1.5*9.1+4.8)
J92 = 10**(1.5*9.2+4.8)
J95 = 10**(1.5*9.5+4.8)

T1 = J1/4.184e9
T5 = J5/4.184e9
T91 = J91/4.184e9
T92 = J92/4.184e9
T95 = J95/4.184e9

print(' ')
print('Richter Measure: ', R)
print('Equivalence in Joules: ', J)
print('Equivalence in Tons of TNT: ', T)
print(' ')
print('Richter           Joules                        TNT')
print('1.0         ',J1,'           ',T1)
print('5.0         ',J5,'           ',T5)
print('9.1         ',J91,'          ',T91)
print('9.2         ',J92,'          ',T92)
print('9.5         ',J95,'          ',T95)
