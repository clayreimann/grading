##CSE 231 Section 1
##3/25/13
##Project 9


import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    #Set up empty foundation and cell
    foundation = [[],[],[],[]]
    cell = [[],[],[],[]]

    #set up deck and lists for tableau
    my_deck = cardsBasic.Deck()
    my_deck.shuffle()
    list1 = []
    list2 = []
    list3 = []
    list4 = []
    list5 = []
    list6 = []
    list7 = []
    list8 = []
    list9 = []
    list10 = []

    #Deals cards to lists
    for card in range(5):
        list1.append(my_deck.deal())
        list2.append(my_deck.deal())
        list3.append(my_deck.deal())
        list4.append(my_deck.deal())
        list5.append(my_deck.deal())
        list6.append(my_deck.deal())
        list7.append(my_deck.deal())
        list8.append(my_deck.deal())
        list9.append(my_deck.deal())
        list10.append(my_deck.deal())
    list1.append(my_deck.deal())
    list2.append(my_deck.deal())

    #Forms tableau from lists
    tableau = [list1,list2,list3,list4,list5,list6,list7,list8,list9,list10]
    
    return foundation,tableau,cell
###############################################################################

def cell_to_foundation(cell,foundation,c_col,f_col):
    '''
    parameters: a cell, a foundation, column of cell, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card from a column of a cell to a column of foundation
    '''
    #Corrects for indices
    c_col -=1
    f_col -=1
    
    #Error Checking
    if cell[c_col] != []:
        if foundation[f_col] == []:
            if cell[c_col][0].get_rank() == 1:
                #pops from and appends to
                pop = cell[c_col].pop()
                foundation[f_col].append(pop)
                my_bool = True
            else:
                my_bool = False
        else:
            if cell[c_col][0].equal_suit(foundation[f_col][-1]):
                if cell[c_col][0].get_rank()-1 == foundation[f_col][-1].get_rank():
                    pop = cell[c_col].pop()
                    foundation[f_col].append(pop)
                    my_bool = True
                else:
                    my_bool = False
            else:
                my_bool = False
    else:
        my_bool = False
    return my_bool
###############################################################################
               
def tableau_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    '''
    #Similar process as cell_to_foundation()
    t_col -=1
    f_col -=1
    
    if tableau[t_col] != []:
        if foundation[f_col] == []:
            if tableau[t_col][-1].get_rank() == 1:
                pop = tableau[t_col].pop()
                foundation[f_col].append(pop)
                my_bool = True
            else:
                my_bool = False
        else:
            if tableau[t_col][-1].equal_suit(foundation[f_col][-1]):
                if tableau[t_col][-1].get_rank()-1 == foundation[f_col][-1].get_rank():
                    pop = tableau[t_col].pop()
                    foundation[f_col].append(pop)
                    my_bool = True
                else:
                    my_bool = False
            else:
                my_bool = False
    else:
        my_bool = False
    return my_bool
###############################################################################

def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    #Similar process as cell_to_foundation() but does not have to check for rank or suit, just if it is an empty cell or not
    t_col -=1
    c_col -=1

    if tableau[t_col] != []:
        if cell[c_col] == []:
            pop = tableau[t_col].pop()
            cell[c_col].append(pop)
            my_bool = True
        else:
            my_bool = False
    else:
        my_bool = False
    return my_bool
###############################################################################

def move_to_tableau(cell,tableau,c_col,t_col):
    '''
    parameters: a cell, a tableau, column of cell, a tableau
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    #Similar process as cell_to_foundation()
    c_col -=1
    t_col -=1
    
    if cell[c_col] != []:
        if tableau[t_col] == []:
            if cell[c_col][0].get_rank() == 13:
                pop = cell[c_col].pop()
                tableau[t_col].append(pop)
                my_bool = True
            else:
                my_bool = False
        else:
            if cell[c_col][0].equal_suit(tableau[t_col][-1]):
                if cell[c_col][0].get_rank()+1 == tableau[t_col][-1].get_rank():
                    pop = cell[c_col].pop()
                    tableau[t_col].append(pop)
                    my_bool = True
                else:
                    my_bool = False
            else:
                my_bool = False
    else:
        my_bool = False
    return my_bool
###############################################################################

def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    #Similar process as cell_to_foundation()
    t_col_source -=1
    t_col_dest -=1
    
    if tableau[t_col_source] != []:
        if tableau[t_col_dest] == []:
            if tableau[t_col_source][-1].get_rank() == 13:
                pop = tableau[t_col_source].pop()
                tableau[t_col_dest].append(pop)
                my_bool = True
            else:
                my_bool = False
        else:
            if tableau[t_col_source][-1].equal_suit(tableau[t_col_dest][-1]):
                if tableau[t_col_source][-1].get_rank()+1 == tableau[t_col_dest][-1].get_rank():
                    pop = tableau[t_col_source].pop()
                    tableau[t_col_dest].append(pop)
                    my_bool = True
                else:
                    my_bool = False
            else:
                my_bool = False
    else:
        my_bool = False
    return my_bool
###############################################################################
    
def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    #Checks if foundation is empty at all
    if foundation[0]==[] or foundation[1]==[] or foundation[2]==[] or foundation[3]==[]:
        my_bool = True
    else: #If not, checks for rank and gives my_bool
        end1 = foundation[0][-1]
        end2 = foundation[1][-1]
        end3 = foundation[2][-1]
        end4 = foundation[3][-1]

        if end1.get_rank()==13 and end2.get_rank()==13 and end3.get_rank()==13 and end4.get_rank()==13:
            my_bool = False
        else:
            my_bool = True
    return my_bool
###############################################################################

def print_game(foundation,tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')
###############################################################################
    
def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)
###############################################################################
    
def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
###############################################################################         
    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup()

    win_bool = True
       
    show_help()
    while win_bool:
        print_game(foundation, tableau, cell)
        response = input("Command (type 'h' for help): ")
        response = response.strip()
        response_list = response.split()        
        if len(response_list) > 0:
            r = response_list[0]
            if r == 't2f':
                #All following if statements check for index range
                if 1<= int(response_list[1]) <=10 and 1<= int(response_list[2]) <=4:
                    my_bool = tableau_to_foundation(tableau,foundation,int(response_list[1]),int(response_list[2]))
                else:
                    my_bool = False
            elif r == 't2t':
                if 1<= int(response_list[1]) <=10 and 1<= int(response_list[2]) <=10:
                    my_bool = move_in_tableau(tableau,int(response_list[1]),int(response_list[2]))
                else:
                    my_bool = False
            elif r == 't2c':
                if 1<= int(response_list[1]) <=10 and 1<= int(response_list[2]) <=4:
                    my_bool = move_to_cell(tableau,cell,int(response_list[1]),int(response_list[2]))                       
                else:
                    my_bool = False
            elif r == 'c2t':
                if 1<= int(response_list[1]) <=4 and 1<= int(response_list[2]) <=10:
                    my_bool = move_to_tableau(cell,tableau,int(response_list[1]),int(response_list[2]))            
                else:
                    my_bool = False
            elif r == 'c2f':
                if 1<= int(response_list[1]) <=4 and 1<= int(response_list[2]) <=4:
                    my_bool = cell_to_foundation(cell,foundation,int(response_list[1]),int(response_list[2]))                      
                else:
                    my_bool = False
            elif r == 'q':
                break
            elif r == 'h':
                show_help()
                my_bool = True
            else:
                print()
                print('Unknown command:',r)
                my_bool = True
            if not my_bool:
                print()
                print('Invalid move:',response)      
        else:
            print("Unknown Command:",response)
        win_bool = is_winner(foundation) #if win_bool==True(not win), loop continues. if win_bool==False (win), loop terminates and goes to else
    else:
        print_game(foundation, tableau, cell)
        print()
        print('CONGRATULATIONS! YOU WIN!')
        print()
    print('Thanks for playing')
###############################################################################

    
play()
        
    

