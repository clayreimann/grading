#CSE 231 Section 1
#2/25/13
#Project 6



def get_input_descriptor():
    '''Repeatedly prompts for input file until valid file name is entered'''
    file_bool = True
    while file_bool:
        try:
            read_input = input('Read File: ')
            read_file = open(read_input,'r')
            file_bool = False
        except IOError: #For Python 3.2 ==> IOError - For 3.3 ==> FileNotFoundError
            print('Bad File Name.')
    return read_file
########################################################################



def get_data_list(file_obj,column_no):
    tuple_list = []
    for line in file_obj:
        line = line.strip()
        line_list = line.split(',')
        tuple1 = line_list[0]
        tuple2 = line_list[column_no]
        if any(c.isdigit() for c in line_list[column_no]):
            my_tuple = tuple1,tuple2
            tuple_list.append(my_tuple)
    return tuple_list
########################################################################



def average_data(tuple_list):

    val_list = []
    month_list = []
    year_list = []
    for my_tuple in tuple_list:
        date_str = my_tuple[0]
        val_float = float(my_tuple[1])
        date_list = date_str.split('-')
        month_str = date_list[1]
        year_str = date_list[0]
        val_list.append(val_float)
        month_list.append(month_str)
        year_list.append(year_str)
        
    j = 0
    avg_date_list = []
    for i in range(1,len(tuple_list)):
        if month_list[i] != month_list[i-1] or i == len(tuple_list)-1:
            sum_val = sum(val_list[j:i])
            avg_val = sum_val/len(val_list[j:i])
            month = month_list[i-1]
            year = year_list[i-1]
            new_date_list = [month,year]
            new_date_str = ":".join(new_date_list)
            avg_date_tuple = avg_val,new_date_str
            avg_date_list.append(avg_date_tuple)
            j = i
            
    return avg_date_list
#######################################################################


def main():
    file_obj = get_input_descriptor()
    column_no = int(input('Which column: '))
    tuple_list = get_data_list(file_obj,column_no)
    my_ans = average_data(tuple_list)
    my_ans.sort()
    low6 = my_ans[0:6]
    high6 = my_ans[-6:]
    

    return print('Highest Six: {} \nLowest Six: {}'.format(high6,low6))
#########################################################################

def run_yn():
    yes_no = input('Run main()? (y/n): ')
    if yes_no == 'y':
        main()
    else:
        print('Ok')
#########################################################################

run_yn()



