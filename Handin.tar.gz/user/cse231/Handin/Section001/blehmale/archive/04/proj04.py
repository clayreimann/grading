#CSE 231 Section 1
#2/4/13
#Project 4

#Prompt user for DNA string
dna_str1 = input('Input DNA String 1: ')
dna_str2 = input('Input DNA String 2: ')

#Prompt user for command
print()
print('`a` to add')
print('`d` to delete')
print('`s` to score')
print('`q` to quit')
print()
command_str = input('What would you like to do: ')


#While loop to account for quitting
while command_str != 'q':
    #If func for scoring
    if command_str == 's':
        #Define variables
        score_str1 = dna_str1.lower()
        score_str2 = dna_str2.lower()
        length1 = 0
        length2 = 0
        #Find length of each string
        for val1 in score_str1:
            length1 +=1
        for val2 in score_str2:
            length2 +=1
        #If strings are different, adds dashes
        if length1 > length2:
            dif = length1 - length2
            score_str2 = score_str2 + dif*'-'
        elif length2 > length1:
            dif = length2 - length1
            score_str1 = score_str1 + dif*'-'
        #Define variables
        which_str = 0
        count = 0
        match = 0
        mismatch = 0
        #Counts matches and mismatches
        for index_str1 in score_str1:
            index_str2 = score_str2[count]
            if index_str1 == index_str2:
                match +=1
            else:
                #Capitalizes mismatches
                index_cap_str1 = index_str1.capitalize()
                index_cap_str2 = index_str2.capitalize()
                score_str1 = score_str1[:count] + index_cap_str1 + score_str1[count+1:]
                score_str2 = score_str2[:count] + index_cap_str2 + score_str2[count+1:]
                mismatch +=1
            count +=1
        #Prints deliverables
        print()
        print('Matches: ',match,' ; Mismatches: ',mismatch)
        print('String 1: ',score_str1)
        print('String 2: ',score_str2)
    #If func for adding or deleting
    elif command_str == 'a' or command_str == 'd':
        #Prompts user for sting selection
        print()
        which_str = input('Which string? (1 or 2): ')
        #Error if wrong selection
        if which_str == '1':
            dna_str = dna_str1
        elif which_str == '2':
            dna_str = dna_str2
        else:
            print()
            print('I said 1 or 2')
            continue
        #If func for adding
        if command_str == 'a':
            var = 0
            #Error and reprompt if index is out of range
            while var != 1:
                print()
                index_int = int(input('Before which index: '))
                length = -1
                for dna in dna_str:
                    length +=1
                if index_int > length:
                    print()
                    print('Index is out of range.')
                else: var = 1
            #Adds dash
            dna_str = dna_str[:index_int] + '-' + dna_str[index_int:]
        else: #if command_str == 'd':
            #Checks if dash is in string or not
            if dna_str.find('-') != -1:
                #Prompts for index to be deleted
                print()
                indel_int = int(input('Delete which index: '))
                #Checks to make sure that index is the dash
                while dna_str[indel_int] != '-':
                    print()
                    print('Index to be deleted must be `-`.')
                    print()
                    indel_int = int(input('Delete which index: '))
                #Deletes dash
                dna_str = dna_str[:indel_int] + dna_str[indel_int+1:]
            else:
                print()
                print('The selected string has no indels to delete.')
    else: #Prints invalid selection and reprompts
        print()
        print('Invalid Selection')
    #Redfines variables and reprompts
    if which_str == '1':
        dna_str1 = dna_str
    elif which_str == '2':
        dna_str2 = dna_str
    else:
        which_str = 0
    print()
    print('`a` to add')
    print('`d` to delete')
    print('`s` to score')
    print('`q` to quit')
    print()
    command_str = input('What would you like to do: ')
else: #Ending statement when quit
    print()
    print('Hopefully this was able to help.')
