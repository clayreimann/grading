#CSE 231 Section 1
#4/22/13
#Project 12


def get_temp_list():
    temp_file = open('temperature.txt','r')
    line_list = []
    templist = []
    templist_list = []
    count = -2
    for line in temp_file:
        if count == -2 or count == -1:
            pass
        else:
            line = line.strip()
            list_of_line = line.split(' ')
            list_of_line[:] = (value for value in list_of_line if value != '')
            temp = list_of_line[-1]
            templist.append(float(temp))
            if count%24 == 23:
                templist_list.append(templist[count-23:count+1])
        count +=1
    temp_file.close()
    return templist_list

def find_high_temp(templist_list):
    max_list = []
    for templist in templist_list:
        max_temp = max(templist)
        max_list.append(float(max_temp))
    return max_list

def find_low_temp(templist_list):
    min_list = []
    for templist in templist_list:
        min_temp = min(templist)
        min_list.append(float(min_temp))
    return min_list

def calc_bar_avg(daily_temp_list,month):
    month_list = ['January','February','March','April','May','June','July','August','September','October','November','December']
    month_length_list = [31,29,31,30,31,30,31,31,30,31,30,31]
    index = month-1
    month_length = int(month_length_list[index])
    if month != 1:  
        days_before = sum(month_length_list[:index])
    else:
        days_before = 0
    temp_sum = sum(daily_temp_list[days_before:days_before+month_length])
    temp_avg = temp_sum/month_length
    return temp_avg

def bar_plot():
    high_list = []
    low_list = []
    for month in range(1,13):
        high_list.append(calc_bar_avg(find_high_temp(get_temp_list()),month))
        low_list.append(calc_bar_avg(find_low_temp(get_temp_list()),month))
    diff_list = []
    for i in range(len(high_list)):
        diff_list.append(high_list[i]-low_list[i])
    import matplotlib.pyplot as plt
    import numpy as np
    plt.bar([0,1,2,3,4,5,6,7,8,9,10,11],diff_list, bottom=low_list)
    plt.title('Average Monthly Temperature for Charleston, MO - 2012')
    plt.ylabel('Average Temperature (Degrees Fahrenheit)')
    ticks = np.arange(12)
    locs,labels = plt.xticks(ticks,('January','February','March','April','May','June','July','August','September','October','November','December'))
    plt.setp(labels,rotation=45)
    plt.savefig('bar_plot.png')
    plt.close()
##########################################################################################################################

def get_solar_list():
    solar_file = open('solar_radition.txt','r')
    line_list = []
    solarlist = []
    solarlist_list = []
    count = -4
    for line in solar_file:
        if count==-4 or count==-3 or count==-2 or count==-1:
            pass
        else:
            line = line.strip()
            list_of_line = line.split(' ')
            list_of_line[:] = (value for value in list_of_line if value != '')
            solar = list_of_line[-1]
            solarlist.append(float(solar))
            if count%24 == 23:
                solarlist_list.append(solarlist[count-23:count+1])
        count +=1
    solar_file.close()
    return solarlist_list

def calc_dual_avg(get_list):
    month_list = ['January','February','March','April','May','June','July','August','September','October','November','December']
    month_length_list = [31,29,31,30,31,30,31,31,30,31,30,31]
    avg_list = []
    index = 5 #only for June
    month_length = int(month_length_list[index])
    days_before = sum(month_length_list[:index])

    hour_list = []
    for i in range(0,24):
        hour_list.append([])
    for day in get_list[days_before:days_before+month_length]:
        i = 0
        for hour in day:
            hour_list[i].append(hour)
            i +=1
    hour_list_avg = []
    for i in range(0,24):
        hour_list_avg.append(sum(hour_list[i])/24)
    return hour_list_avg

def dual_plot():
    hour_list = list(range(1,25))
    temp_avg = calc_dual_avg(get_temp_list())
    solar_avg = calc_dual_avg(get_solar_list())
    import matplotlib.pyplot as plt
    import numpy as np
    fig = plt.figure()
    ax1 = fig.add_subplot(111)
    ax1.plot(hour_list,temp_avg,'b.-')
    ax1.set_xlabel('Hour')
    ax1.set_ylabel('Average Temperature',color='b')
    ax2 = ax1.twinx()
    ax2.plot(hour_list,solar_avg,'r.-')
    ax2.set_ylabel('Average Solar Radiation',color='r')
    plt.title('Charleston MO - June 2012')
    plt.savefig('dual_plot.png')
    plt.close()
##########################################################################################################################

def main():
    bar_plot()
    dual_plot()

main_input = input("Run main function? y/n: ")
if main_input == 'y':
    main()
