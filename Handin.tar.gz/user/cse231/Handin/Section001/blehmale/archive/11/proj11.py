#CSE 231 
#Section 1 
#Project 11 
#4/15/13


import urllib.request

class Tour(object):
    def __init__(self,*cities):
        self.cities = cities
    ###################################################################################
    def __str__(self):
        cities_list = list(self.cities)
        cities_str = ' ; '.join(cities_list)
        return cities_str
    ###################################################################################
    def __repr__(self):
        return self.__str__()
    ###################################################################################
    def distance(self,mode = 'driving'):
        
        import string
        total_dist = 0
        i = 0
        if len(self.cities) <= 1:
            raise ValueError('Number of cities in Tour inappropriate for distance calculation.')
        else:
            while i <= len(self.cities)-1:
                
                origin_str = self.cities[i]
                origin_str = origin_str.replace(',','')
                origin = origin_str.replace(' ','+')

                destination_str = self.cities[i+1]
                destination_str = destination_str.replace(',','')
                destination = destination_str.replace(' ','+')
                
                my_url = "http://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&mode={}&sensor=false".format(origin,destination,mode)
                web_obj = urllib.request.urlopen(my_url) 
                results_str = str(web_obj.read())
                results_list = results_str.split('"')
                web_obj.close() 

                i = 0
                while True:
                    if results_list[i] == 'distance':
                        dist_str = results_list[i+4]
                        break
                    i +=1
                if 'km' in dist_str:
                    mult = 1000
                else:
                    mult = 1    
                distance_str = ''
                for element in dist_str:
                    if element in string.digits:
                        distance_str += element

                distance_int = int(distance_str)*mult
                total_dist += distance_int
                i +=1
        return total_dist
    ###################################################################################
    def __add__(self,tour2):
        self_list = list(self.cities)
        tour2_list = list(tour2.cities)
        for city in tour2_list:
            self_list.append(city)
        new_tour = Tour(*self_list)
        return new_tour
    ###################################################################################
    def __mul__(self,mult):
        if type(mult) != int:
            raise TypeError('Type should be integer.')
        elif mult < 0:
            raise ValueError('Value should be non-negative.')
        else:
            mul_tour = self
            count = 1
            while count < mult:
                mul_tour = self.__add__(mul_tour)
                count+=1
            return mul_tour
    ###################################################################################
    def __rmul__(self,mult):
        if type(mult) != int:
            raise TypeError('Type should be integer.')
        elif mult < 0:
            raise ValueError('Value should be non-negative')
        else:
            mul_tour = self
            count = 1
            while count < mult:
                mul_tour = self.__add__(mul_tour)
                count+=1
            return mul_tour
    ###################################################################################
    def __gt__(self,tour2):
        if self.distance() > tour2.distance():
            gt_bool = True
        else:
            gt_bool = False
        return gt_bool
    ###################################################################################
    def __lt__(self,tour2):
        if self.distance() < tour2.distance():
            lt_bool = True
        else:
            lt_bool = False
        return lt_bool
    ###################################################################################
    def __eq__(self,tour2):
        if str(self.cities) == str(tour2.cities):
            eq_bool = True
        else:
            eq_bool = False
        return eq_bool
    ###################################################################################
    

def main():
    t1 = Tour("East Lansing, MI","Seattle, WA","Sioux Falls, SD")
    t2 = Tour("Pittsburgh, PA","Atlanta, GA")
    t3 = Tour("Harrison Township, MI","Grand Ledge, MI")
    t5 = Tour("New York, NY")

    print("t1: {}\nt2: {}\nt3: {}".format(t1,t2,t3))
    print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000),round(t1.distance('bicycling')/1000),round(t1.distance('walking')/1000)))
    print("Driving distances used from here on forward.")
    print("t4 = t1 + t2")
    t4 = t1+t2
    print("t4: {}".format(t4))
    print("t4 driving distance: {} km".format(round(t4.distance()/1000)))
    print("t4 == t1 + t2:",t4==t1+t2)
    print("t1 > t2",t1>t2)
    print("t2 < t1",t2<t1)
    print("t3 is distance to Ross's house from mine: {} km".format(round(t3.distance()/1000)))
    print("Round trip to Ross's house: {} km".format(round((2*t3.distance())/1000)))
    print("I forgot something, have to go back: {} km".format(round((t3.distance()*3)/1000)))
    print("t5: {}, only contains one city, and therefore no distance can be found".format(t5))
    t5.distance()
    
          
    

    
