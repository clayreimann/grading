#CSE 231 Section 1
#1/21/13
#Project 2
########################################################################

#   Input values for SLAYER
print("Enter a six-digit number, where each digit represents the",\
      " corresponding letter in SLAYER, that supports the following",\
      " equation as true:")
print(" ")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print(" ")

SLAYER_STR = input("Your guess for SLAYER: ")
print(" ")

SLAYER_INT = int(SLAYER_STR)

#   Define each letter as its corresponding digit
R = SLAYER_INT%10
E = (SLAYER_INT//10)%10
Y = (SLAYER_INT//100)%10
A = (SLAYER_INT//1000)%10
L = (SLAYER_INT//10000)%10
S = (SLAYER_INT//100000)%10

#   Calculate each side of the equation
LEFT_INT = 3*(SLAYER_INT)
RIGHT_INT = S+10*R+100*E+1000*Y+10000*A+100000*L

#   If statements to identify errors
if -0.001 < S < 0.001:
    print("Sorry, but you must enter a six-digit number. Please try again.")
    
elif LEFT_INT != RIGHT_INT:
    print("Sorry, but your guess is incorrect. Please try again.")
    print(" ")
    print("SLAYER + SLAYER + SLAYER = ",LEFT_INT)
    print("LAYERS = ",RIGHT_INT)
else:
    print("Correct!! Good Job!")
    print("SLAYER + SLAYER + SLAYER = ",LEFT_INT)
    print("LAYERS = ",RIGHT_INT)

print(" ")
print("Thanks for playing!")

