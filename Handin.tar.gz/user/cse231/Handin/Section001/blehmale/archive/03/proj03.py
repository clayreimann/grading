#CSE 231 Section 1
#1/28/13
#Project 3


nick_count = 25
dime_count = 25
quart_count = 25
one_count = 0
five_count = 0

nick = 5
dime = 10
quart = 25
one = 100
five = 500


print('Welcome to CSE 231 Vending Services!')
print('Stock Contains:')
print(' ',nick_count,' nickels')
print(' ',dime_count,' dimes')
print(' ',quart_count,' quarters')
print(' ',one_count,' ones')
print(' ',five_count,' fives')


while True:
    price_str = input('Enter the price of your desired purchase in the form xx.xx or input `q` to quit: ')
    if price_str =='q':
        total = nick_count*5 + dime_count*10 + quart_count*25 + one_count*100 + five_count*500
        total_dollar = int(total/100)
        total_cent = total%100
        print('Total: ',total_dollar,' dollars and ',total_cent,' cents')
        break
    if price_str.find('.') != -1 or price_str.isdigit() or price_str == 'q':
        if price_str.find('.') != -1:
            price_float = float(price_str)
            price_cents = round(price_float*100)
            if price_float < 0:
                print('Illegal Price! Input must be a non-negative multiple of 5 cents.')
                continue
            if price_cents%5 != 0:
                print('Illegal Price! Input must be a non-negative multiple of 5 cents.')
                continue
    else:
        print('Illegal Price! Input must be a non-negative multiple of 5 cents.')
        continue
        
    price_float = float(price_str)
    price_cents = round(price_float*100)
    dollar = int(price_cents/100)
    cent = price_cents%100

    quart_change = 0
    dime_change = 0
    nick_change = 0
    one_change = 0
    five_change = 0

    print('Menu for deposits:')
    print('`n` - deposit a nickel')
    print('`d` - deposit a dime')
    print('`q` - deposit a quarter')
    print('`o` - deposit a one dollar bill')
    print('`f` - deposit a five dollar bill')
    print('`c` - cancel and receive change')
    print(' ')
    while price_cents > 0:
        print('Payment due: ',dollar,' dollars and ',cent,' cents')
        deposit_str = input('Indicate your deposit: ')
        
        if deposit_str == 'n':
            price_cents = price_cents - nick
            nick_count +=1
            nick_change +=1
        elif deposit_str == 'd':
            price_cents = price_cents - dime
            dime_count +=1
            dime_change +=1
        elif deposit_str == 'q':
            price_cents = price_cents - quart
            quart_count +=1
            quart_change +=1
        elif deposit_str == 'o':
            price_cents = price_cents - one
            one_count +=1
            one_change +=1
        elif deposit_str == 'f':
            price_cents = price_cents - five
            five_count +=1
            five_change +=1
        elif deposit_str == 'c':
            change = nick_change*5 + dime_change*10 + quart_change*25 + one_change*100 + five_change*500
            if int(change/25) > 0:
                if int(change/25) < quart_count:
                    quart_change = int(change/25)
                    quart_count = quart_count - int(change/25)
                    change = change - int(change/25)*25
                else:
                    quart_change = quart_count
                    change = change - quart_count*25
                    quart_count = 0
            if change >= 10:
                if int(change/10) < dime_count:
                    dime_change = int(change/10)
                    dime_count = dime_count - int(change/10)
                    change = change - int(change/10)*10
                else:
                    dime_change = dime_count
                    change = change - dime_count*10
                    dime_count = 0
            if change >= 5:
                if int(change/5) < nick_count:
                    nick_change = int(change/5)
                    nick_count = nick_count - int(change/5)
                    change = change - int(change/5)*5
                else:
                    nick_change = nick_count
                    change = change - nick_count*5
                    nick_count = 0
            
            print('Please take your change.')
            if nick_change !=0:
                print(nick_change,' nickels')
            if dime_change !=0:
                print(dime_change,' dimes')
            if quart_change !=0:
                print(quart_change,' quarters')           
            if change != 0:
                dollar = int(change/100)
                cent = change%100
                print('Machine is out of change. See store manager for remaining refund.')
                print('Remaining Refund: ',dollar,' dollars and ',cent,' cents')
            break
        else:
            print('Illegal Selection')



        dollar = int(price_cents/100)
        cent = price_cents%100

    else:
        if price_cents == 0:
            print('No Change. Thank you for your purchase.')
        else:
            change = 0 - price_cents
            quart_change = 0
            dime_change = 0
            nick_change = 0
            if int(change/25) > 0:
                if int(change/25) < quart_count:
                    quart_change = int(change/25)
                    quart_count = quart_count - int(change/25)
                    change = change - int(change/25)*25
                else:
                    quart_change = quart_count
                    change = change - quart_count*25
                    quart_count = 0
            if change >= 10:
                if int(change/10) < dime_count:
                    dime_change = int(change/10)
                    dime_count = dime_count - int(change/10)
                    change = change - int(change/10)*10
                else:
                    dime_change = dime_count
                    change = change - dime_count*10
                    dime_count = 0
            if change >= 5:
                if int(change/5) < nick_count:
                    nick_change = int(change/5)
                    nick_count = nick_count - int(change/5)
                    change = change - int(change/5)*5
                else:
                    nick_change = nick_count
                    change = change - nick_count*5
                    nick_count = 0
                                    
            print('Please take your change.')
            if nick_change !=0:
                print(nick_change,' nickels')
            if dime_change !=0:
                print(dime_change,' dimes')
            if quart_change !=0:
                print(quart_change,' quarters')           
            if change != 0:
                dollar = int(change/100)
                cent = change%100
                print('Machine is out of change. See store manager for remaining refund.')
                print('Remaining Refund: ',dollar,' dollars and ',cent,' cents')

        print('Stock Contains:')
        print(' ',nick_count,' nickels')
        print(' ',dime_count,' dimes')
        print(' ',quart_count,' quarters')
        print(' ',one_count,' ones')
        print(' ',five_count,' fives')

        
