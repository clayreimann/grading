#CSE 231
#Section 1
#Project 05
#2/11/13



def get_color_choice():

    print('Choices for colors are:')
    print('maroon')
    print('orange')
    print('yellow')
    print('green')
    print('blue')
    print('purple')
    print('pink')
    print('black')
    print()
    #Defines the color string
    while True:
        color_str = input('Please choose a color: ')
        if color_str=='maroon':
            break
        if color_str=='orange':
            color_str = 'DarkOrange'
            break
        if color_str=='yellow':
            color_str = 'light goldenrod yellow'
            break
        if color_str=='green':
            color_str = 'ForestGreen'
            break
        if color_str=='blue':
            color_str = 'light steel blue'
            break
        if color_str=='purple':
            color_str = 'MediumOrchid3'
            break
        if color_str=='pink':
            color_str = 'MistyRose'
            break
        if color_str=='black':
            break
        print()
        print("'",color_str,"'"," is not a valid choice.")
        print()

    return color_str


def get_num_hexagons():
    #Tests for integer between 4 and 20
    while True:
        num_str = input('Please enter a number of hexagons per row: ')
        if num_str.isdigit():
            num_float = float(num_str)
            if num_float%1 == 0:
                num_int = int(num_float)
                if 4 <= num_int <= 20:
                    break
        print()
        print('Your number should be an integer between 4 and 20.')
        print()

    return num_int


def draw_hexagon(color1_str,color2_str,number,pen,math_f,time_f):

    #Defines distances and coordinates
    s_float = (250/number)/math_f.cos(math_f.pi/6)
    d_float = 500/number
    x = -250+250/number
    y = 250-d_float/2+s_float/2
    #Starts turtle
    pen.speed(10)
    pen.color(color1_str)
    print("Look for the Python Turtle Graphics window")
    print("Position it and the Python Shell window side by side.")
    input("Then press `Enter' to continue ...")
    pen.up()
    pen.goto(x,y)
    pen.down()
    pen.right(30)
    
    cnt = 1
    #Sets count for number of rows
    while cnt <= num_int:
        
        count = 1
        #Sets count for number of columns
        while count <= num_int:
            #Selects color
            if count%2 != 0:
                pen.color(color1_str)
            else:
                pen.color(color2_str)
            #Draws top part of hexagon
            pen.begin_fill()
            pen.left(60)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)
            pen.end_fill()

            count +=1

        pen.left(120)

        count = 1
        #Sets count for number of columns
        while count <= num_int:
            #Selects color
            if count%2 != 0:
                if num_int%2 == 0:
                    pen.color(color2_str)
                else:
                    pen.color(color1_str)
            else:
                if num_int%2 == 0:
                    pen.color(color1_str)
                else:
                    pen.color(color2_str)
            #Draws bottom part of hexagon
            pen.begin_fill()
            pen.backward(s_float)
            pen.left(120)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)
            pen.end_fill()

            count +=1

        #Moves turtle to next row
        if cnt%2 != 0:
            x = x - d_float/2
        else:
            x = x + d_float/2
            
        y = y - s_float - s_float*math_f.sin(math_f.pi/6)
        
        cnt +=1

        pen.up()
        pen.goto(x,y)
        pen.down()
        pen.right(120)
    ##########################################################
    #Outlines each hexagon
    x = -250+250/num_int
    y = 250-d_float/2+s_float/2


    pen.color('dark slate gray')
    pen.up()
    pen.goto(x,y)
    pen.down()


    cnt = 1

    while cnt <= num_int:
        
        count = 1

        while count <= num_int:
            pen.left(60)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)

            count +=1

        pen.left(120)

        count = 1

        while count <= num_int:
            pen.backward(s_float)
            pen.left(120)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)
            pen.right(60)
            pen.forward(s_float)

            count +=1

        if cnt%2 != 0:
            x = x - d_float/2
        else:
            x = x + d_float/2
            
        y = y - s_float - s_float*math_f.sin(math_f.pi/6)
        
        cnt +=1

        pen.up()
        pen.goto(x,y)
        pen.down()
        pen.right(120)


        
    pen.hideturtle()
    time_f.sleep(5)
    pen.bye()



import turtle
import math
import time
#Starts functions
color1 = get_color_choice()
color2 = get_color_choice()
num_int = get_num_hexagons()
draw_hexagon(color1,color2,num_int,turtle,math,time)
    
