#CSE 231
#Section 1
#Project 08
#3/18/13



def fill_completions(c_dict,file_obj):
    
    import string
    word_set = set()

    for line in file_obj:
        line = line.strip()
        word_list = line.split()
        for word in word_list:
            word = word.strip(string.punctuation)
            word = word.lower()
            word_set.add(word)
             
            i = 0
            for char in word:
                if (i,char) in c_dict:
                    c_dict[(i,char)].add(word)
                else:
                    c_dict[(i,char)] = {word}
                i +=1
###########################################################

def find_completions(prefix,c_dict):

    if (0,prefix[0]) in c_dict:
        my_set = c_dict[0,prefix[0]]
    else:
        my_set = set()
    
    if len(prefix) > 1:
        i = 1
        for char in prefix[1:]:
            if (i,char) in c_dict:
                my_set = my_set & c_dict[(i,char)]
            else:
                my_set = set()
                break
            i+=1            

    return my_set
###########################################################

def main():

    file_obj = open('ap_docs.txt','r')
    my_dict = {}
    prefix_bool = True
    
    fill_completions(my_dict,file_obj)

    while prefix_bool:
        print()
        prefix = input("Give Prefix (or '#' to quit): ")
        print()
        if prefix == '#':
            prefix_bool = False
        else:
            prefix_words = find_completions(prefix,my_dict)

            if prefix_words == set():
                print('The prefix, {}, has no completions in ap_docs.txt.'.format(prefix))
            else:
                print('Words matching the prefix, {}:'.format(prefix))
                print(prefix_words)

    print('I hope you found what you were looking for!')


    
    
