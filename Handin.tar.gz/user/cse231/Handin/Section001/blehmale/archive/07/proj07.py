#CSE 231
#Section 1
#Project 07
#3/11/13

#Scrambles a single word
def scramble_word(word_str):
    import random
    import string

    word_list = list(word_str)
    punc_list = []
    punc_index_list = []
    count = 0
    for i in range(len(word_str)):
        if word_str[i] in string.punctuation:
            punc_list.append(word_str[i])#Makes a list of the punctuation marks in the word
            punc_index_list.append(i)#Makes a list of the indices of the punctuation marks
            word_list.pop(i-count)#Removes punctuatino marks from word list
            count +=1
    #If less 4, word stays the same
    if len(word_list) <= 3:
        word_scramble = word_str
    #If larger, word is scrambled
    else:
        first = word_list.pop(0)
        last = word_list.pop()
        random.shuffle(word_list)
        word_list.insert(0,first)
        word_list.append(last)
        #Inserts punctutation marks back in
        for j in range(len(punc_list)):
            word_list.insert(punc_index_list[j],punc_list[j])
        word_scramble = ''.join(word_list)

    return word_scramble
#####################################################################

#Scrambles a line using scramble_word
def scramble_line(line_str):
    line_str = line_str.strip()
    line_list = line_str.split(' ')
    list_scramble = []
    #Scrambles each word, and then joins words back together with a space
    for word in line_list:
        word_scramble = scramble_word(word)
        list_scramble.append(word_scramble)
    line_scramble = ' '.join(list_scramble)
    return line_scramble
#####################################################################

#Repeatedly prompts for file name until valid one is typed
def open_read_file(file_name_str):
    file_bool = True
    while file_bool:
        try:
            file_obj = open(file_name_str,'r')
            file_bool = False
        except IOError: #For Python 3.2 ==> IOError - For 3.3 ==> FileNotFoundError
            file_name_str = input('Bad file name. Please try again: ')
    return file_obj
#####################################################################

#Main function
def main():
    file_str = input('File Name: ')
    file_read = open_read_file(file_str)
    file_write = open('proj07.txt','w')
    #Scrambles each line, and then writes each line to new file
    for line in file_read:
        line_scramble = scramble_line(line)
        file_write.write(line_scramble + '\n')
    file_read.close()
    file_write.close()
####################################################################


main()
