# cse 231-001H
# siviakat
# proj08.py
# due Mar. 18, 2013
############################

# 2 functions:
    # 1) fill_completions(c_dict, fd) (return none) reads through provided document and adds words to the dictionary
        # open ap_docs for reading
        # {index, "letter": word}
        # strip of punc, all lowercase
    # 2) find_completions(prefix, c_dict) (return string) takes prefix (key) and finds associated value
        # print off values that match key
        # return empty set if no matches
# ignore numbers, one-letter words
# loop for prefix, '#' to quit
# KEYS CANNOT HOLD MULTIPLE VALUES.  DAMMIT.

#############################

# note: 'discovered' at about 11 am this morning that fill_completions was completely wrong.
    # had to rewrite most of it from scratch instead of figuring out/troubleshooting find_completions.
# as of 11:45 pm, program will not run. at all. probably that damned syntax error that I can't seem to get rid of. I'm calling it quits.
# probably wouldn't work anyway, so no great loss. also, keys are backwards.

##############################

print("start")

import string

def open_read_file(readfile):
    global readfile_obj
    "opens ap_docs.txt for reading"
    readfile_obj = open(readfile, "r")
    return readfile_obj

def fill_completions():
    global c_dict
    c_dict = {}
    for line in readfile_obj:
        line = line.strip()
        line = line.split()
        key_set = set()
        tempword_set = set()
        for word in line:
            if word.isalpha():
                word = word.lower()
                word = word.strip(string.punctuation)
                index = 0
                for letter in word:
                    key_set.add((letter, index))
                    index += 1
                tempword_set.add(word)
    key_list = list(key_set)
    tempword_list = list(tempword_set)
    for key in key_list:
        word_set = set()
        for word in tempword_list:
            index = 0
            for letter in word:
                if (letter, index) == key:
                    word_set.add(word)
                index += 1
        c_dict(key) = word_set # gives syntax error "can't assign to function call"




def find_completions(prefix_str, c_dict):
    result_list = []
    prefix_str = input("Enter a prefix to be matched or ented '#' to quit: ")
    prefix_str = prefix_str.strip()
    if (not prefix_str.isalpha() and prefix_set != "#" ):
        print("Cannot process the entered prefix.")
        prefix_str = input("Enter a prefix to be matched or '#' to quit: ")
        continue
    elif prefix_set == '#':
        print("Goodbye.")
        break
    else:
        prefix_str = prefix_str.lower()
        prefix_list = list(prefix_str)
        index = 0
        index_list = []
        for letter in prefix_list:
            index_list.append((letter, index))
            index += 1
        for item in index_list:
           index = 0
           for key,value in c_dict.items():
               if key == item:
                   result_list += [value]
                # ...and something else goes here. the code's broken anyway.
               else: 
                   continue

        
        
open_read_file('ap_docs.txt')

fill_completions()
print("here's your dictionary: ")
print(c_dict)
find_completions(prefix_str, c_dict)
    



