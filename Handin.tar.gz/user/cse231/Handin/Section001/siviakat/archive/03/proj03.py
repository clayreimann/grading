# siviakat
# cse231-001
# proj03.py
# due 1.28.13
####################################
#
# Prompt for price input or q
#     check if q
#         break
#     check elif price // .05
#         prompt # quarters, nickels, dimes
#         give change (use minigreed?)
#         print new coin amounts
#         continue
#     else
#         invalid input
#         continue
#
####################################
#
# Still not sure how to check for letters with string containing decimals.  Is there some form of is-not?
# For some reason will not print transaction complete message(s); does not print final stock list or coin dispensed list. Stops after dispensing coins.
# The entire sequence does not loop.  Ends after coins are dispensed.  Misalignment somewhere.
# Does not automatically switch to dispensing loop after overpayment.  Does seem to go to that loop when another entry entered after overpayment.


stock05 = 25
stock10 = 25
stock25 = 25
stock100 = 0
stock500 = 0
countini = 0
count05 = 0
count10 = 0
count25 = 0
count100 = 0
count500 = 0

print("Welcome to the Vending Machine Change Maker.")
print()
print("This machine contains:")
print()
print(stock05,"..... Nickels")
print(stock10,"..... Dimes")
print(stock25,"..... Quarters")
print(stock100,"..... One dollar bills")
print(stock500,"..... Five dollar bills")
print()
purchase_str = input("Enter your purchase price (in format xx.xx), enter 'quit' to quit, or enter 's' to see the current stock of coins: ")
while True:
    if purchase_str == "q" or purchase_str == "Q" or purchase_str == "quit" or purchase_str == "Quit" or purchase_str == "QUIT":
        print("Thank you for using the Vending Machine Change Maker.")
        print("Have a nice day!")
        break
    elif purchase_str == "s":
        print("The Vending Machine Change Maker currently contains:")
        print()
        print(stock05,"..... Nickels")
        print(stock10,"..... Dimes")
        print(stock25,"..... Quarters")
        print(stock100,"..... One dollar bills")
        print(stock500,"..... Five dollar bills")
        print()
        purchase_str = input("Enter your purchase price (in format xx.xx), enter 'quit' to quit, or enter 's' to see the current stock of coins: ")
        continue
    elif purchase_str.isalpha():
        print("Invalid input.")
        purchase_str = input("Enter your purchase price (in format xx.xx), enter 'quit' to quit, or enter 's' to see the current stock of coins: ")
        continue
    purchase_int = int(float(purchase_str)*100)
    if purchase_int < 0:
        print("Invalid input. Purchase amount must be a positive number.")
        purchase_str = input("Enter your purchase price (in format xx.xx), enter 'quit' to quit, or enter 's' to see the current stock of coins: ")
        continue
    elif purchase_int % 5 != 0:
        print("The Vending Machine Change Maker cannot process your request.")
        print("The Vending Machine Change Maker can only process purchases payable in nickels ($0.05).")
        purchase_str = input("Enter your purchase price (in format xx.xx), enter 'quit' to quit, or enter 's' to see the current stock of coins: ")
        continue
    else:
        print("How would you like to enter your purchase?")
        print()
        print("Press 'n' to enter a nickel ($0.05)")
        print("Press 'd' to enter a dime ($0.10)")
        print("Press 'q' to enter a quarter ($0.25)")
        print("Press 'o' to enter a one dollar bill ($1.00)")
        print("Press 'f' to enter a five dollar bill ($5.00)")
        print("Press 's' to see what coins are in stock.")
        print("Press 'c' to cancel your purchase.")
        print()
        payment_str = input("Please chose from one of the options above: ")
        while True:
            if payment_str.isdigit():
                print("Invalid input.")
                payment_str = input("Please chose from one of the options above: ")
                continue
            elif payment_str == 'c':
                print("Thank you for chosing the Vending Machine Change Maker.")
                print("We hope to see you again!")
                break
            elif payment_str == "s":
                print("The Vending Machine Change Maker currently contains:")
                print()
                print(stock05,"..... Nickels")
                print(stock10,"..... Dimes")
                print(stock25,"..... Quarters")
                print(stock100,"..... One dollar bills")
                print(stock500,"..... Five dollar bills")
                print()
                payment_str = input("Please chose from one of the options above: ")
                continue
            else:
                while True:
                    while purchase_int > 0:
                        if payment_str == 'n':
                            purchase_int = purchase_int - 5
                            stock05 += 1
                            print("You owe $", purchase_int/100)
                            payment_str = input("Please chose from one of the options above: ")
                            continue
                        elif payment_str == 'd':
                            purchase_int = purchase_int - 10
                            print("You owe $", purchase_int/100)
                            stock10 += 1
                            payment_str = input("Please chose from one of the options above: ")
                            continue
                        elif payment_str == 'q':
                            purchase_int = purchase_int - 25
                            stock25 += 1
                            print("You owe $", purchase_int/100)
                            payment_str = input("Please chose from one of the options above: ")
                            continue
                        elif payment_str == 'o':
                            purchase_int = purchase_int - 100
                            print("You owe $", purchase_int/100)
                            stock100 += 1
                            payment_str = input("Please chose from one of the options above: ")
                            continue
                        elif payment_str == 'f':
                            purchase_int = purchase_int - 500
                            stock500 += 1
                            print("You owe $", purchase_int/100)
                            payment_str = input("Please chose from one of the options above: ")
                            continue
                        elif payment_str == 's':
                            print("The Vending Machine Change Maker currently contains:")
                            print()
                            print(stock05,"..... Nickels")
                            print(stock10,"..... Dimes")
                            print(stock25,"..... Quarters")
                            print(stock100,"..... One dollar bills")
                            print(stock500,"..... Five dollar bills")
                            print()
                            payment_str = input("Please chose from one of the options above: ")
                    while purchase_int < 0:
                        print("You seem to have overpaid.")
                        print("The Vending Machine Change Maker will now dispense your change.")
                        if stock500 > 0 and purchase_int % 500 == 0:
                            purchase_int = purchase_int + 500
                            stock500 = stock500 - 1
                            count500 = countini+1
                            print("The Vending Machine Change Maker has dispensed",count500,"fives.")
                            continue
                        elif stock100 > 0 and purchase_int % 100 == 0:
                            purchase_int = purchase_int + 100
                            stock100 = stock100 - 1
                            count100 = countini+1
                            print("The Vending Machine Change Maker has dispensed",count100,"ones.")
                            continue
                        elif stock25 > 0 and purchase_int % 25 == 0:
                            purchase_int = purchase_int + 25
                            stock25 = stock25 - 1
                            count25 = countini+1
                            print("The Vending Machine Change Maker has dispensed", count25, "quarters.")
                            continue
                        elif stock10 > 0 and purchase_int % 10 == 0:
                            purchase_int = purchase_int + 10
                            stock10 = stock10 - 1
                            count10 = countini+1
                            print("The Vending Machine Change Maker has dispensed", count10,"dimes.")
                            continue
                        elif stock05 > 0 and purchase_int %5 == 0:
                            purchase_int = purchase_int + 5
                            stock05 = stock05 -1
                            count05 = countini + 1
                            print("The Vending Machine Change Maker has dispensed",count05,"nickels.")
                            continue
                        elif stock500 == 0 and stock100 == 0 and stock25 ==0 and stock10 == 0 and stock05 == 0:
                            print("The Vending Machine Change Maker does not have sufficient change to complete your transaction.")
                            print("We apologize for the inconvenience.")
                            print("Have a nice day!")
                            break
                        else:
                            print("Your transaction was completed successfully.")
                            print("The Vending Machine Change Maker has dispensed the following coins:")
                            print()
                            print(count05,"..... Nickels")
                            print(count10,"..... Dimes")
                            print(count25,"..... Quarters")
                            print(count100,"..... One dollar bills")
                            print(count500,"..... Five dollar bills")
                            print()
                            print("Thank you for using the Vending Machine Change Maker.")
                            print("Have a nice day!")
                            break
        else:
            print("Your transaction was completed successfully.")
            print("The Vending Machine Change Maker now contains the following coins:")
            print()
            print(stock05,"..... Nickels")
            print(stock10,"..... Dimes")
            print(stock25,"..... Quarters")
            print(stock100,"..... One dollar bills")
            print(stock500,"..... Five dollar bills")
            print()
            print("Thank you for using the Vending Machine Change Maker.")
            print("Have a nice day!")
    
