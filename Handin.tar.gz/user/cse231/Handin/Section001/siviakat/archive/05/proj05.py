# siviakat
# cse231-001H
# proj05.py
# due Feb. 11, 2013
######################
# IMPORT TURTLE
# Prompt for color 1, color 2
    # chose from: white, navy, blue
    # other: give invalid/redo
# def draw_hexagon function
    # for side in range[0,6]...
# def get_num_hexagons for row count (4-20)
# def get_color_choice <-- do twice
# how to print in rows? how to not start at center?

##########################
# Project is incomplete.
    # there is no function get_hexagons. I've been staring at this for hours and couldn't get pattern to work properly.
        # The function-drawing test code is below.  Theoretically, it could be worked into a function.
        # Test code doesn't draw a very good 'snake pattern', but it's at least vaguely squiggly.  Or something.
        # Test code also doesn't print a square area.

def get_color_choice():
    print("Please chose from one of the color options below: ")
    print()
    print("white")
    print("blue")
    print("navy")
    print()
    color = input("Please enter your chosen color: ")
    while color != 'white' and color != 'blue' and color != 'navy':
        print("Invalid input.")
        print("Please chose from one of the options above.")
        color = input("Please enter your chosen color: ")
        continue
    return color

def get_num_hexagons():
    num_hex = int(input("Please enter the number of hexagons in a row: "))
    while num_hex <4 or num_hex >20:
        print("Invalid input.")
        print("Please input a number in the range 4-20.")
        num_hex = float(input("Please enter the number of hexagons in a row: "))
        continue
    return num_hex

##############################

color1 = get_color_choice()
color2 = get_color_choice()
hex_count = get_num_hexagons()
print("My colors are", color1, "and", color2,"and I have", hex_count,"hexagons in a row.")

#############################

##     TEST CODE     ##

##import math
##num_hex = int(input("gimme number: "))
##side_length = (125/(num_hex))/(math.cos(math.pi/6))
##hex_updown = 250/num_hex
##hex_leftright = 2*side_length
##print(num_hex)
##print(side_length)
##
##import turtle
##turtle.speed(10)
##y_pos = 250
##x_pos = -250
##hex_count = 0
##row_count = 0
##color1 = 'navy'
##color2 = 'blue'
##while row_count <= num_hex:
##    if row_count %2 == 0:
##        y_pos -= .5*hex_updown
##        x_pos = -250
##        while hex_count < num_hex:
##            turtle.up()
##            turtle.goto(x_pos,y_pos)
##            if hex_count % 2 == 0:
##                turtle.color(color1)
##                turtle.begin_fill()
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##                turtle.end_fill()
##            else:
##                turtle.color(color2)
##                turtle.begin_fill()
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##                turtle.end_fill()
##            hex_count += 1
##            x_pos += 1.5*hex_leftright
##        row_count += 1
##        hex_count = 0
##    else:
##        y_pos -=.5*hex_updown
##        x_pos = -250 + .75*hex_leftright  
##        while hex_count < num_hex:
##            turtle.up()
##            turtle.goto(x_pos,y_pos)
##            if hex_count % 2 == 0:
##                turtle.color(color2)
##                turtle.begin_fill()
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##                turtle.end_fill()
##            else:
##                turtle.color(color1)
##                turtle.begin_fill()
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##                turtle.end_fill()
##            hex_count += 1
##            x_pos += 1.5*hex_leftright
##        row_count += 1
##        hex_count = 0
##    
####################
##row_count = 0
##x_pos = -250
##y_pos = 250
##while row_count <= 2.5*num_hex:
##    if row_count %2 == 0:
##        y_pos -= .5*hex_updown
##        x_pos = -250
##        while hex_count < num_hex:
##            turtle.up()
##            turtle.goto(x_pos,y_pos)
##            if hex_count % 2 == 0:
##                turtle.color('white')
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##            else:
##                turtle.color('white')
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##            hex_count += 1
##            x_pos += 1.5*hex_leftright
##        row_count += 1
##        hex_count = 0
##    else:
##        y_pos -=.5*hex_updown
##        x_pos = -250 + .75*hex_leftright  
##        while hex_count < num_hex:
##            turtle.up()
##            turtle.goto(x_pos,y_pos)
##            if hex_count % 2 == 0:
##                turtle.color('white')
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##            else:
##                turtle.color('white')
##                for side in range(6):
##                    turtle.down()
##                    turtle.right(60)
##                    turtle.forward(side_length)
##                    turtle.up()
##            hex_count += 1
##            x_pos += 1.5*hex_leftright
##        row_count += 1
##        hex_count = 0
   


        
    
