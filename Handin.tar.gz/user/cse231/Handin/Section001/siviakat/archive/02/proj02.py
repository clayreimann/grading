# proj02.py
# Kathryn Sivia
# CSE231-001H
# due Jan.21 2013

#################

# Determine whether a given number sequence SLAYER + SLAYER + SLAYER is equal to sequence LAYERS.
# Process
    # Input a slayer_str
    # Convert slayer_str to slayer_float, slayer_int
    # Check slayer_int is positive
    # Check slayer_float is an integer
    # Check slayer_int is nonzero
    # Check slayer_str is six digits
    # Isolate values of slayer_int
    # Isolate values of layers_int
    # Add individual values of layers_int to make layers_int
    # Check if 3*slayer_int == layers_int
    # Else 3*slayer_int =/= layers_int
    # Print result as necessary
# Does not work with letter input. Not sure how to differentiate between letters and numbers in code.
# Workable number: 142857 (from project page)

print("Please input a guess for a six-digit integer SLAYER such that", \
      "the following equation is true, where each letter stands for", \
      "a single digit in the position shown:")
print()
print("SLAYER + SLAYER + SLAYER = LAYERS")
print()
slayer_str=input("Please enter your guess for SLAYER:")
slayer_float=float(slayer_str)
slayer_int=int(slayer_float)
if slayer_int < 0:
    print("I think it'd work better with a POSITIVE integer...")
    print("Restart and try again.")
elif slayer_float % 1 != 0:
    print("You need to enter a six-digit INTEGER.")
    print("Restart and try again.")
elif slayer_float == 0:
    print("You're trying to cheat, aren't you?")
    print("Go play a different game.")
elif len(slayer_str) != 6:
    print("You needed to enter a SIX-DIGIT integer.")
    print("Restart and try again.")
else:
    slayer_r_int = slayer_int%10
    slayer_e_int = (slayer_int//10) % 10
    slayer_y_int = (slayer_int//100) % 10
    slayer_a_int = (slayer_int//1000) % 10
    slayer_l_int = (slayer_int//10000) % 10
    slayer_s_int = (slayer_int//100000) % 10

    layers_l_int = slayer_l_int*100000
    layers_a_int = slayer_a_int*10000
    layers_y_int = slayer_y_int*1000
    layers_e_int = slayer_e_int*100
    layers_r_int = slayer_r_int*10
    layers_s_int = slayer_s_int
    layers_int = layers_l_int + layers_a_int + layers_y_int \
                 + layers_e_int + layers_r_int + layers_s_int

    if 3*slayer_int == layers_int:
        print("SLAYER + SLAYER + SLAYER =", (3*slayer_int))
        print("LAYERS =",layers_int)
        print(layers_int,"=",3*slayer_int)
        print("CONGRATULATIONS!")
        print("Your guess was correct.")
        print("Thanks for playing.")
    else:
        print("SLAYER + SLAYER + SLAYER =", 3*slayer_int)
        print("LAYERS =", layers_int)
        print(layers_int, "=/=", 3*slayer_int)
        print("SORRY!")
        print("Your guess was incorrect.")
        print("Better luck next time.")

# Why can't I use strings again? That takes 2 lines instead of 13. And is much more readable.
    # layers_str=slayer_str[1:6]+slayer_str[:1]
    # layers_int=int(layers_str)

