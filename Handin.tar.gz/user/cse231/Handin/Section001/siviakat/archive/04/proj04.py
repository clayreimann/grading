## siviakat
## cse231-001H
## proj04.py
## due feb.4 2013
##
###########
##
## matching strings
## input two strings (str1, str2)
##    be able to add/delete indel (-) to each
##    score matching
##    do NOT need to replace indel with letters!!!
##    possible print strings to check visually?
##    offer quit option
##
###########
## All items are strings unless marked otherwise.
## Does not replace individual indels, replaces all of them (Could be fixed, but I'm too lazy to fix a non-required operation)
## Once an indel has been replaced, the replacement cannot be deleted (strings can be restored to original values, however)
## Does not preserve original capitalization after scoring.
## Auto-added indels are kept after scoring; can be deleted or strings restored, however
## If an indel is added at an index outside length of string, indel is added to end of string.
## Program does not recognize negative indels; .isalpha() check reads the '-' as a letter and considers it an invalid response
    ## .isalpha() check cannot be moved, or letters will hit the int command and stop the program
## Actions marked with ##### were requried for the project. Others are experimental and can be ignored.

string1original = input("Please enter your first string: ")
string2original = input("Please enter your second string: ")
string1 = string1original
string2 = string2original
string1match = ''
string2match = ''
matchcount_int = 0
mismatchcount_int = 0
index_int = 0
print()
print("Please chose from one of the following options:")
print()
print("a ..... add indel")
print("d ..... delete indel")
print("r ..... replace indel")      # Test to see if I could get it to work
print("s ..... score similarity")
print("p ..... print strings")      # Test to see if I could get it to work
print("t ..... restore string")     # Test to see if I could get it to work
print("q ..... quit")
print()
action = input("What would you like to do? ")

while True:
    if action == 'q': #####
        print("Goodbye.")
        break
    elif action == 'p':
        print(string1)
        print(string2)
        action = input("What would you like to do? ")
        continue
    elif action == 't':
        stringchoice = input("What string would you like to restore? ")
        if stringchoice == '1':
            string1 = string1original
            print("The first string is now:", string1)
        elif stringchoice == '2':
            string2 = string2original
            print("The second string is now:", string2)
        else:
            print("Invalid input.")
            print("Please select a string to edit (1 or 2).")
            continue            
        action = input("What would you like to do? ")
        continue
    elif action == 'a': #####
        stringchoice = input("What string would you like to edit? ")
        if stringchoice == '1':
            addindel = input("Where would you like to add an indel? ")
            if addindel.isalpha():
                print("Invalid input.")
                print("Please select an index location.")
                continue
            addindel_int = int(addindel)
            string1 = string1[:addindel_int] + '-' + string1[addindel_int:]
            print("The first string is now:", string1)
        elif stringchoice == '2':
            addindel = input("Where would you like to add an indel? ")
            if addindel.isalpha():
                print("Invalid input.")
                print("Please select an index location.")
                continue
            addindel_int = int(addindel)
            string2 = string2[:addindel_int] + '-' + string2[addindel_int:]
            print("The second string is now:", string2)
        else:
            print("Invalid input.")
            print("Please select a string to edit (1 or 2).")
            continue
        action = input("What would you like to do? ")
        continue
    elif action == 'd':
        stringchoice = input("What string would you like to edit? ")
        if stringchoice == '1':
            deleteindel = input("Where would you like to delete an indel? ")
            if deleteindel.isalpha():
                print("Invalid input")
                print("Please select an index location.")
                continue
            deleteindel_int = int(deleteindel)
            if deleteindel_int>len(string1):
                print("That index is outside the string.")
                print("Please select an indel within the range 0 to", len(string1)-1)
                continue
            elif string1[deleteindel_int] != '-':
                print("That item is not an indel.")
                print("Please select an indel to delete.")
                continue
            string1 = string1[:deleteindel_int] + string1[(deleteindel_int + 1):]
            print("The first string is now:", string1)
        elif stringchoice == '2':
            deleteindel = input("Where would you like to delete an indel? ")
            if deleteindel.isalpha():
                print("Invalid input")
                print("Please select an index location.")
                continue
            deleteindel_int = int(deleteindel)
            if deleteindel_int>len(string2):
                print("That index is outside the string.")
                print("Please select an indel within the range 0 to", len(string2)-1)
                continue
            elif string2[deleteindel_int] != '-':
                print("That item is not an indel.")
                print("Please select an indel to delete.")
                continue
            string1 = string2[:deleteindel_int] + string2[(deleteindel_int + 1):]
            print("The second string is now:", string2)
        else:
            print("Invalid input.")
            print("Please chose a string to edit (1 or 2).")
            continue
        action = input("What would you like to do? ")
        continue
    elif action == 'r':
        stringchoice = input("What string would you like to edit? ")
        if stringchoice == '1':
            replaceindel = input("What would you like to replace an indel with? ")
            string1 = string1.replace('-', replaceindel)
            print("The first string is now:", string1)
        elif stringchoice == '2':
            replaceindel = input("What would you like to replace an indel with? ")
            string2 = string2.replace('-',replaceindel)
            print("The second string is now:", string2)
        else:
            print("Invalid input.")
            print("Please select a string to edit (1 or 2).")
            continue
        action = input("What would you like to do? ")
        continue
    elif action == 's': #####
        if len(string1) != len(string2):
            print("Strings of different lengths cannot be matched.")
            print("The program will now add indels to the shorter string.")
            while len(string1) != len(string2):
                if len(string1) < len(string2):
                    string1 = string1 + '-'
                elif len(string2) < len(string1):
                    string2 = string2 + '-'
            else:
                print("Your strings are now: ", string1, "and", string2)
        string1 = string1.lower()
        string2 = string2.lower()
        for i in string1:
            if i != string2[index_int]:
                string1match = string1match + string1[index_int].upper()
                string2match = string2match + string2[index_int].upper()
                mismatchcount_int += 1
                index_int += 1
            else:
                string1match = string1match + string1[index_int].lower()
                string2match = string2match + string2[index_int].lower()
                matchcount_int += 1
                index_int += 1
        print(string1match)
        print(string2match)
        print("These statements contained", matchcount_int, "match(es) and", mismatchcount_int, "mismatch(es).")
        index_int = 0
        matchcount_int = 0
        mismatchcount_int = 0
        string1match = ''
        string2match = ''
        action = input("What would you like to do? ")
        continue
    else:
        print("Invalid input.")
        print("Please chose from one of the options above.")
        action = input("What would you like to do? ")
        continue
