# siviakat
# cse231-001H
# proj10.py
# due April 8 2013

#####################

# create function main() that can:
    # read items in senegal.txt, panama.txt
    # use this to draw the respective flags
# classes:
    # class Star - draws specified star
    # class Rectangle - draws specified rectangle
    # class Flag - gets flag info
# notes:
    # turtle draws new figures ON TOP of old ones
    # star needs to be CENTERED around a given point
    # Rectangle needs to be CENTERED around a given point
    # EC for complicated Flag? Maybe USA -- got it to work
        # alternating red-white stripes
        # blue rectangle in upper corner
        # x50 small stars in upper corner

########################

# NOTES FOR INSTRUCTOR:

# The function myFlag automatically draws only 1 flag (that of Antigua & Barbuda).
    # If you would like to see the additional flags coded for, I can send an e-mail, as Handin won't accept them.
    # USA flag will print regardless, as it is not associated with a .txt file. Didn't feel like placing all those stars, or inventing a ScatterStar class.

# divided class Star into SimpleStar (using four arguments, as given in sample files - this is the Star class described in the handout)
    # and ComplexStar (which takes several additional arguments). This was done to enable drawing of 6+ point stars, such as that in myFlag.txt
    # (such as in myFlagAzerbaijan.txt and myFlagAntigua.txt)
# also included are a number of additional classes:
    # Stripes (draws a single Stripe incident instead of several Rectangle instances)
    # Triangle (draws a triangle)
    # Circle (draws a circle)
    # DavidStar (exists for myFlagIsrael.txt)
# most of the flags fit in a 600*400 box, so a black frame is drawn around them automatically (labeled 'box').
    # this is to make white parts visible. it can be ignored.
    # because the flag described in panama.txt is larger than 600*400, it does not fit in the box. the result looks a bit weird, but what the heck.
# the actual return line for flag.__str__ does not print with str(flag).  Does with print(flag), though. not sure why.

##########################################################

import turtle
import time
import math
turtle.speed(10)



class SimpleStar(object):
    def __init__(self, x_pos = 0,y_pos = 0, arm_length = 50, color = 'black'):
        '''gets specs for simple star'''
        self.x_pos= x_pos
        self.y_pos = y_pos
        self.arm_length = arm_length
        self.color = color

    def draw(self, turtle):
        '''draws simple star'''
        turtle.up()
        turtle.goto((self.x_pos + self.arm_length/4), (self.y_pos + self.arm_length/4))
        turtle.setheading(0)
        turtle.color(self.color)
        turtle.down()
        turtle.begin_fill()
        count = 0
        while count < 5:
            turtle.forward(self.arm_length)
            turtle.right(144)
            turtle.forward(self.arm_length)
            turtle.left(72)
            count += 1
        turtle.end_fill()
        turtle.up()

    def __str__(self):
        '''prints simple star specs'''
        print_str = "Simple Star x: {}, y: {}, arm length: {}, color: {}".format(self.x_pos, self.y_pos, self.arm_length, self.color)
        return print_str

##################################

class ComplexStar(object):

    def __init__(self, x_pos = 0, y_pos = 0, x_off = 4, y_off = 4, arm_length = 50, p = 5, q = 2, angle = 0,color = 'black'):
        '''gets specs for complex star'''
        # 5-point black star by default
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.x_off = x_off
        self.y_off = y_off
        self.arm_length = arm_length
        self.p = p
        self.q = q
        self.angle = angle
        self.color = color

    def draw(self, turtle):
        '''draws complex star'''
        # note: centering needs to be manually adjusted for large/non-5 stars
        out_angle = (180*(self.p - 2*self.q))/self.p
        in_angle = ((180*(self.p - 2))/self.p) - ((180*(self.p - 2*self.q))/self.p)
        turtle.up()
        turtle.goto((self.x_pos + self.arm_length/self.x_off), (self.y_pos + self.arm_length/self.y_off))
        turtle.setheading(self.angle)
        turtle.color(self.color)
        turtle.down()
        turtle.begin_fill()
        count = 0
        while count < self.p:
            turtle.forward(self.arm_length)
            turtle.right(180-out_angle)
            turtle.forward(self.arm_length)
            turtle.left(in_angle)
            count += 1
        turtle.end_fill()
        turtle.up()

    def __str__(self):
        '''prints complex star specs'''
        print_str = "Complex Star x: {}, y: {}, arm length: {}, p: {}, q: {}, color: {}".format(self.x_pos, self.y_pos, self.arm_length, self.p, self.q, self.color)
        return print_str

#####################################
        
class DavidStar(object):
    def __init__(self, x_pos = 0,y_pos = 0, arm_length = 50, pen_size = 10, color = 'blue'):
        '''gets specs for star of david'''
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.arm_length = arm_length
        self.pen_size = pen_size
        self.color = color

    def draw(self, turtle):
        '''draws star of david'''
        turtle.up()
        off = 1/6 * math.sqrt(3)*self.arm_length
        turtle.goto((self.x_pos - 2*off),(self.y_pos + off))
        turtle.color(self.color)
        turtle.pensize(self.pen_size)
        turtle.down()
        #1st triangle
        turtle.setheading(0)
        turtle.forward(self.arm_length)
        turtle.right(120)
        turtle.forward(self.arm_length)
        turtle.right(120)
        turtle.forward(self.arm_length)
        #2nd triangle
        turtle.up()
        turtle.goto((self.x_pos-2*off),(self.y_pos-off))
        turtle.down()
        turtle.setheading(180)
        turtle.right(120)
        turtle.forward(self.arm_length)
        turtle.right(120)
        turtle.forward(self.arm_length)
        turtle.right(120)
        turtle.forward(self.arm_length)
        turtle.up()

    def __str__(self):
        '''prints star of david specs'''
        print_str = "Star of David x: {}, y: {}, arm length: {}, pen size: {}, color: {}".format(self.x_pos, self.y_pos, self.arm_length, self.pen_size, self.color)
        return print_str

###################################

class Rectangle(object):

    def __init__(self, x_pos = 0, y_pos = 0, width = 100, height = 100, color = 'black'):
        '''gets specs for rectangle'''
        # 100*100 black square by default
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.height = height
        self.width = width
        self.color = color

    def draw(self, turtle):
        '''draws rectangle'''
        turtle.up()
        turtle.goto((self.x_pos - self.width/2), (self.y_pos +self.height/2))
        turtle.color(self.color)
        turtle.setheading(0)
        turtle.down()
        turtle.begin_fill()
        count = 0
        while count < 2:
            turtle.forward(self.width)
            turtle.right(90)
            turtle.forward(self.height)
            turtle.right(90)
            count += 1
        turtle.end_fill()
        turtle.up()

    def __str__(self):
        '''prints rectanglespecs'''
        print_str = "Rectangle x: {}, y: {}, width: {}, height: {}, color: {}".format(self.x_pos, self.y_pos, self.width, self.height, self.color)
        return print_str
    
#####################################

class Stripes(object):
    
    def __init__(self, x_pos = 0, y_pos = 0, width = 100, height = 100, stripe_count = 10, color1 = 'red', color2 = 'blue'):
        '''gets specs for stripes'''
        # 10 100*10 red & blue stripes by default
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.height = height
        self.width = width
        self.stripe_count = stripe_count
        self.color1 = color1
        self.color2 = color2

    def draw(self, turtle):
        '''draws stripes'''
        turtle.up()
        turtle.goto((self.x_pos - self.width/2), (self.y_pos + self.height/2))
        turtle.setheading(0)
        turtle.down()
        count = 0
        while count < self.stripe_count:
            if count %2 == 0:
                turtle.color(self.color1)
                turtle.begin_fill()
                turtle.forward(self.width) # side 1
                turtle.right(90) # turn 1
                turtle.forward(self.height/self.stripe_count) # s2
                turtle.right(90) # t2
                turtle.forward(self.width) #s3
                turtle.right(90) # t3
                turtle.forward(self.height/self.stripe_count) #s4
                turtle.right(90) #t4
                turtle.forward(self.width) # s5
                turtle.right(90) # t5
                turtle.forward(self.height/self.stripe_count) # s6
                turtle.end_fill()
                turtle.left(90)
                count += 1
            else:
                turtle.color(self.color2)
                turtle.begin_fill()
                turtle.backward(self.width) # side 1
                turtle.left(90) # turn 1
                turtle.backward(self.height/self.stripe_count) # s2
                turtle.left(90) # t2
                turtle.backward(self.width) #s3
                turtle.left(90) # t3
                turtle.backward(self.height/self.stripe_count) #s4
                turtle.left(90) #t4
                turtle.backward(self.width) # s5
                turtle.left(90) # t5
                turtle.backward(self.height/self.stripe_count) # s6
                turtle.end_fill()
                turtle.right(90)
                count += 1
        turtle.up()

    def __str__(self):
        '''prints stripes specs'''
        print_str = "Stripes x: {}, y: {}, width: {}, height: {}, stripe count: {}, color1: {} color2: {}".format(self.x_pos, self.y_pos, self.width, self.height, self.stripe_count, self.color1, self.color2)
        return print_str
        
####################################

class Triangle(object):

    def __init__(self, x1 = 0, y1 = 0, x2 = 0, y2 = 100, x3 = 100, y3 = 0, color = 'black'):
        '''gets specs for triangle'''
        # side = 100 right black triangle by default
        self.x1 = x1
        self.x2 = x2
        self.x3 = x3
        self.y1 = y1
        self.y2 = y2
        self.y3 = y3
        self.color = color

    def draw(self,turtle):
        '''draws triangle'''
        # NOTE: x1,y1 is location of FIRST CORNER
        turtle.up()
        turtle.setheading(0)
        turtle.goto(self.x1, self.y1)
        turtle.down()
        turtle.color(self.color)
        turtle.begin_fill()
        turtle.goto(self.x2,self.y2)
        turtle.goto(self.x3, self.y3)
        turtle.goto(self.x1, self.y1)
        turtle.end_fill()
        turtle.up()
        
        turtle.up()
    def __str__(self):
        '''prints triangle specs'''
        print_str = 'Triangle 1: ({},{}), 2: ({},{}), 3: ({},{}), color:{}'.format(self.x1, self.y1, self.x2,self.y2, self.x3,self.y3, self.color)
        return print_str

####################################

class Circle(object):

    def __init__(self, x_pos = 0, y_pos = 0, radius = 50, color = 'black'):
        '''gets specs for circle'''
        # draws r=50 black circle by default
        self.x_pos = x_pos
        self.y_pos = y_pos
        self.radius = radius
        self.color = color

    def draw(self, turtle):
        '''draws circle'''
        # note: starts drawing from the bottom center of the circle
        turtle.up()
        turtle.goto(self.x_pos, (self.y_pos - self.radius))
        turtle.setheading(0)
        turtle.down()
        turtle.color(self.color)
        turtle.begin_fill()
        turtle.circle(self.radius)
        turtle.end_fill()
        turtle.up()

    def __str__(self):
        '''prints circle specs'''
        print_str = 'Circle x: {}, y: {}, radius: {}, color: {}'.format(self.x_pos, self.y_pos, self.radius, self.color)
        return print_str

####################################

class Flag(object):

    def __init__(self, file_obj = ''):
        self.file_obj = file_obj

    def draw(self, file_obj):
        box = Rectangle(0,0,602,402,'black')
        box.draw(turtle)
        file_obj = open(self.file_obj,"r")
        for line in file_obj:
            line_str = line.strip()
            line_str = line_str.replace(' ','')
            line_list = line_str.split(',')
            if len(line_list) == 6:
                    star = DavidStar(float(line_list[0]), float(line_list[1]), float(line_list[2]),
                                     float(line_list[3]), str(line_list[4]))
                    star.draw(turtle)
                                     
            if len(line_list) == 5:
                if 'circle' in line_list:
                    circle = Circle(float(line_list[0]), float(line_list[1]), float(line_list[2]),
                                    str(line_list[3]))
                    circle.draw(turtle)

                else:
                    rectangle = Rectangle(float(line_list[0]), float(line_list[1]), float(line_list[2]),
                                          float(line_list[3]), str(line_list[4]))
                    rectangle.draw(turtle)

            if len(line_list) == 4:
                star = SimpleStar(float(line_list[0]), float(line_list[1]), float(line_list[2]),
                                  str(line_list[3]))
                star.draw(turtle)

            elif len(line_list) == 8:
                if 'stripes' in line_list:
                    stripes = Stripes(float(line_list[0]), float(line_list[1]), float (line_list[2]),
                                      float(line_list[3]), float(line_list[4]), str(line_list[5]),
                                      str(line_list[6]))
                    stripes.draw(turtle)
                elif 'triangle' in line_list:
                    triangle = Triangle(float(line_list[0]), float(line_list[1]), float (line_list[2]),
                                        float(line_list[3]), float(line_list[4]), float(line_list[5]),
                                        str(line_list[6]))
                    triangle.draw(turtle)

            elif len(line_list) == 9:
                star = ComplexStar(float(line_list[0]), float(line_list[1]), float(line_list[2]),
                                   float(line_list[3]), float(line_list[4]), float(line_list[5]),
                                   float(line_list[6]), float(line_list[7]), str(line_list[8]))
                star.draw(turtle)
        turtle.hideturtle()
        file_obj.close()

    def __str__(self):
        file_obj = open(self.file_obj,"r")
        for line in file_obj:
            line_str = line.strip()
            line_str = line_str.replace(' ','')
            line_list = line_str.split(',')
            if len(line_list) == 6:
                    star = DavidStar(line_list[0], line_list[1], line_list[2],
                                     line_list[3], line_list[4])
                    print(star)
                                     
            if len(line_list) == 5:
                if 'circle' in line_list:
                    circle = Circle(line_list[0], line_list[1], line_list[2],
                                    line_list[3])
                    print(circle)

                else:
                    rectangle = Rectangle(line_list[0], line_list[1], line_list[2],
                                          line_list[3], line_list[4])
                    print(rectangle)

            if len(line_list) == 4:
                star = SimpleStar(line_list[0], line_list[1],line_list[2],
                                  line_list[3])
                print(star)

            if len(line_list) == 8:
                if 'stripes' in line_list:
                    stripes = Stripes(line_list[0], line_list[1], line_list[2],
                                      line_list[3], line_list[4], line_list[5],
                                      line_list[6])
                    print(stripes)
                elif 'triangle' in line_list:
                    triangle = Triangle(line_list[0], line_list[1], line_list[2],
                                        line_list[3], line_list[4], line_list[5],
                                        line_list[6])
                    print(triangle)

            if len(line_list) == 9:
                star = ComplexStar(line_list[0], line_list[1], line_list[2],
                                   line_list[3], line_list[4], line_list[5],
                                   line_list[6], line_list[7], line_list[8])
                print(star)
        flag_str = self.file_obj
        flag_list = flag_str.split('.')                                  
        flag_name = flag_list[0]
        print_str = "The flag belongs to {}".format(flag_name)
        return print_str
            

def main():
    turtle.write("ready?")
    time.sleep(.5)
    turtle.clearscreen()
    turtle.write("go!")
    time.sleep(.5)
    turtle.clearscreen()
    flag = Flag('senegal.txt') # open senegal
    turtle.speed(10)
    str(flag)
    flag.draw(turtle)
    time.sleep(5)
    turtle.clearscreen()

    flag = Flag('panama.txt') # open panama
    turtle.speed(10)
    flag.draw(turtle)
    str(flag)
    time.sleep(5)
    turtle.clearscreen()

def myFlag():
    turtle.write("ready?")
    time.sleep(.5)
    turtle.clearscreen()
    turtle.write("go!")
    time.sleep(.5)
    turtle.clearscreen()
##    flag = Flag('myFlagRussia.txt') # open russia
##    turtle.speed(10)
##    str(flag)
##    flag.draw(turtle)
##    time.sleep(5)
##    turtle.clearscreen()
##
##    flag = Flag('myFlagAzerbaijan.txt') # open azerbaijan
##    turtle.speed(10)
##    flag.draw(turtle)
##    str(flag)
##    time.sleep(5)
##    turtle.clearscreen()
##
##    flag = Flag('myFlagIsrael.txt') # open israel
##    turtle.speed(10)
##    str(flag)
##    flag.draw(turtle)
##    time.sleep(5)
##    turtle.clearscreen()
##
##    flag = Flag('myFlagGreece.txt') # open greece
##    turtle.speed(10)
##    str(flag)
##    flag.draw(turtle)
##    flag.__str__()
##    time.sleep(5)
##    turtle.clearscreen()

    flag = Flag('myFlag.txt') # open antigua
    turtle.speed(10)
    flag.draw(turtle)
    str(flag)
    time.sleep(5)
    turtle.clearscreen()

    # start USA flag draw
    turtle.speed(10)
    box = Rectangle(0,0,602,402,'black')
    stripes = Stripes(0,0,600,400,13,'red', 'white')
    rectangle = Rectangle(-150,94,300,214,'navy blue')
    box.draw(turtle)
    stripes.draw(turtle)
    rectangle.draw(turtle)
    
    x_start = -280
    y_start = 185
    x_pos = x_start
    y_pos = y_start
    count = 0
    row_count = 0
    while count < 50:
        while row_count < 9 and row_count %2 == 0:
            x_pos = x_start
            star_count = 0
            while star_count < 6:
                star = ComplexStar(x_pos,y_pos,4,4,7,5,2,0,'white')
                star.draw(turtle)
                x_pos += 51
                star_count += 1
                count += 1
                str(star)
            y_pos -= 22
            row_count += 1
        while row_count < 9 and row_count %2 != 0:
            star_count = 0
            x_pos = x_start + 26
            while star_count < 5:
                star = ComplexStar(x_pos,y_pos,4,4,7,5,2,0,'white')
                star.draw(turtle)
                x_pos += 51
                star_count += 1
                count += 1
                str(star)
            y_pos -= 22
            row_count += 1
    turtle.hideturtle()
    time.sleep(5)
    turtle.clearscreen()

    turtle.write('thanks for watching!')
    time.sleep(.5)
    turtle.clearscreen()
    turtle.write('bye!')
    time.sleep(.5)
    turtle.bye()

######################################################

main()
myFlag()
    
    

                
            
            
        




