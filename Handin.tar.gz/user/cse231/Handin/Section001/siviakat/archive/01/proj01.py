#For some reason, shell refuses to read line breaks.  not sure why.
#There has GOT to be an easier way of printing tables.  and for doing the same calculation with multiple values.
#Entering negative value produces positive response.
#letters result in a cannot convert string to float error. this persists even after a letter is assigned a value.

tnt_convert=4.184e9
num1=input("Please enter a Richter scale measure:")
richter=float(num1)
joules=10**(1.5*richter+4.8)
tnt=joules/(tnt_convert)
print("Richter measure:", richter,)
print("Equivalence in Joules:",joules)
print("Equivalence in tons of TNT:",tnt)

richter_10=1.0
joules_10=10**(1.5*richter_10+4.8)
tnt_10=joules_10/(tnt_convert)

richter_50=5.0
joules_50=10**(1.5*richter_50+4.8)
tnt_50=joules_50/(tnt_convert)

richter_91=9.1
joules_91=10**(1.5*richter_91+4.8)
tnt_91=joules_91/(tnt_convert)

richter_92=9.2
joules_92=10**(1.5*richter_92+4.8)
tnt_92=joules_92/(tnt_convert)

richter_95=9.5
joules_95=10**(1.5*richter_95+4.8)
tnt_95=joules_95/(tnt_convert)

print("Richter measure is:","  Equivalence in Joules:","  Equivalence in tons of TNT:")
print(richter_10,"                 ",joules_10,"     ",tnt_10)
print(richter_50,"                 ",joules_50,"     ",tnt_50)
print(richter_91,"                 ",joules_91,"  ",tnt_91)
print(richter_92,"                 ",joules_92,"  ",tnt_92)
print(richter_95,"                 ",joules_95," ",tnt_95)







