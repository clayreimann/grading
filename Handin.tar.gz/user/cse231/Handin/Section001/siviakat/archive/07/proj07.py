## proj07.py
## siviakat
## cse231-001H
## due mar.11,2013

############################

## word randomizer
## keep first and last items same
## preserve punctuation! includes word. and don't.

############################

## code can only keep track of one punctuation mark in a single word (not including any at the beginning/end).
##      Since I can't think of any single word in the English language that has multiple apostrophes
##      (except wouldn't've, which MSWord says isn't a word), I don't think this will be a problem.
## also, has a tendency to treat hyphenated words (ex. hello-world) as a single word. Technically, they are. I think.
## this-is-a-test would keep the first hyphen and delete the rest.

###########################

import random
import string

def scramble_word(word_str):
    "Scrambles word"
    global final_str
    punc_str = string.punctuation
    start = 0
    end = 0
    start_str = ''
    end_str = ''
    count = 0
    puncmark_str = ''
    if len(word_str) > 3:
        for char in word_str:
            if char in punc_str:
                start_str = start_str + char
                start += 1
                continue
            else:
                start_str = start_str + char
                start += 1
                break

        reverse_str = word_str[::-1]
        for char in reverse_str:
            if char in punc_str:
                end_str = end_str + char
                end -= 1
                continue
            else:
                end_str = end_str + char
                end -= 1
                break
        end_str = end_str[::-1]
        middle_str = word_str[start:end]

        for char in middle_str:
            if char in punc_str:
                puncmark_str = char
                break
            else:
                count += 1
                continue
        middle_str = middle_str.replace(puncmark_str,'')
        middle_list = list(middle_str)
        random.shuffle(middle_list)
        midfinal_str = ''.join(middle_list)
        midfinal_str = midfinal_str[:count] + puncmark_str + midfinal_str[count:]

        final_list = [start_str,midfinal_str,end_str]
        final_str = ''.join(final_list)
    else:
        final_str = word_str
    outfile_obj.write(final_str)
    outfile_obj.write(" ")
    return

##################

def open_read_file(infile):
    "Opens file for reading, creates file for writing"
    global infile_obj
    global infile_str
    global outfile_obj
    open_file = False
    while (not open_file):
        infile_str = input("Please enter a file to be read: ")
        try:
            infile_obj = open(infile_str, "r")
            open_file = True
        except IOError:
            print("Cannot find the requested file.")
    filename = infile_str.split(".")
    outfile_obj = open(filename[0] + "_scrambled." + filename[1], "w")
    return

##########################

def scramble_line(line_str):
    "Scrambles words in a line"
    for line in infile_obj:
        line_str = line.strip()
        line_list = line_str.split()
        for word in line_list:
            word_str = str(word)
            scramble_word(word_str)
        outfile_obj.write("\n")
    return

###########################

def main():
    "Main function of the program"
    open_read_file("")
    scramble_line("")
    infile_obj.close()
    outfile_obj.close()
    print("Processing...")
    print("Scramble complete.")
    return

#########################
main()

        
    
    

