# siviakat
# cse231-001H
# proj11.py
# due Tax Day
##########################

# Calculate distance between locations using internet
# create class Tour():
    # __init__(*stop)
    # distance(driving mode)
        # driving, bicycling, walking
        # returns distance covered
        # this is where you use the web
    # __str__: returns string of destinations visited
    # __repr__: does same thing as __str__?
    # __add__: add Tours
    # __mul__ & __rmul__: do the Tour multiple times (must be nonnegative int)
    # __gt__: (greater than) compare driving distance between Tours.
        #True if first is greater, False if second is greater
    # __lt__: (less than) opposite of __gt__
    # __eq__ Compare tour distances for equality.  True if true
# create function main() that tests all that shit

# do we assume we can drive/walk/bike to any given destination? Yep (ignore water)
# don't use locations outside US. Google seems to want some weird country code shit.

# Doesn't work for any tour with more than two stops
# no function __repr__ (not sure what it is supposed to do)
# does not do the raise error thing, though at least one error message should be coded in right


##########################

import urllib.request
import string
bad_char = string.punctuation + string.ascii_letters

class Tour(object):

    def __init__(self, *stop):
        self.stop = stop

    def distance(self, drivemode = 'driving'):
        self.drivemode = drivemode
        
        stop_list = list(self.stop)
        stop_url_list = []
        for stop in stop_list:
            stop = stop.replace('.','')
            stop = stop.replace(',','')
            stop = stop.split()
            stop = '+'.join(stop)
            stop_url_list.append(stop)

        web_obj = urllib.request.urlopen("http://maps.googleapis.com/maps/api/distancematrix/json?origins={}&destinations={}&mode={}&sensor=false".format(stop_url_list[0],stop_url_list[1],self.drivemode))
        results_str = str(web_obj.read()) # gets web printout thingy.
        results_list = results_str.split()
        value_list = []
        for item in results_list:
            for char in item:
                if char in bad_char:
                    item = item.replace(char,'')
            else:
                value_list.append(item)

        value_list = list(filter(None, value_list))

        start = stop_list[0]
        end = stop_list[1]
        distance = int(value_list[1])

        return distance

    def __str__(self):
        '''prints tour list'''
        stop_list = list(self.stop)
        print_str = '{}; {}'.format(stop_list[0],stop_list[1])
        return print_str

    def __add__(self,tour2):
        distance = self.distance() + tour2.distance()
        print(distance)
        return distance

    def __mul__(self, repeat):
        try:
            distance = self.distance() * repeat
            print(distance)
            return distance
        except TypeError:
            print("Repeat must be integer.")
        except ValueError:
            print("Repeat must be nonnegative.")

    def __rmul__(self,repeat):
        return self.__mul__(repeat)


    def __gt__(self, tour2):
        if self.distance() > tour2.distance():
            print("True")
        else:
            print("False")

    def __lt__(self, tour2):
        if self.distance() < tour2.distance():
            print("True")
        else:
            print("False")

    def __eq__(self, tour2):
        if self.distance() == tour2.distance():
            print("True")
        else:
            print('False')






        

def main():
    tour1 = Tour("Boston, MA", "Honolulu, HI")
    tour2 = Tour("Anchorage, AK", "Key West, FL")

    print(tour1)
    print(tour2)
    tour1 + tour2
    tour1*2
    2*tour1
    tour1 > tour2
    tour1 < tour2
    tour1 == tour2

main()


