# siviakat
# cse231-001H
# proj12.py (honors)
# due April 22, 2013

#################################

# Notes for instructor:
# misread directions and coded for wrong temperature data (daily, instead of monthly)
    # by the time I realized this, didn't have time to go back and figure out how to grab the correct info
# pretty sure I got the correct solar_radition data, though
# the graph doesn't right; I have no idea what it's graphing. temp_max, temp_min, and temp_ave are being added somewhere. even though the printout says they're not. where.
# need to x out of graph window to go to rad printout

################################

import numpy as np
import matplotlib.pyplot as plt

print("TEMPERATURE")
file_obj = open('temperature.txt', 'r')

first_line = file_obj.readline() # gets rid of line 1 & 2
second_line = file_obj.readline()

third_line = file_obj.readline()
start = third_line.split()
start_list= []
for item in start:
    item = item.strip()
    try:
        item = int(item)
    except ValueError:
        item = float(item)
    start_list.append(item)
    
date = start_list[0:3]
print(start_list)
temp_max = start_list[4]
temp_min = start_list[4]
temp_list = [start_list[4]]


for line in file_obj:
    line = line.split()
    line_list = []
    for item in line:
        item = item.strip()
        try:
            item = int(item)
        except ValueError:
            item = float(item)
        line_list.append(item)
    if line_list[0:3] == date:
        if line_list[4] > temp_max:
            temp_max = line_list[4]
        if line_list[4] < temp_min:
            temp_min = line_list[4]
        temp_list.append(line_list[4])
        temp_ave = sum(temp_list)/len(temp_list)           
           
    else:
        print("{}: max:{}, min:{}, ave:{}".format(date,temp_max,temp_min,temp_ave))
        plt.bar(temp_ave,temp_max,bottom = temp_min)
        date = line_list[0:3]
        temp_max = line_list[4]
        temp_min = line_list[4]
        temp_list = [line_list[4]]
        continue

print("{}: max:{}, min:{}, ave:{}".format(date,temp_max,temp_min,temp_ave))
plt.bar(temp_ave,temp_max,bottom = temp_min)
plt.xlabel('foo')
plt.ylabel('bar')
plt.title("I'm not sure what's being graphed, but at least it's something \n (a.k.a. foo vs. bar)")
plt.show()


#################################

print("SOLAR RADIATION")

file_obj = open('solar_radition.txt', 'r')

first_line = file_obj.readline() # gets rid of line 1-4
second_line = file_obj.readline()
third_line = file_obj.readline()
fourth_line = file_obj.readline()
fifth_line = file_obj.readline()

start = fifth_line.split()
start_list= []
count = 1
for item in start:
    item = item.strip()
    try:
        item = int(item)
    except ValueError:
        item = float(item)
    start_list.append(item)
    
date = start_list[0:2]
rad_100 = []
rad_200 = []
rad_300 = []
rad_400 = []
rad_500 = []
rad_600 = []
rad_700 = []
rad_800 = []
rad_900 = []
rad_1000 = []
rad_1100 = []
rad_1200 = []
rad_1300 = []
rad_1400 = []
rad_1500 = []
rad_1600 = []
rad_1700 = []
rad_1800 = []
rad_1900 = []
rad_2000 = []
rad_2100 = []
rad_2200 = []
rad_2300 = []
rad_2400 = []


for line in file_obj:
    line = line.split()
    line_list = []
    for item in line:
        item = item.strip()
        try:
            item = int(item)
        except ValueError:
            item = float(item)
        line_list.append(item)
  
    if line_list[0] == 6:
        if line_list[3] == 100:
            rad_100.append(line_list[4])
        if line_list[3] == 200:
            rad_200.append(line_list[4])
        if line_list[3] == 300:
            rad_300.append(line_list[4])
        if line_list[3] == 400:
            rad_400.append(line_list[4])
        if line_list[3] == 500:
            rad_500.append(line_list[4])
        if line_list[3] == 600:
            rad_600.append(line_list[4])
        if line_list[3] == 700:
            rad_700.append(line_list[4])
        if line_list[3] == 800:
            rad_800.append(line_list[4])
        if line_list[3] == 900:
            rad_900.append(line_list[4])
        if line_list[3] == 1000:
            rad_1000.append(line_list[4])
        if line_list[3] == 1100:
            rad_1100.append(line_list[4])
        if line_list[3] == 1200:
            rad_1200.append(line_list[4])
        if line_list[3] == 1300:
            rad_1300.append(line_list[4])
        if line_list[3] == 1400:
            rad_1400.append(line_list[4])
        if line_list[3] == 1500:
            rad_1500.append(line_list[4])
        if line_list[3] == 1600:
            rad_1600.append(line_list[4])
        if line_list[3] == 1700:
            rad_1700.append(line_list[4])
        if line_list[3] == 1800:
            rad_1800.append(line_list[4])
        if line_list[3] == 1900:
            rad_1900.append(line_list[4])
        if line_list[3] == 2000:
            rad_2000.append(line_list[4])
        if line_list[3] == 2100:
            rad_2100.append(line_list[4])
        if line_list[3] == 2200:
            rad_2200.append(line_list[4])
        if line_list[3] == 2300:
            rad_2300.append(line_list[4])
        if line_list[3] == 2400:
            rad_2400.append(line_list[4])
    else:
        continue

rad_100_ave = sum(rad_100)/30
rad_200_ave = sum(rad_200)/30
rad_300_ave = sum(rad_300)/30
rad_400_ave = sum(rad_400)/30
rad_500_ave = sum(rad_500)/30
rad_600_ave = sum(rad_600)/30
rad_700_ave = sum(rad_700)/30
rad_800_ave = sum(rad_800)/30
rad_900_ave = sum(rad_900)/30
rad_1000_ave = sum(rad_1000)/30
rad_1100_ave = sum(rad_1100)/30
rad_1200_ave = sum(rad_1200)/30
rad_1300_ave = sum(rad_1300)/30
rad_1400_ave = sum(rad_1400)/30
rad_1500_ave = sum(rad_1500)/30
rad_1600_ave = sum(rad_1600)/30
rad_1700_ave = sum(rad_1700)/30
rad_1800_ave = sum(rad_1800)/30
rad_1900_ave = sum(rad_1900)/30
rad_2000_ave = sum(rad_2000)/30
rad_2100_ave = sum(rad_2100)/30
rad_2200_ave = sum(rad_2200)/30
rad_2300_ave = sum(rad_2300)/30
rad_2400_ave = sum(rad_2400)/30

print("100: {}".format(rad_100_ave))
print("200: {}".format(rad_200_ave))
print("300: {}".format(rad_300_ave))
print("400: {}".format(rad_400_ave))
print("500: {}".format(rad_500_ave))
print("600: {}".format(rad_600_ave))
print("700: {}".format(rad_700_ave))
print("800: {}".format(rad_800_ave))
print("900: {}".format(rad_900_ave))
print("1000: {}".format(rad_1000_ave))
print("1100: {}".format(rad_1100_ave))
print("1200: {}".format(rad_1200_ave))
print("1300: {}".format(rad_1300_ave))
print("1400: {}".format(rad_1400_ave))
print("1500: {}".format(rad_1500_ave))
print("1600: {}".format(rad_1600_ave))
print("1700: {}".format(rad_1700_ave))
print("1800: {}".format(rad_1800_ave))
print("1900: {}".format(rad_1900_ave))
print("2000: {}".format(rad_2000_ave))
print("2100: {}".format(rad_2100_ave))
print("2200: {}".format(rad_2200_ave))
print("2300: {}".format(rad_2300_ave))
print("2400: {}".format(rad_2400_ave))




