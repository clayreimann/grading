# Project 4
# CSE 231H Section 1
# This program will be more practice messing with if statements loops
# and strings

# prompt for the 2 strings 
first_str = input("String 1: ")
second_str = input("String 2: ")

# print out the menu
print("What do you want to do:", '\n', "a (add indel)" \
                   '\n', "d (delete indel)", '\n', "s (score)", \
                   '\n', "q (quit)")
# ask for response
action_str = input("Please enter here: ")

# start a loop that wil continue as long as user doesn't quit
while action_str != 'q':
    # This is the adding an indel part
    if action_str == 'a':
        print()
        # prompt for which string to work on
        add_str = input("Which string do you want to work on (1 or 2): ")
        
        if add_str == '1':
            # prompt for which index the user wants
            index_str = input("Add indel before what index: ")
            # make sure that the index is a number
            while index_str.isdigit() == False:
                print("Invalid input. Please try again.")
                index_str = input("Add indel before what index: ")

            index_int = int(index_str)

            # make sure that the index is a valid index in the string
            while index_int >= len(first_str):
                print("Invalid input. Please try again.")
                index_str = input("Add indel before what index: ")

                while index_str.isdigit() == False:
                    print("Invalid input. Please try again.")
                    index_str = input("Add indel before what index: ")
                
                index_int = int(index_str)
            # add an indel in the spot requested
            else:
                first_str = first_str[:index_int] + '-' + first_str[index_int:]

        elif add_str == '2':
            # prompt for which index the user wants
            index_str = input("Add indel before what index: ")
            # make sure that the index is a number
            while index_str.isdigit() == False:
                print("Invalid input. Please try again.")
                index_str = input("Add indel before what index: ")

            index_int = int(index_str)
            # make sure that the index is a valid index in the string    
            while index_int >= len(second_str):
                print("Invalid input. Please try again.")
                index_str = input("Add indel before what index: ")

                while index_str.isdigit() == False:
                    print("Invalid input. Please try again.")
                    index_str = input("Add indel before what index: ")
                
                index_int = int(index_str)
            # add an indel in the spot requested
            else:
                second_str = second_str[:index_int] + '-' + second_str[index_int:]

        else:
            print("Invalid input. Please try again.")
            continue
    # this is the deleting an indel part
    elif action_str == 'd':
        print()
        # prompt the for which string
        delete_str = input("Which string do you want to work on (1 or 2): ")

        if delete_str == '1':
            # prompt for the index
            index_str = input("Delete which index: ")
            # check to make sure the prompt is a number
            while index_str.isdigit() == False:
                print("Invalid input. Please try again.")
                index_str = input("Delete which index: ")

            index_int = int(index_str)
            # check to make sure the index specified is in the string
            while index_int >= len(first_str):
                print("Invalid input. Please try again.")
                index_str = input("Delete which index: ")

                while index_str.isdigit() == False:
                    print("Invalid input. Please try again.")
                    index_str = input("Delete which index: ")
                
                index_int = int(index_str)
             
            else:
                # check to make sure that the index is an indel
                while first_str[index_int] != "-":
                    print("Invalid input. Can only delete an indel.")
                    index_str = input("Delete which index: ")

                    while index_str.isdigit() == False:
                        print("Invalid input. Please try again.")
                        index_str = input("Delete which index: ")
                
                    index_int = int(index_str)
                # delete the indel
                first_str = first_str[:index_int] + first_str[index_int + 1:]

        elif delete_str == '2':
            # prompt for the index
            index_str = input("Delete which index: ")
            # check to make sure the index is a number
            while index_str.isdigit() == False:
                print("Invalid input. Please try again.")
                index_str = input("Delete which index: ")

            index_int = int(index_str)
            # make sure the index is in the string 
            while index_int >= len(second_str):
                print("Invalid input. Please try again.")
                index_str = input("Delete which index: ")

                while index_str.isdigit() == False:
                    print("Invalid input. Please try again.")
                    index_str = input("Delete which index: ")
                
                index_int = int(index_str)
            else:
                # make sure the index is an indel
                while second_str[index_int] != "-":
                    print("Invalid input. Can only delete an indel.")
                    index_str = input("Delete which index: ")

                    while index_str.isdigit() == False:
                        print("Invalid input. Please try again.")
                        index_str = input("Delete which index: ")
                
                    index_int = int(index_str)
                # delete the indel  
                second_str = second_str[:index_int] + second_str[index_int + 1:]
                     
        else:
            print("Invalid input. Please try again.")
            continue

    elif action_str == 's':
        print()
        # store the two strings so that they can be recalled later
        store1_str = first_str
        store2_str = second_str
        # add indels to the end of one of the strings so they are the same length
        while len(first_str) > len(second_str):
            second_str += "-"
        while len(second_str) > len(first_str):
            first_str += "-"
        #define three variables to help count
        # count_int will help with the index of the character
        count_int = 0
        # match_int will count the number of matches
        match_int = 0
        # diff_int will count the mismatches
        diff_int = 0
        for char1_str in first_str:
            #checks the first index for matches and mismatches
            if count_int == 0:
                if char1_str == second_str[count_int]:
                    first_str = char1_str.lower() + first_str[1:]
                    second_str = second_str[count_int].lower() + second_str[1:]
                    match_int += 1
                else:
                    first_str = char1_str.upper() + first_str[1:]
                    second_str = second_str[count_int].upper() + second_str[1:]
                    diff_int += 1
                # if both are indexes are indels then it will
                #delete the indels and not count anything
                if char1_str == '-' and char1_str == second_str[count_int]:
                    first_str = first_str[1:]
                    second_str = second_str[1:]
            else:
                # checks the rest of the string for matches and mismatches
                if char1_str == second_str[count_int]:
                    first_str = first_str[:count_int] + char1_str.lower() + first_str[count_int+1:]
                    second_str = second_str[:count_int] + second_str[count_int].lower() + second_str[count_int+1:]
                    match_int += 1
                else:
                    first_str = first_str[:count_int] + char1_str.upper() + first_str[count_int+1:]
                    second_str = second_str[:count_int] + second_str[count_int].upper() + second_str[count_int+1:]
                    diff_int += 1
                # if both indexes are indels then it will delete the indels
                if char1_str == '-' and char1_str == second_str[count_int]:
                    first_str = first_str[:-1]
                    second_str = second_str[:-1]
            # change the index that is being used
            count_int +=1
        # print out the number of matches and mismatches
        print("Matches: ", match_int, "Mismatches: ", diff_int)
        print(first_str)
        print(second_str)
        # return the strings to what they were before the scoring occured
        first_str = store1_str
        second_str = store2_str
    # checks for errors in the entry of the original menu.
    else:
        print("Invalid option. Please choose again.", '\n', '')
        print("What do you want to do:", '\n', "a (add indel)", \
                   '\n', "d (delete indel)", '\n', "s (score)", \
                   '\n', "q (quit)")
        action_str = input("Please enter here: ")
    # prints the menu and prompts the user for a response
    print()
    print("What do you want to do:", '\n', "a (add indel)" \
                   '\n', "d (delete indel)", '\n', "s (score)", \
                   '\n', "q (quit)")
    action_str = input("Please enter here: ")
