# Project 12
# Honors Project
# CSE 231 Section 001H
# due April 22, 2013


import numpy
import pylab
class Day_line(object):
    '''This class is used to help parse through the strings and get the data needed.'''
    def __init__(self,input_str):
        self.input_str = input_str
        line_list = input_str.split()
        self.month = int(line_list[0].strip())
        self.day = int(line_list[1].strip())
        self.year = int(line_list[2].strip())
        self.hour = int(line_list[3].strip())
        self.avg_temp = float(line_list[4].strip())


#### This starts part one of the project
def First_part():

    # a function to help find the max and min of list
    def find_max_min(temp_list):
        max_value = max(temp_list)
        min_value = min(temp_list)
        return (max_value,min_value)

    # Initializing some variables so that data can be collected correctly
    first_file_obj = open('temperature.txt')
    month_day_count = {1:31,2:29,3:31,4:30,5:31,6:30,7:31,8:31,9:30,10:31,11:30,12:31}
    high_low_list_dict = {1:[],2:[],3:[],4:[],5:[],6:[],7:[],8:[],9:[],10:[],11:[],12:[]}
    average_high_dict = {}
    average_low_dict = {}


    # skips the first two lines of the file which are just the headers
    for count in range(0,2):
        first_file_obj.readline()

    # A funcution that reads through a 24 hour cycle
    def read_day():
        day_list = []
        for counter in range(1,25):
            one_hour = Day_line(first_file_obj.readline().strip())
            day_list.append(one_hour.avg_temp)
        return (find_max_min(day_list))

    # gets the high and low as tuples in a dictionary
    for count_num1 in range(1,13):
        count_num2 = 1
        while count_num2 <= month_day_count[count_num1]:
            high_low_tuple = read_day()
            high_low_list_dict[count_num1].append(high_low_tuple)
            count_num2 += 1
    first_file_obj.close()

    # finds the high and low averages of each month using the tuples dictionary
    for count_num3 in range(1,13):
        count_num4 = 0
        high_float = 0
        low_float = 0
        while count_num4 < month_day_count[count_num3]:
           high_float += high_low_list_dict[count_num3][count_num4][0]
           low_float += high_low_list_dict[count_num3][count_num4][1]
           count_num4 += 1
        month_high_avg = high_float/(month_day_count[count_num3])
        month_low_avg = low_float/(month_day_count[count_num3])
        average_high_dict[count_num3] = month_high_avg
        average_low_dict[count_num3] = month_low_avg

    #finds the difference list so that the figure can be plotted correctly
    difference_list = []
    for count_num5 in range(1,13):
        difference_list.append(average_high_dict[count_num5] - average_low_dict[count_num5])
    average_low_list = []
    average_high_list = []
    for count_num6 in range(1,13):
        average_low_list.append(average_low_dict[count_num6])
        average_high_list.append(average_high_dict[count_num6])

    # plots the floating bar graph
    months_list = ['January','February','March','April','May','June','July','August','September','October','November','December']
    pylab.xticks(numpy.arange(13)+0.5/2.0,months_list,rotation=20)
    pylab.bar(numpy.arange(12),difference_list,bottom=average_low_list)
    pylab.xlabel('Months')
    #### I don't know why but the xlabel doesnt show up unless the rotation is less than 15
    #### but you cant read the months if you put the rotation that low.
    pylab.ylabel('Average Temp')
    pylab.title('Charleston,MO - 2012')
    pylab.savefig('temp.png')
    pylab.close()

##### This ends part one of the project
def Second_part():

    # function that reads through the files and collects all data necessary
    # this function returns 2 dictionaries filled with temperatures at the hour
    def read_through():
        temp_file_obj = open('temperature.txt')
        solar_file_obj= open('solar_radition.txt')
        for count in range(0,2):
            temp_file_obj.readline()
        for count in range(0,4):
            solar_file_obj.readline()

        hourly_temp_list_dict = {100:[],200:[],300:[],400:[],500:[],600:[],700:[],800:[],\
                            900:[],1000:[],1100:[],1200:[],1300:[],1400:[],1500:[],\
                            1600:[],1700:[],1800:[],1900:[],2000:[],2100:[],2200:[],\
                            2300:[],2400:[]}
        solar_rad_list_dict = {100:[],200:[],300:[],400:[],500:[],600:[],700:[],800:[],\
                            900:[],1000:[],1100:[],1200:[],1300:[],1400:[],1500:[],\
                            1600:[],1700:[],1800:[],1900:[],2000:[],2100:[],2200:[],\
                            2300:[],2400:[]}
        for each_line in temp_file_obj:
            the_day = Day_line(each_line)
            if the_day.month == 6:
                hourly_temp_list_dict[the_day.hour].append(the_day.avg_temp)
        for every_line in solar_file_obj:
            each_day = Day_line(every_line)
            if each_day.month == 6:
                solar_rad_list_dict[each_day.hour].append(each_day.avg_temp)
        temp_file_obj.close()
        solar_file_obj.close()
        return (hourly_temp_list_dict,solar_rad_list_dict)

    # function that takes the two dictionaries from the function above and
    # finds the averages of each hour returns 2 lists
    def get_averages(temp_dict,radiation_dict):
        june_length = 30
        average_temp_per_hour_list = []
        avg_solar_rad_per_hour_list = []
        hour_counter = 100
        while hour_counter <= 2400:
            temp_adder = 0
            rad_adder = 0
            for every_element in temp_dict[hour_counter]:
                temp_adder += every_element
            average_hour_temp = temp_adder/30
            average_temp_per_hour_list.append(average_hour_temp)
            
            for each_element in radiation_dict[hour_counter]:
                rad_adder += each_element
            average_solar_rad = rad_adder/30
            avg_solar_rad_per_hour_list.append(average_solar_rad)
            hour_counter += 100
        return(average_temp_per_hour_list,avg_solar_rad_per_hour_list)

    # function that takes the 2 lists from the function above and plots the
    # with two y-axis
    def plot_lines(temp_list,radiation_list):
        pylab.title('Charleston,MO - 2012')
        pylab.xlabel('Hours')
        pylab.ylabel('Average Temp (F)',color='b')
        pylab.yticks(color='b')
        pylab.plot(list(range(1,25)),temp_list,'bo-')
        pylab.twinx()
        pylab.ylabel('Average Solar Radiation (W/m^2)',color='r')
        pylab.yticks(color='r')
        pylab.plot(list(range(1,25)),radiation_list,'ro-')
        pylab.savefig('solar_rad.png')
        pylab.close()

        
    dictionaries = read_through()
    averages = get_averages(dictionaries[0],dictionaries[1])
    plot_lines(averages[0],averages[1])

#### End of the second part of the project

def main():
    First_part()
    Second_part()
main()

# As soon as the solar radiation appears the temperature starts to rise
# then it takes a little time for it to warm up completely due to the max of
# of the solar radiation and then the temperature reaches its max and begins
# to decline just as the radiation
