# Section 1
# Project 2: Slayer
# This python program will be used to solve the given puzzle

print("For what six-digit number SLAYER is " \
                   "the following equation true, where each     letter " \
                   "stands for the digit in the position shown: ")
print(" ")
print("SLAYER + SLAYER + SLAYER =   LAYERS")
print(" ")

# Ask user for 6 digit number
slayer_str = input("Enter a guess for SLAYER: ")
slayer_int = int(slayer_str)

# Now check to see if integer is 6 digits

if 100000 <= slayer_int <= 999999:

    # Separate the digits so that they can be rearranged
    s_int = slayer_int // 100000 % 10
    l_int = slayer_int // 10000  % 10
    a_int = slayer_int // 1000   % 10
    y_int = slayer_int // 100    % 10
    e_int = slayer_int // 10     % 10
    r_int = slayer_int // 1      % 10

    # Rearrange the digits from SLAYER to LAYERS
    layers_int = (l_int * 100000) + (a_int * 10000) + (y_int * 1000)\
                 + (e_int * 100) + (r_int * 10) + (s_int)

    # Add SLAYER + SLAYER + SLAYER
    added_int = slayer_int + slayer_int + slayer_int

    print('SLAYER + SLAYER + SLAYER = ', added_int)
    print('LAYERS = ', layers_int)

    # Check to see if the guess is correct
    if added_int == layers_int:
        print("Your guess is correct!")
    else:
        print("Your guess is incorrect.")

else:
    print("This number is not six digits:", slayer_int)
