# Section 001H
# Project 11
# due April 15, 2013

import urllib.request

# this function is used to help distance function
def parse(call_str):
    ''' This function takes in a url string and parses through the string that is returned by the url and gets the distance as a string out of url'''
    web_obj = urllib.request.urlopen(call_str)
    results_str = str(web_obj.read())
    web_obj.close()
    lists = results_str.split(':')
    lists_str = lists[7][1:(lists[7].find('\\n'))]
    
    return lists_str

#this function is used to help the distance function
def make_url_call(first_city_str,second_city_str,mode='driving'):
    ''' This function makes a string that can be used to call the google api'''
    if mode == 'driving' or mode == 'bicycling' or mode == 'walking':
        first_city_list = first_city_str.split(',')
        second_city_list = second_city_str.split(',')
        first_city = first_city_list[0].strip()
        first_state = first_city_list[1].strip()
        second_city = second_city_list[0].strip()
        second_state = second_city_list[1].strip()
        city1_split = first_city.split()
        city2_split = second_city.split()
        first_string = ""
        second_string = ""
        for each_blank in city1_split:
            first_string += (each_blank + '+')
        first_string += first_state
        for each_blank in city2_split:
            second_string += (each_blank + '+')
        second_string += second_state
        
        return 'http://maps.googleapis.com/maps/api/distancematrix/json?origins={:s}&destinations={:s}&mode={:s}&sensor=false'.format\
               (first_string,second_string,mode)
    
class Tour(object):
    '''This is the Tour class where cities are input and distances are found using google api'''
    def __init__(self,*cities):
        "cities must be input including city and state"
        self.city_list = []
        for each_str in cities:
            self.city_list.append(each_str.strip())
        self.mode = 'driving'
        self.total_distance = 0
        self.total_distance = self.distance()
    def distance(self,method='driving'):
        ''' a method to find the distance of the tour with the default method being driving'''
        self.mode = method
        distance = 0
        for count in range(0,(len(self.city_list)-1)):
            call_str = make_url_call(self.city_list[count],self.city_list[count+1],self.mode)
            distance += int(parse(call_str))
        if type(distance) != int:
            raise ValueError
        return distance
    def __str__(self):
        ''' Allows for the tour to be printed'''
        return_str = ''
        count = 1
        for each_city in self.city_list:
            if count == 1:
                return_str += each_city
            else:
                return_str = return_str + '; ' + each_city
            count +=1
        return return_str
    def __repr__(self):
        return self.__str__()
    def __add__(self,anoth_tour):
        '''This adds two tours together and changes the first tour in place'''
        for every_city in anoth_tour.city_list:
            self.city_list.append(every_city)
        self.total_distance = self.distance()
        return self
    def __mul__(self,num_of_cycles):
        ''' does the operation of a tour * an int. This changes the the tour in place'''
        if type(num_of_cycles) != int:
            raise TypeError
        elif num_of_cycles < 0:
            raise ValueError
        else:
            self.city_list = self.city_list*num_of_cycles
            self.total_distance = self.distance()
            return self
    def __rmul__(self,num_of_cycles):
        ''' does the operation of an int * a tour'''
        return self.__mul__(num_of_cycles)
    def __gt__(self,anoth_tour):
        ''' this method is for the > operator. it compares the distances'''
        if self.total_distance > anoth_tour.total_distance:
            return True
        else:
            return False
    def __lt__(self,anoth_tour):
        ''' this method is for the < operator. it compares the distances'''
        if self.total_distance < anoth_tour.total_distance:
            return True
        else:
            return False
    def __eq__(self,anoth_tour):
        ''' this method is for the == operator. this checks to see if the tours visit the same cities in the same order.'''
        if self.city_list == anoth_tour.city_list:
            return True
        else:
            return False
def main():
    ''' This program is used to test the methods of the the Tour class'''
    tour1 = Tour('Los Angeles, CA', 'Lima, OH', 'New York, NY')
    tour2 = Tour('Sacramento, CA', 'Oakland, CA', 'Seattle, WA')
    print('tour1: ', tour1)
    print()
    print('tour1 distance driving default: ', tour1.total_distance)
    print()
    print('tour1.distance("walking"): ', tour1.distance('walking'))
    print()
    print('tour2: ', tour2)
    print()
    tour1 + tour2
    print('tour1 + tour2: ', tour1)
    print()
    print('tour1 * 3:', tour1*3)
    print()
    print('2*tour2:', 2*tour2)
    print()
    tour3 = Tour('Los Angeles, CA', 'Lima, OH', 'New York, NY')
    tour4 = Tour('Sacramento, CA', 'Oakland, CA', 'Seattle, WA')
    tour5 = Tour('Los Angeles, CA', 'Lima, OH', 'New York, NY')
    print('tour3: ', tour3)
    print('tour4: ', tour4)
    print('tour5: ', tour5)
    print()
    print('tour3>tour4:',tour3>tour4)
    print('tour4>tour3:',tour4>tour3)
    print('tour3<tour4:',tour3<tour4)
    print('tour4<tour3:',tour4<tour3)
    print('tour3==tour4:',tour3==tour4)
    print('tour3==tour5:',tour3==tour5)
