# Proj 07
# Section 001

import random
import string

def scramble_word(word_str):
    if len(word_str) > 3:
        punc_str = string.punctuation
        return_list = []
        letter_list = []
        scramble_list = []
        char_list = list(word_str)
        letter_store = ""
        for char in char_list:
            if char in punc_str:
                continue
            else:
                letter_list.append(char)   
        scramble_list = letter_list[1:-1]    
        random.shuffle(scramble_list)    
        return_list = scramble_list[:]
        return_list.append(letter_list[-1])    
        return_list.insert(0,letter_list[0])
        index_count = 0
        for char in char_list:
            if char in punc_str:
                return_list.insert(index_count,char)
            index_count += 1
        return_str = "".join(return_list)
    else:
        return_str = word_str
    return return_str
def scramble_line(line_str):
    word_str = line_str.strip()
    word_list = word_str.split()
    place_counter = 0
    for word in word_list:
        word_list[place_counter] = scramble_word(word)
        place_counter += 1
    final_str = " ".join(word_list)
    return final_str
def open_read_file(file_name_str):
    boolean_expression = True
    while boolean_expression:
        try:
            file_obj = open(file_name_str, "r")
            boolean_expression = False
        except FileNotFoundError:
            print("Invalid file name. Please try again.")
            file_name_str = input("What is the file name: ")
    return file_obj
def main():
    file_read_name = input("What file would you like to read from: ")
    read_obj = open_read_file(file_read_name)
    print()
    file_write_name = input("What file would you like to write to: ")
    file_write_obj = open(file_write_name,"w")
    for each_line_str in read_obj:
        scrambled_line_str = scramble_line(each_line_str) +"\n"
        file_write_obj.write(scrambled_line_str)
    file_write_obj.close()
    read_obj.close()
main()
