import cardsBasic

def setup():
    """
    paramaters: None
    returns:
    - a foundation (list of 4 empty lists)
    - cell (list of 4 empty lists)
    - a tableau (a list of 10 lists, the dealt cards)
    """
    foundation = [[],[],[],[]]
    tableau = [[],[],[],[],[],[],[],[],[],[]]
    cell = [[],[],[],[]]

    my_deck = cardsBasic.Deck()
    my_deck.shuffle()
    count_lists = 1
    for lists in tableau:
        if count_lists ==1 or count_lists == 2:
            for number in range(0,6):
                lists.append(my_deck.deal())
        else:
            for number in range(0,5):
                lists.append(my_deck.deal())
        count_lists += 1
    
    return foundation,tableau,cell


def move_to_foundation(tableau,foundation,t_col,f_col):
    '''
    parameters: a tableau, a foundation, column of tableau, column of foundation
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a column of foundation
    This function can also be used to move a card from cell to foundation
    '''
    try:
        moving_card = tableau[(t_col-1)][-1]
        if foundation[(f_col-1)] == []:
            if moving_card.get_rank() == 1:
                foundation[(f_col-1)].append(tableau[(t_col-1)].pop())
                return True
            else:
                print("Must first put ace in foundation.")
                return False
        else:
            if moving_card.equal_suit(foundation[f_col-1][-1]):
                if (moving_card.get_rank() - 1) == foundation[f_col-1][-1].get_rank():
                    foundation[f_col-1].append(tableau[t_col-1].pop())
                    return True
                else:
                    print("Card is not the correct rank.")
                    return False
            else:
                print("Cards are not the same suit.")
                return False
    except IndexError:
        print("One of the places indicated does not exist.")
        return False
            

def move_to_cell(tableau,cell,t_col,c_col):
    '''
    parameters: a tableau, a cell, column of tableau, column of cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card at the end of a column of tableau to a cell
    '''
    try:
        if cell[c_col-1] == []:
            cell[c_col-1].append(tableau[t_col-1].pop())
            return True
        else:
            print("Cell is already filled.")
            return False
    except IndexError:
        print("One of the places indicated does not exist.")
        return False

def move_to_tableau(tableau,cell,c_col,t_col):
    '''
    parameters: a tableau, a cell, column of tableau, a cell
    returns: Boolean (True if the move is valid, False otherwise)
    moves a card in the cell to a column of tableau
    remember to check validity of move
    '''
    try:
        cell_card = cell[c_col-1][-1]
        if tableau[t_col-1] == []:
            if cell_card.get_rank() == 13:
                tableau[t_col-1].append(cell[c_col-1].pop())
                return True
            else:
                print("Can only put a king in an empty row.")
                return False
        elif cell_card.equal_suit(tableau[t_col-1][-1]):
            if (cell_card.get_rank() + 1) == tableau[t_col-1][-1].get_rank():
                tableau[t_col-1].append(cell[c_col-1].pop())
            else:
                print("Card is not the correct rank.")
                return False
        else:
            print("Cards are not the same suit.")
            return False
    except IndexError:
        print("One of the places indicated does not exist.")
        

def is_winner(foundation):
    '''
    parameters: a foundation
    return: Boolean
    '''
    score_list = []
    for each in foundation:
        score_list.append(len(each))
    if score_list == [13,13,13,13]:
        return True
    else:
        return False

def cell_to_foundation(cell,foundation,c_col,f_col):
    try:
        if foundation[f_col-1] == []:
            if cell[c_col-1][-1].get_rank() == 1:
                foundation[f_col-1].append(cell[c_col-1].pop())
            else:
                print("Must first fill foundation with ace")
                return False
        elif cell[c_col-1][-1].equal_suit(foundation[f_col-1][-1]):
            if (cell[c_col-1][-1].get_rank()-1) == foundation[f_col-1][-1].get_rank():
                foundation[f_col-1].append(cell[c_col-1].pop())
            else:
                print("Card is not the correct rank.")
                return False
        else:
            print("Cards are not the same suit.")
            return False
    except IndexError:
        print("One of the places indicated does not exist.")


def move_in_tableau(tableau,t_col_source,t_col_dest):
    '''
    parameters: a tableau, the source tableau column and the destination tableau column
    returns: Boolean
    move card from one tableau column to another
    remember to check validity of move
    '''
    try:
        card_source = tableau[t_col_source-1][-1]
        if tableau[t_col_dest-1] == []:
            if card_source.get_rank() == 13:
                tableau[t_col_dest-1].append(tableau[t_col_source].pop())
            else:
                print("Can only put king in empty list.")
        elif card_source.equal_suit(tableau[t_col_dest-1][-1]):
            if (card_source.get_rank() +1) == tableau[t_col_dest-1][-1].get_rank():
                tableau[t_col_dest-1].append(tableau[t_col_source-1].pop())
            else:
                print("Card is not the correct rank.")
                return False
        else:
            print("Cards are not the same suit.")
            return False
    except IndexError:
        print("One of the columns does not exist.")
        
def print_game(foundation, tableau,cell):
    """
    parameters: a tableau, a foundation and a cell
    returns: Nothing
    prints the game, i.e, print all the info user can see.
    Includes:
        a) print tableau  
        b) print foundation ( can print the top card only)
        c) print cells

    """
    cell_found = '''
      F1      F2      C1      C2      C3      C4      F3      F4
'''
    print(cell_found)

    row = ''
    for stack in foundation[0:2]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''
            
    for c in cell:
        
        try:
            row += '%8s' % c[0]
        except IndexError:
            row += '%8s' % ''
            
    row = row+ ' '
    for stack in foundation[2:]:
        try:
            row += '%8s' % stack[-1]
        except IndexError:
            row += '%8s' % ''

    print (row)
    print ('----------')


    
    print ("Tableau")
    row = ''
    for i in range(len(tableau)):
        row += '%8s' % (i + 1)
    print (row)

    """find the length of the longest stack"""
    stack_length = []
    for stack in tableau:
        stack_length.append(len(stack))
    max_length = max(stack_length)

    for i in range(max_length):
        row = ''                    # remember to clear the row
        for stack in tableau:
            try:
                row += '%8s' % stack[i]
            except IndexError:
                row += '%8s' % ''
        print (row)
    print ('----------')
def print_rules():
    '''
    parameters: none
    returns: nothing
    prints the rules
    '''
    to_print ='''Rules of Seahaven Towers

    a. Only one card at a time can be moved.
    b. Foundation
        Each foundation holds only one suit and is built up from Ace to King.
        You can move a card to the foundation from a cell or the tableau.
        Once a card is on the foundation it cannot be moved off.
    c. Tableau 
        i. The card at the bottom of a column may be moved to an open cell,
           a foundation or another column of the tableau.
        ii. Moving a card to a tableau column follows these rules
            1. A card can only be moved to the bottom of a column
            2. When you move a card to a column in the tableau you can only
               build down by rank and by the same color. For example, you
               can move a Two of Hearts onto a Three of Hearts (the pile goes
               down by rank, and same color)
        iii. Empty columns may be filled only by a King with any color.
    d. Cell
        i. One cell spot can only contain 1 card
        ii. The card may be moved to the tableau or the foundation.
'''
    print(to_print)

def show_help():
    '''
    parameters: none
    returns: nothing
    prints the supported commands
    '''
    response ='''
    Responses are:
    --------------
         t2f T F   - move from Tableau T to Foundation F (T and F are ints)
	 t2c T C   - move from Tableau T to Cell C (T and C are ints)
	 t2t T1 T2 - move from Tableau T1 to Tableau T2 (T1 and T2 are ints)
	 c2t C T   - move from Cell C to Tableau T (C and T are ints)
	 c2f C F   - move from Cell C to Foundation F (C and F are ints)
	 'h' for help
	 'q' to quit
         '''
    print (response)
         

    

    
def play():
    ''' 
    main program. Does error checking on the user input. 
    '''
    print_rules()
    foundation, tableau, cell = setup() 
       
    show_help()
    while True:
        try:
            print_game(foundation, tableau, cell)
            response = input("Command (type 'h' for help): ")
            response = response.strip()
            response_list = response.split()
            if len(response_list) > 0:
                r = response_list[0]
                if r == 't2f':
                    move_to_foundation(tableau,foundation,int(response_list[1]),int(response_list[2]))                  
                elif r == 't2t':
                    move_in_tableau(tableau,int(response_list[1]),int(response_list[2]))                         
                elif r == 't2c':
                    move_to_cell(tableau,cell,int(response_list[1]),int(response_list[2]))                          
                elif r == 'c2t':
                    move_to_tableau(tableau,cell,int(response_list[1]),int(response_list[2]))                          
                elif r == 'c2f':
                    cell_to_foundation(cell,foundation,int(response_list[1]),int(response_list[2]))                          
                elif r == 'q':
                    break
                elif r == 'h':
                    show_help()
                else:
                    print('Unknown command:',r)
            else:
                print("Unknown Command:",response)
        except IndexError:
            print("Invalid input")
        except ValueError:
            print('Be sure to put integers in the second and third position.')
        if is_winner(foundation):
            print("You have won!!!!!!!")
            break
    print('Thanks for playing')

play()


        
    

