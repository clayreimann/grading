# CSE 231H Section 001
# Project 05
# This program will be used to draw N hexagons per row of alternating color
# The requirement is that they are each 500/N pixels wide

# Import modules that will be very helpful
import turtle
import math
import time

# Define a function that prompts user for color choice
def get_color_choice():

    # prints the menu
    print("These three colors are your choices:","\n", "'red'", \
          "\n", "'green'", "\n", "'blue'","\n", "'purple'","\n", "'yellow'")
    print()

    # prompts for a color
    color_str = input("Please choose a color: ")

    # makes sure color choice is on the list
    while color_str != 'red' and color_str != 'green'\
          and color_str != 'blue' and color_str != 'purple'\
          and color_str != 'yellow':
        print("'",color_str,"'","was an invalid color choice.")
        print()
        print("These three colors are your choices:","\n", "'red'", \
          "\n", "'green'", "\n", "'blue'","\n", "'purple'","\n", "'yellow'")
        print()
        color_str = input("Please choose a color: ")

    # returns the color choice
    return color_str

# Define a function that will prompt for number of hexagons
def get_num_hexagons():
    print()

    # prompts for the number of hexagons per row
    hexagon_str = input("Please enter a number of hexagons per row: ")

    # makes sure the number is between 4 and 20
    while hexagon_str > "20" and hexagon_str < "4":
        print("It should be between 4 and 20.", end=" ")
        hexagon_str = input("Please try again: ")
    hexagon_int = int(hexagon_str)

    # return the number as an integer
    return hexagon_int

# define a function that will draw a horizantal row of hexagons alternating color
def horizantal_hexagons(x_start,y_start,number,width,side,color1,color2):

    # define a function that will draw one hexagon that is filled in
    def draw_hexagon(x,y, side_len, pen, color):
        #change the speed so that it doesnt take forever to draw hexagons
        pen.speed(10)
        pen.up()
        pen.goto(x,y)
        pen.seth(0)
        pen.down()
        pen.right(90)
        pen.color(color)
        pen.begin_fill()
        for side in range(0,6):
            pen.right(60)
            pen.forward(side_len)
        pen.end_fill()
        # make the hexagons have a black outline
        pen.up()
        pen.goto(x,y)
        pen.seth(0)
        pen.down()
        pen.right(90)
        pen.color("black")
        for side in range(0,6):
            pen.right(60)
            pen.forward(side_len)
        pen.up()
        pen.seth(0)
        
    count_int = 0

    # this allows for the alternating colors and moving each hexagon
    ## to the right the correct space
    while count_int < number:
        x_value = width*count_int+x_start
        if count_int % 2 == 0:
            draw_hexagon(x_value,y_start,side,turtle,color1)
        else:
            draw_hexagon(x_value,y_start,side,turtle,color2)
        count_int +=1
# prompts for the first color choice
first_color = get_color_choice()

# prompts for the second color choice
second_color = get_color_choice()

# prompts for the number of hexagons per row
num_of_hexagons = get_num_hexagons()

# figures out the width of each hexagons and floats the number
width_of_hexagon = float(500 / num_of_hexagons)

#figures out the how big the side of the hexagon should be
side_of_hexagon = float((width_of_hexagon / 2)/math.cos(math.pi/6))
# changes the original x and y coordinates so that the drawing
## is more centered when the turtle appears
original_x = float(-180)
original_y = float(150)

# this variable is a float which moves the hexagons either right or
## left at the start of each new row
x_alternate = width_of_hexagon/2

# This variable is a float which moves the hexagons down at the
## the start of a new row
y_down = (side_of_hexagon + (width_of_hexagon/2)*(math.tan(math.pi/6)))


vert_count = 0

# Starts drawing horizantal rows and moves them right and left or down according
## to the row which the hexagon is in
while vert_count < num_of_hexagons:
    if vert_count % 2 == 0:
        horizantal_hexagons(original_x,original_y-(y_down*vert_count),\
                            num_of_hexagons,width_of_hexagon,side_of_hexagon,\
                            first_color,second_color)
    else:
        horizantal_hexagons(original_x - x_alternate,original_y-(y_down*vert_count),\
                            num_of_hexagons,width_of_hexagon,side_of_hexagon,\
                            first_color,second_color)
    vert_count += 1

# The program waits ten seconds and then closes the turtle graphics window.
time.sleep(10)
turtle.bye()
