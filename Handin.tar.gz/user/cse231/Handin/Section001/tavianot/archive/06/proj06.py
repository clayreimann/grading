# Project 6 
# Section 001 
# Call a file and find the averages of the column indicated by the user 


def get_input_descriptor(): 
    '''function that will keep prompting until user gives correct input file''' 
     
    # prompts for input file 
    file_name = input("Open what file: ") 

    # define a variable that will be used to end the while loop 
    file_not_opened_bool = True 

    # A while loop that will keep prompting for a file name until 
    ## the file is opened 
    while file_not_opened_bool: 
        try: 
            opened_file = open(file_name, "r") 
            file_not_opened_bool = False 
        except FileNotFoundError: 
            print("File could not be found.") 
            file_name = input("Open what file: ") 

    # returns the open file object 
    return opened_file 

def get_data_list(file_object, column_number): 
    '''function that will get the months and column indicated 
    and return as a list of tuples''' 

    # sets a counter that will show what line the for loop is currently at 
    line_counter = 0 

    # creates an empty list so that data tuples can be added to it 
    data_list = [] 

    # a for loop that will read each line of the file except the first line 
    ## since that data is not relevant and creates a tuple then adds the tuple to 
    ## the list 
    for line_str in file_object: 
        line_counter += 1 

        # strips the line of any unwanted characters 
        line_str = line_str.strip() 

        # splits the line into a list which basically puts them back in columns 
        column_list = line_str.split(",") 

        # skip the first line of irrelevant daata 
        if line_counter == 1: 
            continue 

        # if it isn't the first line it creates a tuple (month,data) then adds 
        ## that tuple to the list 
        else: 
            date_data_tuple  = column_list[0],float(column_list[column_number]) 
            data_list.append(date_data_tuple) 

    # sorts the list by year first then month then days 
    data_list.sort() 

    # returns the list 
    return data_list 


def average_data(list_of_tuples): 
    ''' averages out the column by month and sorts the data from least to most''' 

    # finds the length of the list of tuples and then sets all the counters 
    ## so they can be used to find the averages 
    length_of_list = len(list_of_tuples) 
    index_counter = 0 
    month_avg_float = 0 
    num_day_int = 0 

    # creates an empty list to add tuples to 
    average_data_list = [] 

    # sets a str variable with the starting month 
    month_comparison_str = list_of_tuples[0][0][0:7] 

    # a while loop that averages out the months and adds the averages and 
    ## month/year to the tuple and then a list 
    while index_counter < length_of_list: 

        # if still in the same month keep adding to month_avg float so that it 
        ## can be divided by the number of days once  
        if list_of_tuples[index_counter][0][0:7] == month_comparison_str: 
            month_avg_float += list_of_tuples[index_counter][1] 
            num_day_int += 1 

        # if months are different then it will take the total sum and divide 
        ## by the number of days then reset the counters so the process can be 
        ## repeated 
        else: 
            data_avg_float = month_avg_float / num_day_int 
            month_corrected_str = month_comparison_str[5:] + \
                                  "-" + month_comparison_str[:4] 
            avg_data_tuple = (data_avg_float,month_corrected_str) 
            average_data_list.append(avg_data_tuple) 
            month_comparison_str = list_of_tuples[index_counter][0][0:7] 

            # the counter is subtracted one here so that when the program add one 
            ## after the else statement it will run the first tuple of the next 
            ## month again. This is so that all data is accounted for. 
            index_counter -= 1 
            month_avg_float = 0 
            num_day_int = 0 
        index_counter += 1 
         
    # sort the list lowest to largest 
    average_data_list.sort() 
     
    # return the list 
    return average_data_list 

def main(): 
    '''This is the main function which will be use each of the other functions 
    to average out by month the column that will be indicate. It will also print 
    the lowest 6 averages and the highest 6 averages.''' 

    # calls the file and opens it 
    file_obj = get_input_descriptor() 

    while_loop_boolean = True 

    # a loop that makes sure the user puts in a correct column number 
    while while_loop_boolean: 
        try: 
            column_int = int(input("Which column would you like to average: ")) 
            data_list = get_data_list(file_obj, column_int) 
            avg_data = average_data(data_list) 
            while_loop_boolean = False 
        except IndexError: 
            print("There is no column","{}.".format(column_int),) 
            print() 
        except ValueError: 
            print("There was an error with your input. Please try again") 
            print() 

    # prints the lowest 6 averages from the column 
    print("Lowest 6 values from column",column_int) 
    for number in range(0,6): 
        print("Date: {:>8s},   Value: {:>8.2f}".format(avg_data[number][1],\
                                                          avg_data[number][0])) 
    print() 

    # prints the highest 6 averages from the column 
    print("Highest 6 values from column",column_int) 

    # the range (-6,0) is used so that when that number is subtracted from seven 
    ## it will give the correct index of the highest value then the second 
    ## highest and so on. 
    for number in range(-6,0): 
        print("Date: {:>8s},   Value: {:>8.2f}".format(avg_data[-7-number][1],\
                                                          avg_data[-7-number][0])) 
    # close the file object 
    file_obj.close 

# execute the main function 
main() 
