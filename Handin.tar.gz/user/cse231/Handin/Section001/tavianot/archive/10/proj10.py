import time
import turtle
# This is the star class
class Star(object):
    '''This is a class which is used to store the center, arm length and color
of the star so that it can be drawn using turtle'''

    # initializes the star class
    def __init__(self,x,y,arm_length,color):
        import turtle
        self.x_center = int(x)
        self.y_center = int(y)
        self.arm_length = int(arm_length)
        self.color = str(color)
    # draws the star class and sets the default drawer to turtle if one isn't given
    def draw(self,drawer=None):
        if drawer == None:
            drawer = turtle.Turtle()
        drawer.up()
        drawer.speed('fastest')
        drawer.goto(self.x_center,self.y_center)
        drawer.seth(0)
        drawer.left(90)
        drawer.color(self.color)
        drawer.begin_fill()
        drawer.forward(self.arm_length/2.35)
        drawer.right(90)
        drawer.forward(self.arm_length/3.236)
        drawer.down()
        drawer.forward(self.arm_length)
        drawer.right(144)
        drawer.forward(self.arm_length)
        for count in range(0,4):
            drawer.left(72)
            drawer.forward(self.arm_length)
            drawer.right(144)
            drawer.forward(self.arm_length)
        drawer.end_fill()
        drawer.up()
    # turns the star into a string so it may be printed
    def __str__(self):
        return ("Star x:{:d}, y:{:d}, arm:{:d}, color:{:s}".format\
                (self.x_center,self.y_center,self.arm_length,self.color))
# this is the start of the rectangle class
class Rectangle(object):
    '''This is a rectangle class taking in the information of center, width and height
and color so that it may be drawn using turtle'''

    # initializes the rectangle class    
    def __init__(self,x,y,width,height,color):
        import turtle
        self.x_center = int(x)
        self.y_center = int(y)
        self.width = int(width)
        self.height = int(height)
        self.color = str(color)
    # draws the rectangle in specified drawer if none provided then turtle
    def draw(self,drawer=None):
        if drawer == None:
            drawer = turtle.Turtle()
        drawer.up()
        drawer.speed('fastest')
        drawer.goto(self.x_center,self.y_center)
        drawer.seth(0)
        drawer.left(90)
        drawer.forward(self.height/2)
        drawer.right(90)
        drawer.forward(self.width/2)
        drawer.color(self.color)
        drawer.begin_fill()
        drawer.down()
        drawer.right(90)
        for count in range(0,2):
            drawer.forward(self.height)
            drawer.right(90)
            drawer.forward(self.width)
            drawer.right(90)
        drawer.end_fill()
        drawer.up()
    # turns the rectangle into a string so it may be printed
    def __str__(self):
        return ("Rectangle x:{:d}, y:{:d}, width:{:d}, height:{:d}, color:{:s}".format\
                (self.x_center,self.y_center,self.width,self.height,self.color))
# start of the flag class
class Flag(object):
    '''This is the flag class which stores rectangles and stars so that the entire
flag may be drawn using turtle'''

    # initializes the flag class from a file object
    def __init__(self,file_object):
        import turtle
        self.file_object = file_object
        self.num_rectangles = int((self.file_object.readline()).strip())
        self.rectangle_strings_dict = {}
        for count in range(1,self.num_rectangles +1):
            rectangle_string = (self.file_object.readline()).strip()
            rectangle_list = rectangle_string.split(',')
            rectangle_dict = {}
            rectangle_dict['x'] = rectangle_list[0].strip()
            rectangle_dict['y'] = rectangle_list[1].strip()
            rectangle_dict['width'] = rectangle_list[2].strip()
            rectangle_dict['height'] = rectangle_list[3].strip()
            rectangle_dict['color'] = rectangle_list[4].strip()
            rectangle_rectangle = Rectangle(rectangle_dict['x'],rectangle_dict['y'],\
                                            rectangle_dict['width'],\
                                            rectangle_dict['height'],\
                                            rectangle_dict['color'])
            self.rectangle_strings_dict[count]= rectangle_rectangle


        self.num_stars = int((self.file_object.readline()).strip())
        self.star_strings_dict = {}
        for count in range(1,self.num_stars + 1):
            star_string = (self.file_object.readline()).strip()
            star_list = star_string.split(',')
            star_dict = {}
            star_dict['x'] = star_list[0].strip()
            star_dict['y'] = star_list[1].strip()
            star_dict['arm'] = star_list[2].strip()
            star_dict['color'] = star_list[3].strip()
            star_star = Star(star_dict['x'],star_dict['y'],star_dict['arm'],\
                             star_dict['color'])
            self.star_strings_dict[count] = star_star
    # draws the flag class
    def draw(self,drawer=None):
        if drawer == None:
            drawer= turtle.Turtle()
        for count in range(1,self.num_rectangles +1):
            self.rectangle_strings_dict[count].draw(drawer)
        for count in range(1,self.num_stars +1):
            self.star_strings_dict[count].draw(drawer)
    #turns the flag into a multiple line string so that it may be printed
    def __str__(self):
        return_string = 'Rectangles\n'
        for count in range(1,self.num_rectangles +1):
            return_string += (str(self.rectangle_strings_dict[count])+"\n")
        return_string += 'Stars\n'
        for count in range(1,self.num_stars +1):
            return_string += (str(self.star_strings_dict[count])+"\n")
        return return_string
# The professor provided this main function which he said we could use so that
# something could be used to easily check the drawing of flags
def main():
    import turtle
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    senegal_file = open('senegal.txt')
    senegal_flag = Flag(senegal_file)
    print(senegal_flag)
    senegal_flag.draw(pen)
    senegal_file.close()

    time.sleep(4)   # delay so you can see your flag
    turtle.clearscreen()
    panama_file = open('panama.txt')
    panama_flag = Flag(panama_file)
    print(panama_flag)
    panama_flag.draw(pen)
    panama_file.close()

# function that opens myFlag.txt and prints it and draws it
# I did not call the function after I created it just incase there is
# no myFlag.txt saved
def myFlag():
    import turtle
    turtle.clearscreen()
    pen = turtle.Turtle()
    pen.speed('fastest')
    file_obj = open('myFlag.txt')
    my_flag = Flag(file_obj)
    print(my_flag)
    my_flag.draw(pen)
    file_obj.close()

