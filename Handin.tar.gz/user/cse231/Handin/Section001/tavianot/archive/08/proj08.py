# Project 8
# CSE 231 Section 001

# Creates the fill completions dictionary function with two parameters
def fill_completions(c_dict, file_obj):
    #imports the string module
    import string
    # goes through every line of the file stripping the unnecesary characters
    for line in file_obj:
        line = line.strip()
        word_list = line.split()
        # goes through every word stripping the punctuation off the end
        ## and lowercases all letters
        for word in word_list:
            word = word.strip(string.punctuation)
            word = word.lower()
            # creates a list of tuples of the index and letter of each word
            enum_list = list(enumerate(word))
            # puts the tuple and word in the dictionary if not already
            ## and add to the tuple if it already exists
            for component in enum_list:
                if component in c_dict:
                    c_dict[component].add(word)
                else:
                    c_dict[component] = set()
                    c_dict[component].add(word)
                    
# creates the find completions function
def find_completions(prefix, c_dict):
    #finds the tuples of index and letter of the prefix
    prefix_list = list(enumerate(prefix))
    element_count = 1
    # for the first tuple it just adds it to final set
    ## for all tuples after that it checks the intersection the tuple and
    ## the intersection of the past tuples
    for element in prefix_list:
        if element_count == 1:
            final_set = c_dict[element].copy()
        else:
            temp_set = c_dict[element].copy()
            final_set = (final_set & temp_set)
        element_count += 1
    return final_set

# creates the main function which pulls everything together so that it can run
def main():
    # opens the file
    read_file_obj = open("ap_docs.txt",'r')
    c_dict = {}
    fill_completions(c_dict,read_file_obj)
    #prompts for a prefix to use in find_completions
    prefix_str = input("Please enter a prefix to test or '#' to quit: ")
    # allows for the user to quit when pound sign is entered
    while prefix_str != '#':
        print()
        completion_set = find_completions(prefix_str,c_dict)
        if completion_set == set():
            print("There are no completions to this prefix.")
        else:
            print(completion_set)
        print()
        prefix_str = input("Please enter a prefix to test or '#' to quit: ")
    print()
    print("Thanks for using the system!")
    # closes the file
    read_file_obj.close()
main()
