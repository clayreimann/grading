#This program will use print and input functions to solve Richter Scale problems and print certain values.
#Project 1 CSE 231

richter_string = input("Please enter a Richter scale measure: ")
richter_float = float(richter_string)
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("Richter measure:", richter_float)
print("Energy in joules:", energy_float)
print("Amount of TNT needed in tons:", tnt_float)
print("")
print("Here are Richter scale measures to compare to: ")
print("Richter          Joules                       TNT")
richter_float = 1
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("1", "       ",energy_float, "                 ",tnt_float)
richter_float = 5
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("5", "       ",energy_float, "               ",tnt_float)
richter_float = 9.1
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("9.1", "     ",energy_float, "      ",tnt_float)
richter_float = 9.2
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("9.2", "     ",energy_float, "      ",tnt_float)
richter_float = 9.5
energy_float = 10**((1.5*richter_float)+4.8)
tnt_float = energy_float/((4.184)*(10**9))
print("9.5", "     ",energy_float, "    ",tnt_float)
