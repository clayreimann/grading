# Section 1
# Project 3
# Simulate a vending machine
# Steps for consideration
# 1. Stock the vending machine
# 2. Repeatedly prompt for a price xx.xx or enter 'q' for quit
# 3. Check for price entry errors
# 4. Print menu
# 5. Prompt for a selection and make sure errors cant be entered
# 6. After each entered amount, reprint amount owed
# 7. After full payment entered dispense change using least number of coins
# 8. Print number of coins being dispensed or "no change"
# 9. If no change can be made  tell user to see store manager
# 10. Print the stock again
# 11. Before quiting print the total amount left in stock


#### price_str, price_float, and deposit_str are the only variables that
#### are not integers

# set the stock
nick_int = 25
dime_int = 25
quar_int = 25
ones_int = 0
five_int = 0
paid_int = 0

# print the stock
print("Change maker initialized.")
print("Stock contains:")
print(nick_int, " nickels")
print(dime_int, " dimes")
print(quar_int, " quarters")
print(ones_int, " ones")
print(five_int, " fives")
print("")

# request the first purchase price
price_str = input("Enter the purchase price (xx.xx) or 'q' to quit: ")

# start the loop
while price_str != 'q':

    # set the number of nickels, dimes and quarters to be given back to be 0
    nick_change = 0
    dime_change = 0
    quar_change = 0

    # change the price string into an int and find the number of dollars and cents owed
    price_float = float(price_str)
    price_int = int(round(price_float * 100))
    dollars_owed = int(price_int // 100)
    cents_owed = int(price_int - (dollars_owed*100))

    # check for illegal inputs
    if price_int < 0 or price_int % 5 != 0:
        print("Illegal price must be a non-negative multiple of 5 cents.")
        price_str = input("Enter the price (xx.xx) or 'q' to quit: ")
        continue

    # print the menu
    print()
    print("Menu for depostits:")
    print("'n' - deposit a nickel")
    print("'d' - deposit a dime")
    print("'q' - deposit a quarter")
    print("'o' - deposit a one dollar bill")
    print("'f' - deposit a five dollar bill")
    print("'c' - cancel the purchace")
    print()

    # use another loop to receive the cash from the user
    while price_int > 0:

        # print the payment due
        print("Payment due:", end=" ")
        if cents_owed == 0:
            print(dollars_owed, "dollars")
        elif dollars_owed == 0:
            print(cents_owed, "cents")
        else:
            print(dollars_owed, "dollars and ", cents_owed, "cents")

        # ask for the amount of money being input 
        deposit_str = input("Indicate your deposit: ")

        # describe what happens if a certain amount is entered
        if deposit_str == "n":
            nick_int += 1
            price_int -= 5
            cents_owed -= 5
            paid_int += 5
        elif deposit_str == "d":
            dime_int += 1
            price_int -= 10
            cents_owed -= 10
            paid_int += 10
        elif deposit_str == "q":
            quar_int += 1
            price_int -= 25
            cents_owed -= 25
            paid_int += 25
        elif deposit_str == "o":
            ones_int += 1
            price_int -= 100
            dollars_owed -= 1
            paid_int += 100
        elif deposit_str == "f":
            five_int += 1
            price_int -= 500
            dollars_owed -= 5
            paid_int += 500

        # When order is cancelled prints cancel order and then will print
            # amount of change that needs to be given back
        elif deposit_str == "c":
            price_int = 0
            print("Cancelling order")
            print()
            if paid_int == 0:
                print("No change due.")
            while paid_int >= 25 and quar_int > 0:
                paid_int -= 25
                quar_change += 1
                quar_int -= 1
            while paid_int > 5 and dime_int > 0:
                paid_int -= 10
                dime_change += 1
                dime_int -= 1
            while paid_int > 0 and nick_int > 0:
                paid_int -=5
                nick_change += 1
                nick_int -= 1
            if quar_change != 0:
                print(quar_change, " quarters")
            if dime_change != 0:
                print(dime_change, " dimes")
            if nick_change != 0:
                print(nick_change, " nickels")

            # if there is not enough coins tell user to see manager
            if paid_int != 0:
                print("See store manager for remaining fund.")
                dollars_manag = paid_int // 100
                cents_manag = paid_int - (dollars_manag * 100)
                if cents_manag == 0:
                    print(" ",dollars_manag, "dollars")
                elif dollars_manag == 0:
                    print(" ", cents_manag, "cents")
                else:
                    print(" ", dollars_manag, "dollars and ", cents_manag, "cents")
            break
        # checks for illegal input values
        else:
            print("Illegal selection: ", deposit_str)
            print()

        # Breaks a dollar (if there is one) to make sure there is not a
            # negative cent_owed value
        if cents_owed < 0 and dollars_owed >= 1:
            dollars_owed -= 1
            cents_owed += 100


    # calculates the change that is owed to the user if overpayed
    if price_int == 0:
        print()
    else:
        print("Please collect the following change: ")
        change_int = int(round(float(price_str)*100))
        change_owed = paid_int - change_int
        if change_owed == 0:
            print("No change due.")
        while change_owed >= 25 and quar_int > 0:
            change_owed -= 25
            quar_change += 1
            quar_int -= 1
        while change_owed > 5 and dime_int > 0:
            change_owed -= 10
            dime_change += 1
            dime_int -= 1
        while change_owed > 0 and nick_int > 0:
            change_owed -=5
            nick_change += 1
            nick_int -= 1
        if quar_change != 0:
            print(quar_change, " quarters")
        if dime_change != 0:
            print(dime_change, " dimes")
        if nick_change != 0:
            print(nick_change, " nickels")

        # if there isn't enough change tells user to see manager
        if change_owed != 0:
            print("See store manager for remaining fund.")

            # makes sure that the program doesn't print a word if it doesn't
                # need it
            if change_owed < 100:
                dollars_manag = change_owed // 100
                cents_manag = change_owed - (dollars_manag * 100)
                if cents_manag == 0:
                    print(dollars_manag, "dollars")
                elif dollars_manag == 0:
                    print(cents_manag, "cents")
                else:
                    print(dollars_manag, "dollars and ", cents_manag, "cents")

    # resets the amount paid value    
    paid_int = 0

    # reprints the stock once the transaction is over
    print()
    print("Stock contains:")
    print(nick_int, " nickels")
    print(dime_int, " dimes")
    print(quar_int, " quarters")
    print(ones_int, " ones")
    print(five_int, " fives")
    print()

    # prompts for another price_str value
    price_str = input("Enter the price (xx.xx) or 'q' to quit: ")


# Figures out the total that is left in the machine after all transactions are
    # complete
print("Total: ", end="")
total_nick = nick_int * 5
total_dime = dime_int * 10
total_quar = quar_int * 25
total_ones = ones_int * 100
total_five = five_int * 500
total_int = total_nick + total_dime + total_quar + total_ones + total_five
dollar_total = total_int // 100
cents_total = total_int - (dollar_total * 100)
if dollar_total == 0:
    print(cents_total, " cents")
elif cents_total == 0:
    print(dollar_total, " dollars")
else:
    print(dollar_total, " dollars and ", cents_total, " cents")
