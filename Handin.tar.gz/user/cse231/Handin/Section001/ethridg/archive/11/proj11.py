################################################
## CSE 231 SS13
## Project 11: Google API Tours
## ethridg
################################################

#The purpose of this project was to reinforce classes and their methods
#Additionally, the passing of lists/tuples through a method was emphasized
#This project also included raise error commands.

class Tour(object):
    """Define a class that utilizes Google Map API"""
    def __init__(self, *city):
        """Intialize the class, returns nothing"""
        self.city_list = list(city)
        
    def __str__(self):
        """Parses the list of cities used to construct the tour into a printable string, returns a string"""
        tour_str = ''
        for i in self.city_list:
            tour_str= tour_str + str(i) + '; ' #formating to make a neat list
        length = len(tour_str)
        tour_str = tour_str[0:length-2] #removing the  extra '; ' off the end
        return tour_str

    def __repr__(self):
        """Allows for the shell to represent the class object"""
        return self.__str__()

    def distance(self, mode='driving'):
        """Queries Google API and returns a total distance for the tour object"""
        import string #importing modules
        import urllib.request
        self.mode = str(mode) #intializing the mode
        length = len(self.city_list)
        connections = [] #intialize the counts/lists
        total_distance = 0
        for i in range(0,length-1): #creating a list of tuples of each (start,stop) or leg of the tour
            start = self.city_list[i]
            stop = self.city_list[i+1]
            connect_tuple = start, stop
            connections.append(connect_tuple)
        for i in connections: # using each tuple to query Google API
            directions = i
            start_list = directions[0]
            start = start_list.replace(' ', '+').replace(",", '') #proper formating for the URL
            stop_list = directions[1]
            stop = stop_list.replace(' ', '+').replace(",",'') #proper formating for the URL
            distance_query = 'http://maps.googleapis.com/maps/api/distancematrix/json?origins='+start+'&destinations='+stop+'&mode='+ self.mode +"&sensor=false"
            web_obj = urllib.request.urlopen(distance_query)
            results_str = str(web_obj.read())
            results_list = results_str.strip().split() # beginning of parsing of the web query into a list
            try: #try block for exception of no distance being able to be query
                index_distance = results_list.index('"distance"') #indentifying distance in list
                index_duration = results_list.index('"duration"') #identifying duration in list
                distance_list = results_list[index_distance:index_duration] #slicing to cut the list down
                index_value = distance_list.index('"value"') #further indexing to allow for more slicing
                value_list = distance_list[index_value:-1]
                distance = value_list[-1]
                connection_distance = ''
                for i in distance: #processing the str to remove all but digits
                    if i.isdigit():
                        connection_distance = connection_distance + i
                connection_distance = int(connection_distance) #converstion to int
                total_distance += connection_distance #add to total distance in tour
                web_obj.close()
        
            except ValueError: #raising the value error if "distance" cannot be found
                raise ValueError("One or more of the cities cannot be referenced.\nThe city may have been typed incorrectly!\nNo distance will exist then!")
        return total_distance #return a value for the method
            

    def __add__(self, other):
        """Allows for addition of two tours, returns the sum"""
        new_list = self.city_list + other.city_list
        new_list = list(new_list)
        sum_tour = Tour() #create sum tour
        sum_tour.city_list = new_list #rewrite empty city list to sum of two tours
        return sum_tour
    
    def __mul__(self, multiplier):
        """Allows for multiplication of a tour, simply concatenates the original tour as many times as the multiplier specifies"""
        if type(multiplier) is not int: #error checking for negative int/multiplier type
            raise TypeError("Multiplier is not an integer!")
        elif multiplier < 0:
            raise ValueError("Cannot multiply by a negative integer!")
        else:
            multiply_tour = Tour()
            mult_tour_list = []
            original_list = self.city_list
            mult_tour_list = list()
            for i in range(0,multiplier): # concatenates for multiplier
                for i in original_list:
                    mult_tour_list.append(i) #appends the original list on
            multiply_tour.city_list = mult_tour_list #rewriting empty city list with concatenated of the original
            return multiply_tour           
        
    def __rmul__(self,other):
        """Reverse multiplication if the multiplier is first"""
        return self.__mul__(other)
    
    def __eq__(self, other):
        """Checking to see if the tours are equivalent, in destinations and order, returns Boolean"""
        if self.city_list == other.city_list:
            return True
        else:
            return False
        
    def __gt__(self, other):
        """Checks if the first tour is greater in driving distance than the other"""
        if self.distance() > other.distance():
            return True
        else:
            return False
        
    def __lt__(self, other):
        """Checks if the first tour is shorter in driving distance than the other"""
        if self.distance() < other.distance():
            return True
        else:
            return False
        
def main():
    try:
        t1 = Tour("New York, NY", "Lansing, MI", "Sacramento, CA")#checking proper construction
        t2 = Tour("Oakland, CA")
        t3 = Tour("Sacramento, CA", "Oakland, CA")
        print("t1: {}\nt2:{}\nt3:{}".format(t1,t2,t3)) #checking __str__/__repr__
        print("t1 distances: driving-{} km; biking-{} km; walking-{} km".format(round(t1.distance()/1000), round(t1.distance('bicycling')/1000),round(t1.distance('walking')/1000)))
        print("Using driving distances from here on.")
        t4 = t1 + t2
        print("t4:", t4)#checking addition
        print("t4 driving distance:", round(t4.distance()/1000),"km")
        print("t4 == t1 + t2:", t4 == t1 + t2)  #checking equal
        t5 = Tour("Sacramento, CA", "Oakland, CA","Sacramento, CA", "Oakland, CA")
        print("t5:", t5)
        print("t6 = 2 * t3")
        t6 = 2 * t3 #checking multiplication/substitute -int or float to check errors
        print("t6:", t6)
        print(t5 == t6, "t5 = t6") #checking with equal for multiplication
        print("t1 < t2:", t1 < t2) #checking less than
        print("t1 > t2:", t1 > t2) #checking greater than
    except ValueError as err_msg:
        print(err_msg)
    except TypeError as err_msg:
        print(err_msg)

main()
