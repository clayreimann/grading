########################################################
## CSE231 (001) SS13
## Project 06: Data Mining Apple Stocks
## ethridg
########################################################

#The goal of this project is to gain more practice with file I/O, lists and functions, in order to understand the mutability of
#lists and the immutability of tuples



def get_file(): 
    file_error = True
    while file_error:
        try:
            file_name_str = input("What file would you like to open?:")
            file_obj = open(file_name_str, 'r')
            file_error = False
        except FileNotFoundError: # error checking for proper file name
            print("Bad file name, Please try again.")
            file_name_str = input("What file to try this time?")
    else:
        return file_obj #return obj to global variables

def get_data_list(file_obj, column_number):
    list_of_tuples = []
    for line in file_obj:
        try:
            line = line.strip()
            line_list = line.split(",")
            line_tuple = line_list[0], float(line_list[column_number])
            list_of_tuples.append(line_tuple) #creation of list of tuples to analyze the data
        except ValueError: #error checking for the first line which are just headings
            continue
    return list_of_tuples

def average_data(list_of_tuples):
    first_tuple = list_of_tuples[0]
    first_date_list = first_tuple[0].split('-')
    first_month = first_date_list[1] #setting the check variable for the month
    average_sum = 0.0 #intializing the count variables for sum and number of days summed
    days_this_month = 0.0
    avg_list_of_tuples = []
    for date_tuple in list_of_tuples:
        date_list = date_tuple[0].split('-')
        month = date_list[1]
        year = date_list[0]
        if month == first_month:
            average_sum = average_sum + date_tuple[1]
            days_this_month = days_this_month + 1.0
        else:
            average = average_sum/days_this_month
            averaged_month_year = '{}-{}'.format(first_month,year)
            avg_tuple = average, averaged_month_year
            avg_list_of_tuples.append(avg_tuple)
            first_month = month #restarting of values for the following month
            average_sum = date_tuple[1]
            days_this_month = 1.0
    
    average = average_sum/days_this_month #after the for loop completes, one last value is necessary to add
    averaged_month_year = '{}-{}'.format(first_month,year)
    avg_tuple = average, averaged_month_year
    avg_list_of_tuples.append(avg_tuple)
    return avg_list_of_tuples

def main():
    file_obj = get_file()
    column_number = int(input("What column?:"))
    list_of_tuples = get_data_list(file_obj, column_number)
    averages = average_data(list_of_tuples)
    sorted_averages = sorted(averages) #sorting the average list from lowest to highest
    length_of_final_list = len(sorted_averages)
    lowest_six = sorted_averages[0:6]
    highest_six = sorted_averages[length_of_final_list-6:length_of_final_list+1] #utilizing a for loop to minimize print statements
    print(" ")
    print("Lowest 6 values for column", column_number)
    for losing_values in lowest_six:
        losing_values = losing_values
        print("Date:",losing_values[1],"Value:",round(losing_values[0],2) )
    print(" ")
    print("Highest 6 values for column", column_number)
    for winning_values in highest_six:
        winning_values = winning_values
        print("Date:",winning_values[1],"Value:", round(winning_values[0],2) )
    file_obj.close() #close the file

main() #running of the main program
