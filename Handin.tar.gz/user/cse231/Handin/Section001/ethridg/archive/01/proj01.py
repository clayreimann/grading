###################################################
# Section 01 CSE 231
# Project #1: Richter Scale
# ethridg 100%
###################################################

richter_input=input("Please give me a Richter scale measure (1.0 - 10.0):")
richter_float=float(richter_input) #change input to float
num1=10**((1.5*richter_float)+4.8) #joule calculation from Richter measure
print('Richter measure:',richter_float)
print('Equivlance in joules:',num1)
print('Equivalence in Tons of TNT:',(num1/4.184e9)) #conversion to TNT tons
print('    ') #beginning of chart of predefined value chart
print('Richter','    ','Joules','                       ','TNT')
num2=1
richter2_float=float(num2)
num3=10**((1.5*richter2_float)+4.8)
num4=num3/4.184e9
print(num2,'       ', num3,'       ', num4)
num5=5
richter5_float=float(num5)
num6=10**((1.5*richter5_float)+4.8)
num7=num6/4.184e9
print(num5,'       ', num6,'       ', num7)
num8=9.1
richter8_float=float(num8)
num9=10**((1.5*richter8_float)+4.8)
num10=num9/4.184e9
print(num8,'     ', num9,'    ', num10)
num11=9.2
richter11_float=float(num11)
num12=10**((1.5*richter11_float)+4.8)
num13=num12/4.184e9
print(num11,'     ', num12,'    ', num13)
num14=9.5
richter14_float=float(num14)
num15=10**((1.5*richter14_float)+4.8)
num16=num15/4.184e9
print(num14,'     ', num15,'   ', num16)
 
