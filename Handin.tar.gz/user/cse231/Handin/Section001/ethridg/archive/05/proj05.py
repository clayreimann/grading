#############################################
# CSE 231 SS13
# Project 05: Tesselations
# ethridg
#############################################

## The purpose of this project is to understand the difference between global and local variables as well as passover.
## The project is also to expose the student to functions and greator iteration techniques.

import math
import time
import turtle

def menu_prompt(): #function to display color options
    print("""Choices for colors to draw a tesselation are:
    red
    blue
    yellow
    Or PRESS 'q' to quit!""")

def get_color_choice(): # function for color choice
    choice = input("Please enter your choice:")
    while choice != 'red' and choice != "blue" and choice != 'yellow': #error checking for the proper choice
        print("'",choice,"' is not a valid choice.")
        choice = input("Please try again:")
    return choice

def get_num_hexagons(): #function to get the # of hex
    number = input("Please enter a number of hexagons per row:")
    digits = '0123456789'
    for char in number:
        if char not in digits:#error checking for an integer or a string          
            print ("Please enter a valid integer")
            number = int(input("Please try again:"))
        if char in digits:
            number = int(number)
            while 4 > number or number > 20:
                print("It should be between 4 and 20.")
                number = int(input("Please try again:"))
        return number

def draw_hexagon(x,y,side_length,pen,color): #employing turtle to draw the hexagons
    pen.fillcolor(color)
    pen.setheading(0)
    pen.speed(10)
    pen.up()
    pen.goto(x, y)
    pen.down()
    pen.right(90)
    pen.begin_fill()
    for side in range(5):
        pen.forward(side_length)
        pen.right(60)
    pen.forward(side_length)
    pen.end_fill()


def draw_first_row(number, x_coord, y_coord, side_length, choice_1, choice_2): #code for first row
    for value in range(number):
        if value % 2 == 0:
            draw_hexagon(x_coord,y_coord,side_length,turtle, choice_1)
            x_coord+=2*side_length*(math.cos(math.pi/6)) # shifting the width of the hexagons over
        else:
            draw_hexagon(x_coord,y_coord, side_length, turtle, choice_2)
            x_coord+=2*side_length*(math.cos(math.pi/6))
            number -= 2
    x_coord += side_length*math.cos(math.pi/6) #shifting the starting point for the next row
    y_coord -= (side_length + side_length*math.sin(math.pi/6))
    
def draw_second_row(number, x_coord, y_coord, side_length, choice_1, choice_2): #code for second row
    for value in range(number):
        if value % 2 ==0:
            draw_hexagon(x_coord,y_coord,side_length,turtle, choice_2)
            x_coord += 2*side_length*(math.cos(math.pi/6))
        else:
            draw_hexagon(x_coord, y_coord, side_length, turtle, choice_1)
            x_coord += 2*side_length*(math.cos(math.pi/6))
    x_coord += (side_length*(math.cos(math.pi/6))) #shifting starting point for next row
    y_coord -= (side_length + side_length*(math.cos(math.pi/6)))

def draw_tesselation(number, choice_1, choice_2): #compiling the rows together
    count = 0
    x_coord = -250
    y_coord = 250
    d = 500/number
    side_length = (d/(2*math.cos(math.pi/3)))
    while count < number:
        if count % 2 == 0: #while loop to produce correct amount of rows
            draw_first_row(number, x_coord, y_coord, side_length, choice_1, choice_2)
            count += 1
            x_coord -= side_length*math.cos(math.pi/6)
            y_coord -= (side_length + side_length*math.sin(math.pi/6))
        else:
            draw_second_row(number, x_coord, y_coord, side_length, choice_1, choice_2)
            count += 1
            x_coord += side_length*math.cos(math.pi/6)
            y_coord -= (side_length + side_length*math.sin(math.pi/6))

def complete_tessellation_program(): #pulling the individual functions together to ensure no global variables
    menu_prompt()
    choice_1 = get_color_choice()
    choice_2 = get_color_choice()
    number = get_num_hexagons()
    draw_tesselation(number, choice_1, choice_2)
    time.sleep(5)
    turtle.bye()

complete_tessellation_program() #run the program
    
