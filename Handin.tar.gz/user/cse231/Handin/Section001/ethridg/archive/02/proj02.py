####################################################################
# CSE 231 Section 001 SS13
# Project #2: SLAYER GAME
# ethridg
###################################################################

#The purpose of this program is to demonstrate understanding of
#integer operations using the // and % operations to extract the digits of "SLAYER"
#Using "if/else" you can check if the user is correct in their guess
#Additionally a chained expression can check for a 6-digit number

print("Guess a six-digit number SLAYER so that following equation is true,")
print("where each letter stands for the digit in the position shown:")
print(" ")
print("SLAYER + SLAYER + SLAYER = LAYERS")
print(" ")
print(" ")
slayer = int(input("Enter your guess for SLAYER:"))
r_ones = (slayer%10)                      # digit in the ones for r
e_tens = (slayer//10)%10                  # digit in the tens for e
y_hundreds = (slayer//100)%10             # digit in the hundres for y
a_thousands = (slayer//1000)%10           # digit in the thousands for a
l_ten_thousands = (slayer//10000)%10      # digit in the ten thousands for l
s_hundred_thousands = (slayer//100000)%10 # digit in the hundred thousands for s

slayer_summed_thrice = 3*slayer
layers =(100000*l_ten_thousands)+\
        (10000*a_thousands)+(1000*y_hundreds)+\
        (100*e_tens)+\
        (10*r_ones)+\
        (s_hundred_thousands)
# reforming layers from slayer digits
print(" ")

if 999999 >= slayer >= 100000: #error checking for 6 digit number
    if slayer_summed_thrice != layers: # result for incorrect guess
        print("Your guess is incorrect:")
        print("SLAYER + SLAYER + SLAYER = ", slayer_summed_thrice)
        print("LAYERS = ", layers)
        print("Thanks for playing.")
    else:
        print("Your guess is correct:")
        print("SLAYER + SLAYER + SLAYER = ", slayer_summed_thrice)
        print("LAYERS = ", layers)
        print("Thanks for playing.")
else:
    print ("Your guess is incorrect:")
    print ("SLAYER must be a 6-digit number.")
    print ("Thanks for playing.")
