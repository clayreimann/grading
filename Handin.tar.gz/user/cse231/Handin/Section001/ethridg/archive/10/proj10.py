############################################################################
## CSE231: SS13
## Project 10: Flag Drawing
## ethridg
############################################################################

# The purpose of this project is to read a spec file of a flag to draw,
# import the turtle and time modules, create various classes,
# and then drawing the flag and illustrate a few class techniques and methods.

# For TA: I have commented out the lines in the main program to only draw the myFlag.txt file that I will also turn in.
# Please uncomment out the portions for the senegal and panama flag, if you have the files in the same directory to test them as well


class star(object):
    """Defining the star class, necessary to draw the flag"""
    def __init__(self, x, y, arm_length, color):
        """Intialize the star object.
           Requires, 4 parameters, x (int), y (int), arm_length (int) and color (str)"""
        self.x = x #storing paramters as self.parameters to be passed to other methods
        self.y = y
        self.arm_length = arm_length
        self.color = color
    
    def __str__(self):
        """ Returns the following str 'Star: x:int, y:int, arm:int, color:str'"""
        x_str = self.x
        y_str = self.y
        arm_length = self.arm_length
        color = self.color
        rectangle_str = 'Star x:{}, y:{}, arm length:{}, color:{}'.format(x_str,y_str,arm_length,color) #format of return string for star
        return rectangle_str

    def draw(self, pen):
        """ Draws star centered at given x,y coordinates, returns nothing."""
        pen.fillcolor(self.color) #setting the fill color as specified
        pen.setheading(0)
        pen.speed('fastest')
        start_x = self.x + (self.arm_length/4) #moving pen to correct start location
        start_y = self.y + (self.arm_length/4)
        pen.goto(start_x, start_y)
        pen.down() #pen down to begin drawing
        pen.begin_fill() 
        pen.forward(self.arm_length) #moves forward specified arm_length
        pen.right(144)
        pen.forward(self.arm_length)
        for i in range(0,4): # for loop to draw each of the remaining four points of the start
            pen.right(180) #reverse pen
            pen.right(108) #turning pen
            pen.forward(self.arm_length) #begins next point
            pen.right(144)
            pen.forward(self.arm_length) #finishes next point
        pen.end_fill() #stops fill
        pen.up() 

class rectangle(object):
    """Defining the rectangle class for drawing a flag"""
    def __init__(self, x, y, width, height, color):
        """Initializes the rectangle object.
           Requires x(int), y (int), width (int), height (int), and color (str)"""
        self.x = x #passing parameters to self.variable
        self.y = y
        self.width = width
        self.height = height
        self.color = color

    def __str__(self):
        """Updates object to be printable as a string in the following format,
           'Rectangle x:100, y:200, width:300, height:300, color:blue'"""
        x_str = self.x
        y_str = self.y
        width = self.width
        height = self.height
        color = self.color
        rectangle_str = 'Rectangle x:{}, y:{}, width:{}, height:{}, color:{}'.format(x_str,y_str,width,height,color)
        return rectangle_str
    
    def draw(self, pen):
        """Draws a rectangle centered at given x,y coordinates, returns nothing."""
        pen.fillcolor(self.color)
        pen.setheading(0)
        pen.speed(10)
        start_x = self.x - (self.width/2) #moves to top left corner of rectangle
        start_y = self.y + (self.height/2)
        pen.goto(start_x, start_y) #moves to correct start
        pen.down()
        pen.begin_fill()
        pen.forward(self.width) #right width
        pen.right(90) #turn
        pen.forward(self.height) #down hieght
        pen.right(90) #turn
        pen.forward(self.width) #left width
        pen.right(90) #turn
        pen.forward(self.height) #up height
        pen.end_fill()
        pen.up()
    
class flag(object):
    """Defining the flag object to be used for flag drawing"""
    def __init__(self, file_object):
        """Initializes the flag object, using an opened file of specified format,
           Reads the file one line at a time, compiling a list of component objects of the flag"""
        self.file_object = file_object
        pieces_list = [] #intializing lists
        rectangle_list = []
        star_list = []
        rectangle_count = int(self.file_object.readline().strip()) #grabbing the rectangle count from file
        for i in range(0,rectangle_count): #reading through each rectangle line, in count range
            line_list = self.file_object.readline().strip().split(',') #split, strip, readline, to get parameters
            x_value = int(line_list[0]) #assigning paramters
            y_value = int(line_list[1])
            width_value = int(line_list[2])
            height_value = int(line_list[3])
            color_value = line_list[4].strip()
            new_rectangle = rectangle(x_value, y_value, width_value, height_value, color_value) #creating rectangle obj
            pieces_list.append(new_rectangle)#adding to lists
            rectangle_list.append(new_rectangle)
        star_count = int(self.file_object.readline().strip()) #grabbing start count
        for i in range(0, star_count): #running through the lines that should create star information
            line_list = self.file_object.readline().strip().split(',') #splitting each line to grab parameters
            x_value = int(line_list[0])
            y_value = int(line_list[1])
            arm_length_value = int(line_list[2])
            color_value = line_list[3].strip()
            new_star = star(x_value, y_value, arm_length_value, color_value) #creating star objects
            pieces_list.append(new_star)
            star_list.append(new_star)
        self.rectangles = rectangle_list #adding lists to the self.parameter to pass to __str__ and .draw()
        self.star = star_list
        self.pieces = pieces_list
        self.r_count = rectangle_count
        self.s_count = star_count
    
    def __str__(self):
        """Returns a string of the flag object Iteration through the list of rectangles
           and list of stars to create a str of the flag obj"""
        flag_str = "Rectangles \n"
        for i in self.rectangles: #using rectangle list to piece each rectangle str to total flag str
            flag_str = flag_str + str(i) + '\n'
        flag_str = flag_str + '\nStars\n'
        for i in self.star: #iterating start list to piece star str to total flag_str
            flag_str = flag_str + str(i) + '\n'
        return flag_str

    def draw(self, pen):
        """Method to draw the flag object, returns nothing."""
        for i in self.pieces: #iterating through each object to draw each object
            i.draw(pen)

def main():
    """Runs the main program, importing time and turtle modules, opening each flag spec file,
       and then drawing each flag, printing flag obj as a string, and then closing the file."""
    
    import turtle #importing necessary modules
    import time
    pen = turtle.Turtle() #setting turtle settings
    pen.speed('fastest')
    
# Comment for TA: Please feel free to uncomment out the next two portions to test the program on the flag specs provided for the project

##    turtle.clearscreen()
##    senegal_file = open('senegal.txt')
##    senegal_flag = flag(senegal_file)
##    print("Information for Senegal Flag")
##    print(senegal_flag)
##    senegal_flag.draw(pen)
##    senegal_file.close()
##
##    time.sleep(4)   # delay so you can see your flag
##    turtle.clearscreen()
##    panama_file = open('panama.txt')
##    panama_flag = flag(panama_file)
##    print("Information for Panama Flag")
##    print(panama_flag)
##    panama_flag.draw(pen)
##    panama_file.close()
##    time.sleep(4)   # delay so you can see your flag
    
    turtle.clearscreen()
    alaska_file = open('myFlag.txt')
    alaska_flag = flag(alaska_file)
    print("Information for Alaskan Flag")
    print(alaska_flag)
    alaska_flag.draw(pen)
    alaska_file.close()
    
main() #running of main program
