#####################################################################
## CSE 231: SS13 
## Project 08: Word Completion
## ethridg
#####################################################################

def fill_completions(c_dict, file_obj):
    """This function takes a blank completions library and an opened file.
       Returns: Nothing
       Fills in the completion dictionary"""
    import string #import module for string.punctuation
    for line in file_obj: #file formating/processing
        line = line.strip()
        word_list = line.split()
        for word in word_list:
            word = word.lower()
            word = word.strip(string.punctuation) #removing punctuation
            if word.isalpha():
                for char in enumerate(word): #creating a tuple of (index, "letter")
                    key_tuple = char
                    if key_tuple in c_dict: #checking if in c_dict, to speed up processing
                        c_dict[key_tuple].add(word)
                    else:
                        c_dict[key_tuple] = {word} #creating new key-value pair
            else:
                continue    
    
def find_completions(prefix, c_dict):
    """ Input: Prefix and completions dictionary
        Returns: Set of vocabulary words in the completions dictionary
                If None exist, returns the empty set.
                Returns a  set of strings (str) """
    import string
    prefix = prefix.lower()
    prefix = prefix.strip(string.punctuation) #refortating of the string
    completion_keys = list()
    for prefix_key in enumerate(prefix):
        completion_keys.append(prefix_key)
    completions = c_dict[completion_keys[0]] #initializing set to equal first c_dict[first key]
    for key in completion_keys:
        completions = completions & c_dict[key] #checking the intersection, using iteration to run through the keys
    return completions
    
def main():
    """Open a file to prepare a completion dictionary from
       Call fill_completions to fill out completions dictionary
       Repeatedly prompts user for prefix or '#' to quit.
       Prints a set of words that can complete each prefix, or None Exists"""
    #completions_file_str = input("What txt file would you like to reference for the completion dictionary?:")
    completions_file_str = 'ap_docs.txt' #change to input for other file
    file_error = True
    while file_error: #continuous prompting for a file in the proj directory
        try:
            completions_file_obj = open(completions_file_str, 'r')
            file_error = False
        except IOError: # error checking for proper file name
            print("Bad file name, Please try again.")
            completions_file_str = input("What file name to try this time?")

    c_dict = dict()
    fill_completions(c_dict, completions_file_obj)
    completions_file_obj.close()

    #continuous prompting using a while loop, and while not equal to quit character
    prefix = input("What prefix would you like to complete?: (# to quit) ")
    while prefix != '#':
        if prefix.isalpha():
            completions = find_completions(prefix, c_dict)
            if completions == set(): #print no match if empty set
                print("No matches found.")
            else:
                print(completions)
            prefix = input("What prefix would you like to complete?: (# to quit) ") #reprompt
            
        elif prefix == '' or prefix == " ": #error check for hitting enter or empty space
            print("No completions found.")
            prefix = input("What prefix would you like to complete?: (# to quit) ")
        else:
            print("No completions found.")
            prefix = input("What prefix would you like to complete?: (# to quit) ")

main() #running of main program
    
