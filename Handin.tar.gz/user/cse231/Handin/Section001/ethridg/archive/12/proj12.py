#########################
##  CSE 231 SS13
##  Honors Project #12
##  ethridg
#########################

"""This program is the introduction to matplotlib and numpy
It will save two figures of specific requirements in the working directory
A line graph and a bar graph"""

def average_month_high_lows(obj):
    """Takes file_obj of a text file, returns list of tuples i.e. (month, min_avg, max_avg)"""
    first_day = '1'
    first_month = '1'
    day_values = [] #intialize list
    month_max = []
    month_min = []
    year_month_data_list = []
    for line in obj:
        line_list = line.strip().split() #file processing
        if line_list[0].isdigit(): #skip first line
            month = line_list[0]
            day = line_list[1]
            year = line_list[2]
            if day == first_day:
                day_values.append(float(line_list[4]))
            else:
                day_max = max(day_values) #when changes to a new day
                day_min = min(day_values)
                month_max.append(day_max)
                month_min.append(day_min)
                day_values = [float(line_list[4])]
                first_day = day #reitialize to next day
                if month == first_month:
                    continue
                else:
                    month_max_count = len(month_max) #when changes to a new month
                    month_min_count = len(month_min)
                    month_max_sum = 0
                    month_min_sum = 0
                    for i in month_max:
                        month_max_sum += i
                    for i in month_min:
                        month_min_sum += i
                    month_min_avg = month_min_sum/month_min_count
                    month_max_avg = month_max_sum/month_max_count
                    month_str = '{}-{}'.format(first_month,year)
                    month_tuple = month_str, month_min_avg, month_max_avg
                    year_month_data_list.append(month_tuple)
                    month_max = [day_max]
                    month_min = [day_min]
                    first_month = month #reinitialize to next day
        else:
            continue
    month_max_count = len(month_max)
    month_min_count = len(month_min)
    month_max_sum = 0
    month_min_sum = 0
    for i in month_max:
        month_max_sum += i
    for i in month_min:
        month_min_sum += i
    month_min_avg = month_min_sum/month_min_count #making average
    month_max_avg = month_max_sum/month_max_count
    month_str = '{}-{}'.format(first_month,year)
    month_tuple = month_str, month_min_avg, month_max_avg
    year_month_data_list.append(month_tuple)
    
    return year_month_data_list

def average_data_by_hour(obj):
    """Takes file obj, returns list of tuples (hour, hour_avg of data)"""
    hour_dict = dict()
    for line in obj:
        line_list = line.strip().split()
        if line_list[0] == '6': #change for specific month
            month = line_list[0]
            day = line_list[1]
            year = line_list[2]
            hour = line_list[3]
            value = float(line_list[4])
            if hour in hour_dict: #dictionary of all hour values
                hour_dict[hour].append(value)
            else:
                hour_dict[hour] = [value]
    average_value_hour_list = []
    for hour in hour_dict:
        data = hour_dict[hour]
        hour_sum = 0
        n_count = len(data)
        for i in data:
            hour_sum += i
        hour_avg = hour_sum/n_count #creating avg for each hour
        hour_tuple = int(hour)/100, hour_avg
        average_value_hour_list.append(hour_tuple)
    return average_value_hour_list
            
def temperature_figure():
    """Creates figure using matplotlib and numpy (bar graph)"""
    import numpy as np
    import matplotlib.pyplot as plt
    temp_obj = open("temperature.txt", 'r')
    temp_data = average_month_high_lows(temp_obj) #function for data
    temp_obj.close()
    high_temperature = []
    low_temperature = []
    for i in temp_data:
        low_temperature.append(i[1])
        high_temperature.append(i[2]-i[1])
    N = 12 #set for months
    ind = np.arange(N)  # the x locations for the groups
    width = 0.50       # the width of the bars
    fig = plt.figure() #create figure instance
    ax = fig.add_subplot(111)
    rect = ax.bar(ind+(width/2), high_temperature, width, color='blue', bottom = low_temperature) #plot rect
    ax.set_title('Charleston, MO - 2012')
    ax.set_ylabel('Average Temperature') #axis formating
    ax.set_ylim(20,100)
    ax.set_xlabel('Month')
    ax.set_xticks(ind+width)
    ax.set_xticklabels( ('January', 'February', 'March', 'April', \
    'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December') ) #labeling ticks
    ax.set_yticks(range(20,120,20))
    ax.set_yticklabels(('20', '40', '60', '80', '100', '120', '140', '160', '180'))
    plt.xticks(rotation=45)
    plt.savefig('temp.png') #file save

def temp_rad_line_graph():
    """Creates a line graph with two sets of data using matplotlib/numpy"""
    rad_obj = open("solar_radition.txt", 'r')
    radiation_data = average_data_by_hour(rad_obj)
    radiation_data.sort() #sort data by the hour

    rad_obj.close()
    temp_obj = open('temperature.txt', 'r')
    temperature_data = average_data_by_hour(temp_obj)
    temperature_data.sort()

    avg_rad_list = []
    avg_temp_list = [] #organize to just get the y-values for the plot
    for i in temperature_data:
        avg_temp_list.append(i[1])
    for i in radiation_data:
        avg_rad_list.append(i[1])

    import numpy as np
    import matplotlib.pyplot as plt
    N = 24
    ind = np.arange(N)
    fig = plt.figure()
    ax_temp = fig.add_subplot(111)
    ax_temp.set_title('Charleston, MO -  June 2012')
    ax_temp.set_ylabel("Average Temperature", color='blue')
    ax_temp.set_xlabel("Hour")
    ax_temp.set_xticks(range(0,30,5)) #set tick range
    ax_temp.set_ylim(65,90) #set limits
    ax_temp.set_xticklabels(('0','5','10','15','20','25')) #setting labels
    ax_temp.set_yticks(range(65,95,5))
    for tl in ax_temp.get_yticklabels():
        tl.set_color('b') #coloring to match the axis title
    ax_temp.plot(ind, avg_temp_list, 'b-')

    #use twinx() method to copy x values
    ax_rad = ax_temp.twinx()
    ax_rad.set_ylabel("Average Solar Radiation", color='red')
    ax_rad.set_yticks(range(0,900,100))
    ax_rad.set_ylim(0,800)
    for tl in ax_rad.get_yticklabels():
        tl.set_color('r')
    ax_rad.plot(ind, avg_rad_list, 'r-')
    plt.savefig('radtemp.png') #save figure
    
    
    
    
def main():
    """Main function, calls both figure production functions"""
    
    temperature_figure()
    temp_rad_line_graph()

    

main()
    
