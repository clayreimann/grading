################################################################################
## CSE231 SS13
## Project 07: Word/Text Scramble
## ethridg
###############################################################################

"""Program overview:
     Prompts for the name of a file of English text to read in and a file to write out your results
     Constant prompting required for the file to be read.
     Reads each line of the file
     Performs the scrambling on each word of the file
     Outputs the scrambled line to output file. """


def scramble_word(word_str):
    """This function takes in a single word
       from the file and returns a scrambled word.
       The first and last letter are preserved in the original positions.
       Do not shuffle something of length 3 or less
       Preserve the punctuation of the word
       Returns a string"""
    import random #import this module to randomize inside of the words
    import string #import for punctuation and digit lists to check the words
    
    try: #checking if the word isolated is an integer, if not it will trigger the exception and will run the conversion
        word_final = int(word_str)
        return str(word_final) #conversion of number to str to allow for it to be added to the line
    except ValueError:
        word_str_list = list(word_str)
        punctuation_list = list(string.punctuation) #list to chk if punctuation
        digit_list = list(string.digits) #list to chk if digit
        position = 0 #intialize the following three variables
        punctuation_in_word_list = []
        number = []
        word_to_shuffle = []
        for item in word_str_list:
            if item in punctuation_list: #chk if punctuation
                punctuation = [position, item] # creates list that has punct, and index information
                punctuation_in_word_list.append(punctuation) #embedds this list within a master list of punct
                position += 1
            elif item in digit_list:
                number += item 
            else:
                word_to_shuffle += list(item) #if a letter this creates word to shuffle
                position += 1
                  
        length = len(word_to_shuffle)

        if length > 3: #if greater than 3, this shuffles the word, breaks word into first, last, and middle contents
            word_first_letter = list(word_to_shuffle[0])
            word_middle_letters = list(word_to_shuffle[1:length-1])
            word_last_letter = list(word_to_shuffle[length-1])
            random.shuffle(word_middle_letters) #only shuffles middle 'inner' bit of the word
            shuffled_word_list = word_first_letter + word_middle_letters + word_last_letter
            word_final_list = shuffled_word_list
            for punctuation_to_insert in punctuation_in_word_list: #loop for insert the stored punctuation information
                word_final_list.insert(int(punctuation_to_insert[0]), punctuation_to_insert[1])
            word_final = ''.join(word_final_list)
            return word_final

        else:
            word_final_list = word_to_shuffle
            for punctuation_to_insert in punctuation_in_word_list:
                word_final_list.insert(int(punctuation_to_insert[0]), punctuation_to_insert[1])
            word_final = ''.join(word_final_list)
            return word_final

def scramble_line(line_str):
    """This function recieves a entire line of text and returns a new line (str)
       with each word scrambled using scramble_word()."""
    line_str = line_str.strip() #clean the line
    line_list = line_str.split(" ")
    new_line_list = []
    for word_str in line_list: # iterates through the words of each line of the test
        word = scramble_word(word_str)
        new_line_list.append(word) #add word to the list of the new_line
    new_line_string = ' '.join(new_line_list)
    return new_line_string

def open_read_file(file_name_str): #reading of the file
    """Takes a file string, the name of a file to be opened for reading.
       Reprompts until it can open a file
       Returns a file object"""
    file_error = True
    while file_error: #continuous prompting for a file in the proj directory
        try:
            file_obj = open(file_name_str, 'r')
            file_error = False
        except FileNotFoundError: # error checking for proper file name
            print("Bad file name, Please try again.")
            file_name_str = input("What file name to try this time?")
    else:
        return file_obj #return obj to global variables

def main():
    """Prompts for file to write
       Prompts for file to read, calls open_read_file
       Using file_obj returned from open_read_file
          for each line in the file:
              gets scrambled line by calling scramble_line
              writes the scrambled line to the output file_obj """
    file_inputname_str = input("What file would you like to scramble?:") #prompt for intial file
    read_file_obj = open_read_file(file_inputname_str)
    file_outputname_str = input("What file would you like to write to?:") #prompt for output file
    write_file_obj = open(file_outputname_str, 'w')
    for line_str in read_file_obj: #iterates of the opened text file
        write_file_obj.write(scramble_line(line_str)) #writes to the new obj, the scrambled lines
    read_file_obj.close()
    write_file_obj.close() #close the objs
    print("Well done, you've utilized the 'Cambridge Effect'!")
    print("Please check your directory for the new file entitled", file_outputname_str)
    
main() #running of the program
