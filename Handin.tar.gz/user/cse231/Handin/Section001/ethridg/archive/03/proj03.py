#########################
# CSE 231 Project 03: Vending Machine
# ethridg
############################

#The purpose of this project is to utilize while loops and if statements.


#define stock variables
stock_nickels = 25
stock_dimes = 25
stock_quarters = 25
ones = 0
fives = 0
#intializing the stock
print("Welcome to the vending machine change maker program")
print("Change maker initialized.")
print("Stock contains:")
print("   ", stock_nickels, "nickels")
print("   ", stock_dimes, "dimes")
print("   ", stock_quarters, "quarters")
print("   ", ones, "ones")
print("   ", fives, "fives")
print(" ")
price_str = input("Enter the purchase price (xx.xx) or 'q' to quit:")
#prompting for a price to vend within the machine
while price_str != 'q': #
    price_float = float(price_str)
    print("Purchase price is:", price_float)
    if price_float > 0 and (price_float*100)%5==0: #checking for positive and divisible by 5       
        print("""
Menu for deposits: 
'n' - deposit a nickel 
'd' - deposit a dime 
'q' - deposit a quarters
'o' - deposit a one dollar bill
'f' - deposit a five dollar bill
'c' - cancel the purchase
                """) #menu for the deposit options
        payment_due = int(price_float*100)
        total_price = int((price_float*100)) #calculating the amt due in cents
        dollars_due = payment_due//100 #formatting for Payment Due 'print'
        cents_due = payment_due%100

        print("Payment due:", dollars_due , "dollars and", cents_due, "cents")
        
        deposit_str = input("Indicate your deposit:")
        amt_paid = 0
        while deposit_str != 'c' and amt_paid < total_price: # amt_paid < total_price was intended to go false using the counter variable amt_paid

            # the following if would have been copied to some degree for each of the deposit menu options    
            if (deposit_str == 'n'): #if user denotes putting in a nickel
                payment_due -= 5
                amt_paid += 5
                stock_nickels += 1
                dollars_due = payment_due//100
                cents_due = payment_due%100
                if amt_paid > total_price: # was attempting to use this as the switch for change being dispensed
                    change = amt_paid - total_price # used this to calculate change but it wasn't working
                    q_change = change//25
                    d_change = ((change - (q_change*25))//10)
                    n_change = ((change - ((q_change*25) + (d_change*10)))//5)
                    if change > 0:
                        print("Please take the change below.")
                        if q_change > 0:
                            stock_quarters -= q_change
                            print("   ", q_change, "quarters")
                        if d_change > 0:
                            stock_dimes -= d_change
                            print("   ", d_change, "dimes")
                        if n_change > 0:
                            stock_nickels -= n_change
                            print("   ", n_change, "nickels")
                else: # was hoping to use this to reprompt the user again to insert more money if that did not go over
                    print("Payment due:", dollars_due , "dollars and", cents_due, "cents")
                    deposit_str = input("Indicate your deposit:")

            elif (deposit_str == 'c'):
                print ("Please collect your deposit in the change available from the vending machine.")
        
            else: # if the user input a string that was not of the menu, reprompting for another input
                print("Illegal Selection:", deposit_str)
                print(" Payment due:", int(payment_due/100), "dollars and", int(payment_due%100), "cents")
                deposit_str = input("Indicate your deposit:")
        #else: this else would be also be used to deal with change if the while loop were turned off but I could not seem to get the formatting correct
            
           
    else: #error message if price input is illformatted
        print("Illegal price: Must be a non-negative multiple of 5 cents.")
        print(" ")
        price_str = input("Enter the purchase price (xx.xx) or 'q' to quit:")

