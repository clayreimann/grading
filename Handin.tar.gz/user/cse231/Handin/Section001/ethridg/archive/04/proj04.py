######################################################
##   CSE 231 Section 001
##   Project 4: Sequence Alignment
##   ethridg
######################################################

#prompt two strings
#should be ATG or C, same length isn't necessary
#prompt for three commands, use a while command != q
#"a" for add
    #which string using an "if"
    #at what index do you wish to place indel (placement is before given index)
    #use slicing techiniques to swap out the character, maybe dna[:#given] + dna[#given:]
    #Error if the index is not within the range
#"d" for delete
    #same type of slicing and if commands as the add indel
    #check if the character is an indel "-" or not, reprompt if it isn't
#"s" for score
    #potentially use a for command to compare the two strings
    #any indel is automatically a mismatch
    #fill shorter string with indels? (First step in the scoring process?)
    #score the amount of matching. (Look into the lecture)
    # matching = lowercase, mismatching = upper case
    #an indel is a dash
# q, will cause the while loop to be done

print("Please provide two sequences of DNA to align and compare base pairs.") #description of input
dna_strand_1 = input("Sequence of strand one:")
dna_strand_2 = input("Sequence of strand two:")
command = input("""What would you like to do to the sequenences? 
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""") #intializing of the commands
while command != 'q': #loop to repeat the commands until q is enter
    if command == 'a': #addition of indel
        sequence_choice = input("Add an indel to which sequence?")
        if sequence_choice == '1':
            index_after = int(input("Before what index?"))
            if index_after < int(len(dna_strand_1)):
                dna_strand_1 = dna_strand_1[:index_after] + "-" + dna_strand_1[index_after:] #slicing to allow addition of indel, same as for strand 2
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
            else:
                print("Index is not within range.") #error checking for making sure that the index is not greater than the string
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
                
        if sequence_choice == '2':
            index_after = int(input("Before what index?"))
            if index_after < int(len(dna_strand_2)):
                dna_strand_2 = dna_strand_2[:index_after] + "-" + dna_strand_2[index_after:]
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
            else:
                print("Index is not within range.")
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
        
    if command == 'r': #removal of indel
        sequence_choice = input("Remove an indel from which sequence?")
        if sequence_choice == '1':
            index_removed = int(input("Remove what index?"))
            character_selected = dna_strand_1[index_removed]
            indel = '-' #defining the string indel
            if character_selected in indel: #check if index chosen is an indel
                dna_strand_1 = dna_strand_1[:index_removed] + dna_strand_1[(index_removed+1):] 
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
            else: #Error checking for removal of a non-indel
                print("Error! You cannot removed a non-indel character.")
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
        if sequence_choice == '2':
            index_removed = int(input("Remove what index?"))
            character_selected = dna_strand_2[index_removed]
            indel = '-'
            if character_selected in indel:
                dna_strand_2 = dna_strand_2[:index_removed] + dna_strand_2[(index_removed+1):]
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
            else:
                print("Error! You cannot removed a non-indel character.")
                print(" ")
                print("Strand one sequence:", dna_strand_1)
                print("Strand two sequence:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
                
    if command == 's': #scoring command portion
        if len(dna_strand_1) != len(dna_strand_2): #code for adjustment of dna_strands by adding indels to the end by finding difference in length
            indel = '-'
            if len(dna_strand_1) < len(dna_strand_2):
                indel_add = len(dna_strand_2) - len(dna_strand_1)
                dna_strand_1 = dna_strand_1 + indel * indel_add
            if len(dna_strand_2) < len(dna_strand_1):
                indel_add = len(dna_strand_1) - len(dna_strand_2)
                dna_strand_2 = dna_strand_2 + indel * indel_add
        if len(dna_strand_1) == len(dna_strand_2): #once the strands are the same length now indices can be compared
            check = 0
            match = 0
            mismatch = 0
            while check < int(len(dna_strand_1)):
                if dna_strand_1[check] == dna_strand_2[check]: #if matches between strings
                    dna_strand_1 = dna_strand_1[:check] + dna_strand_1[check].lower() + dna_strand_1[check+1:]
                    dna_strand_2 = dna_strand_2[:check] + dna_strand_2[check].lower() + dna_strand_2[check+1:]
                    check += 1
                    match += 1
                elif dna_strand_1[check] != dna_strand_2[check]: #if index does not match between strings
                    dna_strand_1 = dna_strand_1[:check] + dna_strand_1[check].upper() + dna_strand_1[check+1:]
                    dna_strand_2 = dna_strand_2[:check] + dna_strand_2[check].upper() + dna_strand_2[check+1:] 
                    check += 1
                    mismatch += 1
            else: #print the results
                print(" ")
                print("Matches:", match," Mismatches:", mismatch)
                print("Strand one sequence adjusted:", dna_strand_1)
                print("Strand two sequence adjusted:", dna_strand_2)
                print(" ")
                command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
    else: #error checking for a proper command from the list
        print("You entered an incorrect command. Please try again!")
        command = input("""What would you like to do to the sequenences?
    a (add insertion/deletion)
    r (remove insertion/deletion)
    s (score their likeness)
    q (quit):""")
else: #result if q is pressed
    print("Thank you for using the AlleleAnalyzer2000!")
  
            
    
